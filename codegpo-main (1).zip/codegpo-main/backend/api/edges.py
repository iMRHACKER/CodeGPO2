from fastapi import APIRouter, Depends
from models.edge import Edge
from services.graph_service import add_edge
from auth.auth import get_current_user

router = APIRouter()

@router.post("/edges")
def create_edge(edge: Edge, current_user: dict = Depends(get_current_user)):
    add_edge(edge, org_id=current_user["org_id"])
    return {"status": "ok"}
