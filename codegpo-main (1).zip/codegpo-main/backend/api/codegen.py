from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import Optional
from services.codegen_service import generate_and_govern
from auth.auth import get_current_user

router = APIRouter()

class CodeGenRequest(BaseModel):
    requirement: str
    language: str = "python"
    provider: str = "groq"  # groq or gemini
    architecture_context: Optional[dict] = None  # nodes + edges from graph

@router.post("/codegen/generate")
async def codegen_generate(req: CodeGenRequest, current_user: dict = Depends(get_current_user)):
    """Auth required — this calls a paid LLM API, so it must not be open to anonymous callers."""
    return await generate_and_govern(
        requirement=req.requirement,
        language=req.language,
        provider=req.provider,
        architecture_context=req.architecture_context
    )
