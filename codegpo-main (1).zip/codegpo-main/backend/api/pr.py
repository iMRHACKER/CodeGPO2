"""
CodeGPO Auto PR API
────────────────────
Token priority:
  1. X-GitHub-Token header (user's own PAT from browser localStorage)
  2. GITHUB_TOKEN in .env (server default / demo mode)
"""

import os
from fastapi import APIRouter, HTTPException, Request, Header, Depends
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from services.pr_service import create_schema_pr, preview_pr, sync_architecture_json
from auth.auth import get_current_user

router = APIRouter()


class PRRequest(BaseModel):
    nodes: List[Dict[str, Any]]
    edges: List[Dict[str, Any]]
    title: Optional[str] = None
    targetBranch: Optional[str] = None
    # User-supplied GitHub config (from browser localStorage)
    githubToken: Optional[str] = None
    githubOwner: Optional[str] = None
    githubRepo:  Optional[str] = None


def resolve_github_config(req: PRRequest) -> Dict[str, str]:
    """
    Merge user-supplied config with .env fallback.
    User's own PAT always wins over the server default.
    """
    token = req.githubToken or os.getenv("GITHUB_TOKEN", "")
    owner = req.githubOwner or os.getenv("GITHUB_OWNER", "")
    repo  = req.githubRepo  or os.getenv("GITHUB_REPO",  "")
    return {"token": token, "owner": owner, "repo": repo}


# ── Preview ───────────────────────────────────────────────
@router.post("/pr/preview")
async def pr_preview(req: PRRequest):
    try:
        result = await preview_pr(req.nodes, req.edges)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Create ────────────────────────────────────────────────
@router.post("/pr/create")
async def pr_create(req: PRRequest):
    cfg = resolve_github_config(req)

    # Temporarily override env vars with user-supplied values
    # so pr_service picks them up cleanly
    original = {
        "GITHUB_TOKEN": os.environ.get("GITHUB_TOKEN", ""),
        "GITHUB_OWNER": os.environ.get("GITHUB_OWNER", ""),
        "GITHUB_REPO":  os.environ.get("GITHUB_REPO",  ""),
    }

    try:
        if cfg["token"]: os.environ["GITHUB_TOKEN"] = cfg["token"]
        if cfg["owner"]: os.environ["GITHUB_OWNER"] = cfg["owner"]
        if cfg["repo"]:  os.environ["GITHUB_REPO"]  = cfg["repo"]

        result = await create_schema_pr(
            nodes         = req.nodes,
            edges         = req.edges,
            pr_title      = req.title,
            target_branch = req.targetBranch
        )

        if result.get("status") == "error":
            raise HTTPException(status_code=400, detail=result["message"])

        return result

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        # Always restore original env
        for k, v in original.items():
            os.environ[k] = v


# ── Auto-sync architecture (no PR — commits codegpo.json straight to default branch) ──
@router.post("/architecture/sync")
async def architecture_sync(req: PRRequest, current_user: dict = Depends(get_current_user)):
    """
    Called automatically after every graph save (if the user has GitHub configured).
    Keeps codegpo.json in the repo up to date so the CI/CD governance gate always
    checks against the latest architecture — no manual export/upload needed.
    """
    cfg = resolve_github_config(req)
    original = {
        "GITHUB_TOKEN": os.environ.get("GITHUB_TOKEN", ""),
        "GITHUB_OWNER": os.environ.get("GITHUB_OWNER", ""),
        "GITHUB_REPO":  os.environ.get("GITHUB_REPO",  ""),
    }
    try:
        if cfg["token"]: os.environ["GITHUB_TOKEN"] = cfg["token"]
        if cfg["owner"]: os.environ["GITHUB_OWNER"] = cfg["owner"]
        if cfg["repo"]:  os.environ["GITHUB_REPO"]  = cfg["repo"]

        result = await sync_architecture_json(req.nodes, req.edges)

        if result.get("status") == "error":
            # Not configured or GitHub call failed — don't break the save flow over this.
            return {"status": "skipped", "reason": result.get("message")}

        return result
    finally:
        for k, v in original.items():
            os.environ[k] = v


# ── Config check ──────────────────────────────────────────
@router.post("/pr/config")
async def pr_config_check(req: Optional[PRRequest] = None):
    """Check if GitHub is configured — accepts user config in body."""
    if req:
        cfg = resolve_github_config(req)
    else:
        cfg = {
            "token": os.getenv("GITHUB_TOKEN", ""),
            "owner": os.getenv("GITHUB_OWNER", ""),
            "repo":  os.getenv("GITHUB_REPO",  ""),
        }

    configured = bool(cfg["token"] and cfg["owner"] and cfg["repo"])
    source     = "user" if (req and req.githubToken) else "server"

    return {
        "configured": configured,
        "owner":      cfg["owner"] or None,
        "repo":       cfg["repo"]  or None,
        "hasToken":   bool(cfg["token"]),
        "source":     source,
        "repoUrl":    f"https://github.com/{cfg['owner']}/{cfg['repo']}" if configured else None
    }

# Keep GET for backward compat
@router.get("/pr/config")
async def pr_config_check_get():
    token = os.getenv("GITHUB_TOKEN", "")
    owner = os.getenv("GITHUB_OWNER", "")
    repo  = os.getenv("GITHUB_REPO",  "")
    configured = bool(token and owner and repo)
    return {
        "configured": configured,
        "owner":      owner or None,
        "repo":       repo  or None,
        "hasToken":   bool(token),
        "source":     "server",
        "repoUrl":    f"https://github.com/{owner}/{repo}" if configured else None
    }
