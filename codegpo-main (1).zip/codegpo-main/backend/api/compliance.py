"""
CodeGPO Compliance API
File: backend/api/compliance.py

Add to main.py:
    from api.compliance import compliance_router
    app.include_router(compliance_router)
"""

from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Optional
from services.compliance_engine import (
    get_all_compliance_rules,
    get_framework_summary,
    get_rules_by_framework,
    get_rules_by_severity,
    get_compliance_checklist,
    ALL_COMPLIANCE_FRAMEWORKS,
)

compliance_router = APIRouter(prefix="/api/compliance", tags=["compliance"])


class ChecklistRequest(BaseModel):
    node_types: List[str] = []
    has_payment: bool = False
    has_iot: bool = False
    is_india: bool = True
    serves_eu: bool = False


@compliance_router.get("/frameworks")
def list_frameworks():
    """All compliance frameworks with metadata"""
    return {
        "frameworks": get_framework_summary(),
        "total_frameworks": len(ALL_COMPLIANCE_FRAMEWORKS),
        "total_rules": len(get_all_compliance_rules()),
    }


@compliance_router.get("/rules")
def list_all_rules():
    """All 47 compliance rules across all frameworks"""
    rules = get_all_compliance_rules()
    return {
        "rules": rules,
        "total": len(rules),
        "by_severity": {
            "CRITICAL": len([r for r in rules if r["severity"] == "CRITICAL"]),
            "HIGH": len([r for r in rules if r["severity"] == "HIGH"]),
            "MEDIUM": len([r for r in rules if r["severity"] == "MEDIUM"]),
        }
    }


@compliance_router.get("/rules/{framework_key}")
def rules_by_framework(framework_key: str):
    """Rules for a specific framework: SOC2, PCI-DSS, GDPR, ISO-27001, DPDP, OWASP, IoT-Security"""
    rules = get_rules_by_framework(framework_key)
    fw = ALL_COMPLIANCE_FRAMEWORKS.get(framework_key, {})
    return {
        "framework": framework_key,
        "framework_name": fw.get("name", ""),
        "full_name": fw.get("full_name", ""),
        "governing_body": fw.get("governing_body", ""),
        "penalty": fw.get("penalty", ""),
        "rules": rules,
        "total": len(rules),
    }


@compliance_router.get("/rule/{rule_id}")
def get_rule_detail(rule_id: str):
    """Get full detail of a specific rule by ID (e.g., SOC2-CC6.1)"""
    all_rules = get_all_compliance_rules()
    rule = next((r for r in all_rules if r["ruleId"] == rule_id), None)
    if not rule:
        return {"error": f"Rule {rule_id} not found"}
    return rule


@compliance_router.post("/checklist")
def generate_checklist(req: ChecklistRequest):
    """Generate applicable compliance checklist based on your architecture"""
    checklist = get_compliance_checklist(
        node_types=req.node_types,
        has_payment=req.has_payment,
        has_iot=req.has_iot,
        is_india=req.is_india,
        serves_eu=req.serves_eu,
    )
    return {
        "checklist": checklist,
        "total_checks": len(checklist),
        "critical_checks": len([c for c in checklist if c["severity"] == "CRITICAL"]),
        "high_checks": len([c for c in checklist if c["severity"] == "HIGH"]),
        "applicable_frameworks": list(set(c["framework"] for c in checklist)),
    }


@compliance_router.get("/severity/{severity}")
def rules_by_severity(severity: str):
    """Rules by severity: CRITICAL, HIGH, MEDIUM"""
    rules = get_rules_by_severity(severity.upper())
    return {"severity": severity.upper(), "rules": rules, "total": len(rules)}  
