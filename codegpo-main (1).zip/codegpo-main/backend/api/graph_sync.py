"""
/graph/save  — Frontend se poora graph receive karke Neo4j mein save karo (caller ke org ke liye)
/graph/load  — Neo4j se poora graph load karke frontend ko do (caller ke org ka hi)
"""
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import List, Dict, Any
from services.graph_service import get_graph, save_full_graph
from services.governance_service import check
from auth.auth import get_current_user

router = APIRouter()


class GraphSaveRequest(BaseModel):
    nodes: List[Dict[str, Any]] = []
    edges: List[Dict[str, Any]] = []


@router.post("/graph/save")
def save_graph(req: GraphSaveRequest, current_user: dict = Depends(get_current_user)):
    """Frontend ka poora graph Neo4j mein save karo — sirf caller ke org ke liye."""
    try:
        save_full_graph(req.nodes, req.edges, org_id=current_user["org_id"])
        return {
            "status": "ok",
            "saved_nodes": len(req.nodes),
            "saved_edges": len(req.edges),
        }
    except Exception as e:
        return {"status": "error", "detail": str(e)}


@router.get("/graph/load")
def load_graph(current_user: dict = Depends(get_current_user)):
    """Neo4j se caller ke org ka graph load karke governance violations bhi include karo."""
    try:
        graph = get_graph(org_id=current_user["org_id"])
        violations = check(graph["edges"], graph["nodes"])
        return {
            "nodes":      graph["nodes"],
            "edges":      graph["edges"],
            "violations": violations,
        }
    except Exception as e:
        return {"nodes": [], "edges": [], "violations": [], "error": str(e)}
