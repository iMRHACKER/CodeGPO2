from fastapi import APIRouter
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
from services.graphrag_service import explain_violation, explain, call_gemini, call_ollama, call_openai, LLM_PROVIDER, GEMINI_API_KEY, OPENAI_API_KEY

router = APIRouter()

class ViolationExplainRequest(BaseModel):
    sourceNode: Dict[str, Any]
    targetNode: Dict[str, Any]
    rule: Dict[str, Any]
    allNodes: Optional[List[Dict[str, Any]]] = []
    allEdges: Optional[List[Dict[str, Any]]] = []

class PromptRequest(BaseModel):
    prompt: str

@router.post("/graphrag/explain")
async def graphrag_explain(req: ViolationExplainRequest):
    return await explain_violation(
        source_node=req.sourceNode,
        target_node=req.targetNode,
        rule=req.rule,
        all_nodes=req.allNodes,
        all_edges=req.allEdges
    )

@router.post("/graphrag")
async def graphrag(req: PromptRequest):
    if LLM_PROVIDER == "gemini" and GEMINI_API_KEY:
        response = await call_gemini(req.prompt)
    elif LLM_PROVIDER == "openai" and OPENAI_API_KEY:
        response = await call_openai(req.prompt)
    else:
        response = await call_ollama(req.prompt)
    return {"response": response}
