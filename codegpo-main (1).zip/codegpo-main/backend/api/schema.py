"""
CodeGPO Schema & Contract Generation API
─────────────────────────────────────────
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from services.schema_generator import (
    generate_all_schemas,
    generate_schemas_for_node
)

router = APIRouter()


class SchemaRequest(BaseModel):
    nodes: List[Dict[str, Any]]
    edges: List[Dict[str, Any]]


class SingleNodeSchemaRequest(BaseModel):
    node: Dict[str, Any]
    edges: List[Dict[str, Any]]
    allNodes: Optional[List[Dict[str, Any]]] = []


# ── Generate schemas for entire graph ────────────────────
@router.post("/schema/generate")
def generate_schemas(req: SchemaRequest):
    try:
        results = generate_all_schemas(req.nodes, req.edges)
        return {
            "status": "ok",
            "count": len(results),
            "schemas": results
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Generate schema for a single node ────────────────────
@router.post("/schema/generate/node")
def generate_node_schema(req: SingleNodeSchemaRequest):
    try:
        result = generate_schemas_for_node(
            node=req.node,
            edges=req.edges,
            all_nodes=req.allNodes or []
        )
        return {"status": "ok", "schema": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── List schema-eligible nodes in a graph ────────────────
@router.post("/schema/eligible-nodes")
def get_eligible_nodes(req: SchemaRequest):
    eligible_types = [
        "database", "db", "api", "rest", "sql",
        "mongo", "nosql", "graphql", "endpoint"
    ]
    eligible = [
        n for n in req.nodes
        if any(t in (n.get("type") or "").lower() for t in eligible_types)
    ]
    return {"nodes": eligible, "count": len(eligible)}