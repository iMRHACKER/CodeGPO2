from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from services.auto_scan_service import scan_repo_for_architecture, detect_edges_by_type
from services.graph_service import get_graph, add_node, add_edge
from models.node import Node
from models.edge import Edge
from auth.auth import get_current_user

router = APIRouter()


class AutoScanRequest(BaseModel):
    owner: str
    repo: str
    branch: str = "main"


@router.post("/architecture/auto-scan")
async def auto_scan_and_update(req: AutoScanRequest, current_user: dict = Depends(get_current_user)):
    """
    Re-scans the given GitHub repo (package.json / requirements.txt) and
    ADDS any newly-detected components AND their likely connections to the
    caller's org architecture graph.

    This is additive-only, on purpose:
      - Existing nodes are never touched, so manual edits (intent, owner,
        compliance scope, criticality) are never lost.
      - Existing edges (connections the user drew by hand) are never touched,
        removed, or rewired.
      - A node already present (matched by id) is skipped, not overwritten.
      - New edges are only created if they involve at least one newly-added
        node — a new "Stripe" node gets wired into the architecture using
        standard patterns (Service -> External, etc.), but nothing about
        the existing graph's connections is touched.

    Called automatically by the GitHub Actions workflow on every push to
    main, so newly-added dependencies show up in CodeGPO, already connected,
    without anyone opening the web app.
    """
    org_id = current_user["org_id"]

    result = await scan_repo_for_architecture(req.owner, req.repo, req.branch)
    if result.get("status") == "error":
        raise HTTPException(400, result.get("message", "Auto-scan failed"))

    detected_nodes = result["nodes"]

    current_graph = get_graph(org_id=org_id)
    existing_ids = {n["id"] for n in current_graph["nodes"]}
    existing_edge_keys = {(e.get("source"), e.get("target")) for e in current_graph["edges"]}

    added_nodes = []
    skipped_nodes = []

    for n in detected_nodes:
        if n["id"] in existing_ids:
            skipped_nodes.append(n["id"])
            continue
        add_node(Node(id=n["id"], name=n.get("name", ""), type=n.get("type", "")), org_id=org_id)
        added_nodes.append(n)

    added_ids = {n["id"] for n in added_nodes}

    # Run the type-based connection heuristic over the FULL graph (existing + new),
    # but only keep edges that touch at least one newly-added node — existing
    # connections are never rewired.
    edges_added = []
    if added_nodes:
        full_node_list = current_graph["nodes"] + added_nodes
        candidate_edges = detect_edges_by_type(full_node_list)

        for e in candidate_edges:
            key = (e["source"], e["target"])
            if key in existing_edge_keys:
                continue
            if e["source"] not in added_ids and e["target"] not in added_ids:
                continue  # doesn't touch anything new — leave existing graph exactly as it was
            add_edge(Edge(source=e["source"], target=e["target"], relation=e.get("relation", "")), org_id=org_id)
            existing_edge_keys.add(key)
            edges_added.append(key)

    return {
        "status": "ok",
        "nodes_added": len(added_nodes),
        "nodes_already_present": len(skipped_nodes),
        "edges_added": len(edges_added),
        "added_node_ids": [n["id"] for n in added_nodes],
    }
