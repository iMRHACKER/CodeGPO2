from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any

from auth.auth import get_current_user
from services.accountability_service import (
    compute_violation_id,
    create_approval,
    list_approvals,
)

router = APIRouter(prefix="/accountability", tags=["accountability"])


class ApproveRequest(BaseModel):
    rule_id: str
    source: str = ""
    target: str = ""
    decision: str      # "approved" | "overridden" | "commented"
    reason: str


@router.post("/approve")
def approve_violation(req: ApproveRequest, current_user: dict = Depends(get_current_user)):
    """
    Record a named, timestamped, immutable decision on a violation.
    This is CREATE-only — there is no endpoint to edit or delete an approval.
    """
    if req.decision not in ("approved", "overridden", "commented"):
        raise HTTPException(400, "decision must be 'approved', 'overridden', or 'commented'")
    if not req.reason or len(req.reason.strip()) < 3:
        raise HTTPException(400, "A reason is required — this is an audit record, not a checkbox")

    violation_id = compute_violation_id(req.rule_id, req.source, req.target)

    record = create_approval(
        org_id=current_user["org_id"],
        violation_id=violation_id,
        rule_id=req.rule_id,
        source=req.source,
        target=req.target,
        decision=req.decision,
        approved_by_id=current_user.get("sub", ""),
        approved_by_email=current_user.get("email", ""),
        reason=req.reason.strip(),
    )
    return {"status": "ok", "record": record}


@router.get("/log")
def get_audit_log(violation_id: Optional[str] = None, current_user: dict = Depends(get_current_user)):
    """Full accountability log for the caller's org — evidence-grade, newest first."""
    records = list_approvals(org_id=current_user["org_id"], violation_id=violation_id)
    return {"count": len(records), "records": records}
