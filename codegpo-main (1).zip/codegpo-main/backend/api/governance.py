from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import List, Dict, Any
from services.graph_service import get_graph
from services.governance_service import check
from services.accountability_service import attach_approval_status
from auth.auth import get_current_user

router = APIRouter()


class EvaluateRequest(BaseModel):
    nodes: List[Dict[str, Any]] = []
    edges: List[Dict[str, Any]] = []


@router.get("/governance")
def governance(current_user: dict = Depends(get_current_user)):
    """Evaluate governance on the caller's org's Neo4j-stored graph, with accountability status attached."""
    graph = get_graph(org_id=current_user["org_id"])
    violations = check(graph["edges"], graph["nodes"])
    return attach_approval_status(violations, org_id=current_user["org_id"])


@router.post("/governance/evaluate")
def governance_evaluate(req: EvaluateRequest, current_user: dict = Depends(get_current_user)):
    """Evaluate governance on a client-provided graph, with accountability status attached."""
    violations = check(req.edges, req.nodes)
    return attach_approval_status(violations, org_id=current_user["org_id"])
