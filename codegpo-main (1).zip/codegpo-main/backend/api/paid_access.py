"""
CodeGPO Paid Access System
File: backend/api/paid_access.py

Plans:
- Developer: $49/mo — individual devs
- Team: $199/mo — engineering teams  
- Enterprise: Custom — Zypp-level companies
"""

from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel, EmailStr
from typing import Optional
import hashlib, uuid, os
from datetime import datetime, timedelta
from neo4j import GraphDatabase

paid_router = APIRouter(prefix="/api", tags=["access"])

# ── DB ──────────────────────────────────────────────────
NEO4J_URI  = os.getenv("NEO4J_URI", "")
NEO4J_USER = os.getenv("NEO4J_USER", "neo4j")
NEO4J_PASS = os.getenv("NEO4J_PASSWORD", "")

def get_db():
    return GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASS))

# ── PLANS ───────────────────────────────────────────────
PLANS = {
    "free": {
        "name": "Free Alpha",
        "price_usd": 0,
        "price_inr": 0,
        "max_projects": 2,
        "max_nodes": 10,
        "max_scans_per_day": 5,
        "compliance_frameworks": ["SOC2"],
        "features": ["basic_governance", "schema_gen"],
        "report_download": False,
        "api_access": False,
        "support": "community",
    },
    "developer": {
        "name": "Developer",
        "price_usd": 49,
        "price_inr": 4099,
        "max_projects": 5,
        "max_nodes": 50,
        "max_scans_per_day": 100,
        "compliance_frameworks": ["SOC2", "OWASP", "GDPR"],
        "features": ["basic_governance", "schema_gen", "github_pr", "graphrag", "report_download"],
        "report_download": True,
        "api_access": False,
        "support": "email",
    },
    "team": {
        "name": "Team",
        "price_usd": 199,
        "price_inr": 16599,
        "max_projects": -1,  # unlimited
        "max_nodes": -1,
        "max_scans_per_day": 1000,
        "compliance_frameworks": ["SOC2", "OWASP", "GDPR", "PCI-DSS", "ISO-27001", "DPDP", "IoT-Security"],
        "features": ["basic_governance", "schema_gen", "github_pr", "graphrag",
                     "report_download", "all_frameworks", "custom_rules", "audit_log"],
        "report_download": True,
        "api_access": True,
        "support": "priority_email",
    },
    "enterprise": {
        "name": "Enterprise",
        "price_usd": 0,  # custom
        "price_inr": 0,
        "max_projects": -1,
        "max_nodes": -1,
        "max_scans_per_day": -1,
        "compliance_frameworks": ["SOC2", "OWASP", "GDPR", "PCI-DSS", "ISO-27001", "DPDP", "IoT-Security"],
        "features": ["basic_governance", "schema_gen", "github_pr", "graphrag",
                     "report_download", "all_frameworks", "custom_rules", "audit_log",
                     "sso", "sla", "dedicated_support", "custom_onboarding", "white_label"],
        "report_download": True,
        "api_access": True,
        "support": "dedicated",
        "custom_pricing": True,
    },
}

# ── ALPHA CODES (existing) ───────────────────────────────
ALPHA_CODES = {
    "CODEGPO-2026":    {"plan": "team",      "uses": 0, "max_uses": 5},
    "ALPHA-001":       {"plan": "developer", "uses": 0, "max_uses": 10},
    "EARLY1-1BIRD":    {"plan": "developer", "uses": 0, "max_uses": 20},
    "ZYPP-PILOT":      {"plan": "enterprise","uses": 0, "max_uses": 3},   # Zypp ke liye
    "ZYPP-TEAM":       {"plan": "team",      "uses": 0, "max_uses": 10},  # Zypp team
    "ALPHA_FOUNDER-001": {"plan": "team",    "uses": 0, "max_uses": 5},
    "ALPHA_DEV-2026-1":  {"plan": "developer","uses": 0,"max_uses": 10},
}


# ── MODELS ──────────────────────────────────────────────
class RedeemRequest(BaseModel):
    code: str
    email: str
    company: Optional[str] = None

class VerifyRequest(BaseModel):
    api_key: str

class EnterpriseRequest(BaseModel):
    company_name: str
    contact_name: str
    email: str
    team_size: int
    use_case: str
    message: Optional[str] = None


# ── HELPERS ─────────────────────────────────────────────
def generate_api_key(email: str, plan: str) -> str:
    raw = f"cgpo_{email}_{plan}_{uuid.uuid4().hex[:8]}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]

def mask_key(key: str) -> str:
    return key[:8] + "..." + key[-4:]


# ── ENDPOINTS ───────────────────────────────────────────

@paid_router.get("/plans")
def list_plans():
    """Return all plans with features and pricing"""
    return {
        "plans": {k: {kk: vv for kk, vv in v.items()} for k, v in PLANS.items()},
        "recommended": "team",
        "enterprise_cta": "Contact harsh@codegpo.com for Enterprise pricing",
        "currency_note": "INR pricing available. Contact for invoice.",
    }


@paid_router.post("/access/redeem")
def redeem_code(req: RedeemRequest):
    """Redeem an alpha/promo code to get API key"""
    code = req.code.strip().upper()

    if code not in ALPHA_CODES:
        raise HTTPException(status_code=400, detail="Invalid access code")

    code_data = ALPHA_CODES[code]
    if code_data["max_uses"] > 0 and code_data["uses"] >= code_data["max_uses"]:
        raise HTTPException(status_code=400, detail="This code has reached its usage limit")

    plan = code_data["plan"]
    api_key = generate_api_key(req.email, plan)

    # Increment usage
    ALPHA_CODES[code]["uses"] += 1

    # Save to Neo4j
    try:
        driver = get_db()
        with driver.session() as session:
            session.run("""
                MERGE (u:User {email: $email})
                SET u.plan = $plan,
                    u.api_key = $api_key,
                    u.company = $company,
                    u.redeemed_code = $code,
                    u.redeemed_at = $redeemed_at,
                    u.active = true
                """,
                email=req.email,
                plan=plan,
                api_key=api_key,
                company=req.company or "",
                code=code,
                redeemed_at=datetime.utcnow().isoformat(),
            )
        driver.close()
    except Exception as e:
        # Log but don't fail — return key anyway
        print(f"Neo4j save error: {e}")

    plan_details = PLANS[plan]

    return {
        "success": True,
        "message": f"Welcome to CodeGPO {plan_details['name']} plan!",
        "api_key": api_key,
        "api_key_masked": mask_key(api_key),
        "plan": plan,
        "plan_name": plan_details["name"],
        "features": plan_details["features"],
        "compliance_frameworks": plan_details["compliance_frameworks"],
        "limits": {
            "max_projects": plan_details["max_projects"],
            "max_nodes": plan_details["max_nodes"],
            "max_scans_per_day": plan_details["max_scans_per_day"],
        },
        "support": plan_details["support"],
        "next_steps": [
            f"Save your API key: {api_key}",
            "Go to app.codegpo.com and enter your API key in Settings",
            f"You have access to: {', '.join(plan_details['compliance_frameworks'])}",
            "Contact harsh@codegpo.com for any questions",
        ]
    }


@paid_router.post("/access/verify")
def verify_api_key(req: VerifyRequest):
    """Verify an API key and return plan details"""
    try:
        driver = get_db()
        with driver.session() as session:
            result = session.run(
                "MATCH (u:User {api_key: $api_key, active: true}) RETURN u",
                api_key=req.api_key,
            )
            record = result.single()
        driver.close()

        if not record:
            raise HTTPException(status_code=401, detail="Invalid or inactive API key")

        user = dict(record["u"])
        plan = user.get("plan", "free")
        plan_details = PLANS.get(plan, PLANS["free"])

        return {
            "valid": True,
            "email": user.get("email"),
            "plan": plan,
            "plan_name": plan_details["name"],
            "features": plan_details["features"],
            "compliance_frameworks": plan_details["compliance_frameworks"],
            "limits": {
                "max_projects": plan_details["max_projects"],
                "max_nodes": plan_details["max_nodes"],
                "max_scans_per_day": plan_details["max_scans_per_day"],
            },
            "report_download": plan_details["report_download"],
            "api_access": plan_details["api_access"],
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@paid_router.post("/access/enterprise")
def enterprise_inquiry(req: EnterpriseRequest):
    """Enterprise plan inquiry — save lead and notify"""
    try:
        driver = get_db()
        with driver.session() as session:
            session.run("""
                MERGE (l:EnterpriseLead {email: $email})
                SET l.company_name = $company_name,
                    l.contact_name = $contact_name,
                    l.team_size = $team_size,
                    l.use_case = $use_case,
                    l.message = $message,
                    l.submitted_at = $submitted_at,
                    l.status = 'new'
                """,
                email=req.email,
                company_name=req.company_name,
                contact_name=req.contact_name,
                team_size=req.team_size,
                use_case=req.use_case,
                message=req.message or "",
                submitted_at=datetime.utcnow().isoformat(),
            )
        driver.close()
    except Exception as e:
        print(f"Neo4j save error: {e}")

    return {
        "success": True,
        "message": "Thank you! We'll contact you within 24 hours.",
        "next_steps": [
            "You'll receive a calendar invite for a demo call",
            "We'll prepare a custom compliance setup for your architecture",
            f"Direct contact: harsh@codegpo.com",
        ],
        "pilot_offer": "First 3 months free for enterprise pilot customers",
    }


@paid_router.get("/access/features/{plan}")
def get_plan_features(plan: str):
    """Get detailed feature list for a specific plan"""
    if plan not in PLANS:
        raise HTTPException(status_code=404, detail=f"Plan '{plan}' not found")

    plan_data = PLANS[plan]
    return {
        "plan": plan,
        **plan_data,
        "comparison": {
            "vs_free": "Full compliance frameworks + report download + GitHub PR",
            "vs_developer": "Unlimited projects + all frameworks + team features + API access",
        } if plan == "team" else {},
    }
