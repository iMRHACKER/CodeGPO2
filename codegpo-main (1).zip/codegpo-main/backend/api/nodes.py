from fastapi import APIRouter, Depends
from models.node import Node
from services.graph_service import add_node
from auth.auth import get_current_user

router = APIRouter()

@router.post("/nodes")
def create_node(node: Node, current_user: dict = Depends(get_current_user)):
    add_node(node, org_id=current_user["org_id"])
    return {"status": "ok"}
