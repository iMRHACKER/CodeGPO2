"""
GitHub ZIP proxy — downloads repo ZIP server-side (no CORS issues)
and returns it to frontend so scanZip can process it identically to manual upload.
"""
import httpx
from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from auth.auth import get_current_user

router = APIRouter()

class GithubScanRequest(BaseModel):
    owner: str
    repo: str
    branch: str = "main"

@router.post("/scan/github-zip")
async def proxy_github_zip(req: GithubScanRequest, current_user: dict = Depends(get_current_user)):
    """
    Proxy GitHub repo ZIP download to avoid CORS.
    Frontend calls this, gets the ZIP bytes, then runs scanZip on it.
    Auth required — this proxies outbound requests, so it must not be open to anonymous callers.
    """
    branches = [req.branch, "main", "master", "develop", "dev"]

    async with httpx.AsyncClient(follow_redirects=True, timeout=30) as client:
        for branch in branches:
            url = f"https://github.com/{req.owner}/{req.repo}/archive/refs/heads/{branch}.zip"
            try:
                resp = await client.get(url)
                if resp.status_code == 200:
                    content = resp.content
                    return StreamingResponse(
                        iter([content]),
                        media_type="application/zip",
                        headers={
                            "Content-Disposition": f"attachment; filename={req.repo}-{branch}.zip",
                            "X-Branch": branch,
                            "Access-Control-Allow-Origin": "*"
                        }
                    )
            except Exception:
                continue

    raise HTTPException(404, f"Could not download repository {req.owner}/{req.repo}. Check it exists and is public.")
