from fastapi import APIRouter, Depends
from fastapi.responses import Response
from pydantic import BaseModel

from services.report_service import generate_and_save_report
from services.graph_service import get_graph
from services.governance_service import check
from services.accountability_service import attach_approval_status
from auth.auth import get_current_user

report_router = APIRouter(prefix="/api", tags=["report"])


class ReportRequest(BaseModel):
    project_name: str = "Untitled Project"


# ---------- SEVERITY-WEIGHTED HEALTH SCORE ----------
SEVERITY_WEIGHTS = {"CRITICAL": 15, "HIGH": 8, "MEDIUM": 4, "LOW": 1}

def compute_health_score(violations: list) -> int:
    penalty = sum(SEVERITY_WEIGHTS.get((v.get("severity") or "").upper(), 2) for v in violations)
    return max(0, 100 - penalty)


# ---------- VIOLATION → REPORT-ISSUE MAPPING ----------
def violation_to_issue(v: dict) -> dict:
    source_label = v.get("sourceName") or v.get("source") or ""
    target_label = v.get("targetName") or v.get("target") or ""
    location = f"{source_label} → {target_label}" if (source_label or target_label) else ""

    acc = v.get("accountability") or {"status": "unresolved"}

    return {
        "title":       v.get("message", v.get("ruleId", "Violation")),
        "location":    location,
        "problem":     v.get("description", ""),
        "fix":         v.get("fix", "Review architecture and add appropriate service layer"),
        "severity":    (v.get("severity") or "MEDIUM").upper(),
        "rule_id":     v.get("ruleId", ""),
        "framework":   v.get("framework", ""),
        "accountability_status": acc.get("status", "unresolved"),
        "approved_by":     acc.get("approvedBy"),
        "approved_at":     acc.get("timestamp"),
        "approved_reason": acc.get("reason"),
    }


# ---------- DATA ENRICHMENT ----------
def enrich_data(data):
    issues = data.get("issues", [])

    critical = len([i for i in issues if i.get("severity") == "CRITICAL"])
    high = len([i for i in issues if i.get("severity") == "HIGH"])
    medium = len([i for i in issues if i.get("severity") == "MEDIUM"])
    low = len([i for i in issues if i.get("severity") == "LOW"])

    data["critical_risk"] = critical
    data["high_risk"] = high
    data["medium_risk"] = medium
    data["low_risk"] = low

    for c in data.get("components", []):
        c["status"] = "Healthy" if c.get("status") == "healthy" else "At Risk"

    data["key_insight"] = (
        f"{critical} critical and {high} high-severity issue{'s' if (critical + high) != 1 else ''} "
        f"detected that may affect system stability."
    )

    unresolved = len([i for i in issues if i.get("accountability_status") == "unresolved"])
    if critical > 0:
        data["verdict_reason"] = f"{critical} critical issue{'s' if critical != 1 else ''} must be resolved before production."
    elif high > 0:
        data["verdict_reason"] = f"{high} high-severity issue{'s' if high != 1 else ''} should be resolved before production."
    elif unresolved > 0:
        data["verdict_reason"] = f"{unresolved} violation(s) have no named sign-off — review before treating as compliant."
    else:
        data["verdict_reason"] = "System is safe for production deployment. All violations have named accountability records."

    return data


# ---------- ROUTE ----------
@report_router.post("/report/download")
async def download_report(req: ReportRequest, current_user: dict = Depends(get_current_user)):
    """
    Generates the compliance PDF from the CALLER'S ORG'S ACTUAL Neo4j graph and
    live governance evaluation — never from client-supplied violation data.
    This is what makes the report audit-grade evidence rather than a
    self-reported claim.
    """
    try:
        org_id = current_user["org_id"]
        graph = get_graph(org_id=org_id)
        raw_violations = check(graph["edges"], graph["nodes"])
        violations = attach_approval_status(raw_violations, org_id=org_id)

        issues = [violation_to_issue(v) for v in violations]

        node_names = {n.get("id"): n.get("name", n.get("id", "")) for n in graph["nodes"]}
        violated_pairs = {}
        for v in violations:
            key = (v.get("source"), v.get("target"))
            violated_pairs.setdefault(key, []).append(v.get("ruleId", ""))

        connections = [
            {
                "from_node": node_names.get(e.get("source"), e.get("source", "")),
                "to_node":   node_names.get(e.get("target"), e.get("target", "")),
                "violation": (e.get("source"), e.get("target")) in violated_pairs,
                "rule":      ", ".join(violated_pairs.get((e.get("source"), e.get("target")), [])),
            }
            for e in graph["edges"]
        ]

        data = {
            "project_name": req.project_name,
            "health_score": compute_health_score(violations),
            "total_components": len(graph["nodes"]),
            "total_connections": len(graph["edges"]),
            "components": [
                {
                    "name": n.get("name", n.get("id", "")),
                    "type": n.get("type", ""),
                    "scope": n.get("compliance_scope") or "General",
                    "connections": sum(
                        1 for e in graph["edges"] if e.get("source") == n.get("id") or e.get("target") == n.get("id")
                    ),
                    "status": "healthy" if not any(
                        v.get("source") == n.get("id") or v.get("target") == n.get("id") for v in violations
                    ) else "at_risk",
                }
                for n in graph["nodes"]
            ],
            "connections": connections,
            "issues": issues,
        }
        data = enrich_data(data)

        pdf, _ = generate_and_save_report(data)

        return Response(
            content=pdf,
            media_type="application/pdf",
            headers={"Content-Disposition": "attachment; filename=CodeGPO_Report.pdf"}
        )

    except Exception as e:
        return Response(
            content=f"Report generation failed: {e}".encode(),
            media_type="text/plain",
            status_code=500,
        )
