from pydantic import BaseModel, validator
from typing import Optional


class Node(BaseModel):
    id: str

    # Frontend sends "name", older code sends "label" — accept both
    label: Optional[str] = ""
    name:  Optional[str] = ""

    # "type" is a Python/Neo4j reserved word — keep it but validate carefully
    type: Optional[str] = ""

    # ── Semantic Intent ──────────────────────────────────
    intent:      Optional[str] = ""
    owner:       Optional[str] = ""
    team:        Optional[str] = ""
    criticality: Optional[str] = ""

    # ── Compliance Tags ──────────────────────────────────
    # Comma-separated: "gdpr,hipaa,soc2"
    compliance_scope: Optional[str] = ""

    # ── Schema fields ────────────────────────────────────
    # JSON string: '[{"name":"id","type":"uuid"},...]'
    fields: Optional[str] = "[]"

    @validator("label", always=True)
    def sync_label(cls, v, values):
        # label fallback: use name if label empty
        return v or values.get("name", "") or ""

    @validator("name", always=True)
    def sync_name(cls, v, values):
        # name fallback: use label if name empty
        return v or values.get("label", "") or ""
