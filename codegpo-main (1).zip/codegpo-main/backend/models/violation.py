from pydantic import BaseModel

class Violation(BaseModel):
    rule: str
    source: str
    target: str
    reason: str
