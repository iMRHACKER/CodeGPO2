import asyncio
import json
import uuid
from datetime import datetime
from typing import Dict
import websockets

rooms: Dict[str, dict] = {}

USER_COLORS = [
    "#f59e0b", "#7c3aed", "#0ea5e9", "#ec4899",
    "#22c55e", "#f97316", "#06b6d4", "#8b5cf6"
]

def get_room(room_id: str) -> dict:
    if room_id not in rooms:
        rooms[room_id] = {
            "clients": {},
            "nodes": [],
            "edges": [],
            "updated_at": datetime.utcnow().isoformat()
        }
    return rooms[room_id]

def get_user_color(room: dict) -> str:
    used = {info["color"] for info in room["clients"].values()}
    for color in USER_COLORS:
        if color not in used:
            return color
    return USER_COLORS[len(room["clients"]) % len(USER_COLORS)]

async def broadcast(room: dict, message: dict, exclude=None):
    if not room["clients"]:
        return
    data = json.dumps(message)
    dead = set()
    for ws in list(room["clients"].keys()):
        if ws == exclude:
            continue
        try:
            await ws.send(data)
        except Exception:
            dead.add(ws)
    for ws in dead:
        room["clients"].pop(ws, None)

async def handler(websocket):
    room_id = None
    user_id = str(uuid.uuid4())[:8]

    try:
        raw = await asyncio.wait_for(websocket.recv(), timeout=10)
        msg = json.loads(raw)

        if msg.get("type") != "join":
            await websocket.close()
            return

        room_id = msg.get("roomId", "default")
        user_name = msg.get("userName", f"User {user_id[:4]}")

        room = get_room(room_id)
        color = get_user_color(room)

        user_info = {
            "id": user_id,
            "name": user_name,
            "color": color,
            "cursor": None,
            "joinedAt": datetime.utcnow().isoformat()
        }

        room["clients"][websocket] = user_info

        print(f"[+] {user_name} joined room '{room_id}' ({len(room['clients'])} online)")

        # Send current room state to new user
        await websocket.send(json.dumps({
            "type": "init",
            "userId": user_id,
            "color": color,
            "nodes": room["nodes"],
            "edges": room["edges"],
            "users": [
                {"id": v["id"], "name": v["name"], "color": v["color"]}
                for v in room["clients"].values()
                if v["id"] != user_id
            ]
        }))

        # Announce to others
        await broadcast(room, {
            "type": "user_joined",
            "user": {"id": user_id, "name": user_name, "color": color}
        }, exclude=websocket)

        # Main loop
        async for raw in websocket:
            try:
                msg = json.loads(raw)
                msg_type = msg.get("type")

                if msg_type == "node_add":
                    node = msg["node"]
                    if not any(n["id"] == node["id"] for n in room["nodes"]):
                        room["nodes"].append(node)
                    await broadcast(room, {
                        "type": "node_add",
                        "node": node,
                        "userId": user_id
                    }, exclude=websocket)

                elif msg_type == "node_move":
                    # Update stored position
                    node_id = msg["nodeId"]
                    x = msg["x"]
                    y = msg["y"]
                    for n in room["nodes"]:
                        if n["id"] == node_id:
                            n["x"] = x
                            n["y"] = y
                            break
                    await broadcast(room, {
                        "type": "node_move",
                        "nodeId": node_id,
                        "x": x,
                        "y": y,
                        "userId": user_id
                    }, exclude=websocket)

                elif msg_type == "node_delete":
                    node_id = msg["nodeId"]
                    room["nodes"] = [n for n in room["nodes"] if n["id"] != node_id]
                    room["edges"] = [
                        e for e in room["edges"]
                        if e["source"] != node_id and e["target"] != node_id
                    ]
                    await broadcast(room, {
                        "type": "node_delete",
                        "nodeId": node_id,
                        "userId": user_id
                    }, exclude=websocket)

                elif msg_type == "edge_add":
                    edge = msg["edge"]
                    key = f"{edge['source']}-{edge['target']}"
                    if not any(
                        f"{e['source']}-{e['target']}" == key
                        for e in room["edges"]
                    ):
                        room["edges"].append(edge)
                    await broadcast(room, {
                        "type": "edge_add",
                        "edge": edge,
                        "userId": user_id
                    }, exclude=websocket)

                elif msg_type == "edge_delete":
                    source = msg["source"]
                    target = msg["target"]
                    room["edges"] = [
                        e for e in room["edges"]
                        if not (e["source"] == source and e["target"] == target)
                    ]
                    await broadcast(room, {
                        "type": "edge_delete",
                        "source": source,
                        "target": target,
                        "userId": user_id
                    }, exclude=websocket)

                elif msg_type == "sync_full":
                    room["nodes"] = msg.get("nodes", [])
                    room["edges"] = msg.get("edges", [])
                    room["updated_at"] = datetime.utcnow().isoformat()
                    await broadcast(room, {
                        "type": "sync_full",
                        "nodes": room["nodes"],
                        "edges": room["edges"],
                        "userId": user_id
                    }, exclude=websocket)

                elif msg_type == "cursor":
                    room["clients"][websocket]["cursor"] = msg.get("cursor")
                    await broadcast(room, {
                        "type": "cursor",
                        "userId": user_id,
                        "cursor": msg.get("cursor"),
                        "color": color,
                        "name": user_name
                    }, exclude=websocket)

                elif msg_type == "ping":
                    await websocket.send(json.dumps({"type": "pong"}))

            except json.JSONDecodeError:
                pass
            except Exception as e:
                print(f"[!] Message error: {e}")

    except asyncio.TimeoutError:
        print(f"[-] Timeout from {user_id}")
    except websockets.exceptions.ConnectionClosed:
        pass
    except Exception as e:
        print(f"[!] Handler error: {e}")
    finally:
        if room_id and room_id in rooms:
            room = rooms[room_id]
            user_info = room["clients"].pop(websocket, None)
            if user_info:
                print(f"[-] {user_info['name']} left room '{room_id}' ({len(room['clients'])} online)")
                await broadcast(room, {
                    "type": "user_left",
                    "userId": user_id
                })

async def main():
    print("🚀 CodeGPO Collab Server running on ws://localhost:8765")
    print("   Waiting for connections...")
    async with websockets.serve(handler, "localhost", 8765):
        await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(main())