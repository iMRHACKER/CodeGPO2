"""
CodeGPO Auto Pull Request Engine
──────────────────────────────────
Materializes approved architecture intent into governed code artifacts
and opens a Pull Request on GitHub.

Flow:
  1. Receive graph (nodes + edges)
  2. Generate schemas via schema_generator
  3. Create a branch on GitHub
  4. Commit each generated file
  5. Open a PR with a description derived from the graph's semantic intent
  6. Return PR URL

Nothing is invented. Everything comes from the graph.
"""

import os
import base64
import json
from datetime import datetime
from typing import List, Dict, Any, Optional
from services.schema_generator import (
    generate_all_schemas,
    generate_sql,
    generate_sqlalchemy,
    generate_migration,
    generate_prisma,
    generate_openapi,
    generate_mongo_schema,
    safe_name
)

# ── GitHub config from .env ───────────────────────────────
def _token(): return os.getenv("GITHUB_TOKEN", "")
def _owner(): return os.getenv("GITHUB_OWNER", "")
def _repo():  return os.getenv("GITHUB_REPO",  "")
GITHUB_API   = "https://api.github.com"


# ── GitHub API helpers ────────────────────────────────────

import httpx

def gh_headers() -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {_token()}",
        "Accept":        "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "Content-Type":  "application/json"
    }

def check_config() -> Optional[str]:
    if not _token():
        return "GITHUB_TOKEN not set in .env"
    if not _owner():
        return "GITHUB_OWNER not set in .env"
    if not _repo():
        return "GITHUB_REPO not set in .env"
    return None


async def get_default_branch() -> str:
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.get(
            f"{GITHUB_API}/repos/{_owner()}/{_repo()}",
            headers=gh_headers()
        )
        r.raise_for_status()
        return r.json().get("default_branch", "main")


async def get_branch_sha(branch: str) -> str:
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.get(
            f"{GITHUB_API}/repos/{_owner()}/{_repo()}/git/ref/heads/{branch}",
            headers=gh_headers()
        )
        r.raise_for_status()
        return r.json()["object"]["sha"]


async def create_branch(branch_name: str, from_sha: str) -> bool:
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(
            f"{GITHUB_API}/repos/{_owner()}/{_repo()}/git/refs",
            headers=gh_headers(),
            json={
                "ref": f"refs/heads/{branch_name}",
                "sha": from_sha
            }
        )
        return r.status_code in (201, 422)  # 422 = branch already exists


async def get_file_sha(path: str, branch: str) -> Optional[str]:
    """Get existing file SHA (needed to update a file)."""
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.get(
            f"{GITHUB_API}/repos/{_owner()}/{_repo()}/contents/{path}",
            headers=gh_headers(),
            params={"ref": branch}
        )
        if r.status_code == 200:
            return r.json().get("sha")
        return None


async def commit_file(
    path: str,
    content: str,
    message: str,
    branch: str
) -> bool:
    encoded = base64.b64encode(content.encode("utf-8")).decode("utf-8")
    existing_sha = await get_file_sha(path, branch)

    payload: Dict[str, Any] = {
        "message": message,
        "content": encoded,
        "branch":  branch
    }
    if existing_sha:
        payload["sha"] = existing_sha

    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.put(
            f"{GITHUB_API}/repos/{_owner()}/{_repo()}/contents/{path}",
            headers=gh_headers(),
            json=payload
        )
        return r.status_code in (200, 201)


async def create_pull_request(
    title: str,
    body: str,
    head_branch: str,
    base_branch: str
) -> Dict[str, Any]:
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(
            f"{GITHUB_API}/repos/{_owner()}/{_repo()}/pulls",
            headers=gh_headers(),
            json={
                "title": title,
                "body":  body,
                "head":  head_branch,
                "base":  base_branch
            }
        )
        r.raise_for_status()
        return r.json()


# ── PR description builder ────────────────────────────────

def build_pr_description(
    nodes: List[Dict],
    edges: List[Dict],
    schemas: List[Dict],
    branch_name: str
) -> str:
    now     = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    changed = [s["nodeName"] for s in schemas if s.get("artifacts")]

    # Collect intents from nodes that have them
    intents = [
        f"- **{n['name']}** ({n['type']}): {n['intent']}"
        for n in nodes
        if n.get("intent")
    ]

    # Compliance summary
    compliance_nodes = [
        f"- {n['name']}: `{n['compliance_scope'].upper()}`"
        for n in nodes
        if n.get("compliance_scope")
    ]

    # Violation count
    from services.governance_service import check as run_governance
    violations = run_governance(edges, nodes)
    v_count    = len(violations)

    lines = [
        "## 🏗 CodeGPO — Auto-Generated Schema PR",
        "",
        "> This Pull Request was automatically created by **CodeGPO Nexus**.",
        "> All artifacts are derived deterministically from the Architecture & Schema Knowledge Graph.",
        "> Nothing in this PR was invented by AI — it reflects approved architectural intent.",
        "",
        "---",
        "",
        f"**Branch:** `{branch_name}`  ",
        f"**Generated:** {now}  ",
        f"**Graph:** {len(nodes)} components · {len(edges)} connections  ",
        f"**Governance:** {'✅ 0 violations' if v_count == 0 else f'⚠️ {v_count} violation(s) — review before merging'}",
        "",
        "---",
        "",
        "## 📦 Generated Artifacts",
        "",
    ]

    for schema in schemas:
        if not schema.get("artifacts"):
            continue
        artifact_types = list(schema["artifacts"].keys())
        lines.append(f"### `{schema['nodeName']}` ({schema['nodeType']})")
        if schema.get("intent"):
            lines.append(f"> {schema['intent']}")
        lines.append("")
        lines.append(f"Files generated: {', '.join(f'`{t}`' for t in artifact_types)}")
        lines.append("")

    if intents:
        lines += [
            "---",
            "",
            "## 💡 Semantic Intent",
            "",
            *intents,
            "",
        ]

    if compliance_nodes:
        lines += [
            "---",
            "",
            "## 🔒 Compliance Scope",
            "",
            *compliance_nodes,
            "",
        ]

    lines += [
        "---",
        "",
        "## ✅ Review Checklist",
        "",
        "- [ ] Schema matches intended data model",
        "- [ ] Field types are correct",
        "- [ ] Compliance annotations are accurate",
        "- [ ] No violations in governance report",
        "- [ ] Migration is safe to run",
        "",
        "---",
        "",
        "*Generated by [CodeGPO](https://codegpo.com) — Architecture Governance & AI Control Plane*"
    ]

    return "\n".join(lines)


# ── File path builder ─────────────────────────────────────

def get_file_paths(schema: Dict) -> List[Dict[str, str]]:
    """Returns list of {path, content, artifact_type} for each artifact."""
    files = []
    name  = safe_name(schema.get("nodeName", "unknown"))
    artifacts = schema.get("artifacts", {})

    EXT_MAP = {
        "sql":       ("db/schemas",     f"{name}.sql"),
        "orm":       ("db/models",      f"{name}.py"),
        "migration": ("db/migrations",  f"{name}_migration.py"),
        "prisma":    ("db/prisma",      f"{name}.prisma"),
        "openapi":   ("api/contracts",  f"{name}.yaml"),
        "mongo":     ("db/mongo",       f"{name}.js"),
    }

    for artifact_type, content in artifacts.items():
        if artifact_type in EXT_MAP:
            folder, filename = EXT_MAP[artifact_type]
            files.append({
                "path":          f"codegpo-generated/{folder}/{filename}",
                "content":       content,
                "artifact_type": artifact_type
            })

    return files


# ── Main PR creation function ─────────────────────────────

async def create_schema_pr(
    nodes: List[Dict],
    edges: List[Dict],
    pr_title: Optional[str] = None,
    target_branch: Optional[str] = None
) -> Dict[str, Any]:
    """
    Full flow:
    1. Validate config
    2. Generate schemas from graph
    3. Create branch
    4. Commit all files
    5. Open PR
    6. Return result
    """

    # ── Step 0: Validate ──────────────────────────────────
    err = check_config()
    if err:
        return {"status": "error", "message": err}

    if not nodes:
        return {"status": "error", "message": "No nodes in graph"}

    # ── Step 1: Generate schemas ──────────────────────────
    schemas = generate_all_schemas(nodes, edges)
    if not schemas:
        return {
            "status": "error",
            "message": "No schema-eligible nodes found. Add Database or API components to your architecture."
        }

    # ── Step 2: Branch setup ──────────────────────────────
    ts          = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    branch_name = f"codegpo/schema-update-{ts}"

    try:
        default_branch = await get_default_branch()
        base_sha       = await get_branch_sha(default_branch)
        await create_branch(branch_name, base_sha)
    except Exception as e:
        return {"status": "error", "message": f"GitHub branch creation failed: {str(e)}"}

    # ── Step 3: Commit files ──────────────────────────────
    committed_files = []
    failed_files    = []

    for schema in schemas:
        file_entries = get_file_paths(schema)
        for f in file_entries:
            commit_msg = (
                f"[CodeGPO] Add {f['artifact_type']} for {schema['nodeName']}\n\n"
                f"Generated from Architecture & Schema Knowledge Graph.\n"
                f"Node: {schema['nodeName']} ({schema['nodeType']})\n"
                + (f"Intent: {schema['intent']}\n" if schema.get("intent") else "")
                + "Auto-generated by CodeGPO Nexus — do not edit manually."
            )
            try:
                success = await commit_file(
                    path    = f["path"],
                    content = f["content"],
                    message = commit_msg,
                    branch  = branch_name
                )
                if success:
                    committed_files.append(f["path"])
                else:
                    failed_files.append(f["path"])
            except Exception as e:
                failed_files.append(f"{f['path']} ({str(e)})")

    # Also commit a manifest file
    manifest = {
        "generated_at": datetime.utcnow().isoformat(),
        "graph": {
            "nodes": len(nodes),
            "edges": len(edges)
        },
        "schemas": [
            {
                "node":      s["nodeName"],
                "type":      s["nodeType"],
                "intent":    s.get("intent", ""),
                "artifacts": list(s.get("artifacts", {}).keys())
            }
            for s in schemas
        ]
    }
    try:
        await commit_file(
            path    = "codegpo-generated/manifest.json",
            content = json.dumps(manifest, indent=2),
            message = "[CodeGPO] Update schema generation manifest",
            branch  = branch_name
        )
        committed_files.append("codegpo-generated/manifest.json")
    except Exception:
        pass

    if not committed_files:
        return {
            "status": "error",
            "message": "No files were committed. Check GitHub token permissions."
        }

    # ── Step 4: Open PR ───────────────────────────────────
    title = pr_title or f"[CodeGPO] Schema & Contract Update — {datetime.utcnow().strftime('%Y-%m-%d')}"
    body  = build_pr_description(nodes, edges, schemas, branch_name)

    try:
        pr = await create_pull_request(
            title       = title,
            body        = body,
            head_branch = branch_name,
            base_branch = target_branch or default_branch
        )
    except Exception as e:
        return {
            "status":          "partial",
            "message":         f"Files committed but PR creation failed: {str(e)}",
            "branch":          branch_name,
            "committed_files": committed_files
        }

    # ── Return result ─────────────────────────────────────
    return {
        "status":          "success",
        "pr_url":          pr.get("html_url"),
        "pr_number":       pr.get("number"),
        "pr_title":        pr.get("title"),
        "branch":          branch_name,
        "base_branch":     target_branch or default_branch,
        "committed_files": committed_files,
        "failed_files":    failed_files,
        "schemas_count":   len(schemas),
        "files_count":     len(committed_files),
    }


# ── Preview (no GitHub, just show what would be generated) ─

async def preview_pr(
    nodes: List[Dict],
    edges: List[Dict]
) -> Dict[str, Any]:
    """Returns what would be committed without touching GitHub."""
    schemas = generate_all_schemas(nodes, edges)

    files_preview = []
    for schema in schemas:
        for f in get_file_paths(schema):
            files_preview.append({
                "path":          f["path"],
                "artifact_type": f["artifact_type"],
                "node":          schema["nodeName"],
                "preview":       f["content"][:300] + "..." if len(f["content"]) > 300 else f["content"]
            })

    ts          = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    branch_name = f"codegpo/schema-update-{ts}"
    description = build_pr_description(nodes, edges, schemas, branch_name)

    return {
        "status":        "preview",
        "schemas_count": len(schemas),
        "files_count":   len(files_preview),
        "files":         files_preview,
        "branch_name":   branch_name,
        "pr_title":      f"[CodeGPO] Schema & Contract Update — {datetime.utcnow().strftime('%Y-%m-%d')}",
        "pr_description": description
    }

# ── Auto-sync codegpo.json (for the CI/CD governance gate) ─
async def sync_architecture_json(nodes: List[Dict], edges: List[Dict]) -> Dict[str, Any]:
    """
    Commits the current architecture (nodes + edges) as codegpo.json directly
    to the repo's default branch — no PR needed, since this is just the data
    snapshot the GitHub Actions / GitLab CI governance gate reads on every PR.
    Called automatically after every save, so the user never has to manually
    export and upload this file themselves.
    """
    err = check_config()
    if err:
        return {"status": "error", "message": err}

    try:
        branch = await get_default_branch()

        payload = {
            "nodes": nodes,
            "edges": edges,
            "synced_at": datetime.utcnow().isoformat(),
        }
        content = json.dumps(payload, indent=2)

        ok = await commit_file(
            path="codegpo.json",
            content=content,
            message="chore: sync architecture from CodeGPO",
            branch=branch,
        )

        if not ok:
            return {"status": "error", "message": "GitHub commit failed"}

        return {"status": "ok", "branch": branch, "path": "codegpo.json"}

    except Exception as e:
        return {"status": "error", "message": str(e)}
