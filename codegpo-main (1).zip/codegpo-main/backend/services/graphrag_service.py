"""
CodeGPO GraphRAG Service
─────────────────────────
Real LLM-powered violation explanations.
Provider switch: set LLM_PROVIDER=ollama, openai, gemini, or groq in env
"""

import os
import httpx
from typing import Dict, Any

LLM_PROVIDER      = os.getenv("LLM_PROVIDER", "groq")
OLLAMA_BASE_URL   = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL      = os.getenv("OLLAMA_MODEL", "llama3:latest")
OPENAI_API_KEY    = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL      = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
GEMINI_API_KEY    = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL      = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
GROQ_API_KEY      = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL        = os.getenv("GROQ_MODEL", "llama3-70b-8192")


# ── Build constrained context from graph ──────────────────
def build_graph_context(source_node: Dict, target_node: Dict,
                         all_nodes: list, all_edges: list) -> str:
    neighbour_ids = {source_node["id"], target_node["id"]}
    for e in all_edges:
        if e.get("source") == source_node["id"] or e.get("target") == source_node["id"]:
            neighbour_ids.add(e.get("source", ""))
            neighbour_ids.add(e.get("target", ""))

    visible_nodes = [n for n in all_nodes if n.get("id") in neighbour_ids]

    context_lines = ["Visible architecture context (GraphRAG constrained view):"]
    for n in visible_nodes:
        intent = n.get("intent", "")
        owner  = n.get("owner", "")
        line   = f"  - {n.get('name')} [{n.get('type')}]"
        if intent: line += f" — purpose: {intent}"
        if owner:  line += f" (owned by: {owner})"
        context_lines.append(line)

    context_lines.append("\nVisible connections:")
    for e in all_edges:
        if e.get("source") in neighbour_ids and e.get("target") in neighbour_ids:
            src_name = next((n["name"] for n in all_nodes if n["id"] == e["source"]), e["source"])
            tgt_name = next((n["name"] for n in all_nodes if n["id"] == e["target"]), e["target"])
            context_lines.append(f"  - {src_name} → {tgt_name}")

    return "\n".join(context_lines)


# ── Build prompt ──────────────────────────────────────────
def build_prompt(source_node: Dict, target_node: Dict,
                 rule: Dict, graph_context: str) -> str:
    framework_line = ""
    if rule.get("framework"):
        framework_line = f"Regulatory framework: {rule['framework']}\n"

    return f"""You are a senior software architect and security reviewer for CodeGPO.

{graph_context}

Governance violation detected:
Rule: {rule.get('ruleId')} ({rule.get('severity')} severity)
Violated by: {source_node.get('name')} ({source_node.get('type')}) → {target_node.get('name')} ({target_node.get('type')})
Rule message: {rule.get('message')}
{framework_line}
Respond in exactly this format — no markdown, no bold, no asterisks, plain text only:

WHY THIS IS RISKY:
Write 3-4 detailed sentences explaining the architectural and security risk.

PRINCIPLE VIOLATED:
Write 2 sentences naming and explaining the architectural principle being violated.

RECOMMENDED FIX:
Write 2-3 sentences with a concrete, actionable fix.

COMPLIANCE IMPACT:
Write 2 sentences about the regulatory impact. Mention specific regulations if applicable.

Be detailed, technical, and specific to these exact components."""


# ── Call Ollama ───────────────────────────────────────────
async def call_ollama(prompt: str) -> str:
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(
                f"{OLLAMA_BASE_URL}/api/generate",
                json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False}
            )
            resp.raise_for_status()
            return resp.json().get("response", "").strip()
    except httpx.ConnectError:
        return "❌ Ollama not reachable. Run: ollama serve"
    except Exception as e:
        return f"❌ Ollama error: {str(e)}"


# ── Call OpenAI ───────────────────────────────────────────
async def call_openai(prompt: str) -> str:
    if not OPENAI_API_KEY:
        return "❌ OpenAI API key not set"
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type": "application/json"},
                json={
                    "model": OPENAI_MODEL,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 2048,
                    "temperature": 0.3
                }
            )
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"].strip()
    except Exception as e:
        return f"❌ OpenAI error: {str(e)}"


# ── Call Gemini ───────────────────────────────────────────
async def call_gemini(prompt: str) -> str:
    if not GEMINI_API_KEY:
        return "❌ Gemini API key not set."
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}",
                headers={"Content-Type": "application/json"},
                json={
                    "contents": [{"parts": [{"text": prompt}]}],
                    "generationConfig": {
                        "temperature": 0.3,
                        "maxOutputTokens": 2048
                    }
                }
            )
            resp.raise_for_status()
            data = resp.json()
            return data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except Exception as e:
        return f"❌ Gemini error: {str(e)}"


# ── Call Groq ─────────────────────────────────────────────
async def call_groq(prompt: str) -> str:
    if not GROQ_API_KEY:
        return "❌ Groq API key not set. Add GROQ_API_KEY in Railway variables."
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {GROQ_API_KEY}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": GROQ_MODEL,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 2048,
                    "temperature": 0.3
                }
            )
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"].strip()
    except Exception as e:
        return f"❌ Groq error: {str(e)}"


# ── Main explain function ─────────────────────────────────
async def explain_violation(
    source_node: Dict,
    target_node: Dict,
    rule: Dict,
    all_nodes: list = None,
    all_edges: list = None
) -> Dict[str, Any]:
    all_nodes = all_nodes or []
    all_edges = all_edges or []

    graph_context = build_graph_context(source_node, target_node, all_nodes, all_edges)
    prompt = build_prompt(source_node, target_node, rule, graph_context)

    if LLM_PROVIDER == "groq" and GROQ_API_KEY:
        explanation = await call_groq(prompt)
    elif LLM_PROVIDER == "gemini" and GEMINI_API_KEY:
        explanation = await call_gemini(prompt)
    elif LLM_PROVIDER == "openai" and OPENAI_API_KEY:
        explanation = await call_openai(prompt)
    else:
        explanation = await call_ollama(prompt)

    return {
        "ruleId":      rule.get("ruleId"),
        "severity":    rule.get("severity"),
        "source":      source_node.get("name"),
        "target":      target_node.get("name"),
        "framework":   rule.get("framework"),
        "explanation": explanation,
        "provider":    LLM_PROVIDER
    }


# ── Legacy simple explain ─────────────────────────────────
def explain(edge: Dict) -> Dict:
    return {
        "explanation": (
            f"{edge.get('source')} connects to {edge.get('target')} "
            f"via {edge.get('relation', 'CONNECTS_TO')} based on architecture graph."
        )
    }
