"""
CodeGPO Compliance Report — Professional PDF Generator
Uses ReportLab Platypus for enterprise-grade layout
"""
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor, white, black
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, KeepTogether, HRFlowable
)
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
from reportlab.platypus import Flowable
import io, os, uuid
from datetime import datetime

# ── Colors ────────────────────────────────────────────────────
C_BG       = HexColor("#0F172A")
C_SURFACE  = HexColor("#1E293B")
C_CARD     = HexColor("#1E293B")
C_BORDER   = HexColor("#334155")
C_PURPLE   = HexColor("#7C3AED")
C_PURPLE_L = HexColor("#A78BFA")
C_CYAN     = HexColor("#06B6D4")
C_GREEN    = HexColor("#22C55E")
C_RED      = HexColor("#EF4444")
C_ORANGE   = HexColor("#F97316")
C_YELLOW   = HexColor("#F59E0B")
C_TEXT     = HexColor("#E2E8F0")
C_MUTED    = HexColor("#94A3B8")
C_DIM      = HexColor("#475569")

SEV_COLORS = {
    "CRITICAL": (HexColor("#7F1D1D"), HexColor("#FCA5A5"), HexColor("#EF4444")),
    "HIGH":     (HexColor("#7C2D12"), HexColor("#FED7AA"), HexColor("#F97316")),
    "MEDIUM":   (HexColor("#713F12"), HexColor("#FDE68A"), HexColor("#F59E0B")),
    "LOW":      (HexColor("#14532D"), HexColor("#BBF7D0"), HexColor("#22C55E")),
}

W, H = A4
ML, MR, MT, MB = 20*mm, 20*mm, 15*mm, 15*mm


# ── Custom Flowables ──────────────────────────────────────────
class ColorRect(Flowable):
    def __init__(self, width, height, color, radius=4):
        super().__init__()
        self.width = width
        self.height = height
        self.color = color
        self.radius = radius

    def draw(self):
        self.canv.setFillColor(self.color)
        self.canv.roundRect(0, 0, self.width, self.height, self.radius, fill=1, stroke=0)


class SeverityBadge(Flowable):
    def __init__(self, severity):
        super().__init__()
        self.severity = severity.upper()
        self.width = 60
        self.height = 16

    def draw(self):
        bg, text, _ = SEV_COLORS.get(self.severity, SEV_COLORS["LOW"])
        self.canv.setFillColor(bg)
        self.canv.roundRect(0, 0, self.width, self.height, 4, fill=1, stroke=0)
        self.canv.setFillColor(text)
        self.canv.setFont("Helvetica-Bold", 7)
        self.canv.drawCentredString(self.width/2, 5, self.severity)


class ScoreCircle(Flowable):
    def __init__(self, score, size=80):
        super().__init__()
        self.score = score
        self.width = size
        self.height = size
        self.size = size

    def draw(self):
        cx, cy = self.size/2, self.size/2
        r = self.size/2 - 4

        # Background circle
        self.canv.setFillColor(C_SURFACE)
        self.canv.circle(cx, cy, r, fill=1, stroke=0)

        # Score color
        score = self.score
        if score >= 90: color = C_GREEN
        elif score >= 70: color = C_YELLOW
        elif score >= 50: color = C_ORANGE
        else: color = C_RED

        # Score text
        self.canv.setFillColor(color)
        self.canv.setFont("Helvetica-Bold", int(self.size * 0.28))
        self.canv.drawCentredString(cx, cy + 4, str(score))
        self.canv.setFillColor(C_MUTED)
        self.canv.setFont("Helvetica", int(self.size * 0.11))
        self.canv.drawCentredString(cx, cy - 10, "/100")


# ── Styles ────────────────────────────────────────────────────
def make_styles():
    return {
        "h1": ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=22, textColor=C_TEXT, spaceAfter=4, leading=26),
        "h2": ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=14, textColor=C_TEXT, spaceAfter=4, leading=18),
        "h3": ParagraphStyle("h3", fontName="Helvetica-Bold", fontSize=11, textColor=C_PURPLE_L, spaceAfter=3, leading=14),
        "body": ParagraphStyle("body", fontName="Helvetica", fontSize=9, textColor=C_TEXT, leading=13, spaceAfter=3),
        "muted": ParagraphStyle("muted", fontName="Helvetica", fontSize=8, textColor=C_MUTED, leading=11),
        "label": ParagraphStyle("label", fontName="Helvetica-Bold", fontSize=7, textColor=C_MUTED, leading=10, spaceAfter=2),
        "center": ParagraphStyle("center", fontName="Helvetica", fontSize=9, textColor=C_TEXT, alignment=TA_CENTER),
        "tag": ParagraphStyle("tag", fontName="Helvetica-Bold", fontSize=7, textColor=C_CYAN, leading=9),
        "red": ParagraphStyle("red", fontName="Helvetica-Bold", fontSize=9, textColor=C_RED),
        "green": ParagraphStyle("green", fontName="Helvetica-Bold", fontSize=9, textColor=C_GREEN),
        "small": ParagraphStyle("small", fontName="Helvetica", fontSize=8, textColor=C_MUTED, leading=11),
    }

S = make_styles()


def sp(h=4): return Spacer(1, h*mm)
def hr(): return HRFlowable(width="100%", thickness=0.5, color=C_BORDER, spaceAfter=3, spaceBefore=3)


def section_title(title, color=C_PURPLE_L):
    return [
        Paragraph(title.upper(), ParagraphStyle("st", fontName="Helvetica-Bold", fontSize=8,
            textColor=color, letterSpacing=1.5, spaceAfter=2)),
        HRFlowable(width="100%", thickness=0.5, color=C_BORDER, spaceAfter=6),
    ]


def metric_card(label, value, value_color=C_TEXT):
    data = [[
        Paragraph(str(value), ParagraphStyle("mv", fontName="Helvetica-Bold", fontSize=20,
            textColor=value_color, leading=22, alignment=TA_CENTER)),
        Paragraph(label, ParagraphStyle("ml", fontName="Helvetica-Bold", fontSize=7,
            textColor=C_MUTED, alignment=TA_CENTER)),
    ]]
    t = Table(data, colWidths=["100%"])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), C_SURFACE),
        ("ROUNDEDCORNERS", [6]),
        ("ALIGN", (0,0), (-1,-1), "CENTER"),
        ("TOPPADDING", (0,0), (-1,-1), 8),
        ("BOTTOMPADDING", (0,0), (-1,-1), 8),
    ]))
    return t


# ── Page background ───────────────────────────────────────────
def on_page(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(C_BG)
    canvas.rect(0, 0, W, H, fill=1, stroke=0)

    # Footer bar
    canvas.setFillColor(C_SURFACE)
    canvas.rect(0, 0, W, 12*mm, fill=1, stroke=0)
    canvas.setFillColor(C_DIM)
    canvas.setFont("Helvetica", 7)
    canvas.drawString(ML, 4.5*mm, "CONFIDENTIAL — CodeGPO Architecture Governance Report")
    canvas.drawRightString(W - MR, 4.5*mm, f"Page {doc.page}")
    canvas.restoreState()


# ── Cover Page ────────────────────────────────────────────────
def cover_page(data, styles):
    story = []

    # Purple header bar
    header = Table([[""]], colWidths=[W - ML - MR], rowHeights=[2*mm])
    header.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,-1), C_PURPLE)]))
    story.append(header)
    story.append(sp(8))

    # Logo + title
    story.append(Paragraph("CodeGPO", ParagraphStyle("logo", fontName="Helvetica-Bold",
        fontSize=28, textColor=C_PURPLE_L, leading=32)))
    story.append(sp(2))
    story.append(Paragraph("Architecture Governance & Compliance Report",
        ParagraphStyle("subtitle", fontName="Helvetica", fontSize=13, textColor=C_MUTED, leading=16)))

    story.append(sp(10))
    story.append(HRFlowable(width="100%", thickness=0.5, color=C_BORDER))
    story.append(sp(8))

    # Project name
    pname = data.get("project_name", "Untitled Project")
    story.append(Paragraph("PROJECT", S["label"]))
    story.append(Paragraph(pname, ParagraphStyle("pname", fontName="Helvetica-Bold",
        fontSize=20, textColor=C_TEXT, leading=24)))
    story.append(sp(6))

    # Meta info table
    now = datetime.utcnow()
    meta = [
        ["Generated On:", now.strftime("%B %d, %Y at %H:%M UTC")],
        ["Report ID:", uuid.uuid4().hex[:12].upper()],
        ["Components:", str(data.get("total_components", 0))],
        ["Connections:", str(data.get("total_connections", 0))],
        ["Violations:", str(len(data.get("issues", [])))],
    ]
    t = Table(meta, colWidths=[35*mm, 100*mm])
    t.setStyle(TableStyle([
        ("FONTNAME", (0,0), (0,-1), "Helvetica-Bold"),
        ("FONTNAME", (1,0), (1,-1), "Helvetica"),
        ("FONTSIZE", (0,0), (-1,-1), 9),
        ("TEXTCOLOR", (0,0), (0,-1), C_MUTED),
        ("TEXTCOLOR", (1,0), (1,-1), C_TEXT),
        ("TOPPADDING", (0,0), (-1,-1), 3),
        ("BOTTOMPADDING", (0,0), (-1,-1), 3),
    ]))
    story.append(t)
    story.append(sp(10))

    # Health Score + Status
    score = data.get("health_score", 0)
    issues = data.get("issues", [])
    n_critical = len([i for i in issues if i.get("severity","").upper() == "CRITICAL"])
    n_high     = len([i for i in issues if i.get("severity","").upper() == "HIGH"])
    status_color = C_RED if len(issues) > 0 else C_GREEN
    status_text  = "VIOLATIONS DETECTED" if len(issues) > 0 else "FULLY COMPLIANT"

    score_data = [[
        ScoreCircle(score, size=90),
        [
            Paragraph("ARCHITECTURE HEALTH SCORE", S["label"]),
            sp(2),
            Paragraph(status_text, ParagraphStyle("status", fontName="Helvetica-Bold",
                fontSize=13, textColor=status_color)),
            sp(2),
            Paragraph(f"{n_critical} Critical  |  {n_high} High  |  {len(issues)} Total Issues",
                S["muted"]),
        ]
    ]]
    st = Table(score_data, colWidths=[30*mm, 120*mm])
    st.setStyle(TableStyle([
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING", (0,0), (-1,-1), 0),
        ("RIGHTPADDING", (0,0), (-1,-1), 0),
    ]))
    story.append(st)
    story.append(sp(10))
    story.append(HRFlowable(width="100%", thickness=0.5, color=C_BORDER))
    story.append(sp(6))

    # Frameworks
    story.append(Paragraph("COMPLIANCE FRAMEWORKS EVALUATED", S["label"]))
    story.append(sp(2))
    frameworks = ["GDPR", "HIPAA", "PCI-DSS", "SOC2", "ISO 27001", "DPDP Act 2023",
                  "RBI CSF", "CERT-In 2022", "IT Act 2000", "CCPA", "NIST CSF 2.0", "CIS Controls v8"]
    fw_data = [frameworks[i:i+4] for i in range(0, len(frameworks), 4)]
    for row in fw_data:
        while len(row) < 4: row.append("")
        cells = [[Paragraph(f, ParagraphStyle("fw", fontName="Helvetica-Bold", fontSize=8,
            textColor=C_CYAN, alignment=TA_CENTER))] for f in row]
        ft = Table([cells], colWidths=[W/4 - ML/2]*4)
        ft.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,-1), HexColor("#0E2A3D")),
            ("ROUNDEDCORNERS", [4]),
            ("TOPPADDING", (0,0), (-1,-1), 5),
            ("BOTTOMPADDING", (0,0), (-1,-1), 5),
            ("LEFTPADDING", (0,0), (-1,-1), 4),
            ("RIGHTPADDING", (0,0), (-1,-1), 4),
            ("LINECOLOR", (0,0), (-1,-1), HexColor("#0E4F6E")),
            ("BOX", (0,0), (-1,-1), 0.5, HexColor("#0E4F6E")),
        ]))
        story.append(ft)
        story.append(sp(2))

    story.append(PageBreak())
    return story


# ── Executive Summary ─────────────────────────────────────────
def exec_summary(data):
    story = []
    story += section_title("Executive Summary")

    issues = data.get("issues", [])
    n_critical = len([i for i in issues if i.get("severity","").upper() == "CRITICAL"])
    n_high     = len([i for i in issues if i.get("severity","").upper() == "HIGH"])
    n_medium   = len([i for i in issues if i.get("severity","").upper() == "MEDIUM"])
    n_low      = len([i for i in issues if i.get("severity","").upper() == "LOW"])
    score = data.get("health_score", 0)

    # 5 metric cards
    cw = (W - ML - MR - 12) / 5
    cards = [
        metric_card("HEALTH SCORE", score, C_YELLOW if score < 90 else C_GREEN),
        metric_card("COMPONENTS",   data.get("total_components", 0), C_CYAN),
        metric_card("CONNECTIONS",  data.get("total_connections", 0), C_PURPLE_L),
        metric_card("VIOLATIONS",   len(issues), C_RED if issues else C_GREEN),
        metric_card("CRITICAL",     n_critical, C_RED if n_critical else C_GREEN),
    ]
    row = Table([cards], colWidths=[cw]*5, spaceBefore=3)
    row.setStyle(TableStyle([("ALIGN",(0,0),(-1,-1),"CENTER"),
                              ("LEFTPADDING",(0,0),(-1,-1),3),
                              ("RIGHTPADDING",(0,0),(-1,-1),3)]))
    story.append(row)
    story.append(sp(6))

    # Severity breakdown table
    story += section_title("Violation Breakdown by Severity")
    sev_data = [
        ["Severity", "Count", "Action Required"],
        ["CRITICAL", n_critical, "Immediate — block deployment"],
        ["HIGH",     n_high,     "Fix within current sprint"],
        ["MEDIUM",   n_medium,   "Fix before next release"],
        ["LOW",      n_low,      "Address in backlog"],
    ]
    sev_colors = [C_RED, C_ORANGE, C_YELLOW, C_GREEN]
    sev_table = Table(sev_data, colWidths=[40*mm, 25*mm, 100*mm])
    ts = [
        ("BACKGROUND", (0,0), (-1,0), C_SURFACE),
        ("FONTNAME",   (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE",   (0,0), (-1,-1), 8),
        ("TEXTCOLOR",  (0,0), (-1,0), C_MUTED),
        ("TEXTCOLOR",  (0,1), (0,-1), C_TEXT),
        ("TEXTCOLOR",  (1,1), (1,-1), C_TEXT),
        ("TEXTCOLOR",  (2,1), (2,-1), C_MUTED),
        ("ALIGN",      (1,0), (1,-1), "CENTER"),
        ("TOPPADDING", (0,0), (-1,-1), 5),
        ("BOTTOMPADDING",(0,0),(-1,-1), 5),
        ("LINEBELOW",  (0,0), (-1,-1), 0.3, C_BORDER),
    ]
    for i, color in enumerate(sev_colors, 1):
        ts.append(("TEXTCOLOR", (0,i), (0,i), color))
        ts.append(("FONTNAME", (0,i), (0,i), "Helvetica-Bold"))
    sev_table.setStyle(TableStyle(ts))
    story.append(sev_table)
    story.append(sp(5))

    # Key insight
    insight = data.get("key_insight") or data.get("ai_insight", "Architecture analysis complete.")
    story += section_title("Key Insight")
    insight_t = Table([[Paragraph(insight, S["body"])]])
    insight_t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), HexColor("#1A1F2E")),
        ("LEFTPADDING",(0,0),(-1,-1), 10),
        ("RIGHTPADDING",(0,0),(-1,-1), 10),
        ("TOPPADDING",(0,0),(-1,-1), 8),
        ("BOTTOMPADDING",(0,0),(-1,-1), 8),
        ("LINEBEFORE",(0,0),(0,-1), 3, C_PURPLE),
        ("ROUNDEDCORNERS",[4]),
    ]))
    story.append(insight_t)
    story.append(PageBreak())
    return story


# ── Violations Detail ─────────────────────────────────────────
def violations_section(data):
    story = []
    issues = data.get("issues", [])

    if not issues:
        story += section_title("Violations")
        ok = Table([[Paragraph("No governance violations detected. Architecture is fully compliant.", S["body"])]])
        ok.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,-1), HexColor("#0A2E1A")),
            ("LEFTPADDING",(0,0),(-1,-1),12),
            ("TOPPADDING",(0,0),(-1,-1),10),
            ("BOTTOMPADDING",(0,0),(-1,-1),10),
            ("LINEBEFORE",(0,0),(0,-1),3,C_GREEN),
        ]))
        story.append(ok)
        story.append(PageBreak())
        return story

    story += section_title(f"Violations Detail  ({len(issues)} total)")

    for i, issue in enumerate(issues):
        sev = issue.get("severity","MEDIUM").upper()
        bg_c, text_c, accent_c = SEV_COLORS.get(sev, SEV_COLORS["LOW"])

        # Violation card
        title  = issue.get("title", f"Violation {i+1}")
        loc    = issue.get("location", "")
        prob   = issue.get("problem", issue.get("description",""))
        fix    = issue.get("fix", "Review architecture and add appropriate service layer")
        impact = issue.get("impact", [])
        if isinstance(impact, list): impact = ", ".join(impact)

        card_data = [
            [
                Paragraph(f"#{i+1}  {title}", ParagraphStyle("vt", fontName="Helvetica-Bold",
                    fontSize=9, textColor=text_c)),
                Paragraph(sev, ParagraphStyle("vs", fontName="Helvetica-Bold", fontSize=7,
                    textColor=text_c, alignment=TA_RIGHT)),
            ],
        ]
        if loc:
            card_data.append([Paragraph(f"Location: {loc}", S["small"]), ""])
        card_data.append([Paragraph(f"Problem: {prob}", S["body"]), ""])
        if impact:
            card_data.append([Paragraph(f"Impact: {impact}", S["small"]), ""])
        card_data.append([
            Paragraph(f"Fix: {fix}", ParagraphStyle("fix", fontName="Helvetica",
                fontSize=8, textColor=C_GREEN, leading=11)), ""
        ])

        # ── Accountability (named approve/override record, if any) ──
        acc_status = (issue.get("accountability_status") or "unresolved").lower()
        if acc_status == "unresolved":
            card_data.append([
                Paragraph("Accountability: UNRESOLVED — no named sign-off on file",
                    ParagraphStyle("accu", fontName="Helvetica-Bold", fontSize=7.5,
                        textColor=C_RED, leading=10)), ""
            ])
        else:
            label = "APPROVED" if acc_status == "approved" else "OVERRIDDEN"
            approver = issue.get("approved_by", "unknown")
            approved_at = issue.get("approved_at", "")
            reason = issue.get("approved_reason", "")
            acc_line = f"Accountability: {label} by {approver}"
            if approved_at:
                acc_line += f" on {approved_at}"
            card_data.append([
                Paragraph(acc_line, ParagraphStyle("acca", fontName="Helvetica-Bold",
                    fontSize=7.5, textColor=C_GREEN, leading=10)), ""
            ])
            if reason:
                card_data.append([
                    Paragraph(f'Reason: "{reason}"', ParagraphStyle("accr", fontName="Helvetica-Oblique",
                        fontSize=7.5, textColor=text_c, leading=10)), ""
                ])

        card_t = Table(card_data, colWidths=[W - ML - MR - 30*mm, 28*mm])
        card_t.setStyle(TableStyle([
            ("BACKGROUND",    (0,0), (-1,-1), bg_c),
            ("TOPPADDING",    (0,0), (-1,-1), 5),
            ("BOTTOMPADDING", (0,0), (-1,-1), 5),
            ("LEFTPADDING",   (0,0), (-1,-1), 8),
            ("RIGHTPADDING",  (0,0), (-1,-1), 8),
            ("VALIGN",        (0,0), (-1,-1), "TOP"),
            ("LINEABOVE",     (0,0), (-1,0), 2, accent_c),
            ("ROUNDEDCORNERS",[4]),
        ]))

        story.append(KeepTogether(card_t))
        story.append(sp(3))

        if (i+1) % 5 == 0 and i < len(issues)-1:
            story.append(PageBreak())
            story += section_title(f"Violations Detail (continued)")

    story.append(PageBreak())
    return story


# ── Components Table ──────────────────────────────────────────
def components_section(data):
    story = []
    story += section_title("Architecture Components")

    comps = data.get("components", [])
    if not comps:
        story.append(Paragraph("No components data available.", S["muted"]))
        story.append(PageBreak())
        return story

    headers = ["Component", "Type", "Connections", "Compliance Scope", "Status"]
    rows = [headers]
    for c in comps:
        status = c.get("status","healthy")
        rows.append([
            c.get("name",""),
            c.get("type",""),
            str(c.get("connections",0)),
            c.get("scope","General"),
            "At Risk" if status != "healthy" else "Healthy",
        ])

    colW = [55*mm, 28*mm, 22*mm, 38*mm, 22*mm]
    t = Table(rows, colWidths=colW, repeatRows=1)
    ts = [
        ("BACKGROUND",    (0,0), (-1,0), C_SURFACE),
        ("FONTNAME",      (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE",      (0,0), (-1,-1), 8),
        ("TEXTCOLOR",     (0,0), (-1,0), C_MUTED),
        ("TEXTCOLOR",     (0,1), (-1,-1), C_TEXT),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("LINEBELOW",     (0,0), (-1,-1), 0.3, C_BORDER),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_BG, HexColor("#131C2E")]),
        ("ALIGN",         (2,0), (2,-1), "CENTER"),
    ]
    # Color status column
    for i, c in enumerate(comps, 1):
        status = c.get("status","healthy")
        clr = C_RED if status != "healthy" else C_GREEN
        ts.append(("TEXTCOLOR", (4,i), (4,i), clr))
        ts.append(("FONTNAME",  (4,i), (4,i), "Helvetica-Bold"))
    t.setStyle(TableStyle(ts))
    story.append(t)
    story.append(PageBreak())
    return story


# ── Connections Table ─────────────────────────────────────────
def connections_section(data):
    story = []
    story += section_title("Connection Analysis")

    conns = data.get("connections", [])
    if not conns:
        story.append(Paragraph("No connections data available.", S["muted"]))
        story.append(PageBreak())
        return story

    headers = ["From", "To", "Status", "Rule Violated"]
    rows = [headers]
    for c in conns:
        rows.append([
            c.get("from_node",""),
            c.get("to_node",""),
            "VIOLATION" if c.get("violation") else "Compliant",
            Paragraph(c.get("rule","") or "-", ParagraphStyle("ruleCell", fontName="Helvetica",
                fontSize=7.5, leading=9)),
        ])

    colW = [55*mm, 55*mm, 25*mm, 30*mm]
    t = Table(rows, colWidths=colW, repeatRows=1)
    ts = [
        ("BACKGROUND",    (0,0), (-1,0), C_SURFACE),
        ("FONTNAME",      (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE",      (0,0), (-1,-1), 8),
        ("TEXTCOLOR",     (0,0), (-1,0), C_MUTED),
        ("TEXTCOLOR",     (0,1), (-1,-1), C_TEXT),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("LINEBELOW",     (0,0), (-1,-1), 0.3, C_BORDER),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_BG, HexColor("#131C2E")]),
    ]
    for i, c in enumerate(conns, 1):
        clr = C_RED if c.get("violation") else C_GREEN
        ts.append(("TEXTCOLOR", (2,i), (2,i), clr))
        ts.append(("FONTNAME",  (2,i), (2,i), "Helvetica-Bold"))
    t.setStyle(TableStyle(ts))
    story.append(t)
    story.append(PageBreak())
    return story


# ── Compliance Checklist ──────────────────────────────────────
def checklist_section(data):
    story = []
    story += section_title("Compliance Checklist")

    checklist = data.get("checklist", [])
    if not checklist:
        checklist = [
            {"rule":"Authentication enforced on all services",          "status":"warn"},
            {"rule":"API validation on all endpoints",                   "status":"warn"},
            {"rule":"Secure service-to-service communication",           "status":"fail" if data.get("issues") else "pass"},
            {"rule":"Database access via API layer only",                "status":"fail" if data.get("issues") else "pass"},
            {"rule":"No hardcoded credentials detected",                 "status":"pass"},
            {"rule":"Service boundaries properly defined",               "status":"fail" if data.get("issues") else "pass"},
            {"rule":"Data encryption in transit",                        "status":"warn"},
            {"rule":"PII data properly scoped (GDPR/DPDP)",             "status":"warn"},
            {"rule":"Payment data bounded (PCI-DSS)",                    "status":"warn"},
            {"rule":"Audit logging enabled",                             "status":"warn"},
            {"rule":"Error handling and fallbacks defined",              "status":"pass"},
            {"rule":"Rate limiting implemented",                         "status":"warn"},
        ]

    STATUS_CFG = {
        "pass": (C_GREEN,  "PASS"),
        "fail": (C_RED,    "FAIL"),
        "warn": (C_YELLOW, "WARN"),
    }

    headers = ["Compliance Control", "Status"]
    rows = [headers]
    status_info = []
    for item in checklist:
        s = item.get("status","warn").lower()
        rows.append([item.get("rule",""), STATUS_CFG.get(s, STATUS_CFG["warn"])[1]])
        status_info.append(s)

    colW = [130*mm, 25*mm]
    t = Table(rows, colWidths=colW, repeatRows=1)
    ts = [
        ("BACKGROUND",    (0,0), (-1,0), C_SURFACE),
        ("FONTNAME",      (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE",      (0,0), (-1,-1), 8),
        ("TEXTCOLOR",     (0,0), (-1,0), C_MUTED),
        ("TEXTCOLOR",     (0,1), (-1,-1), C_TEXT),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("LINEBELOW",     (0,0), (-1,-1), 0.3, C_BORDER),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[C_BG, HexColor("#131C2E")]),
        ("ALIGN",         (1,0), (1,-1), "CENTER"),
    ]
    for i, s in enumerate(status_info, 1):
        clr = STATUS_CFG.get(s, STATUS_CFG["warn"])[0]
        ts.append(("TEXTCOLOR", (1,i), (1,i), clr))
        ts.append(("FONTNAME",  (1,i), (1,i), "Helvetica-Bold"))
    t.setStyle(TableStyle(ts))
    story.append(t)
    story.append(PageBreak())
    return story


# ── Recommendations ───────────────────────────────────────────
def recommendations_section(data):
    story = []
    story += section_title("Recommendations")

    recs = data.get("recommendations") or [
        "Implement API Gateway as single entry point for all external and database access",
        "Enforce JWT authentication on every service-to-service endpoint",
        "Remove all direct frontend-to-database connections",
        "Add PCI-DSS compliant payment boundary with tokenization layer",
        "Enable comprehensive audit logging for GDPR, DPDP, and PCI-DSS compliance",
        "Implement rate limiting on all public-facing service endpoints",
        "Define strict service boundaries and enforce via CodeGPO governance rules",
        "Add monitoring and alerting for all critical system components",
        "Implement secrets management — no hardcoded credentials",
        "Conduct quarterly architecture governance review using CodeGPO",
    ]

    for i, rec in enumerate(recs, 1):
        row_data = [[
            Paragraph(str(i), ParagraphStyle("rn", fontName="Helvetica-Bold", fontSize=10,
                textColor=C_PURPLE_L, alignment=TA_CENTER)),
            Paragraph(rec, S["body"]),
        ]]
        rt = Table(row_data, colWidths=[12*mm, W-ML-MR-15*mm])
        rt.setStyle(TableStyle([
            ("VALIGN",        (0,0), (-1,-1), "TOP"),
            ("LEFTPADDING",   (0,0), (-1,-1), 4),
            ("TOPPADDING",    (0,0), (-1,-1), 4),
            ("BOTTOMPADDING", (0,0), (-1,-1), 4),
            ("LINEBELOW",     (0,0), (-1,-1), 0.3, C_BORDER),
        ]))
        story.append(rt)

    story.append(PageBreak())
    return story


# ── Final Verdict ─────────────────────────────────────────────
def verdict_section(data):
    story = []
    story += section_title("Final Verdict")

    issues = data.get("issues", [])
    score  = data.get("health_score", 0)
    n_crit = len([i for i in issues if i.get("severity","").upper() == "CRITICAL"])

    if not issues:
        verdict_bg    = HexColor("#0A2E1A")
        verdict_color = C_GREEN
        verdict_text  = "PRODUCTION READY"
        verdict_desc  = "Architecture meets all governance standards. No violations detected."
    elif n_crit > 0:
        verdict_bg    = HexColor("#2E0A0A")
        verdict_color = C_RED
        verdict_text  = "NOT PRODUCTION SAFE"
        verdict_desc  = data.get("verdict_reason", f"{n_crit} critical violations must be resolved before deployment.")
    else:
        verdict_bg    = HexColor("#2E1E0A")
        verdict_color = C_ORANGE
        verdict_text  = "CONDITIONAL — REVIEW REQUIRED"
        verdict_desc  = data.get("verdict_reason", "No critical issues. Review high/medium violations before deployment.")

    vt = Table([[
        Paragraph(verdict_text, ParagraphStyle("vtext", fontName="Helvetica-Bold",
            fontSize=18, textColor=verdict_color, alignment=TA_CENTER)),
    ]])
    vt.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), verdict_bg),
        ("TOPPADDING", (0,0), (-1,-1), 16),
        ("BOTTOMPADDING",(0,0),(-1,-1), 16),
        ("LINEBEFORE",  (0,0), (0,-1), 4, verdict_color),
        ("LINEAFTER",   (0,0), (0,-1), 4, verdict_color),
        ("LINEABOVE",   (0,0), (-1,0), 4, verdict_color),
        ("LINEBELOW",   (0,0), (-1,-1), 4, verdict_color),
        ("ROUNDEDCORNERS",[6]),
    ]))
    story.append(vt)
    story.append(sp(4))

    story.append(Paragraph(verdict_desc, ParagraphStyle("vdesc", fontName="Helvetica",
        fontSize=10, textColor=C_TEXT, alignment=TA_CENTER, leading=14)))
    story.append(sp(8))

    # Disclaimer
    disc = Table([[Paragraph(
        "This report was generated by CodeGPO — Architecture Governance & Compliance Platform. "
        "The findings are based on architectural patterns and should be reviewed by your security team. "
        "CodeGPO is not liable for decisions made based solely on this report.",
        S["small"]
    )]])
    disc.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), C_SURFACE),
        ("LEFTPADDING",(0,0),(-1,-1),10),
        ("RIGHTPADDING",(0,0),(-1,-1),10),
        ("TOPPADDING",(0,0),(-1,-1),8),
        ("BOTTOMPADDING",(0,0),(-1,-1),8),
    ]))
    story.append(disc)
    return story


# ── MAIN GENERATOR ────────────────────────────────────────────
def generate_report(data):
    buffer = io.BytesIO()

    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=ML, rightMargin=MR,
        topMargin=MT, bottomMargin=MB + 12*mm,
        title=f"CodeGPO Report — {data.get('project_name','Project')}",
        author="CodeGPO",
        subject="Architecture Governance & Compliance Report",
    )

    story = []
    story += cover_page(data, S)
    story += exec_summary(data)
    story += violations_section(data)
    story += components_section(data)
    story += connections_section(data)
    story += checklist_section(data)
    story += recommendations_section(data)
    story += verdict_section(data)

    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)
    buffer.seek(0)
    return buffer.getvalue()


def generate_and_save_report(data):
    pdf = generate_report(data)
    os.makedirs("/tmp/reports", exist_ok=True)
    path = f"/tmp/reports/{uuid.uuid4().hex}.pdf"
    with open(path, "wb") as f:
        f.write(pdf)
    return pdf, path
