"""
CodeGPO Accountability Service
================================
Named, timestamped, immutable record of every violation approve/override
decision — the evidence layer that sits on top of the deterministic
governance engine.

Design rules (do not violate these — they're the whole point):
  1. Records are CREATE-only. No update, no delete endpoint exists anywhere.
  2. Every record is scoped to org_id — never global.
  3. violation_id is a stable hash of (rule_id, source, target) so the same
     violation always maps to the same id across re-evaluations of the graph.
"""
import hashlib
import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional

from core.neo4j import get_session


def compute_violation_id(rule_id: str, source: str, target: str) -> str:
    """Deterministic id for a violation — same rule+source+target always hashes the same."""
    raw = f"{rule_id}|{source or ''}|{target or ''}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def create_approval(
    org_id: str,
    violation_id: str,
    rule_id: str,
    source: str,
    target: str,
    decision: str,          # "approved" | "overridden"
    approved_by_id: str,
    approved_by_email: str,
    reason: str,
) -> Dict[str, Any]:
    if decision not in ("approved", "overridden", "commented"):
        raise ValueError("decision must be 'approved', 'overridden', or 'commented'")

    record = {
        "id": str(uuid.uuid4()),
        "org_id": org_id,
        "violation_id": violation_id,
        "rule_id": rule_id,
        "source": source or "",
        "target": target or "",
        "decision": decision,
        "approved_by_id": approved_by_id,
        "approved_by_email": approved_by_email,
        "reason": reason or "",
        "timestamp": datetime.utcnow().isoformat(),
    }

    with get_session() as s:
        s.run(
            """
            CREATE (a:Approval {
                id:                $id,
                org_id:            $org_id,
                violation_id:      $violation_id,
                rule_id:           $rule_id,
                source:            $source,
                target:            $target,
                decision:          $decision,
                approved_by_id:    $approved_by_id,
                approved_by_email: $approved_by_email,
                reason:            $reason,
                timestamp:         $timestamp
            })
            """,
            **record,
        )
    return record


def get_latest_approval(org_id: str, violation_id: str) -> Optional[Dict[str, Any]]:
    """Most recent approval record for a given violation, if any."""
    with get_session() as s:
        r = s.run(
            """
            MATCH (a:Approval {org_id: $org_id, violation_id: $violation_id})
            RETURN a ORDER BY a.timestamp DESC LIMIT 1
            """,
            org_id=org_id, violation_id=violation_id,
        ).single()
        return dict(r["a"]) if r else None


def list_approvals(org_id: str, violation_id: Optional[str] = None) -> List[Dict[str, Any]]:
    """Full audit log for this org, newest first. Optionally filtered to one violation."""
    with get_session() as s:
        if violation_id:
            rows = s.run(
                "MATCH (a:Approval {org_id: $org_id, violation_id: $violation_id}) "
                "RETURN a ORDER BY a.timestamp DESC",
                org_id=org_id, violation_id=violation_id,
            ).data()
        else:
            rows = s.run(
                "MATCH (a:Approval {org_id: $org_id}) RETURN a ORDER BY a.timestamp DESC",
                org_id=org_id,
            ).data()
    return [r["a"] for r in rows]


def attach_approval_status(violations: List[Dict[str, Any]], org_id: str) -> List[Dict[str, Any]]:
    """
    Given a list of violations from governance_service.check(), attach
    violationId + accountability status (latest approval, if any) to each.
    Does not mutate governance logic — purely additive.
    """
    with get_session() as s:
        rows = s.run(
            "MATCH (a:Approval {org_id: $org_id}) "
            "RETURN a.violation_id AS vid, a ORDER BY a.timestamp DESC",
            org_id=org_id,
        ).data()

    latest_by_vid: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        vid = row["vid"]
        entry = row["a"]
        if entry.get("decision") == "commented":
            continue  # comments are notes, not resolutions — never change the status badge
        if vid not in latest_by_vid:   # first hit per vid = most recent (already ordered desc)
            latest_by_vid[vid] = dict(entry)

    enriched = []
    for v in violations:
        vid = compute_violation_id(v.get("ruleId", ""), v.get("source", ""), v.get("target", ""))
        approval = latest_by_vid.get(vid)
        enriched.append({
            **v,
            "violationId": vid,
            "accountability": {
                "status": approval["decision"] if approval else "unresolved",
                "approvedBy": approval["approved_by_email"] if approval else None,
                "reason": approval["reason"] if approval else None,
                "timestamp": approval["timestamp"] if approval else None,
            } if approval else {
                "status": "unresolved",
                "approvedBy": None,
                "reason": None,
                "timestamp": None,
            },
        })
    return enriched
