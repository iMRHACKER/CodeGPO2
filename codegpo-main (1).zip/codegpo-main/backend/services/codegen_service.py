"""
CodeGPO AI Code Generation Service
────────────────────────────────────
1. User requirement lena
2. Groq/Gemini se code generate karna
3. CodeGPO governance check karna
4. Compliant code deliver karna
"""

import os
import httpx
from typing import Dict, Any, Optional

GROQ_API_KEY   = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL     = os.getenv("GROQ_MODEL", "llama-3.1-8b-instant")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL   = os.getenv("GEMINI_MODEL", "gemini-3.1-flash-lite-preview")

# ── Governance Rules ──────────────────────────────────────────
GOVERNANCE_RULES = [
    {"id": "GOV-001", "pattern": "direct.*database|db\\.query|db\\.execute|cursor\\.execute", "message": "Direct database access detected — use repository pattern", "severity": "CRITICAL"},
    {"id": "GOV-002", "pattern": "password.*=.*['\"]|secret.*=.*['\"]|api_key.*=.*['\"]", "message": "Hardcoded credentials detected — use environment variables", "severity": "CRITICAL"},
    {"id": "GOV-003", "pattern": "eval\\(|exec\\(|subprocess\\.call|os\\.system", "message": "Dangerous code execution pattern detected", "severity": "CRITICAL"},
    {"id": "GOV-004", "pattern": "SELECT \\*|select \\*", "message": "SELECT * detected — specify required columns only", "severity": "HIGH"},
    {"id": "GOV-005", "pattern": "except:|except Exception", "message": "Broad exception handling — catch specific exceptions", "severity": "MEDIUM"},
    {"id": "GOV-006", "pattern": "print\\(|console\\.log", "message": "Debug statements detected — use proper logging", "severity": "LOW"},
    {"id": "GOV-007", "pattern": "http://(?!localhost)", "message": "Non-HTTPS URL detected — use HTTPS in production", "severity": "HIGH"},
    {"id": "GOV-008", "pattern": "TODO|FIXME|HACK|XXX", "message": "Technical debt markers detected", "severity": "LOW"},
]

# ── Build governance-aware prompt ─────────────────────────────
def build_governed_prompt(requirement: str, language: str, arch_context: Optional[dict]) -> str:
    arch_info = ""
    if arch_context and arch_context.get("nodes"):
        nodes = arch_context["nodes"]
        node_list = "\n".join([f"  - {n.get('name')} ({n.get('type')})" for n in nodes[:10]])
        arch_info = f"""
Current Architecture Context:
{node_list}

You MUST follow these architecture constraints:
- Always use repository pattern for database access
- Never access databases directly from controllers/routes
- Use dependency injection for services
- Route all external calls through service layer
"""

    return f"""You are a senior software engineer following strict governance rules.

{arch_info}

MANDATORY CODING STANDARDS — you MUST follow these:
1. NEVER hardcode credentials, API keys, or secrets — always use environment variables
2. NEVER use direct database queries in controllers — use repository pattern
3. NEVER use SELECT * — always specify columns
4. ALWAYS use HTTPS for external URLs
5. ALWAYS catch specific exceptions, not broad Exception
6. ALWAYS use proper logging instead of print/console.log
7. NEVER use eval(), exec(), or os.system()
8. ALWAYS validate and sanitize all inputs

Task: {requirement}
Language: {language}

Generate clean, production-ready, governance-compliant code.
Include proper error handling, input validation, and comments.
Return ONLY the code — no explanations outside of code comments."""

# ── Check generated code against governance rules ─────────────
def check_governance(code: str) -> list:
    import re
    violations = []
    for rule in GOVERNANCE_RULES:
        if re.search(rule["pattern"], code, re.IGNORECASE):
            violations.append({
                "ruleId": rule["id"],
                "message": rule["message"],
                "severity": rule["severity"]
            })
    return violations

# ── Call Groq ─────────────────────────────────────────────────
async def call_groq(prompt: str) -> str:
    if not GROQ_API_KEY:
        return "❌ Groq API key not set"
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={"Authorization": f"Bearer {GROQ_API_KEY}", "Content-Type": "application/json"},
                json={
                    "model": GROQ_MODEL,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 2048,
                    "temperature": 0.2
                }
            )
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"].strip()
    except Exception as e:
        return f"❌ Groq error: {str(e)}"

# ── Call Gemini ───────────────────────────────────────────────
async def call_gemini(prompt: str) -> str:
    if not GEMINI_API_KEY:
        return "❌ Gemini API key not set"
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}",
                headers={"Content-Type": "application/json"},
                json={
                    "contents": [{"parts": [{"text": prompt}]}],
                    "generationConfig": {"temperature": 0.2, "maxOutputTokens": 2048}
                }
            )
            resp.raise_for_status()
            data = resp.json()
            return data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except Exception as e:
        return f"❌ Gemini error: {str(e)}"

# ── Main generate and govern function ─────────────────────────
async def generate_and_govern(
    requirement: str,
    language: str = "python",
    provider: str = "groq",
    architecture_context: Optional[dict] = None
) -> Dict[str, Any]:

    # Step 1: Build governed prompt
    prompt = build_governed_prompt(requirement, language, architecture_context)

    # Step 2: Generate code
    if provider == "gemini" and GEMINI_API_KEY:
        generated_code = await call_gemini(prompt)
    else:
        generated_code = await call_groq(prompt)

    # Step 3: Check generated code for violations
    violations = check_governance(generated_code)

    # Step 4: If violations found — auto fix with specific instructions
    if violations:
        critical_and_high = [v for v in violations if v["severity"] in ["CRITICAL", "HIGH"]]
        if critical_and_high:
            violation_details = chr(10).join([f"- {v['ruleId']} ({v['severity']}): {v['message']}" for v in critical_and_high])

            fix_prompt = f"""You are a senior software engineer. Fix ALL governance violations in this code.

ORIGINAL CODE WITH VIOLATIONS:
{generated_code}

VIOLATIONS TO FIX:
{violation_details}

SPECIFIC FIXES REQUIRED:
- GOV-001 (Direct DB access): Replace direct db calls with repository pattern class
- GOV-002 (Hardcoded credentials): Replace ALL hardcoded values with os.environ.get() or os.getenv()
- GOV-004 (SELECT *): Replace SELECT * with specific column names
- GOV-007 (HTTP URLs): Replace http:// with https://
- GOV-005 (Broad exceptions): Replace bare except: or except Exception: with specific exception types

Return ONLY the fixed, complete code. No explanations. No markdown. Just the code."""

            if provider == "gemini" and GEMINI_API_KEY:
                generated_code = await call_gemini(fix_prompt)
            else:
                generated_code = await call_groq(fix_prompt)

            # Re-check after fix
            violations = check_governance(generated_code)

            # If still critical violations — try one more time
            still_critical = [v for v in violations if v["severity"] == "CRITICAL"]
            if still_critical:
                final_fix = f"""Fix these CRITICAL issues in the code below. Return ONLY corrected code:

{generated_code}

MUST FIX:
{chr(10).join([f"- {v['message']}" for v in still_critical])}

Use os.getenv() for all credentials. Use repository pattern for database access."""

                if provider == "gemini" and GEMINI_API_KEY:
                    generated_code = await call_gemini(final_fix)
                else:
                    generated_code = await call_groq(final_fix)

                violations = check_governance(generated_code)

    # Step 5: Calculate compliance score
    critical_count = len([v for v in violations if v["severity"] == "CRITICAL"])
    high_count = len([v for v in violations if v["severity"] == "HIGH"])
    compliance_score = max(0, 100 - (critical_count * 25) - (high_count * 10))

    return {
        "code": generated_code,
        "violations": violations,
        "compliance_score": compliance_score,
        "is_compliant": len([v for v in violations if v["severity"] in ["CRITICAL", "HIGH"]]) == 0,
        "provider": provider,
        "language": language,
        "governed": True
    }
