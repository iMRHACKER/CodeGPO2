from core.neo4j import get_session


def add_node(node, org_id: str):
    """Save node with ALL fields to Neo4j, scoped to the caller's org (MERGE on org_id+id)."""
    d = node.dict()
    with get_session() as s:
        s.run(
            """
            MERGE (n:Node {org_id: $org_id, id: $id})
            SET n.label            = $label,
                n.name             = $name,
                n.node_type        = $node_type,
                n.intent           = $intent,
                n.owner            = $owner,
                n.team             = $team,
                n.criticality      = $criticality,
                n.compliance_scope = $compliance_scope,
                n.fields           = $fields
            """,
            org_id=org_id,
            id=d["id"],
            label=d.get("label") or d.get("name", ""),
            name=d.get("name") or d.get("label", ""),
            node_type=d.get("type", ""),
            intent=d.get("intent", ""),
            owner=d.get("owner", ""),
            team=d.get("team", ""),
            criticality=d.get("criticality", ""),
            compliance_scope=d.get("compliance_scope", ""),
            fields=d.get("fields", "[]"),
        )


def add_edge(edge, org_id: str):
    with get_session() as s:
        s.run(
            """
            MATCH (a:Node {org_id: $org_id, id: $source}), (b:Node {org_id: $org_id, id: $target})
            MERGE (a)-[r:REL {relation: $relation}]->(b)
            """,
            org_id=org_id,
            source=edge.source,
            target=edge.target,
            relation=edge.relation,
        )


def get_graph(org_id: str):
    """Load all nodes and edges for this org only, normalized for frontend."""
    with get_session() as s:
        raw_nodes = s.run(
            "MATCH (n:Node {org_id: $org_id}) RETURN n.id AS id, n.label AS label, n.name AS name, "
            "n.node_type AS type, n.intent AS intent, n.owner AS owner, "
            "n.team AS team, n.criticality AS criticality, "
            "n.compliance_scope AS compliance_scope, n.fields AS fields",
            org_id=org_id,
        ).data()

        raw_edges = s.run(
            "MATCH (a:Node {org_id: $org_id})-[r:REL]->(b:Node {org_id: $org_id}) "
            "RETURN a.id AS source, b.id AS target, r.relation AS relation",
            org_id=org_id,
        ).data()

    nodes = []
    for n in raw_nodes:
        nodes.append({
            "id":               n["id"],
            "label":            n["label"] or n["name"] or "",
            "name":             n["name"] or n["label"] or "",
            "type":             n["type"] or "",
            "intent":           n["intent"] or "",
            "owner":            n["owner"] or "",
            "team":             n["team"] or "",
            "criticality":      n["criticality"] or "",
            "compliance_scope": n["compliance_scope"] or "",
            "fields":           n["fields"] or "[]",
        })

    edges = [
        {"source": e["source"], "target": e["target"], "relation": e["relation"] or ""}
        for e in raw_edges
    ]

    return {"nodes": nodes, "edges": edges}


def save_full_graph(nodes_data: list, edges_data: list, org_id: str):
    """Replace this org's graph in Neo4j with new nodes + edges. Never touches other orgs' data."""
    with get_session() as s:
        s.run("MATCH (n:Node {org_id: $org_id}) DETACH DELETE n", org_id=org_id)

        for n in nodes_data:
            s.run(
                """
                CREATE (node:Node {
                    org_id:           $org_id,
                    id:               $id,
                    label:            $label,
                    name:             $name,
                    node_type:        $node_type,
                    intent:           $intent,
                    owner:            $owner,
                    team:             $team,
                    criticality:      $criticality,
                    compliance_scope: $compliance_scope,
                    fields:           $fields
                })
                """,
                org_id=org_id,
                id=n.get("id", ""),
                label=n.get("label") or n.get("name", ""),
                name=n.get("name") or n.get("label", ""),
                node_type=n.get("type", ""),
                intent=n.get("intent", ""),
                owner=n.get("owner", ""),
                team=n.get("team", ""),
                criticality=n.get("criticality", ""),
                compliance_scope=n.get("compliance_scope", ""),
                fields=n.get("fields", "[]"),
            )

        for e in edges_data:
            s.run(
                """
                MATCH (a:Node {org_id: $org_id, id: $source}), (b:Node {org_id: $org_id, id: $target})
                CREATE (a)-[r:REL {relation: $relation}]->(b)
                """,
                org_id=org_id,
                source=e.get("source", ""),
                target=e.get("target", ""),
                relation=e.get("relation", ""),
            )
