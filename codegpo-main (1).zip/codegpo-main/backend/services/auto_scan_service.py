"""
CodeGPO Auto-Scan Service
==========================
Server-side port of the browser's project scanner (projectScanner.js).
Reads package.json / requirements.txt from a GitHub repo and detects the
likely architecture (database, queue, cache, external service dependencies)
automatically — no browser, no manual import.

This is a simplified first version: it covers package.json and
requirements.txt (the two most common cases). OpenAPI/Terraform/K8s parsing
exists in the browser scanner but isn't ported here yet.
"""
import io
import json
import zipfile
import re
from typing import List, Dict, Any, Tuple

import httpx

DB_LIBS = ["mongoose", "mongodb", "pg", "postgres", "mysql", "mysql2", "sqlite", "sqlite3",
           "redis", "ioredis", "neo4j", "dynamodb", "cassandra", "prisma", "sequelize",
           "typeorm", "knex", "pymongo", "psycopg", "sqlalchemy", "peewee", "tortoise",
           "supabase", "django.db", "mongoengine", "motor", "aioredis", "asyncpg"]

QUEUE_LIBS = ["kafka", "kafkajs", "rabbitmq", "amqplib", "bull", "bullmq", "sqs", "celery",
              "rq", "nats", "pubsub", "eventbus", "django_celery", "pika", "confluent", "kombu"]

API_LIBS = ["express", "fastapi", "django", "flask", "koa", "hapi", "nestjs", "fastify",
            "rest_framework", "djangorestframework", "spring", "laravel", "rails",
            "gin", "echo", "fiber", "axum", "actix"]

EXTERNAL_LIBS = ["stripe", "twilio", "sendgrid", "mailgun", "paypal", "firebase", "aws-sdk",
                 "boto3", "axios", "requests", "social-auth", "djoser", "oauth", "braintree",
                 "plaid", "algolia", "cloudinary", "pusher", "intercom", "hubspot",
                 "salesforce", "zendesk", "okta", "auth0"]

CACHE_LIBS = ["redis", "ioredis", "memcached", "node-cache", "django_redis",
              "cache_framework", "aioredis", "pylibmc"]

WORKER_LIBS = ["bull", "bullmq", "celery", "rq", "agenda", "node-cron", "apscheduler",
               "django_celery_beat", "sidekiq", "delayed_job", "faktory"]

GATEWAY_LIBS = ["nginx", "traefik", "kong", "envoy", "haproxy", "caddy", "istio", "linkerd"]


def _match(text: str, libs: List[str]) -> bool:
    t = text.lower()
    return any(lib in t for lib in libs)


def _find_lib(text: str, libs: List[str]) -> str:
    t = text.lower()
    return next((lib for lib in libs if lib in t), "")


def _capitalize_lib(lib: str) -> str:
    return lib[:1].upper() + lib[1:] if lib else lib


def _make_id(name: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9]", "-", name).lower()[:40]
    return f"svc-{cleaned}"


def _detect_type_from_content(name: str, content: str) -> str:
    if _match(content, GATEWAY_LIBS):
        return "Gateway"
    if _match(name + content, WORKER_LIBS):
        return "Worker"
    if _match(content, QUEUE_LIBS):
        return "Queue"
    if _match(content, CACHE_LIBS):
        return "Cache"
    if _match(content, DB_LIBS):
        return "Database"
    if _match(content, EXTERNAL_LIBS):
        return "External"
    if _match(content, API_LIBS):
        return "Service"
    return "Service"


def parse_package_json(content: str, filename: str = "app") -> Dict[str, List[Dict]]:
    try:
        pkg = json.loads(content)
        all_deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
        dep_string = " ".join(all_deps.keys())
        name = pkg.get("name", filename)
        return _build_nodes(name, dep_string)
    except Exception:
        return {"nodes": [], "edges": []}


def parse_requirements(content: str, filename: str = "app") -> Dict[str, List[Dict]]:
    lines = []
    for line in content.split("\n"):
        line = line.strip().split("==")[0].split(">=")[0].split("~=")[0]
        if line and not line.startswith("#"):
            lines.append(line)
    dep_string = " ".join(lines)
    name = re.sub(r"requirements[-_]?", "", filename, flags=re.I).replace(".txt", "").strip() or "PythonApp"
    return _build_nodes(name, dep_string)


def _build_nodes(name: str, dep_string: str) -> Dict[str, List[Dict]]:
    nodes = []
    seen = set()

    nodes.append({"id": _make_id(name), "name": name, "type": _detect_type_from_content(name, dep_string)})
    seen.add(name)

    for libs, node_type in [(DB_LIBS, "Database"), (QUEUE_LIBS, "Queue"),
                             (EXTERNAL_LIBS, "External"), (CACHE_LIBS, "Cache")]:
        if _match(dep_string, libs):
            lib = _find_lib(dep_string, libs)
            if lib and lib not in seen:
                seen.add(lib)
                nodes.append({"id": _make_id(lib), "name": _capitalize_lib(lib), "type": node_type})

    return {"nodes": nodes, "edges": []}


def _merge_scan_results(results: List[Dict[str, List[Dict]]]) -> Dict[str, List[Dict]]:
    merged_nodes = {}
    for r in results:
        for n in r.get("nodes", []):
            merged_nodes[n["id"]] = n
    return {"nodes": list(merged_nodes.values()), "edges": []}


def detect_edges_by_type(nodes: List[Dict]) -> List[Dict]:
    """
    Connects nodes using standard architecture patterns based on their type —
    e.g. User -> Gateway -> Service -> Database. This is a heuristic, not a
    real code-import analysis — it fires whenever a new dependency (Database,
    Queue, Cache, External service) is auto-detected, so it gets wired into
    the existing architecture instead of floating disconnected.
    """
    edges = []
    seen = set()

    def add_edge(src, tgt):
        if src == tgt:
            return
        key = f"{src}→{tgt}"
        if key in seen:
            return
        seen.add(key)
        edges.append({"source": src, "target": tgt, "relation": ""})

    by_type: Dict[str, List[Dict]] = {}
    for n in nodes:
        t = (n.get("type") or "Service").lower()
        by_type.setdefault(t, []).append(n)

    def get(t):
        return by_type.get(t, [])

    users, gateways, services, apis, auths = get("user"), get("gateway"), get("service"), get("api"), get("auth")
    dbs, caches, queues, workers, externals = get("database"), get("cache"), get("queue"), get("worker"), get("external")
    monitors, iot = get("monitoring"), get("iot")

    for u in users:
        if gateways:
            for g in gateways: add_edge(u["id"], g["id"])
        elif apis:
            for a in apis: add_edge(u["id"], a["id"])
        elif services:
            add_edge(u["id"], services[0]["id"])

    for g in gateways:
        for a in auths: add_edge(g["id"], a["id"])
        for s in services: add_edge(g["id"], s["id"])
        for a in apis: add_edge(g["id"], a["id"])

    if not gateways:
        for u in users:
            for a in auths: add_edge(u["id"], a["id"])

    for a in auths:
        if dbs:
            add_edge(a["id"], dbs[0]["id"])
        elif services:
            add_edge(a["id"], services[0]["id"])

    for s in services:
        for d in dbs: add_edge(s["id"], d["id"])
        for c in caches: add_edge(s["id"], c["id"])
        for q in queues: add_edge(s["id"], q["id"])
        for e in externals: add_edge(s["id"], e["id"])

    for a in apis:
        for d in dbs: add_edge(a["id"], d["id"])
        for c in caches: add_edge(a["id"], c["id"])
        for q in queues: add_edge(a["id"], q["id"])
        for e in externals: add_edge(a["id"], e["id"])

    for q in queues:
        for w in workers: add_edge(q["id"], w["id"])
    for w in workers:
        for d in dbs: add_edge(w["id"], d["id"])

    for i in iot:
        if gateways:
            for g in gateways: add_edge(i["id"], g["id"])
        elif services:
            add_edge(i["id"], services[0]["id"])

    for m in monitors:
        for n in [*services, *apis, *dbs, *gateways]:
            add_edge(m["id"], n["id"])

    return edges


async def scan_repo_for_architecture(owner: str, repo: str, branch: str = "main") -> Dict[str, Any]:
    """
    Downloads the repo ZIP from GitHub, finds package.json / requirements.txt
    files anywhere in the tree, and builds a best-effort architecture graph.
    """
    branches_to_try = [branch, "main", "master", "develop", "dev"]
    zip_bytes = None

    async with httpx.AsyncClient(follow_redirects=True, timeout=30) as client:
        for b in branches_to_try:
            url = f"https://github.com/{owner}/{repo}/archive/refs/heads/{b}.zip"
            try:
                resp = await client.get(url)
                if resp.status_code == 200:
                    zip_bytes = resp.content
                    break
            except Exception:
                continue

    if not zip_bytes:
        return {"status": "error", "message": f"Could not download {owner}/{repo}"}

    results = []
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as z:
            for name in z.namelist():
                base = name.split("/")[-1]
                if base == "package.json":
                    content = z.read(name).decode("utf-8", errors="ignore")
                    results.append(parse_package_json(content, filename=name))
                elif base.startswith("requirements") and base.endswith(".txt"):
                    content = z.read(name).decode("utf-8", errors="ignore")
                    results.append(parse_requirements(content, filename=base))
    except Exception as e:
        return {"status": "error", "message": f"Failed to read ZIP: {e}"}

    if not results:
        return {"status": "error", "message": "No package.json or requirements.txt found"}

    merged = _merge_scan_results(results)
    return {"status": "ok", "nodes": merged["nodes"], "edges": merged["edges"]}
