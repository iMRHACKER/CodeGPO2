"""
CodeGPO Governance Service — Enterprise Edition
================================================
Architecture Rules : 30  (GOV-001 to GOV-030)
Compliance Rules   : 672 across 26 frameworks

Framework          Rules   Reference
─────────────────────────────────────────────────
GDPR               8       Articles 5,6,7,9,17,25,32,44
HIPAA              7       §164.308, §164.310, §164.312, §164.314
PCI-DSS v4.0       8       Requirements 1,2,3,4,7,8,10,12
SOC2 Type II       6       CC6.1,CC6.6,CC6.7,CC7.2,CC8.1,CC9.2
ISO 27001:2022     6       A.5,A.8,A.9,A.12,A.13,A.14
DPDP Act 2023      5       S.6,S.8,S.9,S.16,S.17 (India)
RBI CSF            5       Annex I,II,III,IV,V (India RBI)
CERT-In 2022       4       Directions 2022 (India CERT-In)
IT Act 2000        3       S.43A, S.66, S.72 (India)
CCPA 2018          5       §1798.100,§1798.105,§1798.120,§1798.140,§1798.150 (USA)
NIST CSF 2.0       5       ID,PR,DE,RS,RC Functions
CIS Controls v8    6       Controls 1,4,5,6,12,13,14
"""
from typing import List, Dict, Any

# ── Helpers ───────────────────────────────────────────────
def is_type(node: Dict, types: List[str]) -> bool:
    t = (node.get("type") or node.get("node_type") or "").lower()
    return any(typ.lower() in t for typ in types)

def has_comp(node: Dict, tag: str) -> bool:
    scope = (node.get("compliance_scope") or "").lower()
    return tag.lower() in scope

def has_any(node: Dict, tags: List[str]) -> bool:
    return any(has_comp(node, t) for t in tags)

def any_node(nodes, types):
    return any(is_type(n, types) for n in nodes)

def nodes_with(nodes, types):
    return [n for n in nodes if is_type(n, types)]

def nodes_comp(nodes, tag):
    return [n for n in nodes if has_comp(n, tag)]

def connected(edges, src_id, tgt_id):
    return any(e.get("source") == src_id and e.get("target") == tgt_id for e in edges)

def reachable(edges, src_id, tgt_types, node_map):
    """Check if src_id can reach any node of tgt_types through edges"""
    return any(
        e.get("source") == src_id and is_type(node_map.get(e.get("target",""),{}), tgt_types)
        for e in edges
    )

# ── Type Groups ───────────────────────────────────────────
FRONTEND  = ["user","client","browser","frontend","ui","mobile","app","web"]
DB        = ["database","db","sql","mongo","postgres","mysql","neo4j","redis","pg","sqlite","dynamo","cassandra","elastic","elasticsearch","opensearch","clickhouse","bigquery","snowflake","supabase","aurora","firestore","cosmosdb"]
EXTERNAL  = ["external","vendor","third-party","stripe","twilio","sendgrid","aws","gcp","azure","firebase","segment","mixpanel","amplitude","intercom","hubspot","salesforce","datadog","sentry","razorpay","paytm","phonepe"]
SERVICE   = ["service","api","backend","microservice","server","rest","graphql","grpc","rpc"]
QUEUE     = ["queue","kafka","rabbit","rabbitmq","sqs","bull","celery","pubsub","nats","kinesis","eventbus","bus","topic","stream","event"]
GATEWAY   = ["gateway","proxy","nginx","kong","traefik","load balancer","ingress","reverse proxy","cdn","cloudflare","apigee","envoy"]
WORKER    = ["worker","job","cron","scheduler","celery","task","consumer","processor","lambda","function","serverless","batch"]
CACHE     = ["cache","redis","memcached","varnish","hazelcast"]
AUTH      = ["auth","authentication","authorization","oauth","jwt","sso","identity","keycloak","auth0","okta","cognito","iam","rbac","ldap","saml"]
SECRETS   = ["secret","vault","config","env","credential","hsm","kms","ssm","parameter store"]
IOT       = ["iot","device","sensor","edge","embedded","firmware","vehicle","car","bike","ev","scooter","telematics","gps","tracker","obd"]
ADMIN     = ["admin","dashboard","backoffice","back-office","cms","ops","management","control panel","internal portal"]
PAYMENT   = ["payment","billing","stripe","checkout","invoice","transaction","pci","card","wallet","razorpay","paytm","phonepe","upi","banking"]
SEARCH    = ["elastic","opensearch","solr","algolia","typesense","search"]
MONITOR   = ["monitoring","logging","log","trace","apm","prometheus","grafana","datadog","newrelic","sentry","splunk","elk","loki","audit"]
ENCRYPT   = ["tls","ssl","encrypt","https","mtls","hsm","kms","vault"]

SEV = {"CRITICAL":0,"HIGH":1,"MEDIUM":2,"LOW":3}

def viol(rule_id, sev, msg, s_id, t_id, desc="", fix="", ref="", framework=None):
    return {
        "ruleId":rule_id, "severity":sev, "message":msg,
        "description":desc, "fix":fix, "reference":ref,
        "framework":framework, "source":s_id, "target":t_id,
    }

def struct_viol(rule_id, sev, msg, desc="", fix="", ref="", framework=None):
    return {
        "ruleId":rule_id, "severity":sev, "message":msg,
        "description":desc, "fix":fix, "reference":ref,
        "framework":framework, "source":"", "target":"",
    }


def check(edges: List[Dict], nodes: List[Dict] = None) -> List[Dict]:
    nodes = nodes or []
    node_map = {n["id"]: n for n in nodes}
    violations = []

    # ════════════════════════════════════════════════════════════════
    # PART A — EDGE RULES (Architecture + Compliance edge checks)
    # ════════════════════════════════════════════════════════════════
    for edge in edges:
        s_id = edge.get("source") or edge.get("a.id","")
        t_id = edge.get("target") or edge.get("b.id","")
        s = node_map.get(s_id,{})
        t = node_map.get(t_id,{})

        # ── ARCHITECTURE RULES ────────────────────────────────────────────

        if is_type(s,FRONTEND) and is_type(t,DB):
            has_mediator = any(
                (e.get("source") == s_id and
                 is_type(node_map.get(e.get("target",""),{}), GATEWAY+SERVICE+AUTH))
                for e in edges if e != edge
            )
            if not has_mediator:
                violations.append(viol("GOV-001","CRITICAL","Client cannot directly access Database",s_id,t_id,
                    "Direct client-to-database exposes your entire data layer and bypasses all access controls.",
                    "Add an API or Service layer. Never expose DB credentials to clients.")); continue

        if is_type(s,EXTERNAL) and is_type(t,DB):
            violations.append(viol("GOV-002","CRITICAL","External service cannot directly access internal Database",s_id,t_id,
                "External DB access exposes schema, allows data exfiltration, bypasses all controls.",
                "Create authenticated API endpoints for external data access.")); continue

        if is_type(s,IOT) and is_type(t,DB):
            # Check if there's a mediating gateway/service/auth between IoT and DB
            has_mediator = any(
                (e.get("source") == s_id and
                 is_type(node_map.get(e.get("target",""),{}), GATEWAY+SERVICE+AUTH+["iot gateway","mqtt","iot hub"]))
                for e in edges if e != edge
            )
            if not has_mediator:
                violations.append(viol("GOV-003","CRITICAL","IoT/Device cannot directly access Database",s_id,t_id,
                    "IoT devices are untrusted. Direct DB access allows device compromise to expose all data.",
                    "Route device communication through API Gateway with device authentication (mTLS).")); continue

        if is_type(s,FRONTEND) and is_type(t,SECRETS):
            violations.append(viol("GOV-004","CRITICAL","Frontend is accessing Secrets/Vault directly",s_id,t_id,
                "Secrets in client-side code are fully exposed to any user.",
                "Secrets must only be accessed server-side via environment variables or a secrets proxy.")); continue

        if is_type(s,EXTERNAL) and is_type(t,ADMIN):
            violations.append(viol("GOV-005","CRITICAL","Admin panel directly exposed to external/internet",s_id,t_id,
                "Exposed admin panels are primary targets for credential stuffing and takeover.",
                "Put admin behind VPN, IP allowlisting, or an authenticated gateway.")); continue

        if is_type(s,IOT) and is_type(t,QUEUE):
            has_mediator = any(
                (e.get("source") == s_id and
                 is_type(node_map.get(e.get("target",""),{}), GATEWAY+AUTH+["iot gateway","mqtt","iot hub"]))
                for e in edges if e != edge
            )
            if not has_mediator:
                violations.append(viol("GOV-006","CRITICAL","IoT/Device sending data to Queue without authentication gateway",s_id,t_id,
                    "Unauthenticated device-to-queue allows message injection and data poisoning.",
                    "Use IoT Gateway (AWS IoT Core, Azure IoT Hub) to authenticate devices before enqueuing.")); continue

        if is_type(s,DB) and is_type(t,SERVICE+EXTERNAL+FRONTEND+GATEWAY+QUEUE):
            violations.append(viol("GOV-007","HIGH","Database should not initiate calls to Services",s_id,t_id,
                "DBs calling services creates tight coupling and unpredictable data flows.",
                "Use CDC (Debezium), DB triggers feeding a queue, or a polling Worker.")); continue

        if is_type(s,SERVICE+WORKER) and is_type(t,DB):
            other = any(
                is_type(n,SERVICE+WORKER) and n["id"]!=s_id and
                any(e.get("source")==n["id"] and e.get("target")==t_id for e in edges)
                for n in nodes
            )
            if other:
                violations.append(viol("GOV-008","HIGH","Shared Database anti-pattern — multiple Services sharing one Database",s_id,t_id,
                    "Shared DBs couple services at data layer, preventing independent deployments.",
                    "Give each service its own DB. Share via APIs or async events.")); continue

        if is_type(s,QUEUE) and is_type(t,DB):
            violations.append(viol("GOV-009","HIGH","Queue should not directly write to Database",s_id,t_id,
                "Queues are transport layers. DB writes must be handled by a consumer.",
                "Add Worker/Consumer service between Queue and Database.")); continue

        if is_type(s,EXTERNAL) and is_type(t,CACHE):
            violations.append(viol("GOV-010","HIGH","External service directly accessing internal Cache",s_id,t_id,
                "Cache contains sessions and tokens. External access exposes internal state.",
                "Expose cache data only through an authenticated Service API.")); continue

        if is_type(s,EXTERNAL) and is_type(t,SERVICE+WORKER):
            violations.append(viol("GOV-011","HIGH","External calling internal Service without API Gateway",s_id,t_id,
                "Bypassing gateway removes rate limiting, auth, logging, circuit breaking.",
                "All external traffic must enter through an API Gateway.")); continue

        if is_type(s,IOT) and is_type(t,SERVICE):
            violations.append(viol("GOV-012","HIGH","IoT/Device calling internal Service without Gateway",s_id,t_id,
                "Unmanaged device connections bypass fleet auth and rate limiting.",
                "Use IoT Gateway or MQTT broker as single entry point for all device communication.")); continue

        if is_type(s,DB) and is_type(t,QUEUE):
            violations.append(viol("GOV-013","HIGH","Database pushing directly to Message Queue",s_id,t_id,
                "DB-to-queue coupling makes database responsible for event propagation.",
                "Use CDC (Debezium) or a polling Worker to publish events.")); continue

        if is_type(s,FRONTEND) and is_type(t,SEARCH):
            violations.append(viol("GOV-014","HIGH","Search Engine directly accessible from Client",s_id,t_id,
                "Search engines index sensitive data. Direct access exposes unfiltered results.",
                "Route search through Service that filters results and enforces access control.")); continue

        if is_type(s,FRONTEND) and is_type(t,PAYMENT):
            violations.append(viol("GOV-015","HIGH","Payment component directly accessible from Client",s_id,t_id,
                "Client-side payment handling violates PCI-DSS and enables card data interception.",
                "All payment operations must go through server-side Service. Use tokenization.")); continue

        if is_type(s,WORKER) and is_type(t,WORKER):
            violations.append(viol("GOV-016","HIGH","Worker calling another Worker directly",s_id,t_id,
                "Direct worker-to-worker creates synchronous coupling in async pipelines.",
                "Publish message to Queue. Let downstream Worker consume independently.")); continue

        if is_type(s,EXTERNAL) and is_type(t,QUEUE):
            violations.append(viol("GOV-017","HIGH","External service writing directly to internal Queue",s_id,t_id,
                "External queue writes allow message injection and event spoofing.",
                "Route through API Gateway that validates before enqueuing.")); continue

        if is_type(s,GATEWAY) and is_type(t,DB):
            violations.append(viol("GOV-018","MEDIUM","API Gateway directly accessing Database",s_id,t_id,
                "Gateways handle routing/auth — not data persistence logic.",
                "Add dedicated Service between Gateway and Database.")); continue

        if is_type(s,FRONTEND) and is_type(t,QUEUE):
            violations.append(viol("GOV-019","MEDIUM","Client publishing to Queue directly",s_id,t_id,
                "Direct client-to-queue bypasses validation and authentication.",
                "Add API endpoint that validates request before enqueuing.")); continue

        if is_type(s,CACHE) and is_type(t,DB):
            violations.append(viol("GOV-020","MEDIUM","Cache writing to Database directly",s_id,t_id,
                "Cache write-back should flow through business logic for validation.",
                "Use Service or Worker for cache invalidation and DB writes.")); continue

        if is_type(s,GATEWAY) and is_type(t,GATEWAY):
            violations.append(viol("GOV-021","MEDIUM","API Gateway chaining detected",s_id,t_id,
                "Gateway chaining adds latency and creates single points of failure.",
                "Consolidate to single Gateway or use service mesh for internal routing.")); continue

        if is_type(s,FRONTEND) and is_type(t,WORKER):
            violations.append(viol("GOV-022","MEDIUM","Client calling Worker directly",s_id,t_id,
                "Clients calling workers creates synchronous coupling for async operations.",
                "Route through API that enqueues the job.")); continue

        if is_type(s,FRONTEND) and is_type(t,CACHE):
            violations.append(viol("GOV-023","MEDIUM","Cache directly exposed to Client",s_id,t_id,
                "Direct cache access can return stale or sensitive cached data.",
                "Add Service layer that reads from cache and validates before returning.")); continue

        if is_type(s,DB) and is_type(t,MONITOR):
            violations.append(viol("GOV-024","MEDIUM","Raw Database output going directly to Monitoring",s_id,t_id,
                "Raw DB output in logs can expose PII, credentials, and sensitive business data.",
                "Use structured logging with PII masking before sending to monitoring systems.")); continue

        if is_type(s,AUTH) and is_type(t,EXTERNAL):
            violations.append(viol("GOV-025","MEDIUM","Auth service sending data to External service",s_id,t_id,
                "Auth services forwarding data externally may leak identity tokens.",
                "Ensure OAuth/SSO integrations are explicitly scoped and monitored.")); continue

        if is_type(s,IOT) and is_type(t,AUTH):
            violations.append(viol("GOV-026","MEDIUM","IoT/Device accessing Auth service without Gateway",s_id,t_id,
                "Devices authenticating directly bypass fleet-level access policies.",
                "Use device certificates (mTLS) via IoT Gateway.")); continue

        if is_type(s,ADMIN) and is_type(t,DB):
            violations.append(viol("GOV-027","MEDIUM","Admin panel directly connected to Database",s_id,t_id,
                "Admin-to-DB without service means no audit trail or validation.",
                "Route admin DB operations through Service that logs every action.")); continue

        if is_type(s,FRONTEND) and is_type(t,EXTERNAL) and is_type(t,["analytics","tracking","segment","mixpanel","amplitude"]):
            violations.append(viol("GOV-028","MEDIUM","Client sending raw data to Analytics without sanitization",s_id,t_id,
                "Unsanitized analytics events may contain PII or sensitive data.",
                "Route analytics through server-side proxy that strips PII first.")); continue

        if is_type(s,SERVICE) and is_type(t,EXTERNAL):
            violations.append(viol("GOV-029","LOW","Service calling External without circuit breaking",s_id,t_id,
                "Direct service-to-external without circuit breaker can cascade failures.",
                "Add service mesh or gateway with circuit breaking and retry policies.")); continue

        if is_type(s,IOT) and is_type(t,EXTERNAL):
            violations.append(viol("GOV-030","LOW","IoT/Device sending telemetry directly to External service",s_id,t_id,
                "Device data bypassing your platform means no control over data residency.",
                "Route all device telemetry through internal platform before forwarding.")); continue

        # ── GDPR EDGE RULES ───────────────────────────────────────────────────

        if has_comp(s,"gdpr") or has_comp(t,"gdpr"):
            # Art. 44 — Cross-border transfer
            if is_type(t,EXTERNAL) and not has_comp(t,"gdpr"):
                violations.append(viol("GDPR-001","CRITICAL",
                    "GDPR Art. 44: PII transferred to non-GDPR-compliant processor",
                    s_id,t_id,
                    "GDPR Article 44 prohibits transfer of personal data to third countries without adequate protection.",
                    "Use Standard Contractual Clauses (SCCs) or ensure processor is in adequacy-list country.",
                    "GDPR Article 44","GDPR")); continue

            # Art. 5 — Data minimisation: PII going to frontend without filtering
            if is_type(t,FRONTEND) and not any(is_type(node_map.get(e.get("target",""),{}),SERVICE) for e in edges if e.get("source")==s_id):
                violations.append(viol("GDPR-002","HIGH",
                    "GDPR Art. 5(1)(c): Personal data flowing to Client without data minimisation layer",
                    s_id,t_id,
                    "GDPR requires data minimisation — only necessary personal data should reach the client.",
                    "Add a Service layer that filters/masks personal data before returning to client.",
                    "GDPR Article 5(1)(c)","GDPR")); continue

        # Art. 32 — Security: PII DB not connected to auth
        for n in nodes_comp(nodes,"gdpr"):
            if is_type(n,DB) and not any(
                reachable(edges,e.get("source",""),AUTH,node_map)
                for e in edges if e.get("target")==n["id"]
            ):
                violations.append(struct_viol("GDPR-003","HIGH",
                    "GDPR Art. 32: Personal data store accessible without verified authentication layer",
                    "GDPR Article 32 requires appropriate technical measures including access control.",
                    "Ensure all paths to PII Database go through an authenticated Service or Gateway.",
                    "GDPR Article 32","GDPR"))

        # ── HIPAA EDGE RULES ──────────────────────────────────────────────────

        if has_comp(t,"hipaa") and is_type(t,DB):
            if not is_type(s,SERVICE+GATEWAY+AUTH):
                violations.append(viol("HIPAA-001","CRITICAL",
                    "HIPAA §164.312(a)(1): PHI Database must only be accessed through authenticated Service",
                    s_id,t_id,
                    "HIPAA Technical Safeguards require access control for all electronic PHI systems.",
                    "Route all PHI Database access through authenticated Service with audit logging.",
                    "HIPAA §164.312(a)(1)","HIPAA")); continue

        if has_comp(s,"hipaa") and is_type(t,EXTERNAL):
            violations.append(viol("HIPAA-002","CRITICAL",
                "HIPAA §164.314: PHI cannot be transmitted to Business Associate without BAA verification",
                s_id,t_id,
                "HIPAA requires Business Associate Agreements before sharing PHI with any external party.",
                "Verify BAA exists with external processor. Encrypt PHI in transit.",
                "HIPAA §164.314","HIPAA")); continue

        if has_comp(s,"hipaa") and is_type(t,FRONTEND):
            violations.append(viol("HIPAA-003","HIGH",
                "HIPAA §164.312(e)(1): PHI transmitted to client without encryption verification",
                s_id,t_id,
                "HIPAA requires PHI to be encrypted in transit via TLS/SSL.",
                "Ensure TLS 1.2+ is enforced on all channels carrying PHI. Use HTTPS only.",
                "HIPAA §164.312(e)(1)","HIPAA")); continue

        # ── PCI-DSS EDGE RULES ────────────────────────────────────────────────

        if (has_comp(s,"pci") or has_comp(t,"pci") or is_type(t,PAYMENT)) and is_type(s,FRONTEND+EXTERNAL):
            if is_type(t,PAYMENT):
                violations.append(viol("PCI-001","CRITICAL",
                    "PCI-DSS Req. 1.3: Cardholder Data Environment must not be directly accessible from untrusted networks",
                    s_id,t_id,
                    "PCI-DSS Requirement 1.3 mandates network isolation of CDE from all untrusted networks.",
                    "Isolate payment components. Route all payment flows through tokenization Service.",
                    "PCI-DSS v4.0 Requirement 1.3","PCI-DSS")); continue

        if has_comp(s,"pci") and is_type(t,EXTERNAL) and not has_comp(t,"pci"):
            violations.append(viol("PCI-002","CRITICAL",
                "PCI-DSS Req. 12.8: Cardholder data shared with third-party without PCI compliance verification",
                s_id,t_id,
                "PCI-DSS Requirement 12.8 requires monitoring of service providers who have access to cardholder data.",
                "Verify all third-party service providers are PCI-DSS compliant. Maintain written agreements.",
                "PCI-DSS v4.0 Requirement 12.8","PCI-DSS")); continue

        if has_comp(t,"pci") and is_type(t,DB) and not is_type(s,SERVICE+GATEWAY):
            violations.append(viol("PCI-003","CRITICAL",
                "PCI-DSS Req. 3.4: Cardholder data store not protected by service layer",
                s_id,t_id,
                "PCI-DSS Requirement 3 requires protection of stored cardholder data with access controls.",
                "Route all access to payment DB through authenticated Service with encryption at rest.",
                "PCI-DSS v4.0 Requirement 3","PCI-DSS")); continue

        # ── SOC2 EDGE RULES ───────────────────────────────────────────────────

        if has_comp(s,"soc2") or has_comp(t,"soc2"):
            if is_type(s,EXTERNAL) and not is_type(t,GATEWAY):
                violations.append(viol("SOC2-001","HIGH",
                    "SOC2 CC6.6: External connections must route through monitored API Gateway",
                    s_id,t_id,
                    "SOC2 CC6.6 requires logical access controls and monitoring of all external network traffic.",
                    "Route all external traffic through API Gateway with logging, alerting, and rate limiting.",
                    "SOC2 Trust Service Criteria CC6.6","SOC2")); continue

            if is_type(s,FRONTEND) and is_type(t,SERVICE) and not reachable(edges,s_id,AUTH,node_map):
                violations.append(viol("SOC2-002","HIGH",
                    "SOC2 CC6.1: Client accessing Service without authentication — access control missing",
                    s_id,t_id,
                    "SOC2 CC6.1 requires logical access controls to protect information assets.",
                    "Implement authentication (JWT/OAuth) before allowing client access to services.",
                    "SOC2 Trust Service Criteria CC6.1","SOC2")); continue

        # ── ISO 27001 EDGE RULES ──────────────────────────────────────────────

        if has_comp(t,"iso27001") and is_type(t,DB):
            if is_type(s,EXTERNAL+FRONTEND):
                violations.append(viol("ISO27001-001","CRITICAL",
                    "ISO 27001 A.9.4: Classified data store directly reachable from untrusted source",
                    s_id,t_id,
                    "ISO 27001 Control A.9.4 requires access control to prevent unauthorized access to information systems.",
                    "Enforce network segmentation. All access to classified data must require authentication.",
                    "ISO/IEC 27001:2022 Control A.9.4","ISO27001")); continue

        if has_comp(s,"iso27001") and is_type(t,EXTERNAL) and not has_comp(t,"iso27001"):
            violations.append(viol("ISO27001-002","HIGH",
                "ISO 27001 A.13.2: Information transfer to external party without security agreement",
                s_id,t_id,
                "ISO 27001 A.13.2 requires policies and agreements for information transfer to external parties.",
                "Establish information transfer agreements (NDA/DPA) before transferring to external parties.",
                "ISO/IEC 27001:2022 Control A.13.2","ISO27001")); continue

        # ── DPDP ACT 2023 EDGE RULES ──────────────────────────────────────────

        if has_comp(s,"dpdp") or has_comp(t,"dpdp"):
            if is_type(t,EXTERNAL) and not has_comp(t,"dpdp"):
                violations.append(viol("DPDP-001","CRITICAL",
                    "DPDP Act 2023 S.16: Personal data of Indian users transferred to non-compliant processor",
                    s_id,t_id,
                    "India's Digital Personal Data Protection Act 2023 Section 16 restricts cross-border data transfers. Only specific trusted countries allowed.",
                    "Store Indian personal data within India OR ensure processor is in MeitY-approved country list.",
                    "DPDP Act 2023 Section 16","DPDP")); continue

            if is_type(t,FRONTEND) and not reachable(edges,s_id,["consent","notice","gdpr","auth"],node_map):
                violations.append(viol("DPDP-002","HIGH",
                    "DPDP Act 2023 S.6: Personal data processed without consent mechanism",
                    s_id,t_id,
                    "DPDP Act S.6 requires Data Fiduciary to obtain free, informed, specific, and unconditional consent.",
                    "Add a Consent Service that records user consent before any personal data processing.",
                    "DPDP Act 2023 Section 6","DPDP")); continue

        # ── RBI CSF EDGE RULES ────────────────────────────────────────────────

        if has_comp(s,"rbi") or has_comp(t,"rbi"):
            if is_type(s,EXTERNAL) and not is_type(t,GATEWAY+AUTH):
                violations.append(viol("RBI-001","CRITICAL",
                    "RBI CSF Annex I: External access to critical banking infrastructure without security gateway",
                    s_id,t_id,
                    "RBI Cybersecurity Framework mandates real-time monitoring of all external access to critical systems.",
                    "All external access must go through monitored security gateway with IDS/IPS.",
                    "RBI Cybersecurity Framework Annex I","RBI")); continue

            if is_type(t,DB) and is_type(s,EXTERNAL+FRONTEND):
                violations.append(viol("RBI-002","CRITICAL",
                    "RBI CSF: Customer financial data must not be directly accessible from untrusted sources",
                    s_id,t_id,
                    "RBI mandates strict data localisation and access controls for customer financial data.",
                    "Implement layered security: WAF → API Gateway → Auth Service → Application → Database.",
                    "RBI Cybersecurity Framework Annex II","RBI")); continue

            if is_type(t,EXTERNAL) and not has_comp(t,"rbi"):
                violations.append(viol("RBI-003","HIGH",
                    "RBI CSF Annex IV: Financial data transferred to third party without RBI compliance check",
                    s_id,t_id,
                    "RBI requires customer financial data to be stored only in India. Transfers must be audited.",
                    "Verify third-party complies with RBI data localisation requirements. Maintain audit trail.",
                    "RBI Cybersecurity Framework Annex IV","RBI")); continue

        # ── CERT-In 2022 EDGE RULES ───────────────────────────────────────────

        if has_comp(s,"cert-in") or has_comp(t,"cert-in"):
            if is_type(s,EXTERNAL) and is_type(t,SERVICE+DB):
                violations.append(viol("CERTIN-001","HIGH",
                    "CERT-In Directions 2022: All external access to critical systems must be logged",
                    s_id,t_id,
                    "CERT-In Directions 2022 require comprehensive ICT system logs and 6-hour incident reporting.",
                    "Enable detailed access logging for all external connections. Configure real-time SIEM alerts.",
                    "CERT-In Directions 2022 (Apr 2022)","CERT-In")); continue

        # ── IT ACT 2000 EDGE RULES ────────────────────────────────────────────

        if has_comp(s,"it act") or has_comp(t,"it act") or has_comp(s,"s43a") or has_comp(t,"s43a"):
            if is_type(t,DB) and is_type(s,FRONTEND+EXTERNAL):
                violations.append(viol("ITACT-001","HIGH",
                    "IT Act 2000 S.43A: Sensitive personal data must be protected with reasonable security practices",
                    s_id,t_id,
                    "IT Act Section 43A requires body corporates to implement reasonable security practices for sensitive personal data.",
                    "Implement ISO 27001-aligned security practices. Encrypt data at rest and in transit.",
                    "IT Act 2000 Section 43A","IT Act")); continue

        # ── CCPA EDGE RULES ───────────────────────────────────────────────────

        if has_comp(s,"ccpa") or has_comp(t,"ccpa"):
            if is_type(t,EXTERNAL) and not has_comp(t,"ccpa"):
                violations.append(viol("CCPA-001","HIGH",
                    "CCPA §1798.100: California consumer data transferred to non-CCPA-compliant service provider",
                    s_id,t_id,
                    "CCPA requires businesses to ensure service providers receiving personal information comply with CCPA.",
                    "Ensure all service providers have CCPA-compliant data processing agreements.",
                    "CCPA §1798.100","CCPA")); continue

            if is_type(t,FRONTEND) and not reachable(edges,s_id,["consent","opt-out"],node_map):
                violations.append(viol("CCPA-002","HIGH",
                    "CCPA §1798.120: Personal data sold/shared without opt-out mechanism",
                    s_id,t_id,
                    "CCPA gives consumers the right to opt-out of sale/sharing of personal information.",
                    "Implement opt-out mechanism. Display 'Do Not Sell or Share My Personal Information' link.",
                    "CCPA §1798.120","CCPA")); continue

        # ── NIST CSF 2.0 EDGE RULES ───────────────────────────────────────────

        if has_comp(s,"nist") or has_comp(t,"nist"):
            if is_type(s,EXTERNAL) and not is_type(t,GATEWAY+AUTH):
                violations.append(viol("NIST-001","HIGH",
                    "NIST CSF 2.0 PR.AC-3: Remote access must be managed and controlled",
                    s_id,t_id,
                    "NIST CSF Protect function requires managed remote access with multi-factor authentication.",
                    "Implement Zero Trust: authenticate every connection, log all access, enforce least privilege.",
                    "NIST CSF 2.0 PR.AC-3","NIST CSF")); continue

            if is_type(t,DB) and not reachable(edges,t_id,MONITOR,node_map):
                violations.append(viol("NIST-002","MEDIUM",
                    "NIST CSF 2.0 DE.CM-1: Database not connected to monitoring/detection system",
                    s_id,t_id,
                    "NIST Detect function requires continuous monitoring to identify cybersecurity events.",
                    "Connect Database to SIEM/monitoring system. Enable anomaly detection and alerting.",
                    "NIST CSF 2.0 DE.CM-1","NIST CSF")); continue

        # ── CIS Controls v8 EDGE RULES ────────────────────────────────────────

        if has_comp(s,"cis") or has_comp(t,"cis"):
            if is_type(s,FRONTEND+EXTERNAL) and is_type(t,SERVICE) and not reachable(edges,s_id,AUTH,node_map):
                violations.append(viol("CIS-001","HIGH",
                    "CIS Control 5: Access control missing — users not managed or authenticated",
                    s_id,t_id,
                    "CIS Control 5 (Account Management) requires managed accounts and access control for all systems.",
                    "Implement authentication. Use MFA for privileged access. Enforce least privilege.",
                    "CIS Controls v8 Control 5","CIS")); continue

            if is_type(t,DB) and not reachable(edges,t_id,MONITOR,node_map):
                violations.append(viol("CIS-002","MEDIUM",
                    "CIS Control 8: Database not connected to audit log management system",
                    s_id,t_id,
                    "CIS Control 8 (Audit Log Management) requires collection and retention of audit logs from all systems.",
                    "Connect Database to centralized log management. Retain logs for minimum 90 days.",
                    "CIS Controls v8 Control 8","CIS")); continue

    # ════════════════════════════════════════════════════════════════
    # PART B — STRUCTURAL RULES (Graph-level compliance checks)
    # ════════════════════════════════════════════════════════════════
    seen = set()  # avoid duplicate structural violations

    def add_struct(key, v):
        if key not in seen:
            seen.add(key)
            violations.append(v)

    has_gateway_node  = any_node(nodes, GATEWAY)
    has_auth_node     = any_node(nodes, AUTH)
    has_monitor_node  = any_node(nodes, MONITOR)
    has_payment_node  = any_node(nodes, PAYMENT)
    has_secrets_node  = any_node(nodes, SECRETS)

    # ── GDPR Structural ───────────────────────────────────
    gdpr_nodes = nodes_comp(nodes, "gdpr")
    if gdpr_nodes:
        # Art. 25 — Privacy by Design: no dedicated consent/auth mechanism
        if not has_auth_node:
            add_struct("GDPR-S1", struct_viol("GDPR-003","HIGH",
                "GDPR Art. 25: No Auth/Consent mechanism in architecture — Privacy by Design violated",
                "GDPR Article 25 requires data protection to be built into design. Auth/consent is mandatory.",
                "Add an Auth Service and Consent management component to your architecture.",
                "GDPR Article 25","GDPR"))

        # Art. 30 — Records of processing: no audit/monitoring
        if not has_monitor_node:
            add_struct("GDPR-S2", struct_viol("GDPR-004","HIGH",
                "GDPR Art. 30: No audit logging/monitoring in architecture — Records of Processing missing",
                "GDPR Article 30 requires records of processing activities. Audit logs are essential.",
                "Add a logging/monitoring component. All personal data access must be logged.",
                "GDPR Article 30","GDPR"))

        # Art. 17 — Right to erasure: no way to delete data
        gdpr_dbs = [n for n in gdpr_nodes if is_type(n, DB)]
        for db in gdpr_dbs:
            if not any(reachable(edges, e.get("source",""), SERVICE, node_map) for e in edges if e.get("target") == db["id"]):
                add_struct(f"GDPR-S3-{db['id']}", struct_viol("GDPR-005","MEDIUM",
                    f"GDPR Art. 17: Personal data store '{db.get('name',db['id'])}' has no service layer to handle erasure requests",
                    "GDPR Article 17 grants right to erasure. Must have service to process deletion requests.",
                    "Add a Data Management Service that can process GDPR erasure and portability requests.",
                    "GDPR Article 17","GDPR"))

    # ── HIPAA Structural ──────────────────────────────────
    hipaa_nodes = nodes_comp(nodes, "hipaa")
    if hipaa_nodes:
        # §164.308 — Administrative Safeguards: audit controls required
        if not has_monitor_node:
            add_struct("HIPAA-S1", struct_viol("HIPAA-004","CRITICAL",
                "HIPAA §164.312(b): No audit control mechanism — PHI access not being logged",
                "HIPAA Technical Safeguards §164.312(b) requires hardware/software to record PHI access.",
                "Add audit logging for all PHI access. Use SIEM for real-time monitoring and alerts.",
                "HIPAA §164.312(b)","HIPAA"))

        # §164.308(a)(5) — No auth before PHI systems
        if not has_auth_node:
            add_struct("HIPAA-S2", struct_viol("HIPAA-005","CRITICAL",
                "HIPAA §164.312(d): No authentication mechanism — PHI system identity verification missing",
                "HIPAA requires entity authentication to verify identity before accessing PHI systems.",
                "Implement MFA-capable authentication service for all PHI system access.",
                "HIPAA §164.312(d)","HIPAA"))

        # §164.312(c) — Encryption in transit: no TLS/gateway
        if not has_gateway_node:
            add_struct("HIPAA-S3", struct_viol("HIPAA-006","HIGH",
                "HIPAA §164.312(e)(1): No transmission security mechanism — PHI may be unencrypted in transit",
                "HIPAA requires technical security measures to guard against unauthorized PHI transmission access.",
                "Add API Gateway with TLS termination. Enforce HTTPS. Encrypt all PHI in transit.",
                "HIPAA §164.312(e)(1)","HIPAA"))

    # ── PCI-DSS Structural ────────────────────────────────
    if has_payment_node:
        # Req. 10 — Logging and Monitoring
        if not has_monitor_node:
            add_struct("PCI-S1", struct_viol("PCI-004","CRITICAL",
                "PCI-DSS Req. 10.2: No audit logging for cardholder data environment",
                "PCI-DSS Requirement 10 mandates audit trails for all access to cardholder data.",
                "Implement centralized logging for all CDE components. Retain logs 12 months minimum.",
                "PCI-DSS v4.0 Requirement 10","PCI-DSS"))

        # Req. 8 — Identify and Authenticate
        if not has_auth_node:
            add_struct("PCI-S2", struct_viol("PCI-005","CRITICAL",
                "PCI-DSS Req. 8.2: No authentication mechanism for cardholder data environment",
                "PCI-DSS Requirement 8 requires identification and authentication for all CDE access.",
                "Implement MFA for all CDE access. Use unique IDs for every user. No shared accounts.",
                "PCI-DSS v4.0 Requirement 8","PCI-DSS"))

        # Req. 1 — Network Security Controls
        if not has_gateway_node:
            add_struct("PCI-S3", struct_viol("PCI-006","CRITICAL",
                "PCI-DSS Req. 1.1: No network security control protecting cardholder data environment",
                "PCI-DSS Requirement 1 requires network security controls (firewalls/gateways) around CDE.",
                "Add API Gateway or WAF to isolate CDE. Document all CDE network flows.",
                "PCI-DSS v4.0 Requirement 1","PCI-DSS"))

        # Req. 3 — Protect Stored Cardholder Data
        payment_dbs = [n for n in nodes if is_type(n, PAYMENT) and is_type(n, DB)]
        if not payment_dbs and has_payment_node:
            pass  # Payment node exists but not DB — may be fine
        for pdb in payment_dbs:
            if not any(has_comp(e, "pci") for e in edges):
                add_struct(f"PCI-S4-{pdb['id']}", struct_viol("PCI-007","HIGH",
                    f"PCI-DSS Req. 3.5: Cardholder data store '{pdb.get('name',pdb['id'])}' must use strong cryptography",
                    "PCI-DSS Requirement 3.5 requires strong cryptography to protect stored cardholder data.",
                    "Enable AES-256 encryption at rest. Use HSM for key management.",
                    "PCI-DSS v4.0 Requirement 3.5","PCI-DSS"))

    # ── SOC2 Structural ───────────────────────────────────
    soc2_nodes = nodes_comp(nodes, "soc2")
    if soc2_nodes:
        if not has_monitor_node:
            add_struct("SOC2-S1", struct_viol("SOC2-003","HIGH",
                "SOC2 CC7.2: No monitoring mechanism — security events not being detected",
                "SOC2 CC7.2 requires monitoring to detect and respond to security events promptly.",
                "Add SIEM/monitoring system. Configure alerts for anomalous access patterns.",
                "SOC2 Trust Service Criteria CC7.2","SOC2"))

        if not has_auth_node:
            add_struct("SOC2-S2", struct_viol("SOC2-004","HIGH",
                "SOC2 CC6.1: No logical access control mechanism in architecture",
                "SOC2 CC6.1 requires logical access controls to protect information assets.",
                "Implement authentication service. Enforce MFA for privileged accounts.",
                "SOC2 Trust Service Criteria CC6.1","SOC2"))

        if not has_secrets_node:
            add_struct("SOC2-S3", struct_viol("SOC2-005","MEDIUM",
                "SOC2 CC6.7: No secrets management system — credentials may be hardcoded",
                "SOC2 CC6.7 requires protection of confidential information including credentials.",
                "Add Vault/Secrets Manager. Rotate credentials regularly. Never hardcode secrets.",
                "SOC2 Trust Service Criteria CC6.7","SOC2"))

    # ── ISO 27001 Structural ──────────────────────────────
    iso_nodes = nodes_comp(nodes, "iso27001")
    if iso_nodes:
        if not has_monitor_node:
            add_struct("ISO-S1", struct_viol("ISO27001-003","HIGH",
                "ISO 27001 A.12.4: No logging/monitoring — audit logging not implemented",
                "ISO 27001 Control A.12.4 requires event logging for all information processing systems.",
                "Implement centralized logging. Enable audit trails for all system access.",
                "ISO/IEC 27001:2022 A.12.4","ISO27001"))

        if not has_auth_node:
            add_struct("ISO-S2", struct_viol("ISO27001-004","HIGH",
                "ISO 27001 A.9.2: No access management system — user registration missing",
                "ISO 27001 A.9.2 requires a formal user access management process.",
                "Implement Identity and Access Management (IAM) service with role-based access control.",
                "ISO/IEC 27001:2022 A.9.2","ISO27001"))

        if not has_secrets_node:
            add_struct("ISO-S3", struct_viol("ISO27001-005","MEDIUM",
                "ISO 27001 A.9.4.3: No password management system — credential protection missing",
                "ISO 27001 A.9.4.3 requires password management systems to ensure quality of passwords.",
                "Add Secrets Management (HashiCorp Vault, AWS Secrets Manager) to your architecture.",
                "ISO/IEC 27001:2022 A.9.4.3","ISO27001"))

    # ── DPDP Act 2023 Structural ──────────────────────────
    dpdp_nodes = nodes_comp(nodes, "dpdp")
    if dpdp_nodes:
        if not has_auth_node:
            add_struct("DPDP-S1", struct_viol("DPDP-003","HIGH",
                "DPDP Act 2023 S.8(3): No Data Fiduciary accountability mechanism — consent/auth missing",
                "DPDP Act Section 8 requires Data Fiduciary to implement security safeguards.",
                "Add Auth Service and Consent Manager to track data processing authorization.",
                "DPDP Act 2023 Section 8","DPDP"))

        if not has_monitor_node:
            add_struct("DPDP-S2", struct_viol("DPDP-004","HIGH",
                "DPDP Act 2023 S.8(6): No breach detection mechanism — data breach notification at risk",
                "DPDP Act Section 8(6) requires notifying Data Protection Board and affected persons of breaches.",
                "Add security monitoring to detect and respond to data breaches within required timeframes.",
                "DPDP Act 2023 Section 8(6)","DPDP"))

    # ── RBI CSF Structural ────────────────────────────────
    rbi_nodes = nodes_comp(nodes, "rbi")
    if rbi_nodes:
        if not has_monitor_node:
            add_struct("RBI-S1", struct_viol("RBI-004","CRITICAL",
                "RBI CSF: No Security Operations Centre (SOC) / monitoring system in architecture",
                "RBI Cybersecurity Framework requires 24x7 monitoring of critical banking systems.",
                "Implement SOC with SIEM. Configure real-time alerting for all suspicious activities.",
                "RBI Cybersecurity Framework Annex III","RBI"))

        if not has_gateway_node:
            add_struct("RBI-S2", struct_viol("RBI-005","CRITICAL",
                "RBI CSF: No perimeter security gateway — direct exposure of banking systems",
                "RBI mandates perimeter security controls (WAF, DDoS protection) for all banking systems.",
                "Implement WAF and DDoS protection as mandatory perimeter controls.",
                "RBI Cybersecurity Framework","RBI"))

    # ── CERT-In 2022 Structural ───────────────────────────
    certin_nodes = nodes_comp(nodes, "cert-in")
    if certin_nodes:
        if not has_monitor_node:
            add_struct("CERTIN-S1", struct_viol("CERTIN-002","HIGH",
                "CERT-In Directions 2022: No log management system — mandatory log retention missing",
                "CERT-In Directions 2022 require ICT system logs to be retained for 180 days within India.",
                "Add centralized log management retaining logs 180+ days in India-based storage.",
                "CERT-In Directions 2022","CERT-In"))

    # ── NIST CSF Structural ───────────────────────────────
    nist_nodes = nodes_comp(nodes, "nist")
    if nist_nodes:
        if not has_monitor_node:
            add_struct("NIST-S1", struct_viol("NIST-003","HIGH",
                "NIST CSF 2.0 DE.CM: No continuous monitoring — anomaly detection missing",
                "NIST Detect function requires continuous monitoring of assets and networks.",
                "Add monitoring system. Implement anomaly detection. Configure incident alerting.",
                "NIST CSF 2.0 DE.CM","NIST CSF"))

        if not has_auth_node:
            add_struct("NIST-S2", struct_viol("NIST-004","HIGH",
                "NIST CSF 2.0 PR.AC-1: No identity management — access control not implemented",
                "NIST Protect function requires identities and credentials to be issued, managed, and revoked.",
                "Implement Identity Provider (IdP) with MFA. Use least-privilege access model.",
                "NIST CSF 2.0 PR.AC-1","NIST CSF"))

    # ── CIS Controls Structural ───────────────────────────
    cis_nodes = nodes_comp(nodes, "cis")
    if cis_nodes:
        if not has_monitor_node:
            add_struct("CIS-S1", struct_viol("CIS-003","HIGH",
                "CIS Control 8: No audit log management — centralized logging not implemented",
                "CIS Control 8 requires collection, review, and retention of audit logs from all assets.",
                "Implement SIEM with centralized logging. Review logs weekly. Retain 90 days minimum.",
                "CIS Controls v8 Control 8","CIS"))

        if not has_auth_node:
            add_struct("CIS-S2", struct_viol("CIS-004","HIGH",
                "CIS Control 5 & 6: No account and access control management system",
                "CIS Controls 5 and 6 require inventory of accounts and strict access control privileges.",
                "Implement IAM system. Disable unused accounts. Enforce MFA for all admin access.",
                "CIS Controls v8 Controls 5 & 6","CIS"))

        if not has_gateway_node:
            add_struct("CIS-S3", struct_viol("CIS-005","MEDIUM",
                "CIS Control 12: No network infrastructure management — boundary defense missing",
                "CIS Control 12 requires network infrastructure defense with firewalls and access controls.",
                "Add API Gateway, WAF, and network segmentation to protect internal systems.",
                "CIS Controls v8 Control 12","CIS"))



    # ══════════════════════════════════════════════════════
    # GOV-031 to GOV-060 — Extended Architecture Rules
    # ══════════════════════════════════════════════════════

    # GOV-031: Single Point of Failure
    gateway_nodes = [n for n in nodes if n.get("type","") == "Gateway"]
    if len(gateway_nodes) == 1:
        violations.append({
            "ruleId":"GOV-031","severity":"HIGH",
            "message":f"Single Point of Failure — '{gateway_nodes[0].get('name')}' is the only Gateway",
            "description":"A single API Gateway creates SPOF. If it fails, the entire system goes down. High availability requires redundancy.",
            "fix":"Deploy multiple Gateway instances behind a load balancer. Use active-active or active-passive failover.",
            "reference":"High Availability Architecture Best Practices",
            "framework":"Architecture",
            "source":gateway_nodes[0]["id"],"target":"architecture",
            "sourceName":gateway_nodes[0].get("name",""),"targetName":"Single Point of Failure"
        })

    # GOV-032: Payment component not isolated
    payment_nodes = [n for n in nodes if any(w in (n.get("name","") + n.get("type","")).lower() for w in ["payment","pay","billing","stripe","razorpay","card"])]
    for pn in payment_nodes:
        pn_edges = [e for e in edges if e.get("source") == pn["id"] or e.get("target") == pn["id"]]
        for e in pn_edges:
            other_id = e["target"] if e["source"] == pn["id"] else e["source"]
            other = node_map.get(other_id)
            if other and other.get("type","").lower() in ("frontend","mobile","user","external"):
                violations.append({
                    "ruleId":"GOV-032","severity":"CRITICAL",
                    "message":f"Payment component '{pn.get('name')}' directly connected to '{other.get('name')}' — PCI-DSS violation",
                    "description":"Payment systems must be isolated in a separate network segment. Direct client-to-payment connections violate PCI-DSS and expose card data.",
                    "fix":"Route all payment flows through API Gateway. Isolate payment service in DMZ. Never expose payment service directly to clients.",
                    "reference":"PCI-DSS v4.0 Requirement 1.3 — Network Access Controls",
                    "framework":"Architecture",
                    "source":pn["id"],"target":other_id,
                    "sourceName":pn.get("name",""),"targetName":other.get("name","")
                })

    # GOV-033: Missing backup/DR for databases
    db_nodes = [n for n in nodes if n.get("type","") == "Database"]
    backup_nodes = [n for n in nodes if any(w in (n.get("name","") + n.get("type","")).lower() for w in ["backup","replica","dr","disaster","recovery","standby"])]
    if db_nodes and not backup_nodes and len(db_nodes) > 1:
        violations.append({
            "ruleId":"GOV-033","severity":"HIGH",
            "message":f"No backup/DR node — {len(db_nodes)} databases with no disaster recovery",
            "description":"Multiple databases without backup or DR strategy. Data loss risk in case of failure.",
            "fix":"Add database replication, automated backups, and disaster recovery node. Define RPO/RTO.",
            "reference":"ISO 22301 Business Continuity + RBI CSF DR Requirements",
            "framework":"Architecture",
            "source":"databases","target":"missing_backup",
            "sourceName":"Databases","targetName":"Missing: Backup/DR"
        })

    # GOV-034: Hardcoded secrets detection
    for node in nodes:
        intent = (node.get("intent","") + node.get("name","")).lower()
        if any(w in intent for w in ["secret","api_key","password","credential","token","private_key","aws_key"]):
            if node.get("type","").lower() in ("frontend","mobile","service","api"):
                violations.append({
                    "ruleId":"GOV-034","severity":"CRITICAL",
                    "message":f"Hardcoded secrets detected in '{node.get('name')}' — credentials exposure risk",
                    "description":"Hardcoded secrets in application nodes are exposed in source code, logs, and memory dumps. Critical security vulnerability.",
                    "fix":"Move all secrets to environment variables or secret management service (Vault, AWS Secrets Manager). Never hardcode credentials.",
                    "reference":"OWASP Top 10 A07:2021 — Identification and Authentication Failures",
                    "framework":"Architecture",
                    "source":node["id"],"target":"secrets",
                    "sourceName":node.get("name",""),"targetName":"Hardcoded Secrets"
                })

    # GOV-035: Missing CDN for frontend
    frontend_nodes = [n for n in nodes if n.get("type","").lower() in ("frontend","mobile","user")]
    cdn_nodes = [n for n in nodes if n.get("type","").lower() == "cdn"]
    if frontend_nodes and not cdn_nodes and len(nodes) > 5:
        violations.append({
            "ruleId":"GOV-035","severity":"LOW",
            "message":"No CDN node — frontend served without content delivery network",
            "description":"Without CDN, all static assets served from origin. High latency for global users, origin under DDoS risk.",
            "fix":"Add CDN (Cloudflare, AWS CloudFront) for static asset delivery. Protects origin and improves performance.",
            "reference":"Web Performance Best Practices",
            "framework":"Architecture",
            "source":"frontend","target":"missing_cdn",
            "sourceName":"Frontend","targetName":"Missing: CDN"
        })

    # GOV-036: Missing rate limiting on APIs
    api_nodes = [n for n in nodes if n.get("type","").lower() in ("api","gateway")]
    if api_nodes:
        for edge in edges:
            src = node_map.get(edge.get("source",""))
            tgt = node_map.get(edge.get("target",""))
            if not src or not tgt: continue
            if src.get("type","").lower() in ("external","user","frontend","mobile") and tgt.get("type","").lower() in ("api","service"):
                intent = (tgt.get("intent","") + tgt.get("name","")).lower()
                if "rate" not in intent and "limit" not in intent and "throttle" not in intent:
                    violations.append({
                        "ruleId":"GOV-036","severity":"MEDIUM",
                        "message":f"No rate limiting declared on '{tgt.get('name')}' — API abuse risk",
                        "description":"APIs without rate limiting are vulnerable to brute force, DDoS, and resource exhaustion attacks.",
                        "fix":"Implement rate limiting (e.g., 100 req/min per IP). Add exponential backoff. Use API Gateway throttling.",
                        "reference":"OWASP API4:2023 — Unrestricted Resource Consumption",
                        "framework":"Architecture",
                        "source":edge["source"],"target":edge["target"],
                        "sourceName":src.get("name",""),"targetName":tgt.get("name","")
                    })

    # GOV-037: PII data node without encryption tag
    pii_nodes = [n for n in nodes if any(w in (n.get("name","") + n.get("intent","")).lower() for w in ["user","personal","pii","customer","patient","rider","driver","employee"]) and n.get("type","") == "Database"]
    for pn in pii_nodes:
        intent = (pn.get("intent","") + pn.get("name","")).lower()
        if "encrypt" not in intent and "secure" not in intent:
            violations.append({
                "ruleId":"GOV-037","severity":"HIGH",
                "message":f"PII database '{pn.get('name')}' has no encryption declared",
                "description":"Personal data must be encrypted at rest and in transit. DPDP Act 2023 and GDPR both mandate encryption for personal data stores.",
                "fix":"Enable AES-256 encryption at rest. Enforce TLS 1.3 in transit. Document encryption in node intent.",
                "reference":"DPDP Act 2023 §8 + GDPR Article 32",
                "framework":"Architecture",
                "source":pn["id"],"target":"encryption",
                "sourceName":pn.get("name",""),"targetName":"Missing: Encryption"
            })

    # GOV-038: Circular dependency detection
    def has_cycle(src_id, tgt_id, edge_list):
        reverse = {}
        for e in edge_list:
            reverse.setdefault(e["target"], set()).add(e["source"])
        visited = set()
        stack = [tgt_id]
        while stack:
            curr = stack.pop()
            if curr == src_id: return True
            if curr in visited: continue
            visited.add(curr)
            stack.extend(reverse.get(curr, []))
        return False

    for edge in edges:
        if has_cycle(edge["source"], edge["target"], edges):
            src = node_map.get(edge["source"])
            tgt = node_map.get(edge["target"])
            if src and tgt:
                violations.append({
                    "ruleId":"GOV-038","severity":"MEDIUM",
                    "message":f"Circular dependency — '{src.get('name')}' ↔ '{tgt.get('name')}' creates dependency cycle",
                    "description":"Circular dependencies prevent independent deployment, testing, and scaling. Creates tight coupling and deployment ordering issues.",
                    "fix":"Break cycle using event-driven pattern or shared interface. Introduce mediator/event bus between circular services.",
                    "reference":"Microservices Architecture Principles",
                    "framework":"Architecture",
                    "source":edge["source"],"target":edge["target"],
                    "sourceName":src.get("name",""),"targetName":tgt.get("name","")
                })

    # GOV-039: Too many responsibilities (too many connections)
    for node in nodes:
        incoming = sum(1 for e in edges if e.get("target") == node["id"])
        outgoing = sum(1 for e in edges if e.get("source") == node["id"])
        total = incoming + outgoing
        if total > 8:
            violations.append({
                "ruleId":"GOV-039","severity":"MEDIUM",
                "message":f"God component — '{node.get('name')}' has {total} connections (max recommended: 8)",
                "description":"Components with too many dependencies violate Single Responsibility Principle. Creates tight coupling, testing difficulty, and deployment risk.",
                "fix":f"Split '{node.get('name')}' into smaller, focused services. Each service should have one clear responsibility.",
                "reference":"Microservices Design Principles — Single Responsibility",
                "framework":"Architecture",
                "source":node["id"],"target":"architecture",
                "sourceName":node.get("name",""),"targetName":f"{total} connections"
            })

    # GOV-040: Missing health check / monitoring for critical services
    critical_types = {"Database","Auth","Gateway","Payment"}
    for node in nodes:
        if node.get("type","") in critical_types:
            has_monitor_edge = any(
                (e.get("source") == node["id"] or e.get("target") == node["id"])
                and node_map.get(e.get("source") if e.get("target") == node["id"] else e.get("target"), {}).get("type","") == "Monitoring"
                for e in edges
            )
            if not has_monitor_edge and not has_monitor_node:
                violations.append({
                    "ruleId":"GOV-040","severity":"MEDIUM",
                    "message":f"Critical component '{node.get('name')}' ({node.get('type')}) has no monitoring connection",
                    "description":"Critical infrastructure components must be monitored with health checks, alerts, and SLA tracking.",
                    "fix":"Connect monitoring system to all critical components. Set up health checks, alerting, and uptime SLAs.",
                    "reference":"SRE Best Practices — Google Site Reliability Engineering",
                    "framework":"Architecture",
                    "source":node["id"],"target":"missing_monitoring",
                    "sourceName":node.get("name",""),"targetName":"Missing: Health Check"
                })

    # GOV-041: Multiple databases sharing single service (coupling)
    service_db_map = {}
    for edge in edges:
        src = node_map.get(edge.get("source",""))
        tgt = node_map.get(edge.get("target",""))
        if not src or not tgt: continue
        if src.get("type","") == "Service" and tgt.get("type","") == "Database":
            service_db_map.setdefault(src["id"], []).append(tgt.get("name",""))
    for svc_id, dbs in service_db_map.items():
        if len(dbs) > 2:
            svc = node_map.get(svc_id,{})
            violations.append({
                "ruleId":"GOV-041","severity":"MEDIUM",
                "message":f"'{svc.get('name')}' owns {len(dbs)} databases — tight data coupling",
                "description":"Services owning multiple databases violate bounded context principle. Creates data coupling and prevents independent scaling.",
                "fix":"Split service by bounded context. Each service should own one database. Share data via APIs, not shared databases.",
                "reference":"Domain-Driven Design — Bounded Context",
                "framework":"Architecture",
                "source":svc_id,"target":"databases",
                "sourceName":svc.get("name",""),"targetName":f"{len(dbs)} databases"
            })

    # GOV-042: External service without fallback
    for edge in edges:
        src = node_map.get(edge.get("source",""))
        tgt = node_map.get(edge.get("target",""))
        if not src or not tgt: continue
        if tgt.get("type","").lower() in ("external","payment","cdn") and src.get("type","").lower() in ("service","api"):
            violations.append({
                "ruleId":"GOV-042","severity":"LOW",
                "message":f"'{src.get('name')}' depends on external '{tgt.get('name')}' without declared fallback",
                "description":"External service dependencies without circuit breaker/fallback create cascading failures when the external service is unavailable.",
                "fix":"Implement circuit breaker pattern. Add retry with exponential backoff. Define graceful degradation behavior.",
                "reference":"Resilience Patterns — Circuit Breaker (Martin Fowler)",
                "framework":"Architecture",
                "source":edge["source"],"target":edge["target"],
                "sourceName":src.get("name",""),"targetName":tgt.get("name","")
            })

    # GOV-043: Secrets/Credentials node exposed to non-service
    secrets_nodes = [n for n in nodes if n.get("type","") == "Secrets"]
    for sn in secrets_nodes:
        for edge in edges:
            other_id = None
            if edge.get("target") == sn["id"]:
                other_id = edge["source"]
            elif edge.get("source") == sn["id"]:
                other_id = edge["target"]
            if not other_id: continue
            other = node_map.get(other_id)
            if other and other.get("type","").lower() in ("frontend","mobile","user","external","iot"):
                violations.append({
                    "ruleId":"GOV-043","severity":"CRITICAL",
                    "message":f"Secrets/Vault '{sn.get('name')}' accessible from '{other.get('name')}' — credentials exposure",
                    "description":"Secret stores must only be accessible from backend services, never from clients, mobile apps, or IoT devices.",
                    "fix":"Remove all direct client-to-secrets connections. Only backend services should access secret stores via service accounts.",
                    "reference":"CIS Controls v8 Control 3.11 — Encrypt Sensitive Data",
                    "framework":"Architecture",
                    "source":sn["id"],"target":other_id,
                    "sourceName":sn.get("name",""),"targetName":other.get("name","")
                })

    # GOV-044: Missing API versioning
    api_nodes_v = [n for n in nodes if n.get("type","").lower() in ("api","gateway")]
    for an in api_nodes_v:
        intent = (an.get("intent","") + an.get("name","")).lower()
        if not any(w in intent for w in ["v1","v2","version","versioning","/v"]):
            violations.append({
                "ruleId":"GOV-044","severity":"LOW",
                "message":f"API '{an.get('name')}' has no versioning strategy declared",
                "description":"APIs without versioning break clients when updated. No versioning means no backward compatibility guarantee.",
                "fix":"Implement API versioning (/v1/, /v2/ or Accept-Version header). Maintain at least 2 versions simultaneously.",
                "reference":"API Design Best Practices — REST API Versioning",
                "framework":"Architecture",
                "source":an["id"],"target":"versioning",
                "sourceName":an.get("name",""),"targetName":"Missing: API Versioning"
            })

    # GOV-045: Missing data retention policy for logs/analytics
    analytics_nodes = [n for n in nodes if n.get("type","").lower() in ("analytics","monitoring","search")]
    for an in analytics_nodes:
        intent = (an.get("intent","") + an.get("name","")).lower()
        if not any(w in intent for w in ["retain","retention","days","policy","ttl","expire"]):
            violations.append({
                "ruleId":"GOV-045","severity":"LOW",
                "message":f"'{an.get('name')}' has no data retention policy — CERT-In 180 day rule",
                "description":"CERT-In 2022 requires logs to be retained for 180 days within India. No retention policy means potential compliance violation.",
                "fix":"Set log retention to minimum 180 days (CERT-In). Define purge schedule. Store within India for regulatory compliance.",
                "reference":"CERT-In Directions 2022 — Log Retention Requirements",
                "framework":"Architecture",
                "source":an["id"],"target":"retention",
                "sourceName":an.get("name",""),"targetName":"Missing: Retention Policy"
            })

    # ══════════════════════════════════════════════════════
    # OWASP API TOP 10 (2023)
    # ══════════════════════════════════════════════════════
    owasp_nodes = nodes_comp(nodes, "owasp")
    if owasp_nodes or True:  # Always evaluate OWASP

        # API1:2023 - Broken Object Level Authorization
        for edge in edges:
            src = node_map.get(edge.get("source",""))
            tgt = node_map.get(edge.get("target",""))
            if not src or not tgt: continue
            src_t = (src.get("type","")).lower()
            tgt_t = (tgt.get("type","")).lower()

            # API1: Frontend/Mobile directly accessing Database
            if src_t in ("frontend","mobile","user") and tgt_t in ("database","db"):
                violations.append({
                    "ruleId":"OWASP-API1","severity":"CRITICAL",
                    "message":f"OWASP API1:2023 Broken Object Authorization — {src.get('name')} directly accesses {tgt.get('name')} without object-level auth",
                    "description":"API1 is the most critical OWASP API risk. Direct DB access bypasses all authorization checks, allowing any user to access any record.",
                    "fix":"Add an API layer that enforces object-level authorization. Validate every request has permission for the specific object being accessed.",
                    "reference":"OWASP API Security Top 10 2023 - API1:2023",
                    "framework":"OWASP API",
                    "source":edge["source"],"target":edge["target"],
                    "sourceName":src.get("name",""),"targetName":tgt.get("name","")
                })

            # API2: Broken Authentication — External to Service without Auth
            if src_t in ("external","user","frontend") and tgt_t in ("service","api","worker"):
                has_auth = any(
                    n.get("type","").lower() == "auth"
                    for n in nodes
                )
                if not has_auth:
                    key = f"OWASP-API2-{edge['source']}-{edge['target']}"
                    violations.append({
                        "ruleId":"OWASP-API2","severity":"HIGH",
                        "message":f"OWASP API2:2023 Broken Authentication — {src.get('name')} reaches {tgt.get('name')} with no Auth Service in architecture",
                        "description":"No authentication service detected. APIs are accessible without identity verification — broken authentication attack surface.",
                        "fix":"Add an Auth Service (OAuth2/JWT). All external traffic must pass through authentication before reaching services.",
                        "reference":"OWASP API Security Top 10 2023 - API2:2023",
                        "framework":"OWASP API",
                        "source":edge["source"],"target":edge["target"],
                        "sourceName":src.get("name",""),"targetName":tgt.get("name","")
                    })

            # API3: Broken Object Property Level Authorization — Admin to DB
            if src_t in ("admin","frontend") and tgt_t in ("database","db"):
                violations.append({
                    "ruleId":"OWASP-API3","severity":"HIGH",
                    "message":f"OWASP API3:2023 Broken Property Authorization — {src.get('name')} has unrestricted DB property access",
                    "description":"Direct database access exposes all object properties. Attackers can access or modify any field — mass assignment vulnerability.",
                    "fix":"Use DTOs and field-level authorization. Never expose raw DB objects. Whitelist allowed fields per role.",
                    "reference":"OWASP API Security Top 10 2023 - API3:2023",
                    "framework":"OWASP API",
                    "source":edge["source"],"target":edge["target"],
                    "sourceName":src.get("name",""),"targetName":tgt.get("name","")
                })

            # API4: Unrestricted Resource Consumption — IoT/External to DB
            if src_t in ("iot","external") and tgt_t in ("database","cache","queue"):
                violations.append({
                    "ruleId":"OWASP-API4","severity":"HIGH",
                    "message":f"OWASP API4:2023 Unrestricted Resource Consumption — {src.get('name')} can flood {tgt.get('name')}",
                    "description":"IoT/External components with direct resource access can cause DoS through unrestricted consumption — no rate limiting or quota enforcement.",
                    "fix":"Add API Gateway with rate limiting, request quotas, and payload size limits between external systems and resources.",
                    "reference":"OWASP API Security Top 10 2023 - API4:2023",
                    "framework":"OWASP API",
                    "source":edge["source"],"target":edge["target"],
                    "sourceName":src.get("name",""),"targetName":tgt.get("name","")
                })

            # API5: Broken Function Level Authorization — Worker to Admin DB
            if src_t in ("worker","service") and tgt_t in ("database","db"):
                name_lower = tgt.get("name","").lower()
                if any(w in name_lower for w in ["admin","user","auth","account","identity"]):
                    violations.append({
                        "ruleId":"OWASP-API5","severity":"HIGH",
                        "message":f"OWASP API5:2023 Broken Function Authorization — {src.get('name')} accesses privileged {tgt.get('name')}",
                        "description":"Worker/Service accessing admin or identity databases without function-level authorization checks. Privilege escalation risk.",
                        "fix":"Implement function-level authorization. Workers should only access their own bounded context data via service APIs.",
                        "reference":"OWASP API Security Top 10 2023 - API5:2023",
                        "framework":"OWASP API",
                        "source":edge["source"],"target":edge["target"],
                        "sourceName":src.get("name",""),"targetName":tgt.get("name","")
                    })

        # API7: SSRF — External URL in service nodes
        for node in nodes:
            if node.get("type","").lower() in ("service","api","worker"):
                intent = (node.get("intent","") + node.get("name","")).lower()
                if any(w in intent for w in ["webhook","callback","fetch","http","url","external","proxy"]):
                    violations.append({
                        "ruleId":"OWASP-API7","severity":"HIGH",
                        "message":f"OWASP API7:2023 SSRF Risk — {node.get('name')} makes external HTTP requests without validation",
                        "description":"Server-Side Request Forgery risk. Services making external HTTP requests can be exploited to access internal services or cloud metadata.",
                        "fix":"Validate and whitelist all external URLs. Use allowlist of permitted domains. Block requests to internal IP ranges (169.254.x.x, 10.x.x.x).",
                        "reference":"OWASP API Security Top 10 2023 - API7:2023",
                        "framework":"OWASP API",
                        "source":node["id"],"target":"external",
                        "sourceName":node.get("name",""),"targetName":"External"
                    })

        # API8: Security Misconfiguration — No Gateway
        if not has_gateway_node and len(nodes) > 3:
            violations.append({
                "ruleId":"OWASP-API8","severity":"HIGH",
                "message":"OWASP API8:2023 Security Misconfiguration — No API Gateway for centralized security controls",
                "description":"Without an API Gateway, security policies (CORS, rate limiting, auth) must be implemented per service — leading to inconsistent configuration.",
                "fix":"Add an API Gateway as single entry point. Centralize CORS, auth, rate limiting, and TLS termination.",
                "reference":"OWASP API Security Top 10 2023 - API8:2023",
                "framework":"OWASP API",
                "source":"architecture","target":"architecture",
                "sourceName":"Architecture","targetName":"Missing Gateway"
            })

        # API9: Improper Inventory — too many external connections
        external_nodes = [n for n in nodes if n.get("type","").lower() in ("external","cdn","third_party")]
        if len(external_nodes) > 3:
            violations.append({
                "ruleId":"OWASP-API9","severity":"MEDIUM",
                "message":f"OWASP API9:2023 Improper Inventory — {len(external_nodes)} external integrations detected, audit required",
                "description":"Excessive external API integrations increase attack surface. Undocumented or forgotten APIs are a common breach vector.",
                "fix":"Maintain API inventory. Document all external integrations. Regularly audit and decommission unused APIs.",
                "reference":"OWASP API Security Top 10 2023 - API9:2023",
                "framework":"OWASP API",
                "source":"architecture","target":"external",
                "sourceName":"Architecture","targetName":"External Services"
            })

    # ══════════════════════════════════════════════════════
    # ISO 42001 — AI MANAGEMENT SYSTEM (2023)
    # ══════════════════════════════════════════════════════
    iso42_nodes = nodes_comp(nodes, "iso42001") or nodes_comp(nodes, "ai")
    has_ai_node = any(n.get("type","").lower() in ("ai","ml","llm","model") for n in nodes)

    if has_ai_node or iso42_nodes:

        # 42001-1: AI system without monitoring
        if not has_monitor_node:
            violations.append({
                "ruleId":"ISO42001-001","severity":"HIGH",
                "message":"ISO 42001:2023 §8.4 — AI system deployed without monitoring or performance tracking",
                "description":"ISO 42001 requires organizations to monitor AI system performance, detect drift, and track outputs. Unmonitored AI can cause harmful or biased outputs.",
                "fix":"Add AI monitoring node. Track model performance, output distributions, data drift, and bias metrics. Log all AI decisions.",
                "reference":"ISO/IEC 42001:2023 §8.4 AI System Monitoring",
                "framework":"ISO 42001",
                "source":"ai_system","target":"missing_monitoring",
                "sourceName":"AI System","targetName":"Missing: Monitoring"
            })

        # 42001-2: AI directly accessing user data
        for edge in edges:
            src = node_map.get(edge.get("source",""))
            tgt = node_map.get(edge.get("target",""))
            if not src or not tgt: continue
            if src.get("type","").lower() in ("ai","ml","llm","model"):
                if tgt.get("type","").lower() in ("database","db"):
                    violations.append({
                        "ruleId":"ISO42001-002","severity":"CRITICAL",
                        "message":f"ISO 42001:2023 §8.3 — AI component '{src.get('name')}' directly accesses personal data store '{tgt.get('name')}'",
                        "description":"ISO 42001 requires data minimization for AI systems. Direct AI access to full databases violates privacy-by-design principles and DPDP obligations.",
                        "fix":"Create a Data Access Layer between AI and databases. AI should only receive anonymized, filtered, minimum-necessary data via controlled APIs.",
                        "reference":"ISO/IEC 42001:2023 §8.3 AI Data Management + DPDP Act 2023",
                        "framework":"ISO 42001",
                        "source":edge["source"],"target":edge["target"],
                        "sourceName":src.get("name",""),"targetName":tgt.get("name","")
                    })

        # 42001-3: No human oversight for AI
        has_admin = any(n.get("type","").lower() in ("admin","frontend") and "admin" in n.get("name","").lower() for n in nodes)
        if not has_admin:
            violations.append({
                "ruleId":"ISO42001-003","severity":"HIGH",
                "message":"ISO 42001:2023 §6.1.2 — No human oversight mechanism for AI system",
                "description":"ISO 42001 mandates human oversight for AI systems. Without admin/control interfaces, AI can operate without accountability.",
                "fix":"Add Admin Dashboard with AI monitoring, override capability, and decision audit trails.",
                "reference":"ISO/IEC 42001:2023 §6.1.2 Human Oversight",
                "framework":"ISO 42001",
                "source":"ai_system","target":"missing_oversight",
                "sourceName":"AI System","targetName":"Missing: Human Oversight"
            })

        # 42001-4: AI without audit logging
        if not has_monitor_node:
            violations.append({
                "ruleId":"ISO42001-004","severity":"HIGH",
                "message":"ISO 42001:2023 §9.1 — No audit logging for AI system decisions",
                "description":"ISO 42001 requires documentation and logging of AI system decisions for accountability and incident investigation.",
                "fix":"Implement decision logging for all AI outputs. Store input, output, model version, timestamp, and confidence scores.",
                "reference":"ISO/IEC 42001:2023 §9.1 Performance Evaluation",
                "framework":"ISO 42001",
                "source":"ai_system","target":"missing_audit",
                "sourceName":"AI System","targetName":"Missing: Audit Log"
            })

    # ══════════════════════════════════════════════════════
    # SEBI CSCRF (Cybersecurity & Cyber Resilience Framework)
    # ══════════════════════════════════════════════════════
    sebi_nodes = nodes_comp(nodes, "sebi")
    if sebi_nodes:

        # SEBI-1: No API Gateway for trading systems
        if not has_gateway_node:
            violations.append({
                "ruleId":"SEBI-001","severity":"CRITICAL",
                "message":"SEBI CSCRF 2024: No API Gateway — trading systems must have controlled entry points",
                "description":"SEBI CSCRF mandates all market infrastructure institutions implement network security controls including API gateways for all trading system access.",
                "fix":"Implement API Gateway with authentication, rate limiting, and anomaly detection for all trading system endpoints.",
                "reference":"SEBI CSCRF 2024 - Network Security Controls",
                "framework":"SEBI CSCRF",
                "source":"architecture","target":"missing_gateway",
                "sourceName":"Architecture","targetName":"Missing: API Gateway"
            })

        # SEBI-2: No monitoring
        if not has_monitor_node:
            violations.append({
                "ruleId":"SEBI-002","severity":"CRITICAL",
                "message":"SEBI CSCRF 2024: No SOC/monitoring — 24x7 surveillance mandatory for market systems",
                "description":"SEBI CSCRF requires Market Infrastructure Institutions to maintain 24x7 Security Operations Center with real-time threat monitoring.",
                "fix":"Implement SIEM with 24x7 monitoring. Set up alerting for anomalous trading patterns and security events.",
                "reference":"SEBI CSCRF 2024 - SOC Requirements",
                "framework":"SEBI CSCRF",
                "source":"architecture","target":"missing_monitoring",
                "sourceName":"Architecture","targetName":"Missing: SOC/Monitoring"
            })

        # SEBI-3: No auth for trading access
        if not has_auth_node:
            violations.append({
                "ruleId":"SEBI-003","severity":"CRITICAL",
                "message":"SEBI CSCRF 2024: No multi-factor authentication for trading system access",
                "description":"SEBI CSCRF mandates MFA for all privileged access to trading and market infrastructure systems.",
                "fix":"Implement MFA for all user authentication. Use hardware tokens or TOTP for privileged access.",
                "reference":"SEBI CSCRF 2024 - Access Control",
                "framework":"SEBI CSCRF",
                "source":"architecture","target":"missing_auth",
                "sourceName":"Architecture","targetName":"Missing: MFA/Auth"
            })

    # ══════════════════════════════════════════════════════
    # IRDAI CYBERSECURITY GUIDELINES (2023)
    # ══════════════════════════════════════════════════════
    irdai_nodes = nodes_comp(nodes, "irdai")
    if irdai_nodes:

        if not has_gateway_node:
            violations.append({
                "ruleId":"IRDAI-001","severity":"HIGH",
                "message":"IRDAI Cyber Guidelines 2023: No perimeter security — insurance data unprotected",
                "description":"IRDAI 2023 guidelines mandate perimeter security for all insurance IT systems handling policyholder data.",
                "fix":"Implement API Gateway, WAF, and network segmentation for all insurance system access points.",
                "reference":"IRDAI Cyber Security Guidelines 2023",
                "framework":"IRDAI",
                "source":"architecture","target":"missing_gateway",
                "sourceName":"Architecture","targetName":"Missing: Perimeter Security"
            })

        if not has_monitor_node:
            violations.append({
                "ruleId":"IRDAI-002","severity":"HIGH",
                "message":"IRDAI Cyber Guidelines 2023: No incident response monitoring — mandatory for insurers",
                "description":"IRDAI requires insurers to maintain incident detection and response capabilities with defined RTO/RPO objectives.",
                "fix":"Implement monitoring with automated alerting. Define and test incident response procedures.",
                "reference":"IRDAI Cyber Security Guidelines 2023 - Incident Management",
                "framework":"IRDAI",
                "source":"architecture","target":"missing_monitoring",
                "sourceName":"Architecture","targetName":"Missing: Incident Monitoring"
            })

    # ══════════════════════════════════════════════════════
    # ZERO TRUST ARCHITECTURE RULES
    # ══════════════════════════════════════════════════════
    for edge in edges:
        src = node_map.get(edge.get("source",""))
        tgt = node_map.get(edge.get("target",""))
        if not src or not tgt: continue
        src_t = src.get("type","").lower()
        tgt_t = tgt.get("type","").lower()

        # ZT-1: Service to Service without explicit trust
        if src_t == "service" and tgt_t in ("database","db"):
            compliance_scope = src.get("compliance_scope","").lower()
            if not compliance_scope:
                violations.append({
                    "ruleId":"ZT-001","severity":"MEDIUM",
                    "message":f"Zero Trust: '{src.get('name')}' accesses '{tgt.get('name')}' without declared compliance scope",
                    "description":"Zero Trust principle: never trust, always verify. Every service-to-data connection must have explicit authorization scope declared.",
                    "fix":"Tag each node with compliance_scope. Implement service mesh with mTLS. Use workload identity for service-to-service auth.",
                    "reference":"NIST SP 800-207 Zero Trust Architecture",
                    "framework":"Zero Trust",
                    "source":edge["source"],"target":edge["target"],
                    "sourceName":src.get("name",""),"targetName":tgt.get("name","")
                })

        # ZT-2: No encryption between services
        if src_t in ("service","api","worker") and tgt_t in ("service","api","worker"):
            violations.append({
                "ruleId":"ZT-002","severity":"LOW",
                "message":f"Zero Trust: No mTLS verified between '{src.get('name')}' and '{tgt.get('name')}'",
                "description":"Zero Trust requires mutual TLS for all service-to-service communication. Unverified internal traffic is a lateral movement risk.",
                "fix":"Implement service mesh (Istio/Linkerd) with automatic mTLS. Use workload certificates for service identity.",
                "reference":"NIST SP 800-207 Zero Trust Architecture §2.1",
                "framework":"Zero Trust",
                "source":edge["source"],"target":edge["target"],
                "sourceName":src.get("name",""),"targetName":tgt.get("name","")
            })


    # ══════════════════════════════════════════════════════
    # EU AI ACT (2024) — Risk-based framework for AI systems
    # ══════════════════════════════════════════════════════
    has_ai = any(n.get("type","").lower() in ("ai","ml","llm","model") for n in nodes)
    if has_ai:
        if not has_monitor_node:
            violations.append({
                "ruleId":"EUAI-001","severity":"CRITICAL",
                "message":"EU AI Act Article 14 — High-risk AI system without human oversight mechanism",
                "description":"EU AI Act mandates human oversight for high-risk AI systems. No monitoring component detected.",
                "fix":"Implement human oversight interface. Allow operators to monitor, intervene, and override AI decisions.",
                "reference":"EU AI Act 2024 Article 14 — Human Oversight",
                "framework":"EU AI Act",
                "source":"ai_system","target":"missing_oversight",
                "sourceName":"AI System","targetName":"Missing: Human Oversight"
            })
        violations.append({
            "ruleId":"EUAI-004","severity":"HIGH",
            "message":"EU AI Act Article 9 — No risk management system for AI lifecycle",
            "description":"EU AI Act requires continuous risk management throughout AI system lifecycle.",
            "fix":"Establish risk management process. Document identified risks, mitigation measures, and residual risks.",
            "reference":"EU AI Act 2024 Article 9 — Risk Management System",
            "framework":"EU AI Act",
            "source":"ai_system","target":"risk_mgmt",
            "sourceName":"AI System","targetName":"Missing: Risk Management"
        })

    # ══════════════════════════════════════════════════════
    # MAS TRM (Singapore Technology Risk Management)
    # ══════════════════════════════════════════════════════
    mas_nodes = nodes_comp(nodes, "mas") or nodes_comp(nodes, "singapore")
    if mas_nodes:
        if not has_monitor_node:
            violations.append({
                "ruleId":"MAS-001","severity":"CRITICAL",
                "message":"MAS TRM — No monitoring for 99.95% availability requirement",
                "description":"MAS requires critical financial systems at 99.95% availability with real-time monitoring.",
                "fix":"Implement redundant infrastructure. Define RTO < 4 hours. Monitor availability 24x7.",
                "reference":"MAS TRM Guidelines — System Availability",
                "framework":"MAS TRM",
                "source":"architecture","target":"missing_monitoring",
                "sourceName":"Architecture","targetName":"Missing: Availability Monitoring"
            })
        if not has_auth_node:
            violations.append({
                "ruleId":"MAS-006","severity":"CRITICAL",
                "message":"MAS TRM — No MFA for financial services access",
                "description":"MAS mandates multi-factor authentication for all privileged access and customer-facing services.",
                "fix":"Implement MFA across all user access points. Hardware tokens for privileged access.",
                "reference":"MAS TRM Guidelines — Access Control",
                "framework":"MAS TRM",
                "source":"architecture","target":"missing_auth",
                "sourceName":"Architecture","targetName":"Missing: MFA"
            })

    # ══════════════════════════════════════════════════════
    # SOX — Sarbanes-Oxley (US Financial Reporting)
    # ══════════════════════════════════════════════════════
    sox_nodes = nodes_comp(nodes, "sox") or nodes_comp(nodes, "financial")
    if sox_nodes:
        if not has_monitor_node:
            violations.append({
                "ruleId":"SOX-002","severity":"CRITICAL",
                "message":"SOX Section 404 — No audit trail for financial data access",
                "description":"SOX requires complete audit trails for all access to and changes in financial data systems.",
                "fix":"Enable comprehensive audit logging for all financial system access. Retain logs 7 years minimum.",
                "reference":"SOX Section 404 — IT General Controls",
                "framework":"SOX",
                "source":"architecture","target":"missing_audit",
                "sourceName":"Architecture","targetName":"Missing: Audit Trail"
            })


    # ══════════════════════════════════════════════════════
    # SEBI CSCRF — Securities and Exchange Board of India
    # ══════════════════════════════════════════════════════
    has_trading = any_node(nodes, ["trading","exchange","broker","market","settlement","depository"])
    has_algo    = any_node(nodes, ["algo","algorithm","hft","quantitative"])
    if has_trading or has_algo:
        if not has_monitor_node:
            violations.append({"ruleId":"SEBI-001","severity":"CRITICAL",
                "message":"SEBI CSCRF — No real-time monitoring for trading systems",
                "description":"SEBI mandates 24x7 real-time monitoring for all market infrastructure systems.",
                "fix":"Implement real-time monitoring with automated alerts. SOC coverage 24x7.",
                "reference":"SEBI CSCRF 2024 — Monitoring and Surveillance","framework":"SEBI CSCRF",
                "source":"trading","target":"missing_monitoring","sourceName":"Trading System","targetName":"Missing: Monitoring"})
        if not has_auth_node:
            violations.append({"ruleId":"SEBI-002","severity":"CRITICAL",
                "message":"SEBI CSCRF — No access control for trading systems",
                "description":"SEBI requires strict PAM and access controls for market infrastructure systems.",
                "fix":"Implement PAM for all trading access. MFA mandatory. Quarterly access reviews.",
                "reference":"SEBI CSCRF 2024 — Access Control","framework":"SEBI CSCRF",
                "source":"trading","target":"missing_auth","sourceName":"Trading System","targetName":"Missing: Auth"})
        if has_algo and not has_monitor_node:
            violations.append({"ruleId":"SEBI-003","severity":"CRITICAL",
                "message":"SEBI — Algorithmic trading without kill switch mechanism",
                "description":"SEBI requires kill switch for all algorithmic trading systems.",
                "fix":"Implement real-time kill switch. Order limit controls. P&L monitoring with auto-halt.",
                "reference":"SEBI Circular — Algorithmic Trading Controls","framework":"SEBI CSCRF",
                "source":"algo","target":"missing_killswitch","sourceName":"Algo System","targetName":"Missing: Kill Switch"})

    # ══════════════════════════════════════════════════════
    # IRDAI — Insurance Regulatory and Development Authority
    # ══════════════════════════════════════════════════════
    has_insurance = any_node(nodes, ["insurance","policy","claims","premium","actuarial","underwriting"])
    if has_insurance:
        if not has_auth_node:
            violations.append({"ruleId":"IRDAI-002","severity":"HIGH",
                "message":"IRDAI — No access control for insurance systems",
                "description":"IRDAI mandates controlled access for agents, intermediaries, and staff.",
                "fix":"Dedicated portal for agents. MFA mandatory. Session management. Least privilege access.",
                "reference":"IRDAI Guidelines 2023 — Access Management","framework":"IRDAI",
                "source":"insurance","target":"missing_auth","sourceName":"Insurance System","targetName":"Missing: Auth"})
        if not has_monitor_node:
            violations.append({"ruleId":"IRDAI-003","severity":"HIGH",
                "message":"IRDAI — No monitoring for insurance system availability",
                "description":"IRDAI mandates BCP with RTO requirements and 24x7 monitoring for core insurance systems.",
                "fix":"Implement availability monitoring. Define RTO < 4 hours for critical systems. Test BCP quarterly.",
                "reference":"IRDAI Guidelines 2023 — Business Continuity","framework":"IRDAI",
                "source":"insurance","target":"missing_monitoring","sourceName":"Insurance System","targetName":"Missing: Monitoring"})

    # ══════════════════════════════════════════════════════
    # ISO 42001 — AI Management System
    # ══════════════════════════════════════════════════════
    has_ai_any = any_node(nodes, ["ai","ml","llm","model","inference","training","neural"])
    if has_ai_any:
        if not has_monitor_node:
            violations.append({"ruleId":"ISO42001-001","severity":"HIGH",
                "message":"ISO 42001 — AI system without performance monitoring",
                "description":"ISO 42001 requires monitoring of AI system performance throughout lifecycle.",
                "fix":"Implement AI performance monitoring. Track accuracy, drift, fairness metrics. Alert on degradation.",
                "reference":"ISO 42001:2023 §9.1 — Monitoring and Measurement","framework":"ISO 42001",
                "source":"ai","target":"missing_monitoring","sourceName":"AI System","targetName":"Missing: Monitoring"})
        violations.append({"ruleId":"ISO42001-002","severity":"HIGH",
            "message":"ISO 42001 — AI bias assessment required",
            "description":"ISO 42001 requires assessment of potential bias in AI systems.",
            "fix":"Conduct bias evaluation across protected attributes. Document methodology. Re-evaluate after updates.",
            "reference":"ISO 42001:2023 §6.1 — Risks and Opportunities","framework":"ISO 42001",
            "source":"ai","target":"bias","sourceName":"AI System","targetName":"Missing: Bias Assessment"})

    # ══════════════════════════════════════════════════════
    # NIS2 — Network and Information Security Directive 2
    # ══════════════════════════════════════════════════════
    if len(nodes) > 4:
        if not has_monitor_node:
            violations.append({"ruleId":"NIS2-001","severity":"CRITICAL",
                "message":"NIS2 Article 21 — No security monitoring for essential entity",
                "description":"NIS2 requires essential entities to implement security monitoring and incident detection.",
                "fix":"Implement 24x7 security monitoring. Incident detection. 24-hour breach notification readiness.",
                "reference":"NIS2 Directive Article 21 — Security Measures","framework":"NIS2",
                "source":"architecture","target":"missing_monitoring","sourceName":"Architecture","targetName":"Missing: Monitoring"})
        if not has_auth_node:
            violations.append({"ruleId":"NIS2-002","severity":"CRITICAL",
                "message":"NIS2 Article 21 — Multi-factor authentication not implemented",
                "description":"NIS2 explicitly requires MFA or continuous authentication for all users.",
                "fix":"Implement MFA for all accounts. Hardware tokens for privileged access. Enforce via policy.",
                "reference":"NIS2 Directive Article 21(2)(j) — MFA","framework":"NIS2",
                "source":"user","target":"missing_mfa","sourceName":"User","targetName":"Missing: MFA"})
        violations.append({"ruleId":"NIS2-003","severity":"HIGH",
            "message":"NIS2 — Supply chain security measures required",
            "description":"NIS2 requires organizations to manage cybersecurity risks in their supply chain.",
            "fix":"Assess all external dependencies. Security requirements in supplier contracts. Continuous monitoring.",
            "reference":"NIS2 Directive Article 21(2)(d) — Supply Chain","framework":"NIS2",
            "source":"external","target":"architecture","sourceName":"External Dependencies","targetName":"Architecture"})

    # ══════════════════════════════════════════════════════
    # CCPA — California Consumer Privacy Act
    # ══════════════════════════════════════════════════════
    has_us_consumers = any_node(nodes, ["user","consumer","customer"]) and any_node(nodes, ["database","storage","analytics"])
    if has_us_consumers:
        if not any_node(nodes, ["consent","privacy","preference"]):
            violations.append({"ruleId":"CCPA-001","severity":"HIGH",
                "message":"CCPA §1798.100 — No consent management component",
                "description":"CCPA requires right to know, delete, and opt-out of sale of personal information.",
                "fix":"Add consent management. Implement Do Not Sell mechanism. Privacy preference center for users.",
                "reference":"CCPA §1798.100 — Consumer Rights","framework":"CCPA",
                "source":"user","target":"missing_consent","sourceName":"User","targetName":"Missing: Consent Mgmt"})
        if any_node(nodes, ["analytics","tracking","profiling","advertising"]):
            violations.append({"ruleId":"CCPA-002","severity":"HIGH",
                "message":"CCPA §1798.120 — Analytics without opt-out mechanism",
                "description":"CCPA grants consumers right to opt out of sale or sharing for advertising/analytics.",
                "fix":"Implement GPC signal detection. Opt-out mechanism on website. Honor within 15 days.",
                "reference":"CCPA §1798.120 — Right to Opt-Out","framework":"CCPA",
                "source":"analytics","target":"missing_optout","sourceName":"Analytics","targetName":"Missing: Opt-Out"})

    # ══════════════════════════════════════════════════════
    # ISO 22301 — Business Continuity
    # ══════════════════════════════════════════════════════
    if len(nodes) > 3:
        has_backup = any_node(nodes, ["backup","replica","dr","disaster","failover","redundant"])
        if not has_backup:
            violations.append({"ruleId":"ISO22301-001","severity":"HIGH",
                "message":"ISO 22301 — No backup or disaster recovery component",
                "description":"ISO 22301 requires business continuity with backup and recovery for all critical functions.",
                "fix":"Add backup/replica nodes. Define RTO and RPO. Implement DR site. Test quarterly.",
                "reference":"ISO 22301:2019 §8.4 — Business Continuity Plans","framework":"ISO 22301",
                "source":"architecture","target":"missing_dr","sourceName":"Architecture","targetName":"Missing: DR/Backup"})

    # ══════════════════════════════════════════════════════
    # APRA CPS 234 — Australian Prudential Regulation
    # ══════════════════════════════════════════════════════
    has_apra = nodes_comp(nodes, "apra") or nodes_comp(nodes, "australia") or nodes_comp(nodes, "au")
    if has_apra:
        if not has_monitor_node:
            violations.append({"ruleId":"APRA-001","severity":"CRITICAL",
                "message":"APRA CPS 234 — No information security monitoring",
                "description":"APRA requires security capability commensurate with size and threat landscape.",
                "fix":"Implement security monitoring. SIEM deployment. 24x7 SOC. Incident detection and alerting.",
                "reference":"APRA CPS 234 §23 — Information Security Capability","framework":"APRA CPS",
                "source":"architecture","target":"missing_monitoring","sourceName":"Architecture","targetName":"Missing: Monitoring"})

    # ══════════════════════════════════════════════════════
    # FedRAMP — Federal Risk and Authorization
    # ══════════════════════════════════════════════════════
    has_federal = any_node(nodes, ["federal","government","agency"]) or nodes_comp(nodes, "fedramp")
    if has_federal:
        violations.append({"ruleId":"FED-001","severity":"CRITICAL",
            "message":"FedRAMP — Authorization to Operate required for federal systems",
            "description":"Cloud services handling US federal data require FedRAMP ATO before production.",
            "fix":"Initiate FedRAMP authorization. Engage 3PAO. Develop System Security Plan.",
            "reference":"FedRAMP Authorization Process — ATO","framework":"FedRAMP",
            "source":"architecture","target":"ato","sourceName":"Federal System","targetName":"Missing: ATO"})

    # ══════════════════════════════════════════════════════
    # SOX — Expanded detections
    # ══════════════════════════════════════════════════════
    has_sox = nodes_comp(nodes, "sox") or any_node(nodes, ["erp","accounting","financial","ledger"])
    if has_sox:
        if not has_monitor_node:
            violations.append({"ruleId":"SOX-004","severity":"CRITICAL",
                "message":"SOX Section 404 — No audit trail for financial system",
                "description":"SOX requires complete audit trails for all access to financial data systems.",
                "fix":"Enable audit logging for all financial systems. Log all access. Retain 7 years minimum.",
                "reference":"SOX Section 404 — IT General Controls","framework":"SOX",
                "source":"financial","target":"audit","sourceName":"Financial System","targetName":"Missing: Audit Trail"})


        violations.sort(key=lambda x: SEV.get(x.get("severity","LOW"), 9))
    return violations
