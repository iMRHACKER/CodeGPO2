"""
CodeGPO Compliance Engine v2
File: backend/services/compliance_engine.py

47 → 105 rules across 12 frameworks
New frameworks: HIPAA, NIST CSF, CIS Controls, FedRAMP,
                CCPA, RBI Cybersecurity, SEBI CSCRF, MAS TRM
"""
from fastapi import APIRouter
router = APIRouter(prefix="/api/compliance", tags=["compliance"])

FRAMEWORKS = {
    # ── Existing ──────────────────────────────────────────────────────────────
    "soc2": {
        "name": "SOC 2 Type II",
        "description": "Service Organization Control 2 — Security, Availability, Confidentiality",
        "icon": "🔐",
        "category": "Security",
        "region": "Global"
    },
    "pci_dss": {
        "name": "PCI-DSS v4.0",
        "description": "Payment Card Industry Data Security Standard",
        "icon": "💳",
        "category": "Payment",
        "region": "Global"
    },
    "gdpr": {
        "name": "GDPR",
        "description": "General Data Protection Regulation",
        "icon": "🇪🇺",
        "category": "Privacy",
        "region": "EU"
    },
    "iso_27001": {
        "name": "ISO 27001:2022",
        "description": "Information Security Management System",
        "icon": "🏆",
        "category": "Security",
        "region": "Global"
    },
    "dpdp": {
        "name": "DPDP Act 2023",
        "description": "Digital Personal Data Protection Act — India",
        "icon": "🇮🇳",
        "category": "Privacy",
        "region": "India"
    },
    "owasp": {
        "name": "OWASP Top 10",
        "description": "Open Web Application Security Project Top 10 Risks",
        "icon": "🕷️",
        "category": "AppSec",
        "region": "Global"
    },
    "iot_security": {
        "name": "IoT Security",
        "description": "IoT Security Foundation Best Practices",
        "icon": "📡",
        "category": "IoT",
        "region": "Global"
    },
    # ── New Frameworks ────────────────────────────────────────────────────────
    "hipaa": {
        "name": "HIPAA",
        "description": "Health Insurance Portability and Accountability Act",
        "icon": "🏥",
        "category": "Healthcare",
        "region": "USA"
    },
    "nist_csf": {
        "name": "NIST CSF 2.0",
        "description": "NIST Cybersecurity Framework",
        "icon": "🛡️",
        "category": "Security",
        "region": "USA/Global"
    },
    "cis_controls": {
        "name": "CIS Controls v8",
        "description": "Center for Internet Security Critical Controls",
        "icon": "🔒",
        "category": "Security",
        "region": "Global"
    },
    "ccpa": {
        "name": "CCPA",
        "description": "California Consumer Privacy Act",
        "icon": "🏖️",
        "category": "Privacy",
        "region": "USA/California"
    },
    "rbi_cyber": {
        "name": "RBI Cybersecurity",
        "description": "Reserve Bank of India Cybersecurity Framework",
        "icon": "🏦",
        "category": "Finance",
        "region": "India"
    },
}

RULES = {
    # ══════════════════════════════════════════════════════════════════════════
    # SOC2 — 10 rules
    # ══════════════════════════════════════════════════════════════════════════
    "SOC2-CC1.1": {
        "id": "SOC2-CC1.1", "framework": "soc2", "severity": "HIGH",
        "title": "Access Control Policy Required",
        "description": "All system access must be governed by a documented access control policy.",
        "fix": "Define and document access control policies for all services.",
        "category": "Access Control"
    },
    "SOC2-CC2.1": {
        "id": "SOC2-CC2.1", "framework": "soc2", "severity": "HIGH",
        "title": "Communication of Responsibilities",
        "description": "Security roles and responsibilities must be clearly defined.",
        "fix": "Document security ownership for each service component.",
        "category": "Communication"
    },
    "SOC2-CC3.2": {
        "id": "SOC2-CC3.2", "framework": "soc2", "severity": "CRITICAL",
        "title": "Risk Assessment Required",
        "description": "A risk assessment must be performed for all system changes.",
        "fix": "Implement change management with mandatory risk assessment.",
        "category": "Risk Management"
    },
    "SOC2-CC6.1": {
        "id": "SOC2-CC6.1", "framework": "soc2", "severity": "CRITICAL",
        "title": "Logical Access Controls",
        "description": "Implement logical access security controls for all system resources.",
        "fix": "Enforce role-based access control on all service endpoints.",
        "category": "Access Control"
    },
    "SOC2-CC6.2": {
        "id": "SOC2-CC6.2", "framework": "soc2", "severity": "HIGH",
        "title": "Authentication Required",
        "description": "All users must authenticate before accessing system resources.",
        "fix": "Implement strong authentication — JWT or OAuth 2.0.",
        "category": "Authentication"
    },
    "SOC2-CC6.3": {
        "id": "SOC2-CC6.3", "framework": "soc2", "severity": "HIGH",
        "title": "Access Restriction",
        "description": "Access to sensitive data must be restricted to authorized users only.",
        "fix": "Implement least-privilege access with explicit authorization.",
        "category": "Authorization"
    },
    "SOC2-CC7.1": {
        "id": "SOC2-CC7.1", "framework": "soc2", "severity": "MEDIUM",
        "title": "Vulnerability Detection",
        "description": "Systems must detect and respond to vulnerabilities.",
        "fix": "Implement automated vulnerability scanning in CI/CD pipeline.",
        "category": "Vulnerability Management"
    },
    "SOC2-CC7.2": {
        "id": "SOC2-CC7.2", "framework": "soc2", "severity": "HIGH",
        "title": "System Monitoring",
        "description": "Continuously monitor system components for unauthorized activity.",
        "fix": "Deploy application monitoring with alerts for anomalous activity.",
        "category": "Monitoring"
    },
    "SOC2-CC8.1": {
        "id": "SOC2-CC8.1", "framework": "soc2", "severity": "MEDIUM",
        "title": "Change Management",
        "description": "All system changes must go through a formal change management process.",
        "fix": "Implement PR-based change management with approval gates.",
        "category": "Change Management"
    },
    "SOC2-CC9.1": {
        "id": "SOC2-CC9.1", "framework": "soc2", "severity": "HIGH",
        "title": "Vendor Risk Management",
        "description": "Third-party vendors must be assessed for security risks.",
        "fix": "Document and assess all external service dependencies.",
        "category": "Vendor Management"
    },

    # ══════════════════════════════════════════════════════════════════════════
    # PCI-DSS — 10 rules
    # ══════════════════════════════════════════════════════════════════════════
    "PCI-1.1": {
        "id": "PCI-1.1", "framework": "pci_dss", "severity": "CRITICAL",
        "title": "Network Segmentation",
        "description": "Cardholder data environment must be isolated from other networks.",
        "fix": "Implement network segmentation — separate payment services from other services.",
        "category": "Network Security"
    },
    "PCI-2.1": {
        "id": "PCI-2.1", "framework": "pci_dss", "severity": "HIGH",
        "title": "No Default Credentials",
        "description": "Change all default passwords and security parameters before deployment.",
        "fix": "Rotate all default credentials. Use secrets management (e.g., Vault).",
        "category": "Configuration"
    },
    "PCI-3.1": {
        "id": "PCI-3.1", "framework": "pci_dss", "severity": "CRITICAL",
        "title": "No Raw Card Data Storage",
        "description": "Cardholder data must never be stored in plain text.",
        "fix": "Use tokenization (Stripe tokens) — never store raw card numbers.",
        "category": "Data Protection"
    },
    "PCI-3.4": {
        "id": "PCI-3.4", "framework": "pci_dss", "severity": "CRITICAL",
        "title": "PAN Data Encryption",
        "description": "Primary Account Numbers must be encrypted at rest.",
        "fix": "Encrypt PAN with AES-256. Use tokenization where possible.",
        "category": "Encryption"
    },
    "PCI-4.1": {
        "id": "PCI-4.1", "framework": "pci_dss", "severity": "CRITICAL",
        "title": "Encryption in Transit",
        "description": "Card data must be encrypted during transmission over open networks.",
        "fix": "Enforce TLS 1.2+ for all payment data transmission.",
        "category": "Transmission Security"
    },
    "PCI-6.1": {
        "id": "PCI-6.1", "framework": "pci_dss", "severity": "HIGH",
        "title": "Vulnerability Management",
        "description": "Payment systems must have a vulnerability management program.",
        "fix": "Implement automated dependency scanning for payment service.",
        "category": "Vulnerability Management"
    },
    "PCI-7.1": {
        "id": "PCI-7.1", "framework": "pci_dss", "severity": "HIGH",
        "title": "Restrict Access to Card Data",
        "description": "Access to cardholder data must be restricted on a need-to-know basis.",
        "fix": "Implement RBAC — only payment service can access card-related data.",
        "category": "Access Control"
    },
    "PCI-8.2": {
        "id": "PCI-8.2", "framework": "pci_dss", "severity": "HIGH",
        "title": "Unique User Authentication",
        "description": "All users accessing payment systems must have unique credentials.",
        "fix": "Prohibit shared accounts. Enforce individual user authentication.",
        "category": "Authentication"
    },
    "PCI-10.1": {
        "id": "PCI-10.1", "framework": "pci_dss", "severity": "HIGH",
        "title": "Audit Logging",
        "description": "All access to card data must be logged.",
        "fix": "Enable audit logging on payment service. Log all data access events.",
        "category": "Logging"
    },
    "PCI-12.1": {
        "id": "PCI-12.1", "framework": "pci_dss", "severity": "MEDIUM",
        "title": "Security Policy Documentation",
        "description": "A comprehensive security policy must be documented.",
        "fix": "Document and publish security policies for all payment-handling components.",
        "category": "Policy"
    },

    # ══════════════════════════════════════════════════════════════════════════
    # GDPR — 10 rules
    # ══════════════════════════════════════════════════════════════════════════
    "GDPR-Art5": {
        "id": "GDPR-Art5", "framework": "gdpr", "severity": "HIGH",
        "title": "Data Minimization",
        "description": "Collect only data that is necessary for the stated purpose.",
        "fix": "Audit data fields — remove any that aren't strictly necessary.",
        "category": "Data Minimization"
    },
    "GDPR-Art6": {
        "id": "GDPR-Art6", "framework": "gdpr", "severity": "CRITICAL",
        "title": "Lawful Basis for Processing",
        "description": "Every data processing activity must have a documented lawful basis.",
        "fix": "Document lawful basis (consent/contract/legitimate interest) for each data type.",
        "category": "Legal Basis"
    },
    "GDPR-Art13": {
        "id": "GDPR-Art13", "framework": "gdpr", "severity": "HIGH",
        "title": "Privacy Notice Required",
        "description": "Users must be informed about data processing at point of collection.",
        "fix": "Add privacy notice/policy accessible at data collection points.",
        "category": "Transparency"
    },
    "GDPR-Art17": {
        "id": "GDPR-Art17", "framework": "gdpr", "severity": "HIGH",
        "title": "Right to Erasure",
        "description": "Systems must support deletion of user data on request.",
        "fix": "Implement data deletion API and cascade delete for all user data.",
        "category": "Data Rights"
    },
    "GDPR-Art20": {
        "id": "GDPR-Art20", "framework": "gdpr", "severity": "MEDIUM",
        "title": "Data Portability",
        "description": "Users must be able to export their personal data.",
        "fix": "Implement data export endpoint returning user data in machine-readable format.",
        "category": "Data Rights"
    },
    "GDPR-Art25": {
        "id": "GDPR-Art25", "framework": "gdpr", "severity": "HIGH",
        "title": "Privacy by Design",
        "description": "Privacy must be built into systems from the start, not added later.",
        "fix": "Review data architecture — apply privacy by default (opt-in, not opt-out).",
        "category": "Privacy Engineering"
    },
    "GDPR-Art32": {
        "id": "GDPR-Art32", "framework": "gdpr", "severity": "CRITICAL",
        "title": "Encryption of Personal Data",
        "description": "Personal data must be protected with appropriate technical measures.",
        "fix": "Encrypt personal data at rest and in transit. Implement access controls.",
        "category": "Security Measures"
    },
    "GDPR-Art33": {
        "id": "GDPR-Art33", "framework": "gdpr", "severity": "HIGH",
        "title": "72-Hour Breach Notification",
        "description": "Data breaches must be reported to authorities within 72 hours.",
        "fix": "Implement breach detection and automated notification workflow.",
        "category": "Incident Response"
    },
    "GDPR-Art35": {
        "id": "GDPR-Art35", "framework": "gdpr", "severity": "MEDIUM",
        "title": "Data Protection Impact Assessment",
        "description": "High-risk processing requires a DPIA before implementation.",
        "fix": "Conduct DPIA for all high-risk data processing (biometrics, profiling, health).",
        "category": "Risk Assessment"
    },
    "GDPR-Art44": {
        "id": "GDPR-Art44", "framework": "gdpr", "severity": "HIGH",
        "title": "Cross-Border Data Transfer",
        "description": "Personal data transfers outside EU require adequate protection.",
        "fix": "Use Standard Contractual Clauses for non-EU data transfers.",
        "category": "International Transfer"
    },

    # ══════════════════════════════════════════════════════════════════════════
    # ISO 27001 — 8 rules
    # ══════════════════════════════════════════════════════════════════════════
    "ISO-A5.1": {
        "id": "ISO-A5.1", "framework": "iso_27001", "severity": "HIGH",
        "title": "Information Security Policy",
        "description": "An information security policy must be defined and approved.",
        "fix": "Document and publish information security policy. Review annually.",
        "category": "Policy"
    },
    "ISO-A8.1": {
        "id": "ISO-A8.1", "framework": "iso_27001", "severity": "HIGH",
        "title": "Asset Inventory",
        "description": "All information assets must be identified and documented.",
        "fix": "Maintain an asset inventory of all services, databases, and data stores.",
        "category": "Asset Management"
    },
    "ISO-A9.1": {
        "id": "ISO-A9.1", "framework": "iso_27001", "severity": "CRITICAL",
        "title": "Access Control Policy",
        "description": "Access to information must be restricted based on business requirements.",
        "fix": "Implement role-based access control aligned with business function.",
        "category": "Access Control"
    },
    "ISO-A10.1": {
        "id": "ISO-A10.1", "framework": "iso_27001", "severity": "CRITICAL",
        "title": "Cryptographic Controls",
        "description": "Cryptographic controls must be used to protect sensitive information.",
        "fix": "Enforce AES-256 encryption at rest, TLS 1.3 in transit.",
        "category": "Cryptography"
    },
    "ISO-A12.1": {
        "id": "ISO-A12.1", "framework": "iso_27001", "severity": "MEDIUM",
        "title": "Operational Procedures",
        "description": "Operating procedures must be documented and maintained.",
        "fix": "Document operational runbooks for all critical system components.",
        "category": "Operations"
    },
    "ISO-A14.2": {
        "id": "ISO-A14.2", "framework": "iso_27001", "severity": "HIGH",
        "title": "Secure Development",
        "description": "Security must be integrated into the software development lifecycle.",
        "fix": "Implement security code review, SAST/DAST tools in CI/CD.",
        "category": "Secure Development"
    },
    "ISO-A16.1": {
        "id": "ISO-A16.1", "framework": "iso_27001", "severity": "HIGH",
        "title": "Incident Management",
        "description": "Security incidents must be reported and managed consistently.",
        "fix": "Define incident response procedures. Establish escalation paths.",
        "category": "Incident Management"
    },
    "ISO-A18.1": {
        "id": "ISO-A18.1", "framework": "iso_27001", "severity": "MEDIUM",
        "title": "Legal Compliance",
        "description": "All applicable legal requirements must be identified and met.",
        "fix": "Maintain a compliance register. Map controls to legal requirements.",
        "category": "Compliance"
    },

    # ══════════════════════════════════════════════════════════════════════════
    # DPDP Act 2023 (India) — 8 rules
    # ══════════════════════════════════════════════════════════════════════════
    "DPDP-S4": {
        "id": "DPDP-S4", "framework": "dpdp", "severity": "CRITICAL",
        "title": "Consent for Personal Data",
        "description": "Processing personal data requires free, specific, informed consent.",
        "fix": "Implement explicit consent mechanisms before collecting personal data.",
        "category": "Consent"
    },
    "DPDP-S6": {
        "id": "DPDP-S6", "framework": "dpdp", "severity": "HIGH",
        "title": "Notice Before Collection",
        "description": "Data principals must be notified before or during data collection.",
        "fix": "Display clear notice of data being collected and its purpose.",
        "category": "Notice"
    },
    "DPDP-S9": {
        "id": "DPDP-S9", "framework": "dpdp", "severity": "HIGH",
        "title": "Children's Data Protection",
        "description": "Processing children's data requires verifiable parental consent.",
        "fix": "Implement age verification and parental consent for under-18 users.",
        "category": "Child Safety"
    },
    "DPDP-S10": {
        "id": "DPDP-S10", "framework": "dpdp", "severity": "HIGH",
        "title": "Data Fiduciary Obligations",
        "description": "Data fiduciaries must ensure data accuracy and implement security.",
        "fix": "Implement data quality checks. Secure data with encryption and access controls.",
        "category": "Data Quality"
    },
    "DPDP-S13": {
        "id": "DPDP-S13", "framework": "dpdp", "severity": "HIGH",
        "title": "Right to Correction & Erasure",
        "description": "Data principals have the right to correct and erase their data.",
        "fix": "Implement user-accessible data correction and deletion APIs.",
        "category": "Data Rights"
    },
    "DPDP-S17": {
        "id": "DPDP-S17", "framework": "dpdp", "severity": "MEDIUM",
        "title": "Data Localisation",
        "description": "Certain personal data must be stored within India.",
        "fix": "Review data residency. Store sensitive personal data on India-hosted servers.",
        "category": "Data Localisation"
    },
    "DPDP-S40": {
        "id": "DPDP-S40", "framework": "dpdp", "severity": "HIGH",
        "title": "Breach Notification",
        "description": "Data breaches must be notified to the Data Protection Board.",
        "fix": "Implement breach detection and notification workflow.",
        "category": "Incident Response"
    },
    "DPDP-S44": {
        "id": "DPDP-S44", "framework": "dpdp", "severity": "CRITICAL",
        "title": "Cross-Border Data Transfer",
        "description": "Transfer of personal data outside India requires government approval.",
        "fix": "Document all cross-border transfers. Obtain required approvals.",
        "category": "International Transfer"
    },

    # ══════════════════════════════════════════════════════════════════════════
    # OWASP Top 10 — 10 rules
    # ══════════════════════════════════════════════════════════════════════════
    "OWASP-A01": {
        "id": "OWASP-A01", "framework": "owasp", "severity": "CRITICAL",
        "title": "Broken Access Control",
        "description": "Access control failures allow unauthorized access to functionality.",
        "fix": "Implement deny-by-default. Enforce access control server-side.",
        "category": "Access Control"
    },
    "OWASP-A02": {
        "id": "OWASP-A02", "framework": "owasp", "severity": "CRITICAL",
        "title": "Cryptographic Failures",
        "description": "Weak cryptography exposes sensitive data.",
        "fix": "Use AES-256, TLS 1.3. Never use MD5/SHA1 for passwords. Use bcrypt/argon2.",
        "category": "Cryptography"
    },
    "OWASP-A03": {
        "id": "OWASP-A03", "framework": "owasp", "severity": "CRITICAL",
        "title": "Injection Vulnerabilities",
        "description": "SQL/NoSQL/OS injection allows attacker-controlled queries.",
        "fix": "Use parameterized queries. Validate and sanitize all user input.",
        "category": "Injection"
    },
    "OWASP-A04": {
        "id": "OWASP-A04", "framework": "owasp", "severity": "HIGH",
        "title": "Insecure Design",
        "description": "Missing security controls in design lead to exploitable patterns.",
        "fix": "Apply threat modeling. Enforce security design patterns from architecture phase.",
        "category": "Secure Design"
    },
    "OWASP-A05": {
        "id": "OWASP-A05", "framework": "owasp", "severity": "HIGH",
        "title": "Security Misconfiguration",
        "description": "Insecure default configs, open cloud storage, verbose errors.",
        "fix": "Harden configurations. Disable unused features. Enable security headers.",
        "category": "Configuration"
    },
    "OWASP-A06": {
        "id": "OWASP-A06", "framework": "owasp", "severity": "HIGH",
        "title": "Vulnerable Components",
        "description": "Using components with known vulnerabilities.",
        "fix": "Run dependency scanning. Update vulnerable packages. Pin dependency versions.",
        "category": "Dependency Management"
    },
    "OWASP-A07": {
        "id": "OWASP-A07", "framework": "owasp", "severity": "CRITICAL",
        "title": "Authentication Failures",
        "description": "Weak authentication allows credential attacks.",
        "fix": "Implement MFA. Use secure session management. Enforce password policy.",
        "category": "Authentication"
    },
    "OWASP-A08": {
        "id": "OWASP-A08", "framework": "owasp", "severity": "HIGH",
        "title": "Software Integrity Failures",
        "description": "Unsigned/unverified code and updates.",
        "fix": "Verify digital signatures. Use trusted package sources. Implement SRI.",
        "category": "Software Integrity"
    },
    "OWASP-A09": {
        "id": "OWASP-A09", "framework": "owasp", "severity": "MEDIUM",
        "title": "Security Logging Failures",
        "description": "Insufficient logging prevents detection and forensics.",
        "fix": "Log all auth events, access violations, and data operations. Set up alerts.",
        "category": "Logging"
    },
    "OWASP-A10": {
        "id": "OWASP-A10", "framework": "owasp", "severity": "HIGH",
        "title": "Server-Side Request Forgery",
        "description": "SSRF allows attackers to induce server-side requests.",
        "fix": "Validate and sanitize all user-supplied URLs. Implement allowlists.",
        "category": "SSRF"
    },

    # ══════════════════════════════════════════════════════════════════════════
    # HIPAA — 10 rules
    # ══════════════════════════════════════════════════════════════════════════
    "HIPAA-164.308a1": {
        "id": "HIPAA-164.308a1", "framework": "hipaa", "severity": "CRITICAL",
        "title": "Security Officer Designation",
        "description": "A security official must be designated to develop security policies.",
        "fix": "Appoint a HIPAA Security Officer. Document their responsibilities.",
        "category": "Administrative"
    },
    "HIPAA-164.308a3": {
        "id": "HIPAA-164.308a3", "framework": "hipaa", "severity": "CRITICAL",
        "title": "Workforce Authorization",
        "description": "Procedures for authorizing workforce access to PHI must exist.",
        "fix": "Implement role-based access for PHI. Document authorization procedures.",
        "category": "Access Control"
    },
    "HIPAA-164.308a5": {
        "id": "HIPAA-164.308a5", "framework": "hipaa", "severity": "HIGH",
        "title": "Security Awareness Training",
        "description": "All workforce must receive security awareness training.",
        "fix": "Implement mandatory annual security training for all staff.",
        "category": "Training"
    },
    "HIPAA-164.312a1": {
        "id": "HIPAA-164.312a1", "framework": "hipaa", "severity": "CRITICAL",
        "title": "Unique User Identification",
        "description": "Each user accessing PHI must have a unique identifier.",
        "fix": "No shared accounts. Assign unique user IDs for all PHI system access.",
        "category": "Authentication"
    },
    "HIPAA-164.312a2": {
        "id": "HIPAA-164.312a2", "framework": "hipaa", "severity": "HIGH",
        "title": "Emergency Access Procedure",
        "description": "Emergency procedures for obtaining PHI must be established.",
        "fix": "Document and implement emergency access procedures for PHI systems.",
        "category": "Emergency Access"
    },
    "HIPAA-164.312b": {
        "id": "HIPAA-164.312b", "framework": "hipaa", "severity": "CRITICAL",
        "title": "Audit Controls",
        "description": "Hardware and software activity in PHI systems must be logged.",
        "fix": "Enable comprehensive audit logging for all PHI access and modification.",
        "category": "Audit"
    },
    "HIPAA-164.312c": {
        "id": "HIPAA-164.312c", "framework": "hipaa", "severity": "HIGH",
        "title": "Data Integrity",
        "description": "PHI must be protected from alteration or destruction.",
        "fix": "Implement checksums/hash verification for PHI data. Enable immutable storage.",
        "category": "Data Integrity"
    },
    "HIPAA-164.312e1": {
        "id": "HIPAA-164.312e1", "framework": "hipaa", "severity": "CRITICAL",
        "title": "PHI Transmission Encryption",
        "description": "PHI transmitted over networks must be encrypted.",
        "fix": "Enforce TLS 1.3 for all PHI transmission. No cleartext PHI.",
        "category": "Transmission Security"
    },
    "HIPAA-164.314a1": {
        "id": "HIPAA-164.314a1", "framework": "hipaa", "severity": "HIGH",
        "title": "Business Associate Agreement",
        "description": "All vendors handling PHI must have a signed BAA.",
        "fix": "Execute BAAs with all vendors who handle PHI (AWS, cloud providers, etc).",
        "category": "Business Associates"
    },
    "HIPAA-164.316a": {
        "id": "HIPAA-164.316a", "framework": "hipaa", "severity": "MEDIUM",
        "title": "Policy Documentation",
        "description": "All HIPAA policies must be documented and retained for 6 years.",
        "fix": "Document all security policies. Maintain version history for 6 years.",
        "category": "Documentation"
    },

    # ══════════════════════════════════════════════════════════════════════════
    # NIST CSF 2.0 — 8 rules
    # ══════════════════════════════════════════════════════════════════════════
    "NIST-GV.OC-01": {
        "id": "NIST-GV.OC-01", "framework": "nist_csf", "severity": "HIGH",
        "title": "Cybersecurity Roles Defined",
        "description": "Cybersecurity roles and responsibilities must be established.",
        "fix": "Define security roles. Document responsibilities in org chart.",
        "category": "Governance"
    },
    "NIST-ID.AM-01": {
        "id": "NIST-ID.AM-01", "framework": "nist_csf", "severity": "HIGH",
        "title": "Asset Identification",
        "description": "Organizational assets that enable achieving cybersecurity objectives must be identified.",
        "fix": "Maintain an up-to-date inventory of hardware, software, and data assets.",
        "category": "Asset Management"
    },
    "NIST-PR.AC-01": {
        "id": "NIST-PR.AC-01", "framework": "nist_csf", "severity": "CRITICAL",
        "title": "Identity Management",
        "description": "Identities and credentials for authorized users must be managed.",
        "fix": "Implement IAM solution with lifecycle management for all user accounts.",
        "category": "Identity & Access"
    },
    "NIST-PR.DS-01": {
        "id": "NIST-PR.DS-01", "framework": "nist_csf", "severity": "CRITICAL",
        "title": "Data at Rest Protection",
        "description": "Data at rest must be protected from unauthorized access.",
        "fix": "Encrypt all sensitive data at rest using AES-256 or equivalent.",
        "category": "Data Security"
    },
    "NIST-DE.CM-01": {
        "id": "NIST-DE.CM-01", "framework": "nist_csf", "severity": "HIGH",
        "title": "Network Monitoring",
        "description": "Networks must be monitored to detect cybersecurity events.",
        "fix": "Implement network monitoring with anomaly detection and alerting.",
        "category": "Detection"
    },
    "NIST-RS.RP-01": {
        "id": "NIST-RS.RP-01", "framework": "nist_csf", "severity": "HIGH",
        "title": "Incident Response Plan",
        "description": "An incident response plan must exist and be executable.",
        "fix": "Create and test an incident response plan. Run tabletop exercises.",
        "category": "Response"
    },
    "NIST-RC.RP-01": {
        "id": "NIST-RC.RP-01", "framework": "nist_csf", "severity": "MEDIUM",
        "title": "Recovery Plan",
        "description": "A recovery plan must exist to restore normal operations.",
        "fix": "Document and test disaster recovery plan. Define RPO and RTO.",
        "category": "Recovery"
    },
    "NIST-ID.RA-01": {
        "id": "NIST-ID.RA-01", "framework": "nist_csf", "severity": "HIGH",
        "title": "Risk Assessment",
        "description": "Vulnerabilities and threats must be identified and assessed.",
        "fix": "Conduct regular risk assessments. Maintain risk register.",
        "category": "Risk Assessment"
    },

    # ══════════════════════════════════════════════════════════════════════════
    # CIS Controls v8 — 8 rules
    # ══════════════════════════════════════════════════════════════════════════
    "CIS-C01": {
        "id": "CIS-C01", "framework": "cis_controls", "severity": "HIGH",
        "title": "Enterprise Asset Inventory",
        "description": "Actively manage all enterprise assets to understand attack surface.",
        "fix": "Implement automated asset discovery and maintain current inventory.",
        "category": "Asset Management"
    },
    "CIS-C03": {
        "id": "CIS-C03", "framework": "cis_controls", "severity": "HIGH",
        "title": "Data Protection",
        "description": "Develop processes to identify, classify, and secure data.",
        "fix": "Classify data by sensitivity. Apply controls based on classification.",
        "category": "Data Protection"
    },
    "CIS-C05": {
        "id": "CIS-C05", "framework": "cis_controls", "severity": "CRITICAL",
        "title": "Account Management",
        "description": "Use processes and tools to manage credentials for all accounts.",
        "fix": "Implement privileged access management. Enforce MFA on all accounts.",
        "category": "Account Management"
    },
    "CIS-C07": {
        "id": "CIS-C07", "framework": "cis_controls", "severity": "HIGH",
        "title": "Continuous Vulnerability Management",
        "description": "Continuously acquire and remediate vulnerabilities.",
        "fix": "Run automated vulnerability scans weekly. Patch critical CVEs within 24h.",
        "category": "Vulnerability Management"
    },
    "CIS-C08": {
        "id": "CIS-C08", "framework": "cis_controls", "severity": "HIGH",
        "title": "Audit Log Management",
        "description": "Collect, alert, review, and retain audit logs.",
        "fix": "Centralize logs with SIEM. Retain 90+ days. Set up critical event alerts.",
        "category": "Logging"
    },
    "CIS-C12": {
        "id": "CIS-C12", "framework": "cis_controls", "severity": "HIGH",
        "title": "Network Infrastructure Management",
        "description": "Establish, implement, and manage network infrastructure security.",
        "fix": "Segment network. Implement firewall rules. Use private subnets for databases.",
        "category": "Network Security"
    },
    "CIS-C16": {
        "id": "CIS-C16", "framework": "cis_controls", "severity": "HIGH",
        "title": "Application Software Security",
        "description": "Manage the security life cycle of in-house developed software.",
        "fix": "Implement SDLC security gates. Train developers on secure coding.",
        "category": "Application Security"
    },
    "CIS-C17": {
        "id": "CIS-C17", "framework": "cis_controls", "severity": "MEDIUM",
        "title": "Incident Response Management",
        "description": "Establish a program to prepare, detect, contain, and recover.",
        "fix": "Formalize incident response process. Define roles and escalation path.",
        "category": "Incident Response"
    },

    # ══════════════════════════════════════════════════════════════════════════
    # CCPA — 8 rules
    # ══════════════════════════════════════════════════════════════════════════
    "CCPA-1798.100": {
        "id": "CCPA-1798.100", "framework": "ccpa", "severity": "HIGH",
        "title": "Right to Know",
        "description": "Consumers have the right to know what personal information is collected.",
        "fix": "Implement data transparency — provide categories of data collected.",
        "category": "Consumer Rights"
    },
    "CCPA-1798.105": {
        "id": "CCPA-1798.105", "framework": "ccpa", "severity": "HIGH",
        "title": "Right to Delete",
        "description": "Consumers can request deletion of their personal information.",
        "fix": "Implement deletion request handling. Process within 45 days.",
        "category": "Data Deletion"
    },
    "CCPA-1798.120": {
        "id": "CCPA-1798.120", "framework": "ccpa", "severity": "HIGH",
        "title": "Right to Opt-Out of Sale",
        "description": "Consumers can opt out of the sale of their personal information.",
        "fix": "Add 'Do Not Sell My Personal Information' option. Honor opt-outs.",
        "category": "Data Sale"
    },
    "CCPA-1798.140": {
        "id": "CCPA-1798.140", "framework": "ccpa", "severity": "MEDIUM",
        "title": "Privacy Policy Disclosure",
        "description": "Businesses must disclose data practices in a privacy policy.",
        "fix": "Update privacy policy with CCPA-required disclosures. Post prominently.",
        "category": "Disclosure"
    },
    "CCPA-1798.150": {
        "id": "CCPA-1798.150", "framework": "ccpa", "severity": "HIGH",
        "title": "Data Security Standards",
        "description": "Businesses must implement reasonable security measures.",
        "fix": "Implement industry-standard security controls. Document security practices.",
        "category": "Security"
    },
    "CCPA-MinorData": {
        "id": "CCPA-MinorData", "framework": "ccpa", "severity": "CRITICAL",
        "title": "Minor Data Restrictions",
        "description": "Selling data of under-16s requires opt-in consent.",
        "fix": "Implement age verification. Prohibit data sale for verified minors.",
        "category": "Minor Protection"
    },
    "CCPA-NonDiscrimination": {
        "id": "CCPA-NonDiscrimination", "framework": "ccpa", "severity": "HIGH",
        "title": "Non-Discrimination",
        "description": "Consumers must not be discriminated against for exercising rights.",
        "fix": "Ensure all users receive same service quality regardless of privacy choices.",
        "category": "Non-Discrimination"
    },
    "CCPA-DataBroker": {
        "id": "CCPA-DataBroker", "framework": "ccpa", "severity": "MEDIUM",
        "title": "Data Broker Registration",
        "description": "Data brokers must register with the California Privacy Protection Agency.",
        "fix": "Determine if your business qualifies as a data broker. Register if required.",
        "category": "Registration"
    },

    # ══════════════════════════════════════════════════════════════════════════
    # RBI Cybersecurity Framework (India Banks) — 8 rules
    # ══════════════════════════════════════════════════════════════════════════
    "RBI-IT.1": {
        "id": "RBI-IT.1", "framework": "rbi_cyber", "severity": "CRITICAL",
        "title": "IT Governance Framework",
        "description": "Banks must establish an IT governance framework.",
        "fix": "Establish IT steering committee. Document IT governance policies.",
        "category": "Governance"
    },
    "RBI-IT.2": {
        "id": "RBI-IT.2", "framework": "rbi_cyber", "severity": "CRITICAL",
        "title": "Cyber Crisis Management Plan",
        "description": "Banks must have a cyber crisis management plan.",
        "fix": "Develop and test cyber crisis management plan. Train response team.",
        "category": "Crisis Management"
    },
    "RBI-IT.3": {
        "id": "RBI-IT.3", "framework": "rbi_cyber", "severity": "HIGH",
        "title": "Patch Management",
        "description": "Critical patches must be applied within defined timeframes.",
        "fix": "Implement patch management process. Apply critical patches within 30 days.",
        "category": "Patch Management"
    },
    "RBI-IT.4": {
        "id": "RBI-IT.4", "framework": "rbi_cyber", "severity": "CRITICAL",
        "title": "Data Localisation — Financial",
        "description": "Payment system data must be stored only in India.",
        "fix": "Ensure all payment data is stored in India-hosted infrastructure.",
        "category": "Data Localisation"
    },
    "RBI-IT.5": {
        "id": "RBI-IT.5", "framework": "rbi_cyber", "severity": "HIGH",
        "title": "Internet Banking Security",
        "description": "Internet banking must implement multi-factor authentication.",
        "fix": "Implement MFA for all internet banking transactions.",
        "category": "Authentication"
    },
    "RBI-IT.6": {
        "id": "RBI-IT.6", "framework": "rbi_cyber", "severity": "HIGH",
        "title": "SWIFT Security Controls",
        "description": "SWIFT messaging must comply with SWIFT Customer Security Programme.",
        "fix": "Implement SWIFT CSP mandatory controls. Conduct annual assessment.",
        "category": "SWIFT"
    },
    "RBI-IT.7": {
        "id": "RBI-IT.7", "framework": "rbi_cyber", "severity": "HIGH",
        "title": "Cyber Incident Reporting",
        "description": "Cyber incidents must be reported to RBI within defined timelines.",
        "fix": "Establish incident reporting workflow. Report to RBI CSITE within 2-6 hours.",
        "category": "Reporting"
    },
    "RBI-IT.8": {
        "id": "RBI-IT.8", "framework": "rbi_cyber", "severity": "MEDIUM",
        "title": "Vendor Risk Management",
        "description": "Third-party IT service providers must be assessed for security.",
        "fix": "Conduct security assessments of all IT vendors. Include security SLAs.",
        "category": "Vendor Management"
    },

    # ══════════════════════════════════════════════════════════════════════════
    # IoT Security — existing (keeping 7 rules)
    # ══════════════════════════════════════════════════════════════════════════
    "IOT-1": {
        "id": "IOT-1", "framework": "iot_security", "severity": "CRITICAL",
        "title": "No Default Credentials on Devices",
        "description": "IoT devices must not ship with default usernames/passwords.",
        "fix": "Implement unique credentials per device. Force password change on first boot.",
        "category": "Authentication"
    },
    "IOT-2": {
        "id": "IOT-2", "framework": "iot_security", "severity": "HIGH",
        "title": "Secure Boot",
        "description": "IoT devices must implement secure boot mechanisms.",
        "fix": "Implement cryptographically verified boot chain for all IoT devices.",
        "category": "Boot Security"
    },
    "IOT-3": {
        "id": "IOT-3", "framework": "iot_security", "severity": "HIGH",
        "title": "Device Communication Encryption",
        "description": "All device-to-cloud communication must be encrypted.",
        "fix": "Use TLS/DTLS for all device communication. Verify server certificates.",
        "category": "Encryption"
    },
    "IOT-4": {
        "id": "IOT-4", "framework": "iot_security", "severity": "HIGH",
        "title": "Secure Firmware Updates",
        "description": "Firmware updates must be signed and verified before installation.",
        "fix": "Implement signed OTA updates. Verify signature before applying.",
        "category": "Update Security"
    },
    "IOT-5": {
        "id": "IOT-5", "framework": "iot_security", "severity": "MEDIUM",
        "title": "Minimal Attack Surface",
        "description": "Unused ports and services on IoT devices must be disabled.",
        "fix": "Disable all non-essential ports and services. Apply principle of least privilege.",
        "category": "Hardening"
    },
    "IOT-6": {
        "id": "IOT-6", "framework": "iot_security", "severity": "HIGH",
        "title": "Device Identity",
        "description": "Each IoT device must have a unique, verifiable identity.",
        "fix": "Provision unique device certificates at manufacture. Use PKI for device auth.",
        "category": "Identity"
    },
    "IOT-7": {
        "id": "IOT-7", "framework": "iot_security", "severity": "MEDIUM",
        "title": "Privacy Controls",
        "description": "IoT devices must implement data minimization and user controls.",
        "fix": "Limit data collection to what's necessary. Provide user controls for data.",
        "category": "Privacy"
    },
}

def get_rules_list():
    return list(RULES.values())

def get_rule(rule_id: str):
    return RULES.get(rule_id)

def get_rules_by_framework(framework_key: str):
    return [r for r in RULES.values() if r["framework"] == framework_key]

# ── API Endpoints ─────────────────────────────────────────────────────────────
@router.get("/frameworks")
def get_frameworks():
    result = []
    for key, fw in FRAMEWORKS.items():
        rules = get_rules_by_framework(key)
        critical = sum(1 for r in rules if r["severity"] == "CRITICAL")
        high = sum(1 for r in rules if r["severity"] == "HIGH")
        result.append({
            "key": key,
            "name": fw["name"],
            "description": fw["description"],
            "icon": fw["icon"],
            "category": fw["category"],
            "region": fw["region"],
            "rule_count": len(rules),
            "critical_rules": critical,
            "high_rules": high,
        })
    return {
        "frameworks": result,
        "total_frameworks": len(FRAMEWORKS),
        "total_rules": len(RULES)
    }

@router.get("/rules")
def get_all_rules(framework: str = None, severity: str = None):
    rules = get_rules_list()
    if framework:
        rules = [r for r in rules if r["framework"] == framework]
    if severity:
        rules = [r for r in rules if r["severity"].upper() == severity.upper()]
    return {
        "rules": rules,
        "total": len(rules),
        "filters": {"framework": framework, "severity": severity}
    }

@router.get("/rules/{rule_id}")
def get_single_rule(rule_id: str):
    rule = get_rule(rule_id)
    if not rule:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail=f"Rule {rule_id} not found")
    framework = FRAMEWORKS.get(rule["framework"], {})
    return {**rule, "framework_info": framework}

@router.get("/rules/framework/{framework_key}")
def get_framework_rules(framework_key: str):
    if framework_key not in FRAMEWORKS:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail=f"Framework {framework_key} not found")
    rules = get_rules_by_framework(framework_key)
    return {
        "framework": FRAMEWORKS[framework_key],
        "framework_key": framework_key,
        "rules": rules,
        "total": len(rules)
    }

@router.get("/summary")
def get_summary():
    return {
        "total_frameworks": len(FRAMEWORKS),
        "total_rules": len(RULES),
        "by_severity": {
            "CRITICAL": sum(1 for r in RULES.values() if r["severity"] == "CRITICAL"),
            "HIGH": sum(1 for r in RULES.values() if r["severity"] == "HIGH"),
            "MEDIUM": sum(1 for r in RULES.values() if r["severity"] == "MEDIUM"),
            "LOW": sum(1 for r in RULES.values() if r["severity"] == "LOW"),
        },
        "frameworks": list(FRAMEWORKS.keys())
    }
