"""
CodeGPO Schema & Contract Generator
─────────────────────────────────────
Deterministically generates schemas from the Living Graph.
Nothing is invented. If it's not in the graph, it's not in the schema.

Generates:
  - SQL CREATE TABLE statements
  - NoSQL (MongoDB) collection schemas
  - SQLAlchemy ORM models (Python)
  - Prisma schema (JS/TS)
  - OpenAPI 3.0 contract stubs
  - Alembic migration stubs
"""

import json
from typing import List, Dict, Any, Optional
from datetime import datetime


# ── Type helpers ──────────────────────────────────────────

def is_type(node: Dict, types: List[str]) -> bool:
    t = (node.get("type") or "").lower()
    return any(tp.lower() in t for tp in types)

def parse_fields(node: Dict) -> List[Dict]:
    """Parse the fields JSON string from node model."""
    raw = node.get("fields", "[]") or "[]"
    try:
        fields = json.loads(raw)
        if not isinstance(fields, list):
            return []
        return fields
    except Exception:
        return []

def safe_name(name: str) -> str:
    """Convert node name to safe identifier."""
    return (name or "unknown").lower().replace(" ", "_").replace("-", "_").replace(".", "_")

def pascal_case(name: str) -> str:
    """Convert to PascalCase for class names."""
    parts = name.replace("-", " ").replace("_", " ").split()
    return "".join(p.capitalize() for p in parts)


# ── SQL type mapping ──────────────────────────────────────

SQL_TYPE_MAP = {
    "uuid":      "UUID DEFAULT gen_random_uuid()",
    "id":        "UUID DEFAULT gen_random_uuid()",
    "string":    "VARCHAR(255)",
    "str":       "VARCHAR(255)",
    "text":      "TEXT",
    "int":       "INTEGER",
    "integer":   "INTEGER",
    "float":     "FLOAT",
    "decimal":   "DECIMAL(10,2)",
    "bool":      "BOOLEAN",
    "boolean":   "BOOLEAN",
    "datetime":  "TIMESTAMP WITH TIME ZONE",
    "timestamp": "TIMESTAMP WITH TIME ZONE",
    "date":      "DATE",
    "json":      "JSONB",
    "array":     "JSONB",
    "email":     "VARCHAR(255)",
    "url":       "TEXT",
    "bigint":    "BIGINT",
}

PRISMA_TYPE_MAP = {
    "uuid":      "String   @id @default(uuid())",
    "id":        "String   @id @default(uuid())",
    "string":    "String",
    "str":       "String",
    "text":      "String",
    "int":       "Int",
    "integer":   "Int",
    "float":     "Float",
    "decimal":   "Decimal",
    "bool":      "Boolean",
    "boolean":   "Boolean",
    "datetime":  "DateTime @default(now())",
    "timestamp": "DateTime @default(now())",
    "date":      "DateTime",
    "json":      "Json",
    "email":     "String",
    "url":       "String",
}

SQLALCHEMY_TYPE_MAP = {
    "uuid":      "UUID(as_uuid=True), primary_key=True, default=uuid.uuid4",
    "id":        "UUID(as_uuid=True), primary_key=True, default=uuid.uuid4",
    "string":    "String(255)",
    "str":       "String(255)",
    "text":      "Text",
    "int":       "Integer",
    "integer":   "Integer",
    "float":     "Float",
    "decimal":   "Numeric(10, 2)",
    "bool":      "Boolean",
    "boolean":   "Boolean",
    "datetime":  "DateTime(timezone=True), default=func.now()",
    "timestamp": "DateTime(timezone=True), default=func.now()",
    "date":      "Date",
    "json":      "JSONB",
    "email":     "String(255)",
    "url":       "Text",
}


# ── Default fields by component type ─────────────────────

DEFAULT_FIELDS = {
    "database": [
        {"name": "id",         "type": "uuid",     "required": True,  "primary": True},
        {"name": "created_at", "type": "datetime", "required": True},
        {"name": "updated_at", "type": "datetime", "required": True},
    ],
    "api": [
        {"name": "id",      "type": "string", "required": True},
        {"name": "name",    "type": "string", "required": True},
        {"name": "version", "type": "string", "required": False},
    ],
    "service": [
        {"name": "id",     "type": "uuid",   "required": True, "primary": True},
        {"name": "status", "type": "string", "required": True},
    ]
}

def get_effective_fields(node: Dict) -> List[Dict]:
    """Merge node-defined fields with sensible defaults."""
    custom = parse_fields(node)
    node_type = (node.get("type") or "").lower()

    # Find matching default
    defaults = []
    for key, defs in DEFAULT_FIELDS.items():
        if key in node_type:
            defaults = defs
            break

    # Merge: custom fields take priority, defaults fill gaps
    custom_names = {f["name"] for f in custom}
    merged = list(custom)
    for d in defaults:
        if d["name"] not in custom_names:
            merged.insert(0, d)  # defaults first

    # Always have at least an id
    if not any(f.get("primary") or f["name"] == "id" for f in merged):
        merged.insert(0, {"name": "id", "type": "uuid", "required": True, "primary": True})

    return merged


# ── SQL Generator ─────────────────────────────────────────

def generate_sql(node: Dict) -> str:
    table = safe_name(node.get("name", "unknown"))
    fields = get_effective_fields(node)
    intent = node.get("intent", "")
    owner  = node.get("owner", "")
    compliance = node.get("compliance_scope", "")

    lines = []
    lines.append(f"-- ─────────────────────────────────────────────")
    lines.append(f"-- Table: {table}")
    if intent:
        lines.append(f"-- Purpose: {intent}")
    if owner:
        lines.append(f"-- Owner: {owner}")
    if compliance:
        lines.append(f"-- Compliance: {compliance.upper()}")
    lines.append(f"-- Generated by CodeGPO Nexus — {datetime.utcnow().strftime('%Y-%m-%d')}")
    lines.append(f"-- ─────────────────────────────────────────────")
    lines.append(f"CREATE TABLE IF NOT EXISTS {table} (")

    col_lines = []
    primary_key = None
    for f in fields:
        col_name = safe_name(f["name"])
        col_type_key = (f.get("type") or "string").lower()
        col_type = SQL_TYPE_MAP.get(col_type_key, "VARCHAR(255)")
        nullable = "" if f.get("required", False) else ""
        not_null = " NOT NULL" if f.get("required", False) else ""

        if f.get("primary"):
            primary_key = col_name
            col_lines.append(f"  {col_name:<20} {col_type}{not_null}")
        else:
            col_lines.append(f"  {col_name:<20} {col_type}{not_null}")

    if primary_key:
        col_lines.append(f"  PRIMARY KEY ({primary_key})")

    lines.append(",\n".join(col_lines))
    lines.append(");")
    lines.append("")

    # Compliance comment
    if compliance:
        if "gdpr" in compliance.lower():
            lines.append(f"-- GDPR: This table may contain personal data. Ensure data retention policies are applied.")
        if "hipaa" in compliance.lower():
            lines.append(f"-- HIPAA: This table contains PHI. Access must be logged and encrypted at rest.")
        if "soc2" in compliance.lower():
            lines.append(f"-- SOC2: Audit logging required for all writes to this table.")

    return "\n".join(lines)


# ── Prisma Generator ──────────────────────────────────────

def generate_prisma(node: Dict) -> str:
    model_name = pascal_case(node.get("name", "Unknown"))
    table_name = safe_name(node.get("name", "unknown"))
    fields = get_effective_fields(node)
    intent = node.get("intent", "")

    lines = []
    if intent:
        lines.append(f"/// {intent}")
    lines.append(f"model {model_name} {{")
    lines.append(f"  @@map(\"{table_name}\")")
    lines.append("")

    for f in fields:
        field_name = safe_name(f["name"])
        type_key   = (f.get("type") or "string").lower()
        ptype      = PRISMA_TYPE_MAP.get(type_key, "String")
        optional   = "" if f.get("required", True) else "?"
        lines.append(f"  {field_name:<20} {ptype}{optional}")

    lines.append("}")
    return "\n".join(lines)


# ── SQLAlchemy ORM Generator ──────────────────────────────

def generate_sqlalchemy(node: Dict) -> str:
    class_name = pascal_case(node.get("name", "Unknown"))
    table_name = safe_name(node.get("name", "unknown"))
    fields     = get_effective_fields(node)
    intent     = node.get("intent", "")

    lines = []
    lines.append("import uuid")
    lines.append("from sqlalchemy import Column, String, Integer, Float, Boolean, Text, Date, Numeric, JSONB")
    lines.append("from sqlalchemy.dialects.postgresql import UUID")
    lines.append("from sqlalchemy.sql import func")
    lines.append("from sqlalchemy.orm import DeclarativeBase")
    lines.append("")
    lines.append("class Base(DeclarativeBase): pass")
    lines.append("")
    if intent:
        lines.append(f'"""{intent}"""')
    lines.append(f"class {class_name}(Base):")
    lines.append(f'    __tablename__ = "{table_name}"')
    lines.append("")

    for f in fields:
        col_name  = safe_name(f["name"])
        type_key  = (f.get("type") or "string").lower()
        sa_type   = SQLALCHEMY_TYPE_MAP.get(type_key, "String(255)")
        nullable  = "nullable=False" if f.get("required", False) else "nullable=True"

        if f.get("primary"):
            lines.append(f"    {col_name} = Column({sa_type})")
        else:
            lines.append(f"    {col_name} = Column({sa_type}, {nullable})")

    lines.append("")
    lines.append(f"    def __repr__(self):")
    lines.append(f"        return f'<{class_name} {{self.id}}>'")

    return "\n".join(lines)


# ── Alembic Migration Generator ───────────────────────────

def generate_migration(node: Dict) -> str:
    table_name = safe_name(node.get("name", "unknown"))
    fields     = get_effective_fields(node)
    ts         = datetime.utcnow().strftime("%Y%m%d_%H%M%S")

    lines = []
    lines.append(f'"""Create {table_name} table')
    lines.append("")
    lines.append(f"Generated by CodeGPO Nexus")
    lines.append(f"Revision: codegpo_{ts}")
    lines.append('"""')
    lines.append("from alembic import op")
    lines.append("import sqlalchemy as sa")
    lines.append("from sqlalchemy.dialects import postgresql")
    lines.append("")
    lines.append(f"revision = 'codegpo_{ts}'")
    lines.append("down_revision = None")
    lines.append("branch_labels = None")
    lines.append("depends_on = None")
    lines.append("")
    lines.append("")
    lines.append("def upgrade() -> None:")
    lines.append(f"    op.create_table(")
    lines.append(f"        '{table_name}',")

    for f in fields:
        col_name = safe_name(f["name"])
        type_key = (f.get("type") or "string").lower()
        nullable = f.get("required", False) is False

        if type_key in ("uuid", "id"):
            lines.append(f"        sa.Column('{col_name}', postgresql.UUID(as_uuid=True), nullable=False),")
        elif type_key in ("string", "str", "email", "url"):
            lines.append(f"        sa.Column('{col_name}', sa.String(255), nullable={nullable}),")
        elif type_key == "text":
            lines.append(f"        sa.Column('{col_name}', sa.Text(), nullable={nullable}),")
        elif type_key in ("int", "integer"):
            lines.append(f"        sa.Column('{col_name}', sa.Integer(), nullable={nullable}),")
        elif type_key in ("bool", "boolean"):
            lines.append(f"        sa.Column('{col_name}', sa.Boolean(), nullable={nullable}),")
        elif type_key in ("datetime", "timestamp"):
            lines.append(f"        sa.Column('{col_name}', sa.DateTime(timezone=True), nullable={nullable}),")
        elif type_key == "json":
            lines.append(f"        sa.Column('{col_name}', postgresql.JSONB(), nullable={nullable}),")
        else:
            lines.append(f"        sa.Column('{col_name}', sa.String(255), nullable={nullable}),")

    # Primary key constraint
    pk_field = next((f for f in fields if f.get("primary")), None)
    if pk_field:
        lines.append(f"        sa.PrimaryKeyConstraint('{safe_name(pk_field['name'])}'),")

    lines.append("    )")
    lines.append("")
    lines.append("")
    lines.append("def downgrade() -> None:")
    lines.append(f"    op.drop_table('{table_name}')")

    return "\n".join(lines)


# ── OpenAPI Contract Generator ────────────────────────────

def generate_openapi(node: Dict, edges: List[Dict], all_nodes: List[Dict]) -> str:
    api_name   = node.get("name", "Unknown API")
    safe_id    = safe_name(api_name)
    intent     = node.get("intent", f"API for {api_name}")
    owner      = node.get("owner", "")
    compliance = node.get("compliance_scope", "")

    # Find what this API connects to (databases it serves)
    connected_dbs = []
    for e in edges:
        if e.get("source") == node["id"]:
            tgt = next((n for n in all_nodes if n["id"] == e.get("target")), None)
            if tgt and is_type(tgt, ["database", "db"]):
                connected_dbs.append(tgt)

    lines = []
    lines.append("openapi: '3.0.3'")
    lines.append("info:")
    lines.append(f"  title: {api_name}")
    lines.append(f"  description: '{intent}'")
    lines.append(f"  version: '1.0.0'")
    if owner:
        lines.append(f"  x-owner: '{owner}'")
    if compliance:
        lines.append(f"  x-compliance: '{compliance.upper()}'")
    lines.append(f"  x-generated-by: 'CodeGPO Nexus'")
    lines.append("")
    lines.append("paths:")
    lines.append(f"  /{safe_id}:")
    lines.append("    get:")
    lines.append(f"      summary: List {api_name} resources")
    lines.append("      operationId: list" + pascal_case(api_name))
    lines.append("      tags:")
    lines.append(f"        - {pascal_case(api_name)}")
    lines.append("      responses:")
    lines.append("        '200':")
    lines.append(f"          description: Successful response")
    lines.append("          content:")
    lines.append("            application/json:")
    lines.append("              schema:")
    lines.append("                type: array")
    lines.append("                items:")
    lines.append(f"                  $ref: '#/components/schemas/{pascal_case(api_name)}'")
    lines.append("        '401':")
    lines.append("          description: Unauthorized")
    lines.append("        '403':")
    lines.append("          description: Forbidden")
    lines.append(f"  /{safe_id}/{{id}}:")
    lines.append("    get:")
    lines.append(f"      summary: Get {api_name} by ID")
    lines.append("      operationId: get" + pascal_case(api_name))
    lines.append("      parameters:")
    lines.append("        - name: id")
    lines.append("          in: path")
    lines.append("          required: true")
    lines.append("          schema:")
    lines.append("            type: string")
    lines.append("      responses:")
    lines.append("        '200':")
    lines.append(f"          description: {api_name} object")
    lines.append("          content:")
    lines.append("            application/json:")
    lines.append("              schema:")
    lines.append(f"                $ref: '#/components/schemas/{pascal_case(api_name)}'")
    lines.append("        '404':")
    lines.append("          description: Not found")
    lines.append("")
    lines.append("components:")
    lines.append("  schemas:")
    lines.append(f"  {pascal_case(api_name)}:")
    lines.append("    type: object")
    lines.append("    properties:")
    lines.append("      id:")
    lines.append("        type: string")
    lines.append("        format: uuid")
    lines.append("      created_at:")
    lines.append("        type: string")
    lines.append("        format: date-time")

    # Add properties from connected DB fields
    for db in connected_dbs:
        for f in parse_fields(db):
            if f["name"] not in ("id", "created_at", "updated_at"):
                lines.append(f"      {safe_name(f['name'])}:")
                t = (f.get("type") or "string").lower()
                if t in ("int", "integer"):
                    lines.append("        type: integer")
                elif t in ("bool", "boolean"):
                    lines.append("        type: boolean")
                elif t in ("float", "decimal"):
                    lines.append("        type: number")
                else:
                    lines.append("        type: string")

    if compliance and "gdpr" in compliance.lower():
        lines.append("  securitySchemes:")
        lines.append("    bearerAuth:")
        lines.append("      type: http")
        lines.append("      scheme: bearer")
        lines.append("      bearerFormat: JWT")

    return "\n".join(lines)


# ── MongoDB Schema Generator ──────────────────────────────

def generate_mongo_schema(node: Dict) -> str:
    coll_name = safe_name(node.get("name", "unknown"))
    fields    = get_effective_fields(node)
    intent    = node.get("intent", "")

    MONGO_TYPE_MAP = {
        "uuid": "string", "id": "string", "string": "string",
        "str": "string", "text": "string", "email": "string",
        "url": "string", "int": "number", "integer": "number",
        "float": "number", "decimal": "number", "bool": "bool",
        "boolean": "bool", "datetime": "date", "timestamp": "date",
        "date": "date", "json": "object", "array": "array"
    }

    lines = []
    lines.append(f"// MongoDB Schema — {coll_name}")
    if intent:
        lines.append(f"// Purpose: {intent}")
    lines.append(f"// Generated by CodeGPO Nexus — {datetime.utcnow().strftime('%Y-%m-%d')}")
    lines.append("")
    lines.append(f"db.createCollection('{coll_name}', {{")
    lines.append("  validator: {")
    lines.append("    $jsonSchema: {")
    lines.append("      bsonType: 'object',")

    required_fields = [f["name"] for f in fields if f.get("required", False)]
    if required_fields:
        req_str = ", ".join(f'"{safe_name(r)}"' for r in required_fields)
        lines.append(f"      required: [{req_str}],")

    lines.append("      properties: {")
    for f in fields:
        col_name  = safe_name(f["name"])
        type_key  = (f.get("type") or "string").lower()
        mtype     = MONGO_TYPE_MAP.get(type_key, "string")
        lines.append(f"        {col_name}: {{ bsonType: '{mtype}' }},")
    lines.append("      }")
    lines.append("    }")
    lines.append("  }")
    lines.append("});")
    lines.append("")
    lines.append(f"db.{coll_name}.createIndex({{ _id: 1 }});")
    lines.append(f"db.{coll_name}.createIndex({{ created_at: -1 }});")

    return "\n".join(lines)


# ── Master generator ──────────────────────────────────────

def generate_schemas_for_node(
    node: Dict,
    edges: List[Dict],
    all_nodes: List[Dict]
) -> Dict[str, Any]:
    """
    Generate all applicable schema artifacts for a single node.
    Returns a dict of artifact_type -> generated_code
    """
    node_type = (node.get("type") or "").lower()
    artifacts = {}

    if is_type(node, ["database", "db", "sql", "postgres", "mysql", "sqlite"]):
        artifacts["sql"]         = generate_sql(node)
        artifacts["orm"]         = generate_sqlalchemy(node)
        artifacts["migration"]   = generate_migration(node)
        artifacts["prisma"]      = generate_prisma(node)

    elif is_type(node, ["database", "mongo", "nosql", "dynamodb", "firestore"]):
        artifacts["mongo"]       = generate_mongo_schema(node)

    elif is_type(node, ["api", "rest", "graphql", "endpoint"]):
        artifacts["openapi"]     = generate_openapi(node, edges, all_nodes)

    # If no type matched but node has custom fields — generate SQL anyway
    if not artifacts and parse_fields(node):
        artifacts["sql"]         = generate_sql(node)
        artifacts["orm"]         = generate_sqlalchemy(node)

    return {
        "nodeId":    node.get("id"),
        "nodeName":  node.get("name"),
        "nodeType":  node.get("type"),
        "intent":    node.get("intent", ""),
        "owner":     node.get("owner", ""),
        "artifacts": artifacts,
        "generatedAt": datetime.utcnow().isoformat()
    }


def generate_all_schemas(nodes: List[Dict], edges: List[Dict]) -> List[Dict]:
    """Generate schemas for all schema-eligible nodes in the graph."""
    results = []
    for node in nodes:
        node_type = (node.get("type") or "").lower()
        # Only generate for data-bearing components
        if any(t in node_type for t in ["database", "db", "api", "rest", "sql",
                                          "mongo", "nosql", "graphql", "endpoint"]):
            result = generate_schemas_for_node(node, edges, nodes)
            if result["artifacts"]:
                results.append(result)
    return results