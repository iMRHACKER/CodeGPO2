import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

from api.graph import router as graph_router
from api.graph_sync import router as graph_sync_router   # /graph/save + /graph/load
from api.edges import router as edges_router
from api.nodes import router as nodes_router
from api.governance import router as governance_router
from api.accountability import router as accountability_router
from api.auto_scan import router as auto_scan_router
from api.graphrag import router as graphrag_router
from api.schema import router as schema_router
from api.pr import router as pr_router
from api.codegen import router as codegen_router
from auth.alpha_codes import router as alpha_router
from api.github_scan import router as github_scan_router  # purana alpha code system
from auth.forgot_password import router as forgot_router 

try:
    from api.report import report_router
except ImportError:
    report_router = None

try:
    from api.compliance import compliance_router
except ImportError:
    compliance_router = None

try:
    from api.paid_access import paid_router
except ImportError:
    paid_router = None

from auth.auth import router as jwt_auth_router

ENVIRONMENT = os.getenv("ENVIRONMENT", "development")
PORT = int(os.getenv("PORT", 8000))

limiter = Limiter(key_func=get_remote_address, default_limits=["200/minute"])
app = FastAPI(
    title="CodeGPO API",
    description="Architecture Governance & Compliance Platform",
    version="0.2.0"
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Core routers
app.include_router(graph_router)
app.include_router(github_scan_router)
app.include_router(graph_sync_router)   # /graph/save + /graph/load
app.include_router(edges_router)
app.include_router(nodes_router)
app.include_router(governance_router)
app.include_router(accountability_router)
app.include_router(auto_scan_router)
app.include_router(graphrag_router)
app.include_router(schema_router)
app.include_router(pr_router)
app.include_router(codegen_router)
app.include_router(forgot_router)
app.include_router(alpha_router)  # purana alpha code — abhi bhi kaam karega

# Optional routers
if report_router:
    app.include_router(report_router)
if compliance_router:
    app.include_router(compliance_router)
if paid_router:
    app.include_router(paid_router)
app.include_router(jwt_auth_router)


# ── Collab WebSocket (integrated into FastAPI) ──────────────
from fastapi import WebSocket as FWebSocket, WebSocketDisconnect
import json, uuid
from datetime import datetime

collab_rooms = {}
COLORS = ["#f59e0b","#7c3aed","#0ea5e9","#ec4899","#22c55e","#f97316","#06b6d4","#8b5cf6"]

def get_room(rid):
    if rid not in collab_rooms:
        collab_rooms[rid] = {"clients": {}, "nodes": [], "edges": [], "updated_at": datetime.utcnow().isoformat()}
    return collab_rooms[rid]

async def broadcast_room(room, msg, exclude=None):
    data = json.dumps(msg)
    dead = []
    for ws, info in list(room["clients"].items()):
        if ws == exclude: continue
        try: await ws.send_text(data)
        except: dead.append(ws)
    for ws in dead: room["clients"].pop(ws, None)

@app.websocket("/collab/{room_id}")
async def collab_ws(websocket: FWebSocket, room_id: str):
    await websocket.accept()
    room = get_room(room_id)
    user_id = str(uuid.uuid4())[:8]
    used_colors = {v["color"] for v in room["clients"].values()}
    color = next((c for c in COLORS if c not in used_colors), COLORS[0])
    user_name = "Anonymous"
    room["clients"][websocket] = {"id": user_id, "color": color, "name": user_name, "cursor": None}

    try:
        while True:
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
                mtype = msg.get("type", "")

                if mtype == "join":
                    user_name = msg.get("userName", "Anonymous")
                    room["clients"][websocket]["name"] = user_name
                    await websocket.send_text(json.dumps({
                        "type": "joined", "userId": user_id, "color": color,
                        "users": [{"id": v["id"], "name": v["name"], "color": v["color"]}
                                  for v in room["clients"].values()
                                  if v["id"] != user_id],
                        "nodes": room["nodes"], "edges": room["edges"]
                    }))
                    await broadcast_room(room, {
                        "type": "user_joined",
                        "userId": user_id,
                        "name": user_name,
                        "color": color,
                        "user": {"id": user_id, "name": user_name, "color": color}
                    }, exclude=websocket)
                    # Always send current room architecture to new joiner
                    await websocket.send_text(json.dumps({
                        "type": "sync",
                        "nodes": room["nodes"],
                        "edges": room["edges"],
                        "userId": "server"
                    }))
                    # Ask existing users to send their full state
                    await broadcast_room(room, {
                        "type": "request_sync",
                        "forUserId": user_id
                    }, exclude=websocket)

                elif mtype in ("sync", "sync_full"):
                    # Store in room state
                    if msg.get("nodes") is not None:
                        room["nodes"] = msg.get("nodes", [])
                        room["edges"] = msg.get("edges", [])
                    # Broadcast to ALL others
                    await broadcast_room(room, {
                        "type": "sync",
                        "nodes": room["nodes"],
                        "edges": room["edges"],
                        "userId": user_id
                    }, exclude=websocket)

                elif mtype == "cursor":
                    room["clients"][websocket]["cursor"] = msg.get("cursor")
                    await broadcast_room(room, {"type": "cursor", "userId": user_id, "cursor": msg.get("cursor"), "color": color, "name": user_name}, exclude=websocket)

                elif mtype == "node_move":
                    await broadcast_room(room, {"type": "node_move", "userId": user_id, "nodeId": msg.get("nodeId"), "x": msg.get("x"), "y": msg.get("y")}, exclude=websocket)

                elif mtype == "node_add":
                    await broadcast_room(room, {"type": "node_add", "userId": user_id, "node": msg.get("node")}, exclude=websocket)

                elif mtype == "node_delete":
                    await broadcast_room(room, {"type": "node_delete", "userId": user_id, "nodeId": msg.get("nodeId")}, exclude=websocket)

                elif mtype == "edge_add":
                    await broadcast_room(room, {"type": "edge_add", "userId": user_id, "edge": msg.get("edge")}, exclude=websocket)

                elif mtype == "edge_delete":
                    await broadcast_room(room, {"type": "edge_delete", "userId": user_id, "source": msg.get("source"), "target": msg.get("target")}, exclude=websocket)

                elif mtype == "ping":
                    await websocket.send_text(json.dumps({"type": "pong"}))

            except json.JSONDecodeError:
                pass
    except WebSocketDisconnect:
        room["clients"].pop(websocket, None)
        await broadcast_room(room, {"type": "user_left", "userId": user_id})

@app.get("/health")
def health():
    return {"status": "ok", "version": "0.2.0", "environment": ENVIRONMENT}


@app.get("/")
def root():
    return {
        "name": "CodeGPO API",
        "version": "0.2.0",
        "endpoints": {
            "governance": "/api/governance/evaluate",
            "compliance": "/api/compliance/frameworks",
            "plans": "/api/plans",
            "redeem": "/api/access/redeem",
            "report": "/api/report/download",
            "docs": "/docs",
        }
    }
