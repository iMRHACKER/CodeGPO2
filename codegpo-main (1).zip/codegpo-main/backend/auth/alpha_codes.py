"""
CodeGPO Alpha Gate — Server-Side Validation
"""
import os
from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

router = APIRouter()

# In-memory user tracking (resets on redeploy)
access_log = []

def get_valid_codes():
    raw = os.getenv("ALPHA_CODES", "")
    return {c.strip().upper() for c in raw.split(",") if c.strip()}

class CodeRequest(BaseModel):
    code: str

@router.post("/auth/validate-code")
def validate_code(req: CodeRequest):
    valid_codes = get_valid_codes()
    submitted = req.code.strip().upper()

    if not submitted:
        raise HTTPException(status_code=400, detail="No code provided")

    if submitted not in valid_codes:
        raise HTTPException(status_code=401, detail="Invalid invite code")

    # Log access
    timestamp = datetime.now(timezone.utc).isoformat()
    entry = {"code": submitted, "timestamp": timestamp}
    access_log.append(entry)
    print(f"[ALPHA ACCESS] code={submitted} time={timestamp}")

    return {
        "status": "granted",
        "message": "Access granted. Welcome to CodeGPO Alpha."
    }

@router.get("/auth/users")
def get_alpha_users(key: str = Query(default="")):
    admin_key = os.getenv("ADMIN_KEY", "")
    if not admin_key or key != admin_key:
        raise HTTPException(status_code=403, detail="Unauthorized")

    return {
        "total_users": len(set(e["code"] for e in access_log)),
        "total_logins": len(access_log),
        "users": access_log
    }
