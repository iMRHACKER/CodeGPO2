"""
CodeGPO Auth System — Neo4j persistent, redeploy safe
"""
import os
from slowapi import Limiter
from slowapi.util import get_remote_address
from fastapi import Request

limiter = Limiter(key_func=get_remote_address)
import bcrypt
import uuid
from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends, Header
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

try:
    import jwt as pyjwt
except ImportError:
    from jose import jwt as pyjwt

router = APIRouter(prefix="/api/auth", tags=["auth"])
security = HTTPBearer(auto_error=False)

SECRET_KEY = os.getenv("JWT_SECRET")
if not SECRET_KEY:
    raise RuntimeError("JWT_SECRET environment variable is required!")
ALGORITHM  = "HS256"
EXPIRE_H   = 24  # 24 hours

# Alpha codes removed — product is now public

# ── Login attempt tracking (in-memory) ─────────────────────────
from collections import defaultdict
import time

_login_attempts = defaultdict(list)  # email -> [timestamps]
LOCKOUT_ATTEMPTS = 5
LOCKOUT_WINDOW   = 300   # 5 minutes
LOCKOUT_DURATION = 900   # 15 minutes lockout

def check_lockout(email: str):
    now = time.time()
    attempts = _login_attempts[email]
    # Remove old attempts outside window
    attempts = [t for t in attempts if now - t < LOCKOUT_WINDOW]
    _login_attempts[email] = attempts
    if len(attempts) >= LOCKOUT_ATTEMPTS:
        remaining = int(LOCKOUT_DURATION - (now - attempts[0]))
        raise HTTPException(429, f"Too many failed attempts. Try again in {remaining//60+1} minutes.")

def record_failed(email: str):
    _login_attempts[email].append(time.time())

def clear_attempts(email: str):
    _login_attempts[email] = []

# ── Neo4j helpers ──────────────────────────────────────────────
def _db():
    from core.neo4j import get_session
    return get_session()

def _get_user(email: str):
    try:
        with _db() as s:
            r = s.run("MATCH (u:User {email:$e}) RETURN u", e=email).single()
            return dict(r["u"]) if r else None
    except Exception as ex:
        raise HTTPException(500, f"DB error: {ex}")

def _create_user(user: dict):
    try:
        with _db() as s:
            s.run("""
                CREATE (u:User {
                    id:$id, email:$email, name:$name,
                    password_hash:$password_hash,
                    org_id:$org_id, org_name:$org_name,
                    plan:$plan, alpha_code:$alpha_code,
                    created_at:$created_at
                })
            """, **user)
    except Exception as ex:
        raise HTTPException(500, f"DB error: {ex}")

def _count_alpha(code: str) -> int:
    try:
        with _db() as s:
            r = s.run("MATCH (u:User {alpha_code:$c}) RETURN count(u) AS n", c=code).single()
            return r["n"] if r else 0
    except:
        return 0

def _all_users():
    try:
        with _db() as s:
            return s.run(
                "MATCH (u:User) RETURN u.id AS id, u.email AS email, "
                "u.name AS name, u.plan AS plan, u.created_at AS created_at "
                "ORDER BY u.created_at DESC"
            ).data()
    except:
        return []

# ── Password Validation ────────────────────────────────────────
def validate_password(password: str):
    if len(password) < 8:
        raise HTTPException(400, "Password must be at least 8 characters")
    if not any(c.isupper() for c in password):
        raise HTTPException(400, "Password must contain at least one uppercase letter")
    if not any(c.isdigit() for c in password):
        raise HTTPException(400, "Password must contain at least one number")

# ── JWT ────────────────────────────────────────────────────────
def create_token(user_id, org_id, email, plan):
    payload = {
        "sub": user_id, "org_id": org_id,
        "email": email, "plan": plan,
        "exp": datetime.utcnow() + timedelta(hours=EXPIRE_H),
        "iat": datetime.utcnow(),
    }
    token = pyjwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
    return token if isinstance(token, str) else token.decode("utf-8")

def verify_token(token: str) -> dict:
    try:
        return pyjwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except Exception:
        raise HTTPException(401, "Token invalid or expired — please log in again")

def get_current_user(creds: HTTPAuthorizationCredentials = Depends(security)):
    if not creds:
        raise HTTPException(401, "Not authenticated")
    return verify_token(creds.credentials)

def get_optional_user(authorization: Optional[str] = Header(None)):
    if not authorization or not authorization.startswith("Bearer "):
        return None
    try:
        return verify_token(authorization.split(" ", 1)[1])
    except:
        return None

# ── Models ─────────────────────────────────────────────────────
class RegisterRequest(BaseModel):
    email: str
    password: str
    name: str
    org_name: str  # Required

class LoginRequest(BaseModel):
    email: str
    password: str

# ── Routes ─────────────────────────────────────────────────────
@router.post("/register")
@limiter.limit("5/minute")
def register(request: Request, req: RegisterRequest):
    email = req.email.lower().strip()
    if not email or not req.password or not req.name:
        raise HTTPException(400, "Email, password and name are required")
    if len(req.password) < 6:
        raise HTTPException(400, "Password must be at least 6 characters")
    if _get_user(email):
        raise HTTPException(400, "Email already registered")

    plan, used_code = "free", ""

    # Hash password
    # Validate email format
    import re as _re
    if not _re.match(r"^[\w.%+\-]+@[\w.\-]+\.[a-zA-Z]{2,}$", req.email):
        raise HTTPException(400, "Invalid email address")
    # Validate name length
    if len(req.name.strip()) < 2:
        raise HTTPException(400, "Name must be at least 2 characters")
    if len(req.org_name.strip()) < 2:
        raise HTTPException(400, "Organization name must be at least 2 characters")
    validate_password(req.password)
    salt = bcrypt.gensalt()
    pw_hash = bcrypt.hashpw(req.password.encode("utf-8"), salt).decode("utf-8")

    org_id  = str(uuid.uuid4())
    user_id = str(uuid.uuid4())
    user = {
        "id": user_id, "email": email, "name": req.name,
        "password_hash": pw_hash, "org_id": org_id,
        "org_name": req.org_name or f"{req.name}'s Org",
        "plan": plan, "alpha_code": used_code,
        "created_at": datetime.utcnow().isoformat(),
    }
    _create_user(user)

    # Normalize plan names
    plan_map = {"developer": "pro", "team": "pro"}
    plan = plan_map.get(plan, plan)
    token = create_token(user_id, org_id, email, plan)
    user_data = {k: v for k, v in user.items() if k != "password_hash"}
    return {"access_token": token, "token_type": "bearer", "user": user_data}


@router.post("/login")
@limiter.limit("10/minute")
def login(request: Request, req: LoginRequest):
    email = req.email.lower().strip()
    user  = _get_user(email)
    if not user:
        raise HTTPException(401, "Invalid email or password")

    pw_hash = user.get("password_hash", "")
    try:
        ok = bcrypt.checkpw(req.password.encode("utf-8"), pw_hash.encode("utf-8"))
    except Exception:
        raise HTTPException(401, "Invalid email or password")

    if not ok:
        record_failed(req.email)
        raise HTTPException(401, "Invalid email or password")
    clear_attempts(req.email)

    token = create_token(user["id"], user.get("org_id",""), email, user.get("plan","free"))
    user_data = {k: v for k, v in user.items() if k != "password_hash"}
    return {"access_token": token, "token_type": "bearer", "user": user_data}


@router.get("/me")
def get_me(user: dict = Depends(get_current_user)):
    # Always fetch fresh from DB to get latest plan
    db_user = _get_user(user.get("email",""))
    if db_user:
        return {k: v for k, v in db_user.items() if k != "password_hash"}
    return user

# ── Email Verification ─────────────────────────────────────
import secrets as secrets_module

def send_verification_email(email: str, name: str, token: str):
    import urllib.request, json as _json
    APP_URL = os.getenv("APP_URL", "https://app.codegpo.com")
    SENDGRID_KEY = os.getenv("SENDGRID_API_KEY", "")
    if not SENDGRID_KEY:
        return  # Skip if no SendGrid key
    verify_url = f"{APP_URL}?verify={token}"
    payload = {
        "personalizations": [{"to": [{"email": email}]}],
        "from": {"email": os.getenv("SMTP_FROM", "harsh@codegpo.com"), "name": "CodeGPO"},
        "subject": "Verify your CodeGPO email",
        "content": [{"type": "text/html", "value": f"""
        <div style="font-family:Arial;max-width:500px;margin:0 auto;background:#0D0D1F;color:#CBD5E1;padding:32px;border-radius:12px">
          <h2 style="color:#A78BFA">⚡ Welcome to CodeGPO, {name}!</h2>
          <p>Click below to verify your email and activate your account:</p>
          <a href="{verify_url}" style="display:inline-block;padding:12px 24px;background:#7C3AED;color:#fff;text-decoration:none;border-radius:8px;font-weight:700;margin:16px 0">
            Verify Email →
          </a>
          <p style="color:#475569;font-size:12px">Link expires in 24 hours. If you didn't create an account, ignore this email.</p>
        </div>
        """}]
    }
    try:
        req = urllib.request.Request(
            "https://api.sendgrid.com/v3/mail/send",
            data=_json.dumps(payload).encode(),
            headers={"Authorization": f"Bearer {SENDGRID_KEY}", "Content-Type": "application/json"},
            method="POST"
        )
        urllib.request.urlopen(req, timeout=10)
    except Exception:
        pass  # Don't block registration if email fails

@router.get("/verify-email")
def verify_email(token: str):
    with _db() as session:
        result = session.execute_write(lambda tx: tx.run(
            """MATCH (u:User {verify_token:$token})
               WHERE u.verify_token_exp > $now
               SET u.email_verified=true, u.verify_token=null
               RETURN u.email AS email""",
            token=token, now=datetime.utcnow().isoformat()
        ).single())
    if not result:
        raise HTTPException(400, "Invalid or expired verification link")
    return {"ok": True, "message": "Email verified! You can now log in."}

# ── Activity Tracking ──────────────────────────────────────
@router.post("/me/ping")
def ping_activity(user: dict = Depends(get_current_user)):
    """Called periodically to track last_seen"""
    email = user.get("email", "")
    now = datetime.utcnow().isoformat()
    with _db() as s:
        s.execute_write(lambda tx: tx.run(
            "MATCH (u:User {email:$e}) SET u.last_seen=$now",
            e=email, now=now
        ))
    return {"ok": True}

@router.get("/admin/analytics")
def get_analytics(admin_key: str):
    """Admin analytics endpoint"""
    ADMIN_KEY = os.getenv("ADMIN_KEY", "")
    if not ADMIN_KEY or admin_key != ADMIN_KEY:
        raise HTTPException(403, "Invalid admin key")
    now = datetime.utcnow()
    day_ago   = (now - timedelta(hours=24)).isoformat()
    week_ago  = (now - timedelta(days=7)).isoformat()
    month_ago = (now - timedelta(days=30)).isoformat()
    with _db() as s:
        result = s.run("""
            MATCH (u:User)
            RETURN
                count(u) AS total,
                sum(CASE WHEN u.last_seen >= $day_ago   THEN 1 ELSE 0 END) AS dau,
                sum(CASE WHEN u.last_seen >= $week_ago  THEN 1 ELSE 0 END) AS wau,
                sum(CASE WHEN u.last_seen >= $month_ago THEN 1 ELSE 0 END) AS mau,
                sum(CASE WHEN u.plan IN ['pro','developer','team','enterprise','custom'] THEN 1 ELSE 0 END) AS paid
        """, day_ago=day_ago, week_ago=week_ago, month_ago=month_ago).single()
        return {
            "total": result["total"],
            "dau":   result["dau"],
            "wau":   result["wau"],
            "mau":   result["mau"],
            "paid":  result["paid"],
        }

# ── Resend verification email ──────────────────────────────
@router.post("/resend-verification")
def resend_verification(user: dict = Depends(get_current_user)):
    db_user = _get_user(user.get("email",""))
    if not db_user:
        raise HTTPException(404, "User not found")
    if db_user.get("email_verified", False):
        return {"ok": True, "message": "Email already verified"}
    verify_token_val = secrets_module.token_urlsafe(32)
    verify_exp = (datetime.utcnow() + timedelta(hours=24)).isoformat()
    with _db() as s:
        s.execute_write(lambda tx: tx.run(
            "MATCH (u:User {email:$e}) SET u.verify_token=$t, u.verify_token_exp=$exp",
            e=db_user["email"], t=verify_token_val, exp=verify_exp
        ))
    send_verification_email(db_user["email"], db_user.get("name",""), verify_token_val)
    return {"ok": True, "message": "Verification email sent"}

# ── Update profile name ────────────────────────────────────
class UpdateProfileReq(BaseModel):
    name: str

@router.post("/me/update")
def update_profile(req: UpdateProfileReq, user: dict = Depends(get_current_user)):
    email = user.get("email", "")
    with _db() as session:
        session.execute_write(lambda tx: tx.run(
            "MATCH (u:User {email:$email}) SET u.name=$name",
            email=email, name=req.name.strip()
        ))
    return {"ok": True, "name": req.name.strip()}

# ── Change password ─────────────────────────────────────────
class ChangePasswordReq(BaseModel):
    old_password: str
    new_password: str

@router.post("/me/change-password")
def change_password(req: ChangePasswordReq, user: dict = Depends(get_current_user)):
    email = user.get("email", "")
    db_user = _get_user(email)
    if not db_user:
        raise HTTPException(404, "User not found")
    if not bcrypt.checkpw(req.old_password.encode(), db_user["password_hash"].encode()):
        raise HTTPException(400, "Current password is incorrect")
    validate_password(req.new_password)
    new_hash = bcrypt.hashpw(req.new_password.encode(), bcrypt.gensalt()).decode()
    with _db() as session:
        session.execute_write(lambda tx: tx.run(
            "MATCH (u:User {email:$email}) SET u.password_hash=$hash",
            email=email, hash=new_hash
        ))
    return {"ok": True}

# ── Delete account ──────────────────────────────────────────
@router.delete("/me/delete")
def delete_account(user: dict = Depends(get_current_user)):
    email = user.get("email", "")
    with _db() as session:
        session.execute_write(lambda tx: tx.run(
            "MATCH (u:User {email:$email}) DETACH DELETE u",
            email=email
        ))
    return {"ok": True}

@router.post("/me/refresh-plan")
def refresh_plan(user: dict = Depends(get_current_user)):
    """Returns fresh token with latest plan from DB"""
    db_user = _get_user(user.get("email",""))
    if not db_user:
        raise HTTPException(404, "User not found")
    raw_plan = db_user.get("plan", "free")
    plan_map = {"developer": "pro", "team": "pro"}
    plan = plan_map.get(raw_plan, raw_plan)
    token = create_token(db_user["id"], db_user.get("org_id",""), db_user["email"], plan)
    return {"access_token": token, "plan": plan, "user": {k:v for k,v in db_user.items() if k!="password_hash"}}


@router.post("/refresh")
def refresh(user: dict = Depends(get_current_user)):
    token = create_token(user["sub"], user.get("org_id",""), user["email"], user.get("plan","free"))
    return {"access_token": token, "token_type": "bearer"}


@router.get("/health")
def auth_health():
    try:
        users = _all_users()
        return {"status": "ok", "users_registered": len(users)}
    except Exception as e:
        return {"status": "error", "detail": str(e)}


@router.get("/admin/users")
def admin_users(admin_key: str = ""):
    key = os.getenv("ADMIN_KEY", "")
    if not key or admin_key != key:
        raise HTTPException(403, "Unauthorized")
    return _all_users()


class UpdatePlanRequest(BaseModel):
    plan: str
    admin_key: str

@router.post("/admin/users/{user_id}/plan")
def update_user_plan(user_id: str, req: UpdatePlanRequest):
    key = os.getenv("ADMIN_KEY", "")
    if not key or req.admin_key != key:
        raise HTTPException(403, "Unauthorized")
    valid_plans = ["free", "developer", "team", "pro", "enterprise", "custom"]
    if req.plan not in valid_plans:
        raise HTTPException(400, f"Invalid plan. Choose: {valid_plans}")
    try:
        from core.neo4j import get_session

        with get_session() as s:
            # Use explicit transaction for guaranteed commit
            try:
                with s.begin_transaction() as tx:
                    result = tx.run(
                        "MATCH (u:User) WHERE u.id = $uid "
                        "SET u.plan = $plan "
                        "RETURN u.id AS id, u.email AS email, u.plan AS plan",
                        uid=user_id, plan=req.plan
                    )
                    record = result.single()
                    tx.commit()
            except AttributeError:
                # Fallback for older neo4j driver
                result = s.run(
                    "MATCH (u:User) WHERE u.id = $uid "
                    "SET u.plan = $plan "
                    "RETURN u.id AS id, u.email AS email, u.plan AS plan",
                    uid=user_id, plan=req.plan
                )
                record = result.single()

        if not record:
            raise HTTPException(404, f"User not found: {user_id}")

        print(f"[ADMIN] Plan updated: {record['email']} → {record['plan']}")
        return {
            "status": "ok",
            "user_id": user_id,
            "plan": record["plan"],
            "confirmed": record["plan"],
            "email": record["email"]
        }
    except HTTPException:
        raise
    except Exception as e:
        print(f"[ADMIN ERROR] {e}")
        raise HTTPException(500, f"DB error: {str(e)}")

@router.get("/admin/users/{user_id}")
def get_single_user(user_id: str, admin_key: str = ""):
    key = os.getenv("ADMIN_KEY", "")
    if not key or admin_key != key:
        raise HTTPException(403, "Unauthorized")
    try:
        from core.neo4j import get_session
        with get_session() as s:
            result = s.run(
                "MATCH (u:User) WHERE u.id = $uid RETURN u.id AS id, u.email AS email, u.plan AS plan",
                uid=user_id
            )
            record = result.single()
            if not record:
                raise HTTPException(404, "User not found")
            return dict(record)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, str(e))

@router.delete("/admin/users/{user_id}")
def delete_user(user_id: str, admin_key: str = ""):
    key = os.getenv("ADMIN_KEY", "")
    if not key or admin_key != key:
        raise HTTPException(403, "Unauthorized")
    try:
        from core.neo4j import get_session
        with get_session() as s:
            s.run("MATCH (u:User {id:$id}) DELETE u", id=user_id)
        return {"status": "ok", "deleted": user_id}
    except Exception as e:
        raise HTTPException(500, str(e))
