"""
CodeGPO Forgot Password — Brevo Integration
"""
import os
import secrets
from datetime import datetime, timedelta
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/api/auth", tags=["auth"])

BREVO_API_KEY = os.getenv("BREVO_API_KEY", "")
SMTP_FROM     = os.getenv("SMTP_FROM", "harsh@codegpo.com")
APP_URL       = os.getenv("APP_URL", "https://app.codegpo.com")

def _save_token(email: str, token: str, expires_at: str):
    from core.neo4j import get_session
    with get_session() as s:
        s.run("""
            MERGE (t:ResetToken {token: $token})
            SET t.email = $email, t.expires_at = $expires_at, t.used = false
        """, token=token, email=email, expires_at=expires_at)

def _get_token(token: str):
    from core.neo4j import get_session
    with get_session() as s:
        r = s.run("MATCH (t:ResetToken {token:$token, used:false}) RETURN t", token=token).single()
        return dict(r["t"]) if r else None

def _invalidate_token(token: str):
    from core.neo4j import get_session
    with get_session() as s:
        s.run("MATCH (t:ResetToken {token:$token}) SET t.used=true", token=token)

def _update_password(email: str, new_hash: str):
    from core.neo4j import get_session
    with get_session() as s:
        s.run("MATCH (u:User {email:$email}) SET u.password_hash=$hash", email=email, hash=new_hash)

def _user_exists(email: str) -> bool:
    from core.neo4j import get_session
    with get_session() as s:
        r = s.run("MATCH (u:User {email:$email}) RETURN u.id", email=email).single()
        return r is not None

def send_reset_email(to_email: str, token: str) -> bool:
    reset_link = f"{APP_URL}/reset-password?token={token}"

    if not BREVO_API_KEY:
        print(f"\n🔐 [DEV] RESET LINK for {to_email}:\n   {reset_link}\n")
        return True

    try:
        import urllib.request, urllib.error, json

        html = f"""
        <html><body style="font-family:Arial,sans-serif;background:#08080F;color:#E2E8F0;padding:40px;">
          <div style="max-width:480px;margin:0 auto;background:#0D0D1F;border:1px solid #1A1A35;border-radius:12px;padding:32px;">
            <div style="font-size:24px;font-weight:800;color:#fff;margin-bottom:8px;">⚡ CodeGPO</div>
            <div style="font-size:13px;color:#475569;margin-bottom:24px;">Architecture as Law. Governance as Code.</div>
            <p style="color:#CBD5E1;font-size:15px;">Someone requested a password reset for your account.</p>
            <a href="{reset_link}" style="display:inline-block;background:linear-gradient(135deg,#6D28D9,#7C3AED);color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:700;margin:16px 0;">
              Reset Password →
            </a>
            <p style="color:#334155;font-size:12px;margin-top:24px;">
              Didn't request this? Ignore this email — your account is safe.<br/>
              Link expires in 1 hour.
            </p>
          </div>
        </body></html>
        """

        payload = json.dumps({
            "sender": {"email": SMTP_FROM, "name": "CodeGPO"},
            "to": [{"email": to_email}],
            "subject": "CodeGPO — Reset Your Password",
            "htmlContent": html,
            "textContent": f"Reset your CodeGPO password: {reset_link}\n\nExpires in 1 hour.",
        }).encode("utf-8")

        req = urllib.request.Request(
            "https://api.brevo.com/v3/smtp/email",
            data=payload,
            headers={
                "api-key": BREVO_API_KEY,
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=15) as res:
            print(f"[Brevo] Email sent to {to_email} — status {res.status}")
        return True

    except Exception as e:
        print(f"[Brevo error] {e}")
        return False

class ForgotRequest(BaseModel):
    email: str

class ResetRequest(BaseModel):
    token: str
    new_password: str

@router.post("/forgot-password")
def forgot_password(req: ForgotRequest):
    email = req.email.lower().strip()
    if _user_exists(email):
        token = secrets.token_urlsafe(32)
        expires_at = (datetime.utcnow() + timedelta(hours=1)).isoformat()
        _save_token(email, token, expires_at)
        send_reset_email(email, token)
    return {"message": "If this email is registered, you'll receive a reset link shortly.", "status": "sent"}

@router.post("/reset-password")
def reset_password(req: ResetRequest):
    import bcrypt
    token_data = _get_token(req.token)
    if not token_data:
        raise HTTPException(400, "Invalid or expired reset link")
    if datetime.utcnow() > datetime.fromisoformat(token_data["expires_at"]):
        _invalidate_token(req.token)
        raise HTTPException(400, "Reset link has expired — please request a new one")
    if len(req.new_password) < 6:
        raise HTTPException(400, "Password must be at least 6 characters")
    new_hash = bcrypt.hashpw(req.new_password.encode(), bcrypt.gensalt()).decode()
    _update_password(token_data["email"], new_hash)
    _invalidate_token(req.token)
    return {"message": "Password reset successful — you can now sign in."}

@router.get("/reset-password/validate")
def validate_reset_token(token: str):
    token_data = _get_token(token)
    if not token_data:
        raise HTTPException(400, "Invalid or expired reset link")
    if datetime.utcnow() > datetime.fromisoformat(token_data["expires_at"]):
        raise HTTPException(400, "Reset link has expired")
    return {"valid": True, "email": token_data["email"]}
