# CodeGPO VS Code Extension - Auto Installer
Write-Host ""
Write-Host "  CodeGPO VS Code Extension Installer" -ForegroundColor Cyan
Write-Host "  ------------------------------------" -ForegroundColor DarkGray
Write-Host ""

# Check VS Code is installed
if (-not (Get-Command code -ErrorAction SilentlyContinue)) {
  Write-Host "  VS Code not found. Install from https://code.visualstudio.com" -ForegroundColor Red
  exit 1
}
Write-Host "  OK - VS Code found" -ForegroundColor Green

# Check node
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host "  Node.js not found. Install from https://nodejs.org" -ForegroundColor Red
  exit 1
}
Write-Host "  OK - Node.js found" -ForegroundColor Green

# Go to extension dir
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

# Install deps
Write-Host ""
Write-Host "  Installing dependencies..." -ForegroundColor Gray
npm install --silent 2>$null

# Package extension
Write-Host "  Packaging extension..." -ForegroundColor Gray
npx vsce package --allow-missing-repository --no-dependencies -o codegpo-latest.vsix 2>$null | Out-Null

if (-not (Test-Path "codegpo-latest.vsix")) {
  Write-Host "  Packaging failed - trying with warnings allowed..." -ForegroundColor Yellow
  npx vsce package --allow-missing-repository -o codegpo-latest.vsix
}

if (-not (Test-Path "codegpo-latest.vsix")) {
  Write-Host "  Packaging failed" -ForegroundColor Red
  exit 1
}

Write-Host "  OK - Packaged successfully" -ForegroundColor Green

# Install into VS Code
Write-Host "  Installing into VS Code..." -ForegroundColor Gray
code --install-extension codegpo-latest.vsix --force

Write-Host ""
Write-Host "  CodeGPO extension installed!" -ForegroundColor Green
Write-Host ""
Write-Host "  Next steps:" -ForegroundColor White
Write-Host "  1. Reload VS Code (Ctrl+Shift+P then type Reload Window)" -ForegroundColor Gray
Write-Host "  2. Open any project folder" -ForegroundColor Gray
Write-Host "  3. See results in CodeGPO at localhost:5173" -ForegroundColor Gray
Write-Host ""