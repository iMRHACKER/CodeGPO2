#!/bin/bash

echo ""
echo "  ⚡ CodeGPO VS Code Extension Installer"
echo "  ─────────────────────────────────────"
echo ""

# Check VS Code
if ! command -v code &> /dev/null; then
  echo "  ✗ VS Code not found. Install from https://code.visualstudio.com"
  exit 1
fi
echo "  ✓ VS Code found"

# Check node
if ! command -v node &> /dev/null; then
  echo "  ✗ Node.js not found. Install from https://nodejs.org"
  exit 1
fi
echo "  ✓ Node.js found"

# Go to script dir
cd "$(dirname "$0")"

# Install deps
echo "  Installing dependencies..."
npm install --silent 2>/dev/null

# Package
echo "  Packaging extension..."
npx vsce package --allow-missing-repository --no-dependencies -o codegpo-latest.vsix 2>/dev/null

if [ ! -f "codegpo-latest.vsix" ]; then
  echo "  ✗ Packaging failed"
  exit 1
fi
echo "  ✓ Packaged"

# Install
echo "  Installing into VS Code..."
code --install-extension codegpo-latest.vsix --force 2>/dev/null

echo ""
echo "  ✅ CodeGPO extension installed!"
echo ""
echo "  Next steps:"
echo "  1. Reload VS Code (Ctrl+Shift+P → Reload Window)"
echo "  2. Open any project folder"
echo "  3. See results in CodeGPO at localhost:5173"
echo ""