const vscode = require("vscode");
const http = require("http");
const path = require("path");
const os = require("os");
const fs = require("fs");
const { scanWorkspace } = require("./scanner");
const { evaluateViolations } = require("./violations");

let diagnosticCollection;
let statusBarItem;
let scanTimeout;
let violationsProvider;
let componentsProvider;
let lastScanResult = null;
let bridgeServer = null;

// ── Bridge server — lets CodeGPO web app fetch scan results ──
function startBridgeServer() {
  if (bridgeServer) return;

  bridgeServer = http.createServer((req, res) => {
    // CORS — allow CodeGPO web app to fetch
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");

    if (req.method === "OPTIONS") {
      res.writeHead(200);
      res.end();
      return;
    }

    if (req.method === "GET" && req.url === "/scan") {
      if (lastScanResult) {
        res.setHeader("Content-Type", "application/json");
        res.writeHead(200);
        res.end(JSON.stringify(lastScanResult));
      } else {
        res.writeHead(204);
        res.end();
      }
      return;
    }

    if (req.method === "GET" && req.url === "/ping") {
      res.setHeader("Content-Type", "application/json");
      res.writeHead(200);
      res.end(JSON.stringify({
        status: "ok",
        workspace: vscode.workspace.workspaceFolders?.[0]?.name || null,
        lastScan: lastScanResult?.timestamp || null
      }));
      return;
    }

    res.writeHead(404);
    res.end();
  });

  bridgeServer.listen(27420, "localhost", () => {
    console.log("CodeGPO bridge server running on localhost:27420");
  });

  bridgeServer.on("error", (err) => {
    // Port already in use — another VS Code instance has it, that's fine
    console.log("CodeGPO bridge:", err.message);
  });
}

// ── Tree items ──────────────────────────────────────────────
class ViolationItem extends vscode.TreeItem {
  constructor(violation) {
    const label = `${violation.ruleId} — ${violation.sourceNode.name} → ${violation.targetNode.name}`;
    super(label, vscode.TreeItemCollapsibleState.None);
    this.description = violation.severity;
    this.tooltip = violation.message;
    this.iconPath = new vscode.ThemeIcon(
      violation.severity === "CRITICAL" || violation.severity === "HIGH"
        ? "error" : "warning"
    );
    if (violation.sourceNode.filePath) {
      this.command = {
        command: "vscode.open",
        title: "Open File",
        arguments: [vscode.Uri.file(violation.sourceNode.filePath)]
      };
    }
  }
}

class ComponentItem extends vscode.TreeItem {
  constructor(node) {
    super(node.name, vscode.TreeItemCollapsibleState.None);
    this.description = node.type;
    this.tooltip = node.relativePath || node.filePath;
    this.iconPath = new vscode.ThemeIcon(getTypeIcon(node.type));
    if (node.filePath) {
      this.command = {
        command: "vscode.open",
        title: "Open File",
        arguments: [vscode.Uri.file(node.filePath)]
      };
    }
  }
}

function getTypeIcon(type) {
  if (!type) return "circle-outline";
  const t = type.toLowerCase();
  if (t.includes("service") || t.includes("api")) return "server-process";
  if (t.includes("database") || t.includes("db")) return "database";
  if (t.includes("queue") || t.includes("kafka")) return "list-ordered";
  if (t.includes("cache")) return "zap";
  if (t.includes("gateway") || t.includes("proxy")) return "globe";
  if (t.includes("worker") || t.includes("job")) return "gear";
  if (t.includes("external")) return "link-external";
  if (t.includes("user") || t.includes("frontend")) return "person";
  return "circle-outline";
}

class ViolationsTreeProvider {
  constructor() {
    this._onDidChangeTreeData = new vscode.EventEmitter();
    this.onDidChangeTreeData = this._onDidChangeTreeData.event;
    this.violations = [];
  }
  refresh(violations) {
    this.violations = violations;
    this._onDidChangeTreeData.fire();
  }
  getTreeItem(el) { return el; }
  getChildren() {
    if (!this.violations.length) {
      const item = new vscode.TreeItem("No violations detected ✓");
      item.iconPath = new vscode.ThemeIcon("check");
      return [item];
    }
    return this.violations.map(v => new ViolationItem(v));
  }
}

class ComponentsTreeProvider {
  constructor() {
    this._onDidChangeTreeData = new vscode.EventEmitter();
    this.onDidChangeTreeData = this._onDidChangeTreeData.event;
    this.nodes = [];
  }
  refresh(nodes) {
    this.nodes = nodes;
    this._onDidChangeTreeData.fire();
  }
  getTreeItem(el) { return el; }
  getChildren() {
    if (!this.nodes.length) {
      const item = new vscode.TreeItem("No components scanned yet");
      item.iconPath = new vscode.ThemeIcon("info");
      return [item];
    }
    const groups = {};
    for (const node of this.nodes) {
      if (!groups[node.type]) groups[node.type] = [];
      groups[node.type].push(node);
    }
    return Object.entries(groups).map(([type, nodes]) => {
      const item = new vscode.TreeItem(
        `${type} (${nodes.length})`,
        vscode.TreeItemCollapsibleState.None
      );
      item.iconPath = new vscode.ThemeIcon(getTypeIcon(type));
      return item;
    });
  }
}

// ── Main scan ───────────────────────────────────────────────
async function runScan(context) {
  const workspaceFolders = vscode.workspace.workspaceFolders;
  if (!workspaceFolders?.length) {
    vscode.window.showWarningMessage("CodeGPO: No workspace folder open");
    return;
  }

  const workspacePath = workspaceFolders[0].uri.fsPath;
  const workspaceName = workspaceFolders[0].name;

  statusBarItem.text = "$(sync~spin) CodeGPO: Scanning...";
  statusBarItem.show();

  try {
    const { nodes, edges } = scanWorkspace(workspacePath);

    if (!nodes.length) {
      statusBarItem.text = "$(shield) CodeGPO: Nothing detected";
      vscode.window.showInformationMessage(
        "CodeGPO: No architecture components found. Try a project with services, databases, or APIs."
      );
      return;
    }

    const violations = evaluateViolations(nodes, edges);

    // Update tree views
    violationsProvider.refresh(violations);
    componentsProvider.refresh(nodes);

    // Update diagnostics
    diagnosticCollection.clear();
    const diagMap = new Map();

    for (const v of violations) {
      const fp = v.sourceNode.filePath;
      if (!fp) continue;
      if (!diagMap.has(fp)) diagMap.set(fp, []);
      const diag = new vscode.Diagnostic(
        new vscode.Range(0, 0, 0, 100),
        `[${v.ruleId}] ${v.message} (→ ${v.targetNode.name})`,
        v.vscodeSeverity
      );
      diag.source = "CodeGPO";
      diag.code = v.ruleId;
      diagMap.get(fp).push(diag);
    }

    for (const [fp, diags] of diagMap) {
      diagnosticCollection.set(vscode.Uri.file(fp), diags);
    }

    // Calculate score
    let score = 100;
    for (const v of violations) {
      if (v.severity === "CRITICAL") score -= 20;
      else if (v.severity === "HIGH") score -= 12;
      else if (v.severity === "MEDIUM") score -= 6;
      else score -= 3;
    }
    score = Math.max(0, Math.min(100, score));
    const grade = score >= 90 ? "A" : score >= 80 ? "B" : score >= 70 ? "C" : score >= 55 ? "D" : "F";

    // Store result for bridge server
    lastScanResult = {
      source: "vscode",
      timestamp: new Date().toISOString(),
      workspace: workspaceName,
      workspacePath,
      score,
      grade,
      nodes: nodes.map(n => ({ id: n.id, name: n.name, type: n.type })),
      edges,
      violations: violations.map(v => ({
        ruleId: v.ruleId,
        severity: v.severity,
        message: v.message,
        source: v.source,
        target: v.target
      }))
    };

    // Also write to temp file as backup
    try {
      const tmpFile = path.join(os.tmpdir(), "codegpo-vscode-scan.json");
      fs.writeFileSync(tmpFile, JSON.stringify(lastScanResult, null, 2));
    } catch {}

    // Status bar
    const icon = violations.length === 0
      ? "$(check)"
      : violations.some(v => v.severity === "CRITICAL") ? "$(error)" : "$(warning)";

    statusBarItem.text = `${icon} CodeGPO: ${score}/100 (${grade}) · ${nodes.length} components · ${violations.length} violations`;
    statusBarItem.tooltip = "Click to open CodeGPO dashboard";
    statusBarItem.show();

    // Notification
    if (violations.length === 0) {
      vscode.window.showInformationMessage(
        `✅ CodeGPO: ${nodes.length} components — All compliant! Score: ${score}/100`,
        "Open Dashboard"
      ).then(a => {
        if (a === "Open Dashboard") openDashboard();
      });
    } else {
      const critCount = violations.filter(v => v.severity === "CRITICAL").length;
      vscode.window.showWarningMessage(
        `⚠️ CodeGPO: ${violations.length} violations (${critCount} critical) · Score: ${score}/100`,
        "Open in CodeGPO",
        "Dismiss"
      ).then(a => {
        if (a === "Open in CodeGPO") openDashboard();
      });
    }

  } catch (err) {
    statusBarItem.text = "$(error) CodeGPO: Scan failed";
    vscode.window.showErrorMessage(`CodeGPO scan failed: ${err.message}`);
  }
}

function openDashboard() {
  const config = vscode.workspace.getConfiguration("codegpo");
  const url = config.get("serverUrl", "http://localhost:5173");
  // Pass flag so web app knows to load VS Code scan
  vscode.env.openExternal(
    vscode.Uri.parse(`${url}?from=vscode`)
  );
}

// ── Activate ────────────────────────────────────────────────
function activate(context) {
  console.log("CodeGPO extension activated");

  // Start bridge server immediately
  startBridgeServer();

  diagnosticCollection = vscode.languages.createDiagnosticCollection("codegpo");
  context.subscriptions.push(diagnosticCollection);

  statusBarItem = vscode.window.createStatusBarItem(
    vscode.StatusBarAlignment.Left, 100
  );
  statusBarItem.command = "codegpo.openDashboard";
  statusBarItem.text = "$(shield) CodeGPO: Ready";
  statusBarItem.tooltip = "Click to open CodeGPO dashboard";
  statusBarItem.show();
  context.subscriptions.push(statusBarItem);

  violationsProvider = new ViolationsTreeProvider();
  componentsProvider = new ComponentsTreeProvider();

  context.subscriptions.push(
    vscode.window.registerTreeDataProvider("codegpoViolations", violationsProvider),
    vscode.window.registerTreeDataProvider("codegpoComponents", componentsProvider)
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("codegpo.scan", () => runScan(context)),
    vscode.commands.registerCommand("codegpo.openDashboard", openDashboard),
    vscode.commands.registerCommand("codegpo.clearDiagnostics", () => {
      diagnosticCollection.clear();
      violationsProvider.refresh([]);
      statusBarItem.text = "$(shield) CodeGPO: Ready";
      vscode.window.showInformationMessage("CodeGPO: Diagnostics cleared");
    })
  );

  // Auto-scan on save
  context.subscriptions.push(
    vscode.workspace.onDidSaveTextDocument(() => {
      const config = vscode.workspace.getConfiguration("codegpo");
      if (!config.get("autoScan", true)) return;
      clearTimeout(scanTimeout);
      const delay = config.get("scanDelay", 2000);
      scanTimeout = setTimeout(() => runScan(context), delay);
    })
  );

  // Initial scan
  setTimeout(() => runScan(context), 1500);
}

function deactivate() {
  if (diagnosticCollection) diagnosticCollection.dispose();
  if (statusBarItem) statusBarItem.dispose();
  if (bridgeServer) bridgeServer.close();
  clearTimeout(scanTimeout);
}

module.exports = { activate, deactivate };