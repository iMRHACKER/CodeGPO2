# CodeGPO — Architecture Governance for VS Code

Scan your project architecture and detect governance violations directly in VS Code.

## Features

- **Auto-scan on save** — detects architecture components automatically
- **Inline diagnostics** — red/yellow underlines on violating files
- **Sidebar panel** — see all components and violations in the explorer
- **Status bar score** — live health score in the bottom bar
- **Syncs with CodeGPO** — sends results to your running CodeGPO instance

## How to Install

### Option A — Install from .vsix (recommended)
```bash
cd F:\CodeGPOPro\vscode-extension
npm run install-vsce
npx vsce package
```
Then in VS Code: Extensions → ... → Install from VSIX → select `codegpo-0.1.0.vsix`

### Option B — Dev mode
1. Open `F:\CodeGPOPro\vscode-extension` in VS Code
2. Press `F5` to launch Extension Development Host

## Commands

| Command | Description |
|---|---|
| `CodeGPO: Scan Architecture` | Manually trigger a scan |
| `CodeGPO: Open Dashboard` | Open CodeGPO in browser |
| `CodeGPO: Clear Diagnostics` | Remove all diagnostics |

## Settings

| Setting | Default | Description |
|---|---|---|
| `codegpo.serverUrl` | `http://localhost:5173` | Your CodeGPO URL |
| `codegpo.autoScan` | `true` | Auto-scan on file save |
| `codegpo.scanDelay` | `2000` | Delay before auto-scan (ms) |

## Usage

1. Open any project in VS Code
2. Press `Ctrl+Shift+P` → `CodeGPO: Scan Architecture`
3. See violations as red underlines in your files
4. Click the status bar item to re-scan anytime