const RULES = [
  {
    ruleId: "GOV-001", severity: "CRITICAL",
    message: "Client cannot directly access Database — route through an API or Service",
    check: (src, tgt) =>
      isType(src, ["user","client","browser","frontend"]) &&
      isType(tgt, ["database","db","sql","mongo","redis"])
  },
  {
    ruleId: "GOV-002", severity: "HIGH",
    message: "Client cannot directly access Queue — route through a Service",
    check: (src, tgt) =>
      isType(src, ["user","client","browser","frontend"]) &&
      isType(tgt, ["queue","kafka","rabbit","sqs"])
  },
  {
    ruleId: "GOV-003", severity: "HIGH",
    message: "Database should not initiate outbound calls",
    check: (src, tgt) =>
      isType(src, ["database","db","sql","mongo"]) &&
      isType(tgt, ["service","api","user","external","worker"])
  },
  {
    ruleId: "GOV-004", severity: "CRITICAL",
    message: "Gateway should not access Database directly",
    check: (src, tgt) =>
      isType(src, ["gateway","proxy","nginx"]) &&
      isType(tgt, ["database","db","sql","mongo","redis"])
  },
  {
    ruleId: "GOV-005", severity: "CRITICAL",
    message: "External services cannot access internal Database",
    check: (src, tgt) =>
      isType(src, ["external","vendor","thirdparty"]) &&
      isType(tgt, ["database","db","sql","mongo","redis"])
  },
  {
    ruleId: "GOV-006", severity: "HIGH",
    message: "External services cannot access internal Queue",
    check: (src, tgt) =>
      isType(src, ["external","vendor","thirdparty"]) &&
      isType(tgt, ["queue","kafka","rabbit","sqs"])
  },
  {
    ruleId: "GOV-007", severity: "MEDIUM",
    message: "Client should not call External services directly",
    check: (src, tgt) =>
      isType(src, ["user","client","browser","frontend"]) &&
      isType(tgt, ["external","vendor","stripe","twilio"])
  },
  {
    ruleId: "GOV-008", severity: "MEDIUM",
    message: "Client cannot access Cache directly",
    check: (src, tgt) =>
      isType(src, ["user","client","browser","frontend"]) &&
      isType(tgt, ["cache","redis","memcached"])
  }
];

function isType(node, keywords) {
  if (!node?.type) return false;
  const t = node.type.toLowerCase();
  return keywords.some(k => t.includes(k));
}

const SEVERITY_MAP = {
  CRITICAL: 0,  // vscode.DiagnosticSeverity.Error
  HIGH:     0,
  MEDIUM:   1,  // vscode.DiagnosticSeverity.Warning
  LOW:      2   // vscode.DiagnosticSeverity.Information
};

function evaluateViolations(nodes, edges) {
  const nodeMap = new Map(nodes.map(n => [n.id, n]));
  const violations = [];

  for (const edge of edges) {
    const src = nodeMap.get(edge.source);
    const tgt = nodeMap.get(edge.target);
    if (!src || !tgt) continue;

    for (const rule of RULES) {
      if (rule.check(src, tgt)) {
        violations.push({
          ruleId: rule.ruleId,
          severity: rule.severity,
          vscodeSeverity: SEVERITY_MAP[rule.severity] ?? 1,
          message: rule.message,
          source: edge.source,
          target: edge.target,
          sourceNode: src,
          targetNode: tgt
        });
      }
    }
  }

  return violations;
}

module.exports = { evaluateViolations };