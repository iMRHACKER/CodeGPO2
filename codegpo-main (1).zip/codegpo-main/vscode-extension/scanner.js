const fs = require("fs");
const path = require("path");

// File extensions to scan
const SCAN_EXTENSIONS = [
  ".js", ".jsx", ".ts", ".tsx",
  ".py", ".java", ".go", ".cs",
  ".yaml", ".yml", ".json", ".toml"
];

// Skip these folders
const SKIP_DIRS = new Set([
  "node_modules", ".git", "dist", "build",
  ".next", "__pycache__", "venv", ".venv",
  "coverage", ".nyc_output", "target", "bin", "obj"
]);

// Patterns to detect component types from file content and names
const COMPONENT_PATTERNS = [
  {
    type: "Service",
    patterns: [
      /class\s+\w*(Service|Controller|Handler|Manager)\b/i,
      /\bexpress\(\)/,
      /FastAPI\(\)/,
      /\bapp\s*=\s*Flask/,
      /\brouter\b.*=.*Router/i,
      /@RestController/,
      /@Service/,
      /gin\.Default\(\)/,
      /http\.ListenAndServe/
    ]
  },
  {
    type: "Database",
    patterns: [
      /mongoose\.connect|MongoClient|pymongo/i,
      /createConnection|getConnection|DataSource/i,
      /new\s+Pool\(|pg\.Pool|mysql\.createPool/i,
      /prisma\.\w+\.findMany|prisma\.\w+\.create/i,
      /SQLAlchemy|create_engine/i,
      /neo4j\.driver|GraphDatabase/i,
      /redis\.createClient|aioredis|Redis\(/i,
      /sqlite3|better-sqlite3/i,
      /sequelize\.define|Model\.init/i
    ]
  },
  {
    type: "Queue",
    patterns: [
      /kafka|KafkaConsumer|KafkaProducer/i,
      /amqplib|pika\.BlockingConnection|RabbitMQ/i,
      /SQS|sqs\.sendMessage|sqs\.receiveMessage/i,
      /Bull\(|BullMQ|Queue\(/i,
      /celery|Celery\(/i,
      /redis\.lpush|redis\.rpop|BLPOP/i
    ]
  },
  {
    type: "Cache",
    patterns: [
      /redis\.get|redis\.set|redisClient\./i,
      /memcached|MemcachedClient/i,
      /NodeCache|node-cache/i,
      /cache\.get|cache\.set|cacheManager/i,
      /lru-cache|LRUCache/i
    ]
  },
  {
    type: "Gateway",
    patterns: [
      /nginx|proxy_pass|upstream\s+\w+/i,
      /createProxyMiddleware|http-proxy/i,
      /kong|traefik|envoy/i,
      /api.?gateway|ApiGateway/i,
      /loadBalancer|load.?balancer/i
    ]
  },
  {
    type: "Worker",
    patterns: [
      /cron\.schedule|node-cron|CronJob/i,
      /setInterval.*\d{4,}|setTimeout.*repeat/i,
      /@Scheduled|schedule\.every/i,
      /worker_threads|new Worker\(/i,
      /celery\.task|@shared_task/i,
      /job\.process|queue\.process/i
    ]
  },
  {
    type: "External",
    patterns: [
      /stripe\.|Stripe\(/i,
      /sendgrid\.|SendGrid/i,
      /twilio\.|Twilio\(/i,
      /aws\.S3|s3\.upload|S3Client/i,
      /axios\.get.*https?:\/\/(?!localhost)/i,
      /fetch\('https?:\/\/(?!localhost)/i,
      /googleapis|google\.auth/i,
      /firebase\.initializeApp/i
    ]
  },
  {
    type: "API",
    patterns: [
      /app\.(get|post|put|delete|patch)\s*\(/i,
      /@Get\(|@Post\(|@Put\(|@Delete\(/,
      /router\.(get|post|put|delete)\s*\(/i,
      /graphql|makeExecutableSchema|typeDefs/i,
      /@app\.route|@blueprint\.route/i
    ]
  },
  {
    type: "User",
    patterns: [
      /ReactDOM\.render|createRoot/i,
      /useState|useEffect|React\.Component/i,
      /<App\s*\/>|render\s*\(\s*<\w+/i,
      /flutter|SwiftUI|UIViewController/i,
      /MainActivity|setContentView/i
    ]
  }
];

// Detect connections from import/require patterns
const CONNECTION_PATTERNS = [
  { pattern: /import.*from\s+['"](.+)['"]/g,  type: "import" },
  { pattern: /require\s*\(\s*['"](.+)['"]\s*\)/g, type: "require" },
  { pattern: /from\s+(\w+)\s+import/g, type: "python_import" }
];

function detectComponentType(content, filePath) {
  for (const { type, patterns } of COMPONENT_PATTERNS) {
    for (const pattern of patterns) {
      if (pattern.test(content)) return type;
    }
  }

  // Fallback: guess from filename
  const base = path.basename(filePath, path.extname(filePath)).toLowerCase();
  if (base.includes("service") || base.includes("controller")) return "Service";
  if (base.includes("model") || base.includes("schema")) return "Database";
  if (base.includes("worker") || base.includes("job") || base.includes("cron")) return "Worker";
  if (base.includes("cache")) return "Cache";
  if (base.includes("queue") || base.includes("consumer") || base.includes("producer")) return "Queue";
  if (base.includes("gateway") || base.includes("proxy")) return "Gateway";
  if (base.includes("router") || base.includes("route") || base.includes("api")) return "API";
  if (base.includes("app") || base.includes("index") || base.includes("main")) return "Service";

  return null;
}

function getComponentName(filePath, workspacePath) {
  const rel = path.relative(workspacePath, filePath);
  const base = path.basename(filePath, path.extname(filePath));
  // Capitalize and clean up
  return base
    .replace(/[-_]/g, " ")
    .replace(/\b\w/g, c => c.toUpperCase())
    .trim();
}

function scanFile(filePath, workspacePath) {
  try {
    const content = fs.readFileSync(filePath, "utf8");
    const type = detectComponentType(content, filePath);
    if (!type) return null;

    return {
      id: `vsc-${filePath.replace(workspacePath, "").replace(/[\/\\]/g, "-").replace(/^-/, "")}`,
      name: getComponentName(filePath, workspacePath),
      type,
      filePath,
      relativePath: path.relative(workspacePath, filePath)
    };
  } catch {
    return null;
  }
}

function walkDir(dir, results = []) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch { return results; }

  for (const entry of entries) {
    if (SKIP_DIRS.has(entry.name)) continue;

    const fullPath = path.join(dir, entry.name);

    if (entry.isDirectory()) {
      walkDir(fullPath, results);
    } else if (entry.isFile()) {
      const ext = path.extname(entry.name).toLowerCase();
      if (SCAN_EXTENSIONS.includes(ext)) {
        results.push(fullPath);
      }
    }
  }
  return results;
}

function inferEdges(nodes, workspacePath) {
  const edges = [];
  const nodeMap = new Map(nodes.map(n => [n.filePath, n]));

  for (const node of nodes) {
    try {
      const content = fs.readFileSync(node.filePath, "utf8");
      const dir = path.dirname(node.filePath);

      for (const { pattern } of CONNECTION_PATTERNS) {
        pattern.lastIndex = 0;
        let match;
        while ((match = pattern.exec(content)) !== null) {
          const importPath = match[1];
          if (!importPath.startsWith(".")) continue;

          // Resolve the import to a file
          const extensions = [".js", ".jsx", ".ts", ".tsx", ".py"];
          for (const ext of extensions) {
            const resolved = path.resolve(dir, importPath + ext);
            const targetNode = nodeMap.get(resolved);
            if (targetNode && targetNode.id !== node.id) {
              const edgeKey = `${node.id}->${targetNode.id}`;
              if (!edges.find(e => `${e.source}->${e.target}` === edgeKey)) {
                edges.push({ source: node.id, target: targetNode.id });
              }
              break;
            }
          }
        }
      }
    } catch {}
  }

  return edges;
}

function scanWorkspace(workspacePath) {
  const files = walkDir(workspacePath);
  const nodes = [];

  for (const filePath of files) {
    const component = scanFile(filePath, workspacePath);
    if (component) nodes.push(component);
  }

  // Deduplicate by name+type
  const seen = new Set();
  const uniqueNodes = nodes.filter(n => {
    const key = `${n.name}-${n.type}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  const edges = inferEdges(uniqueNodes, workspacePath);

  return { nodes: uniqueNodes, edges };
}

module.exports = { scanWorkspace };