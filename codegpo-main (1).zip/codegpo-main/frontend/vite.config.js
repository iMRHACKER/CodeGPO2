import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  preview: {
    host: "0.0.0.0",
    port: process.env.PORT || 8080,
    allowedHosts: ["all", ".railway.app", ".codegpo.com", "codegpo.com", "app.codegpo.com"]
  },
  server: {
    host: "0.0.0.0",
    port: 5173,
    allowedHosts: ["all", ".railway.app", ".codegpo.com", "codegpo.com", "app.codegpo.com"]
  }
});
