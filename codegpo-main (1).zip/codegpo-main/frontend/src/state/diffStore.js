import { create } from "zustand";

const STORAGE_KEY = "codegpo_snapshots";
const MAX_SNAPSHOTS = 20;

function loadSnapshots() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function saveSnapshots(snapshots) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshots.slice(0, MAX_SNAPSHOTS)));
}

export const useDiffStore = create((set, get) => ({
  snapshots: loadSnapshots(),

  saveSnapshot: ({ projectId, projectName, nodes, edges, violations, label }) => {
    const snapshot = {
      id: `snap-${Date.now()}`,
      projectId,
      projectName,
      label: label || `Snapshot ${new Date().toLocaleString()}`,
      timestamp: new Date().toISOString(),
      nodes: JSON.parse(JSON.stringify(nodes)),
      edges: JSON.parse(JSON.stringify(edges)),
      violations: JSON.parse(JSON.stringify(violations)),
      nodeCount: nodes.length,
      edgeCount: edges.length,
      violationCount: violations.length
    };
    const snapshots = [snapshot, ...get().snapshots].slice(0, MAX_SNAPSHOTS);
    saveSnapshots(snapshots);
    set({ snapshots });
    return snapshot;
  },

  deleteSnapshot: (id) => {
    const snapshots = get().snapshots.filter(s => s.id !== id);
    saveSnapshots(snapshots);
    set({ snapshots });
  },

  getProjectSnapshots: (projectId) =>
    get().snapshots.filter(s => s.projectId === projectId),

  computeDiff: (snapshotA, snapshotB) => {
    // A = old/snapshot, B = new/current
    const nodesA = new Map(snapshotA.nodes.map(n => [n.id, n]));
    const nodesB = new Map(snapshotB.nodes.map(n => [n.id, n]));
    const edgesA = new Set(snapshotA.edges.map(e => `${e.source}→${e.target}`));
    const edgesB = new Set(snapshotB.edges.map(e => `${e.source}→${e.target}`));
    const violationsA = new Set(snapshotA.violations.map(v => `${v.source}→${v.target}→${v.ruleId}`));
    const violationsB = new Set(snapshotB.violations.map(v => `${v.source}→${v.target}→${v.ruleId}`));

    // Added nodes (in B not in A)
    const addedNodes = snapshotB.nodes.filter(n => !nodesA.has(n.id));

    // Removed nodes (in A not in B)
    const removedNodes = snapshotA.nodes.filter(n => !nodesB.has(n.id));

    // Renamed/changed nodes (same id different name/type)
    const changedNodes = snapshotB.nodes.filter(n => {
      const old = nodesA.get(n.id);
      return old && (old.name !== n.name || old.type !== n.type);
    }).map(n => ({ old: nodesA.get(n.id), new: n }));

    // Added edges
    const addedEdges = snapshotB.edges.filter(e =>
      !edgesA.has(`${e.source}→${e.target}`)
    ).map(e => ({
      ...e,
      sourceName: nodesB.get(e.source)?.name || e.source,
      targetName: nodesB.get(e.target)?.name || e.target
    }));

    // Removed edges
    const removedEdges = snapshotA.edges.filter(e =>
      !edgesB.has(`${e.source}→${e.target}`)
    ).map(e => ({
      ...e,
      sourceName: nodesA.get(e.source)?.name || e.source,
      targetName: nodesA.get(e.target)?.name || e.target
    }));

    // New violations
    const newViolations = snapshotB.violations.filter(v =>
      !violationsA.has(`${v.source}→${v.target}→${v.ruleId}`)
    );

    // Fixed violations
    const fixedViolations = snapshotA.violations.filter(v =>
      !violationsB.has(`${v.source}→${v.target}→${v.ruleId}`)
    );

    const hasChanges =
      addedNodes.length > 0 ||
      removedNodes.length > 0 ||
      changedNodes.length > 0 ||
      addedEdges.length > 0 ||
      removedEdges.length > 0 ||
      newViolations.length > 0 ||
      fixedViolations.length > 0;

    return {
      addedNodes,
      removedNodes,
      changedNodes,
      addedEdges,
      removedEdges,
      newViolations,
      fixedViolations,
      hasChanges,
      summary: {
        totalChanges:
          addedNodes.length + removedNodes.length + changedNodes.length +
          addedEdges.length + removedEdges.length,
        healthDelta:
          (snapshotB.violations?.length || 0) - (snapshotA.violations?.length || 0)
      }
    };
  }
}));