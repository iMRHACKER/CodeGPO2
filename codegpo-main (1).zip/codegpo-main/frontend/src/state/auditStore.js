import { create } from "zustand";

const STORAGE_KEY = "codegpo_audit_log";
const EXPLANATIONS_KEY = "codegpo_explanations";
const MAX_ENTRIES = 200;

function loadLog() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function loadExplanations() {
  try {
    const raw = localStorage.getItem(EXPLANATIONS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function saveLog(log) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(log.slice(0, MAX_ENTRIES)));
}

function saveExplanations(explanations) {
  localStorage.setItem(EXPLANATIONS_KEY, JSON.stringify(explanations.slice(0, 50)));
}

export const ACTION_TYPES = {
  NODE_ADDED: "NODE_ADDED",
  NODE_DELETED: "NODE_DELETED",
  EDGE_ADDED: "EDGE_ADDED",
  EDGE_DELETED: "EDGE_DELETED",
  VIOLATION_DETECTED: "VIOLATION_DETECTED",
  GRAPH_SAVED: "GRAPH_SAVED",
  GRAPH_LOADED: "GRAPH_LOADED",
  PROJECT_CREATED: "PROJECT_CREATED",
  PROJECT_DELETED: "PROJECT_DELETED",
  RULE_ADDED: "RULE_ADDED",
  RULE_DELETED: "RULE_DELETED",
  SCAN_COMPLETED: "SCAN_COMPLETED",
  ARCHITECTURE_EXPLAINED: "ARCHITECTURE_EXPLAINED",
};

export const ACTION_LABELS = {
  NODE_ADDED: "Node Added",
  NODE_DELETED: "Node Deleted",
  EDGE_ADDED: "Edge Added",
  EDGE_DELETED: "Edge Deleted",
  VIOLATION_DETECTED: "Violation Detected",
  GRAPH_SAVED: "Graph Saved",
  GRAPH_LOADED: "Graph Loaded",
  PROJECT_CREATED: "Project Created",
  PROJECT_DELETED: "Project Deleted",
  RULE_ADDED: "Rule Added",
  RULE_DELETED: "Rule Deleted",
  SCAN_COMPLETED: "Scan Completed",
  ARCHITECTURE_EXPLAINED: "Architecture Explained",
};

export const ACTION_COLORS = {
  NODE_ADDED: "#5a9e6f",
  NODE_DELETED: "#cc6666",
  EDGE_ADDED: "#6699cc",
  EDGE_DELETED: "#cc6666",
  VIOLATION_DETECTED: "#cc9944",
  GRAPH_SAVED: "#7c6aad",
  GRAPH_LOADED: "#7c6aad",
  PROJECT_CREATED: "#5a9e6f",
  PROJECT_DELETED: "#cc6666",
  RULE_ADDED: "#cc6699",
  RULE_DELETED: "#cc6666",
  SCAN_COMPLETED: "#6699cc",
  ARCHITECTURE_EXPLAINED: "#6699cc",
};

export const ACTION_ICONS = {
  NODE_ADDED: "●",
  NODE_DELETED: "○",
  EDGE_ADDED: "→",
  EDGE_DELETED: "✕",
  VIOLATION_DETECTED: "⚠",
  GRAPH_SAVED: "↑",
  GRAPH_LOADED: "↓",
  PROJECT_CREATED: "□",
  PROJECT_DELETED: "✕",
  RULE_ADDED: "◈",
  RULE_DELETED: "✕",
  SCAN_COMPLETED: "⌕",
  ARCHITECTURE_EXPLAINED: "✦",
};

export const useAuditStore = create((set, get) => ({
  log: loadLog(),
  explanations: loadExplanations(),

  record: (action, detail = "", projectName = "") => {
    const entry = {
      id: `log-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      action, detail, projectName,
      timestamp: new Date().toISOString()
    };
    const log = [entry, ...get().log].slice(0, MAX_ENTRIES);
    saveLog(log);
    set({ log });
  },

  saveExplanation: ({ projectName, projectId, nodes, edges, violations, sections }) => {
    const entry = {
      id: `exp-${Date.now()}`,
      projectName,
      projectId,
      timestamp: new Date().toISOString(),
      nodeCount: nodes.length,
      edgeCount: edges.length,
      violationCount: violations.length,
      sections
    };
    const explanations = [entry, ...get().explanations].slice(0, 50);
    saveExplanations(explanations);
    set({ explanations });

    // Also add to audit log
    get().record(
      ACTION_TYPES.ARCHITECTURE_EXPLAINED,
      `${nodes.length} components, ${violations.length} violations`,
      projectName
    );
  },

  clearLog: () => {
    localStorage.removeItem(STORAGE_KEY);
    set({ log: [] });
  },

  clearExplanations: () => {
    localStorage.removeItem(EXPLANATIONS_KEY);
    set({ explanations: [] });
  }
}));