import { create } from "zustand";

const STORAGE_KEY = "codegpo_projects";

function loadProjects() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function saveProjects(projects) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
}

export const useProjectStore = create((set, get) => ({
  projects: loadProjects(),
  activeProjectId: null,

  createProject: (name, description = "") => {
    const project = {
      id: `proj-${Date.now()}`,
      name,
      description,
      createdAt: new Date().toISOString(),
      nodes: [],
      edges: []
    };
    const projects = [...get().projects, project];
    saveProjects(projects);
    set({ projects, activeProjectId: project.id });
    return project;
  },

  deleteProject: (id) => {
    const projects = get().projects.filter(p => p.id !== id);
    saveProjects(projects);
    const activeProjectId = get().activeProjectId === id ? null : get().activeProjectId;
    set({ projects, activeProjectId });
  },

  setActiveProject: (id) => {
    set({ activeProjectId: id });
  },

  saveActiveGraph: (nodes, edges) => {
    const { activeProjectId, projects } = get();
    if (!activeProjectId) return;
    const updated = projects.map(p =>
      p.id === activeProjectId ? { ...p, nodes, edges, updatedAt: new Date().toISOString() } : p
    );
    saveProjects(updated);
    set({ projects: updated });
  },

  getActiveProject: () => {
    const { activeProjectId, projects } = get();
    return projects.find(p => p.id === activeProjectId) || null;
  },

  renameProject: (id, name) => {
    const projects = get().projects.map(p => p.id === id ? { ...p, name } : p);
    saveProjects(projects);
    set({ projects });
  }
}));        