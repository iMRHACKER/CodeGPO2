import { create } from "zustand";

const WS_URL = (() => {
  const api = import.meta.env.VITE_API_URL || "https://codegpo-production-9548.up.railway.app";
  return api.replace("https://", "wss://").replace("http://", "ws://");
})();

let ws = null;
let reconnectTimer = null;
let pingTimer = null;
let positionThrottle = {};

export const useCollabStore = create((set, get) => ({
  connected: false,
  connecting: false,
  roomId: null,
  userId: null,
  userColor: null,
  userName: "",
  users: [],
  cursors: {},
  enabled: false,

  setUserName: (name) => set({ userName: name }),

  join: (roomId, userName, onSync) => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      get().leave();
    }

    set({ connecting: true, enabled: true, roomId, userName });

    ws = new WebSocket(`${WS_URL}/collab/${roomId}`);

    ws.onopen = () => {
      ws.send(JSON.stringify({
        type: "join",
        roomId,
        userName: userName || "Anonymous"
      }));

      pingTimer = setInterval(() => {
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: "ping" }));
        }
      }, 25000);
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        get()._handleMessage(msg, onSync);
      } catch {}
    };

    ws.onclose = () => {
      set({ connected: false, connecting: false });
      clearInterval(pingTimer);
      if (get().enabled) {
        reconnectTimer = setTimeout(() => {
          const { roomId, userName, join } = get();
          if (roomId) join(roomId, userName, onSync);
        }, 3000);
      }
    };

    ws.onerror = () => {
      set({ connected: false, connecting: false });
    };
  },

  leave: () => {
    clearTimeout(reconnectTimer);
    clearInterval(pingTimer);
    positionThrottle = {};
    set({
      connected: false, connecting: false,
      enabled: false, roomId: null,
      userId: null, userColor: null,
      users: [], cursors: {}
    });
    if (ws) {
      ws.close();
      ws = null;
    }
  },

  _handleMessage: (msg, onSync) => {
    switch (msg.type) {

      case "init":
      case "joined":
        set({
          connected: true,
          connecting: false,
          userId: msg.userId,
          userColor: msg.color,
          users: msg.users || []
        });
        // Only sync if remote room has content — dont wipe local canvas
        if (onSync && msg.nodes && msg.nodes.length > 0) {
          onSync({ nodes: msg.nodes, edges: msg.edges || [] });
        }
        break;

      case "user_joined":
        const newUser = msg.user || { id: msg.userId, name: msg.name, color: msg.color };
        set(state => ({
          users: [...state.users.filter(u => u.id !== (msg.userId || msg.user?.id)), newUser]
        }));
        break;

      case "user_left":
        set(state => ({
          users: state.users.filter(u => u.id !== msg.userId),
          cursors: Object.fromEntries(
            Object.entries(state.cursors).filter(([id]) => id !== msg.userId)
          )
        }));
        break;

      case "cursor":
        if (msg.userId !== get().userId) {
          set(state => ({
            cursors: {
              ...state.cursors,
              [msg.userId]: {
                x: msg.cursor?.x,
                y: msg.cursor?.y,
                name: msg.name,
                color: msg.color
              }
            }
          }));
        }
        break;

      case "node_move":
        // Move node directly on canvas — NO state update, NO re-render, NO re-layout
        if (msg.userId !== get().userId) {
          try {
            const cy = window.__cyInstance;
            if (cy) {
              const node = cy.getElementById(msg.nodeId);
              if (node && node.length > 0) {
                node.position({ x: msg.x, y: msg.y });
              }
            }
          } catch {}
        }
        break;

      case "sync":
      case "sync_full":
        if (msg.userId === "server" || msg.userId !== get().userId) {
          if (onSync && msg.nodes?.length > 0) {
            onSync({ nodes: msg.nodes, edges: msg.edges || [] });
            // Apply positions after render
            setTimeout(() => {
              const cy = window.__cyInstance;
              if (!cy) return;
              msg.nodes.forEach(n => {
                if (n._x !== undefined && n._y !== undefined) {
                  const cyNode = cy.getElementById(n.id);
                  if (cyNode && cyNode.length > 0) {
                    cyNode.position({ x: n._x, y: n._y });
                  }
                }
              });
              cy.fit(cy.nodes(), 60);
            }, 300);
          }
        }
        break;

      case "request_sync":
        // Someone joined — send them our current graph
        const graphState = typeof window !== "undefined" && window.__codegpo_getGraph?.();
        if (graphState && graphState.nodes?.length > 0 && ws && ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            type: "sync_full",
            nodes: graphState.nodes,
            edges: graphState.edges || []
          }));
        }
        break;

      case "node_add":
        if (msg.userId !== get().userId && onSync) {
          onSync({ type: "node_add", node: msg.node });
        }
        break;

      case "node_delete":
        if (msg.userId !== get().userId && onSync) {
          onSync({ type: "node_delete", nodeId: msg.nodeId });
        }
        break;

      case "edge_add":
        if (msg.userId !== get().userId && onSync) {
          onSync({ type: "edge_add", edge: msg.edge });
        }
        break;

      case "edge_delete":
        if (msg.userId !== get().userId && onSync) {
          onSync({ type: "edge_delete", source: msg.source, target: msg.target });
        }
        break;
    }
  },

  sendNodeAdd: (node) => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ type: "node_add", node }));
  },

  sendNodeDelete: (nodeId) => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ type: "node_delete", nodeId }));
  },

  // Throttled to max 20 position updates/sec per node
  sendNodeMove: (nodeId, x, y) => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    if (positionThrottle[nodeId]) return;
    positionThrottle[nodeId] = setTimeout(() => {
      delete positionThrottle[nodeId];
    }, 50);
    ws.send(JSON.stringify({ type: "node_move", nodeId, x, y }));
  },

  sendEdgeAdd: (edge) => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ type: "edge_add", edge }));
  },

  sendEdgeDelete: (source, target) => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ type: "edge_delete", source, target }));
  },

  sendFullSync: (nodes, edges) => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    // Include node positions from Cytoscape
    const cy = window.__cyInstance;
    const nodesWithPos = nodes.map(n => {
      if (cy) {
        const cyNode = cy.getElementById(n.id);
        if (cyNode && cyNode.length > 0) {
          const pos = cyNode.position();
          return { ...n, _x: pos.x, _y: pos.y };
        }
      }
      return n;
    });
    ws.send(JSON.stringify({ type: "sync_full", nodes: nodesWithPos, edges }));
  },

  sendCursor: (x, y) => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ type: "cursor", cursor: { x, y } }));
  }
}));
