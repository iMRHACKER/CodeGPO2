import { create } from "zustand";

const STORAGE_KEY = "codegpo_alert_config";
const HISTORY_KEY = "codegpo_alert_history";

function loadConfig() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {
      slackEnabled: false,
      slackWebhook: "",
      emailEnabled: false,
      emailAddress: "",
      alertOnCritical: true,
      alertOnHigh: true,
      alertOnMedium: false,
      alertOnLow: false,
      digestMode: false
    };
  } catch { return {}; }
}

function loadHistory() {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function saveConfig(config) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
}

function saveHistory(history) {
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 100)));
}

export const useAlertStore = create((set, get) => ({
  config: loadConfig(),
  history: loadHistory(),
  sending: false,
  lastViolationIds: new Set(),

  updateConfig: (updates) => {
    const config = { ...get().config, ...updates };
    saveConfig(config);
    set({ config });
  },

  addHistory: (entry) => {
    const history = [
      {
        ...entry,
        id: `alert-${Date.now()}`,
        timestamp: new Date().toISOString()
      },
      ...get().history
    ].slice(0, 100);
    saveHistory(history);
    set({ history });
  },

  sendSlackAlert: async (violations, projectName) => {
    const { config, addHistory } = get();
    if (!config.slackEnabled || !config.slackWebhook) return false;

    const filtered = violations.filter(v => {
      if (v.severity === "CRITICAL" && config.alertOnCritical) return true;
      if (v.severity === "HIGH"     && config.alertOnHigh)     return true;
      if (v.severity === "MEDIUM"   && config.alertOnMedium)   return true;
      if (v.severity === "LOW"      && config.alertOnLow)      return true;
      return false;
    });

    if (filtered.length === 0) return false;

    const critCount = filtered.filter(v => v.severity === "CRITICAL").length;
    const highCount = filtered.filter(v => v.severity === "HIGH").length;

    const violationLines = filtered.slice(0, 5).map(v =>
      `• *${v.ruleId}* [${v.severity}] — ${v.message}`
    ).join("\n");

    const payload = {
      text: `⚠️ *CodeGPO Violation Alert* — ${projectName || "Your Project"}`,
      blocks: [
        {
          type: "header",
          text: {
            type: "plain_text",
            text: "⚡ CodeGPO — Governance Violation Alert"
          }
        },
        {
          type: "section",
          text: {
            type: "mrkdwn",
            text: `*Project:* ${projectName || "Untitled"}\n*Total violations:* ${filtered.length}${critCount > 0 ? `\n🔴 *${critCount} CRITICAL* issue${critCount > 1 ? "s" : ""} need immediate attention` : ""}`
          }
        },
        {
          type: "section",
          text: {
            type: "mrkdwn",
            text: `*Violations:*\n${violationLines}${filtered.length > 5 ? `\n_...and ${filtered.length - 5} more_` : ""}`
          }
        },
        {
          type: "context",
          elements: [{
            type: "mrkdwn",
            text: `Detected by CodeGPO at ${new Date().toLocaleString()}`
          }]
        }
      ]
    };

    set({ sending: true });
    try {
      const res = await fetch(config.slackWebhook, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const success = res.ok;
      addHistory({
        type: "slack",
        success,
        violationCount: filtered.length,
        projectName,
        error: success ? null : `HTTP ${res.status}`
      });
      set({ sending: false });
      return success;
    } catch (err) {
      addHistory({
        type: "slack",
        success: false,
        violationCount: filtered.length,
        projectName,
        error: err.message
      });
      set({ sending: false });
      return false;
    }
  },

  sendTestSlack: async () => {
    const { config, addHistory } = get();
    if (!config.slackWebhook) return false;

    const payload = {
      blocks: [
        {
          type: "header",
          text: { type: "plain_text", text: "⚡ CodeGPO — Test Alert" }
        },
        {
          type: "section",
          text: {
            type: "mrkdwn",
            text: "✅ Your Slack integration is working correctly!\nYou will receive alerts when governance violations are detected."
          }
        }
      ]
    };

    set({ sending: true });
    try {
      const res = await fetch(config.slackWebhook, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const success = res.ok;
      addHistory({
        type: "slack_test",
        success,
        violationCount: 0,
        projectName: "Test",
        error: success ? null : `HTTP ${res.status}`
      });
      set({ sending: false });
      return success;
    } catch (err) {
      addHistory({
        type: "slack_test",
        success: false,
        violationCount: 0,
        projectName: "Test",
        error: err.message
      });
      set({ sending: false });
      return false;
    }
  },

  // Check violations and auto-alert if new ones found
  checkAndAlert: async (violations, projectName) => {
    const { lastViolationIds, sendSlackAlert } = get();
    const currentIds = new Set(violations.map(v => `${v.source}-${v.target}-${v.ruleId}`));

    const newViolations = violations.filter(
      v => !lastViolationIds.has(`${v.source}-${v.target}-${v.ruleId}`)
    );

    set({ lastViolationIds: currentIds });

    if (newViolations.length > 0) {
      await sendSlackAlert(newViolations, projectName);
    }
  }
}));