import { create } from "zustand";
import { SEVERITY } from "../core/governanceEngine";

const STORAGE_KEY = "codegpo_custom_rules";

function loadRules() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function saveRules(rules) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(rules));
}

export const useRulesStore = create((set, get) => ({
  rules: loadRules(),

  addRule: (rule) => {
    const newRule = {
      id: `custom-${Date.now()}`,
      ruleId: `CUSTOM-${get().rules.length + 1}`,
      sourceType: rule.sourceType.trim(),
      targetType: rule.targetType.trim(),
      message: rule.message.trim(),
      severity: rule.severity || "MEDIUM",
      enabled: true,
      createdAt: new Date().toISOString()
    };
    const rules = [...get().rules, newRule];
    saveRules(rules);
    set({ rules });
    return newRule;
  },

  deleteRule: (id) => {
    const rules = get().rules.filter(r => r.id !== id);
    saveRules(rules);
    set({ rules });
  },

  toggleRule: (id) => {
    const rules = get().rules.map(r =>
      r.id === id ? { ...r, enabled: !r.enabled } : r
    );
    saveRules(rules);
    set({ rules });
  },

  evaluateCustomRules: (nodes, edges) => {
    const { rules } = get();
    const violations = [];
    const nodeMap = {};
    nodes.forEach(n => { nodeMap[n.id] = n; });

    edges.forEach(edge => {
      const source = nodeMap[edge.source];
      const target = nodeMap[edge.target];
      if (!source || !target) return;

      rules.filter(r => r.enabled).forEach(rule => {
        const sMatch = source.type?.toLowerCase().includes(rule.sourceType.toLowerCase());
        const tMatch = target.type?.toLowerCase().includes(rule.targetType.toLowerCase());
        if (sMatch && tMatch) {
          violations.push({
            ruleId: rule.ruleId,
            severity: rule.severity || "MEDIUM",
            message: rule.message,
            source: edge.source,
            target: edge.target,
            custom: true
          });
        }
      });
    });

    return violations.sort((a, b) =>
      (SEVERITY[b.severity]?.priority || 0) - (SEVERITY[a.severity]?.priority || 0)
    );
  }
}));