import cytoscape from "cytoscape";
import { useEffect, useRef } from "react";
import { useGraphStore } from "../state/graphStore";
import { useCollabStore } from "../state/collabStore";
import "../styles/canvas.css";

// ── Type config ───────────────────────────────────────────
const TYPE_CONFIG = {
  // Entry Points
  service:    { icon: "⚙",  color: "#7c3aed", bg: "#1a0a2e", label: "Service"    },
  api:        { icon: "◈",  color: "#22c55e", bg: "#0a1f0f", label: "API"        },
  user:       { icon: "◎",  color: "#f59e0b", bg: "#1f160a", label: "User"       },
  client:     { icon: "◎",  color: "#f59e0b", bg: "#1f160a", label: "Client"     },
  frontend:   { icon: "▣",  color: "#f59e0b", bg: "#1f160a", label: "Frontend"   },
  browser:    { icon: "▣",  color: "#f59e0b", bg: "#1f160a", label: "Browser"    },
  mobile:     { icon: "📱", color: "#f59e0b", bg: "#1f160a", label: "Mobile"     },
  admin:      { icon: "🔧", color: "#94a3b8", bg: "#141820", label: "Admin"      },
  iot:        { icon: "📡", color: "#10b981", bg: "#0a1f14", label: "IoT"        },
  // Infrastructure
  database:   { icon: "🗄", color: "#0ea5e9", bg: "#0a1929", label: "Database"   },
  db:         { icon: "🗄", color: "#0ea5e9", bg: "#0a1929", label: "Database"   },
  queue:      { icon: "⇌",  color: "#ec4899", bg: "#1f0a18", label: "Queue"      },
  cache:      { icon: "⚡", color: "#06b6d4", bg: "#0a1f22", label: "Cache"      },
  gateway:    { icon: "◉",  color: "#f97316", bg: "#1f110a", label: "Gateway"    },
  worker:     { icon: "↻",  color: "#8b5cf6", bg: "#160a2e", label: "Worker"     },
  auth:       { icon: "🔒", color: "#a78bfa", bg: "#160a2e", label: "Auth"       },
  cdn:        { icon: "🌐", color: "#f97316", bg: "#1f110a", label: "CDN"        },
  // Data
  search:     { icon: "🔍", color: "#06b6d4", bg: "#0a1f22", label: "Search"     },
  storage:    { icon: "🗂",  color: "#64748b", bg: "#111820", label: "Storage"    },
  secrets:    { icon: "🔑", color: "#f59e0b", bg: "#1f160a", label: "Secrets"    },
  // External & Observability
  external:   { icon: "⊕",  color: "#64748b", bg: "#111820", label: "External"   },
  payment:    { icon: "💳", color: "#10b981", bg: "#0a1f14", label: "Payment"    },
  monitoring: { icon: "📊", color: "#f97316", bg: "#1f110a", label: "Monitoring" },
  analytics:  { icon: "📈", color: "#a78bfa", bg: "#160a2e", label: "Analytics"  },
  ai:         { icon: "🤖", color: "#22c55e", bg: "#0a1f0f", label: "AI"         },
};

function getTypeConfig(type) {
  if (!type) return TYPE_CONFIG.service;
  const t = type.toLowerCase();
  for (const [key, cfg] of Object.entries(TYPE_CONFIG)) {
    if (t.includes(key)) return cfg;
  }
  return { icon: "◆", color: "#888", bg: "#1a1a1a", label: type };
}

// ── Position persistence ──────────────────────────────────
const POS_KEY = "codegpo_node_positions";

function loadPositions() {
  try {
    return JSON.parse(localStorage.getItem(POS_KEY) || "{}");
  } catch { return {}; }
}

function savePositions(positions) {
  try {
    localStorage.setItem(POS_KEY, JSON.stringify(positions));
  } catch {}
}

// ── Clamp node to safe canvas zone ───────────────────────
// Toolbar is ~130px left, Inspector is ~320px right, ~56px top bar
const TOOLBAR_W  = 220;   // px — must match CSS toolbar width (.toolbar width)
const INSPECTOR_W = 330;  // px — right panel width
const MARGIN     = 20;    // extra breathing room

function clampPosition(cy, pos) {
  const container = cy.container();
  if (!container) return pos;
  const W = container.offsetWidth;
  const H = container.offsetHeight;
  const zoom = cy.zoom();
  const pan  = cy.pan();

  // Convert screen boundaries to graph coordinates
  const minScreenX = TOOLBAR_W + MARGIN;
  const maxScreenX = W - INSPECTOR_W - MARGIN;
  const minScreenY = MARGIN;
  const maxScreenY = H - MARGIN;

  const minX = (minScreenX - pan.x) / zoom;
  const maxX = (maxScreenX - pan.x) / zoom;
  const minY = (minScreenY - pan.y) / zoom;
  const maxY = (maxScreenY - pan.y) / zoom;

  return {
    x: Math.max(minX, Math.min(maxX, pos.x)),
    y: Math.max(minY, Math.min(maxY, pos.y))
  };
}

// ── Node SVG ──────────────────────────────────────────────
function escapeXML(str) {
  return (str || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
}

function makeNodeSVG(name, type, isViolation = false) {
  name = escapeXML(name);
  const cfg = getTypeConfig(type);
  const W = 140, H = 70;
  const borderColor = isViolation ? "#cc4444" : cfg.color;
  const displayName = name.length > 16 ? name.slice(0, 14) + "…" : name;
  const displayType = cfg.label || type;

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">
    <defs>
      <filter id="glow">
        <feGaussianBlur stdDeviation="2" result="blur"/>
        <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
      </filter>
    </defs>
    <rect x="4" y="4" width="${W-8}" height="${H-8}" rx="10" fill="#000" opacity="0.4"/>
    <rect x="2" y="2" width="${W-4}" height="${H-4}" rx="10"
      fill="${cfg.bg}" stroke="${borderColor}" stroke-width="1.5" filter="url(#glow)"/>
    <rect x="2" y="2" width="${W-4}" height="3" rx="10" fill="${borderColor}" opacity="0.8"/>
    <circle cx="26" cy="${H/2}" r="14"
      fill="${borderColor}" opacity="0.15" stroke="${borderColor}" stroke-width="1"/>
    <text x="26" y="${H/2 + 5}" text-anchor="middle"
      font-size="14" font-family="sans-serif" fill="${borderColor}">${cfg.icon}</text>
    <text x="54" y="${H/2 - 5}" text-anchor="start"
      font-size="12" font-weight="600"
      font-family="-apple-system, BlinkMacSystemFont, sans-serif" fill="#e5e5e5">${displayName}</text>
    <rect x="52" y="${H/2 + 4}" width="${displayType.length * 6 + 10}" height="14"
      rx="4" fill="${borderColor}" opacity="0.2"/>
    <text x="57" y="${H/2 + 14}" text-anchor="start"
      font-size="9" font-weight="700" letter-spacing="0.5"
      font-family="sans-serif" fill="${borderColor}">${displayType.toUpperCase()}</text>
  </svg>`;

  return "data:image/svg+xml;utf8," + encodeURIComponent(svg);
}

export function exportCanvasPNG(projectName) {
  const cy = window.__cyInstance;
  if (!cy) return;
  const png = cy.png({ full: true, scale: 2, bg: "#0d0d0d" });
  const a = document.createElement("a");
  a.href = png;
  a.download = `${projectName || "architecture"}-${Date.now()}.png`;
  a.click();
}

export function focusNode(nodeId) {
  const cy = window.__cyInstance;
  if (!cy) return;
  const node = cy.getElementById(nodeId);
  if (!node || node.empty()) return;
  cy.animate({
    fit: { eles: node, padding: 140 },
    duration: 400,
    easing: "ease-in-out-cubic"
  });
  setTimeout(() => node.flashClass("highlighted", 900), 100);
}

function buildStyle(violationSet) {
  return [
    {
      selector: "node",
      style: {
        shape: "rectangle",
        width: 140,
        height: 70,
        "background-opacity": 0,
        "border-width": 0,
        "background-image": ele => {
          const isV = [...violationSet].some(
            v => v.startsWith(ele.id() + "-") || v.endsWith("-" + ele.id())
          );
          return makeNodeSVG(ele.data("name") || ele.id(), ele.data("type") || "Service", isV);
        },
        "background-fit": "contain",
        "background-clip": "none",
        label: "",
        "overlay-opacity": 0
      }
    },
    {
      selector: "node:selected",
      style: { "border-width": 2, "border-color": "#f59e0b", "border-opacity": 1 }
    },
    {
      selector: "node.edge-source",
      style: { "border-width": 2, "border-color": "#f59e0b", "border-opacity": 1 }
    },
    {
      selector: "node.highlighted",
      style: { "border-width": 3, "border-color": "#f59e0b", "border-opacity": 1 }
    },
    {
      selector: "edge",
      style: {
        width: ele => ele.data("bad") ? 2.5 : 1.5,
        "line-color": ele => ele.data("bad") ? "#cc4444" : "#334455",
        "line-style": ele => ele.data("bad") ? "dashed" : "solid",
        "line-dash-pattern": [8, 4],
        "target-arrow-color": ele => ele.data("bad") ? "#cc4444" : "#334455",
        "target-arrow-shape": "triangle",
        "curve-style": "unbundled-bezier",
        "control-point-distances": [20],
        "control-point-weights": [0.5],
        "arrow-scale": 1.1,
        opacity: ele => ele.data("bad") ? 1 : 0.6,
        "transition-property": "line-color, target-arrow-color, width, opacity",
        "transition-duration": "0.2s"
      }
    },
    {
      selector: "edge:selected",
      style: {
        "line-color": "#f59e0b",
        "target-arrow-color": "#f59e0b",
        width: 2.5,
        opacity: 1
      }
    },
    {
      selector: "edge.violation-edge",
      style: {
        "line-color": "#cc4444",
        "target-arrow-color": "#cc4444",
        width: 2.5,
        opacity: 1,
        "line-style": "dashed"
      }
    }
  ];
}

export default function GraphCanvas({ customViolations = [] }) {
  const ref    = useRef(null);
  const cyRef  = useRef(null);
  const prevNodeCount    = useRef(0);
  const violationSetRef  = useRef(new Set());
  const hasLayoutRun     = useRef(false);   // did we ever run cose for this session?
  const savedPositions   = useRef(loadPositions());

  const {
    nodes, edges, violations,
    edgeMode, edgeSourceId,
    startEdge, finishEdge,
    selectNode, selectEdge
  } = useGraphStore();

  const { connected } = useCollabStore();

  const allViolations = [...violations, ...customViolations];
  const violationSet  = new Set(allViolations.map(v => `${v.source}-${v.target}`));
  violationSetRef.current = violationSet;

  // ── Init Cytoscape once ───────────────────────────────
  useEffect(() => {
    if (!ref.current) return;

    const cy = cytoscape({
      container: ref.current,
      elements: [],
      style: buildStyle(new Set()),
      layout: { name: "preset" },
      wheelSensitivity: 0.3,
      minZoom: 0.08,
      maxZoom: 3,
      boxSelectionEnabled: false
    });

    cyRef.current = cy;
    window.__cyInstance = cy;
    hasLayoutRun.current = false;

    cy.on("tap", "node", evt => {
      const id = evt.target.id();
      const { edgeMode, edgeSourceId } = useGraphStore.getState();
      if (edgeMode && edgeSourceId) {
        finishEdge(id);
      } else {
        startEdge(id);
        selectNode(id);
      }
    });

    cy.on("tap", "edge", evt => {
      selectEdge(evt.target.data());
    });

    cy.on("tap", evt => {
      if (evt.target === cy) {
        useGraphStore.getState().selectNode(null);
      }
    });

    // ── Save positions on drag ────────────────────────
    cy.on("dragfree", "node", evt => {
      const node = evt.target;
      // Clamp to safe zone — prevents hiding behind toolbar/inspector
      const clamped = clampPosition(cy, node.position());
      node.position(clamped);

      // Persist to localStorage
      const positions = loadPositions();
      positions[node.id()] = { x: clamped.x, y: clamped.y };
      savePositions(positions);
      savedPositions.current = positions;

      // Collab sync
      if (useCollabStore.getState().connected) {
        useCollabStore.getState().sendNodeMove(node.id(), clamped.x, clamped.y);
      }
    });

    return () => {
      cy.destroy();
      cyRef.current = null;
      window.__cyInstance = null;
    };
  }, []);

  // ── Update drag handler on collab connect ─────────────
  useEffect(() => {
    const cy = cyRef.current;
    if (!cy) return;
    cy.off("dragfree", "node");
    cy.on("dragfree", "node", evt => {
      const node    = evt.target;
      const clamped = clampPosition(cy, node.position());
      node.position(clamped);

      const positions = loadPositions();
      positions[node.id()] = { x: clamped.x, y: clamped.y };
      savePositions(positions);
      savedPositions.current = positions;

      if (useCollabStore.getState().connected) {
        useCollabStore.getState().sendNodeMove(node.id(), clamped.x, clamped.y);
      }
    });
  }, [connected]);

  // ── Sync graph data to Cytoscape ─────────────────────
  useEffect(() => {
    const cy = cyRef.current;
    if (!cy) return;

    const positions = savedPositions.current;

    // Determine which nodes are brand new (not yet in Cytoscape)
    const newNodeIds = [];

    nodes.forEach(n => {
      const existing = cy.getElementById(n.id);
      if (!existing.length) {
        newNodeIds.push(n.id);
        const hasSaved = positions[n.id];
        cy.add({
          group: "nodes",
          data: { id: n.id, name: n.name, type: n.type },
          // Restore saved position, or place off-screen temporarily
          position: hasSaved
            ? { x: positions[n.id].x, y: positions[n.id].y }
            : { x: -9999, y: -9999 }   // will be laid out below
        });
      } else {
        existing.data({ name: n.name, type: n.type });
      }
    });

    // Remove deleted nodes
    cy.nodes().forEach(cyNode => {
      if (!nodes.find(n => n.id === cyNode.id())) {
        // Also remove its saved position
        const positions = loadPositions();
        delete positions[cyNode.id()];
        savePositions(positions);
        savedPositions.current = positions;
        cy.remove(cyNode);
      }
    });

    // Add/update edges
    edges.forEach(e => {
      const edgeId   = `${e.source}-${e.target}`;
      const existing = cy.getElementById(edgeId);
      if (!existing.length) {
        try {
          cy.add({
            group: "edges",
            data: {
              id: edgeId,
              source: e.source,
              target: e.target,
              bad: violationSet.has(edgeId)
            }
          });
        } catch {}
      } else {
        existing.data("bad", violationSet.has(edgeId));
      }
    });

    // Remove deleted edges
    cy.edges().forEach(cyEdge => {
      const src = cyEdge.data("source");
      const tgt = cyEdge.data("target");
      if (!edges.find(e => e.source === src && e.target === tgt)) {
        cy.remove(cyEdge);
      }
    });

    // Update violation colours on all edges
    cy.edges().forEach(cyEdge => {
      const edgeId = `${cyEdge.data("source")}-${cyEdge.data("target")}`;
      cyEdge.data("bad", violationSet.has(edgeId));
    });

    const currentCount = cy.nodes().length;

    // ── Layout decision ───────────────────────────────
    const nodesWithSavedPositions = nodes.filter(n => positions[n.id]).length;
    const allHaveSavedPositions   = nodesWithSavedPositions === nodes.length && nodes.length > 0;

    if (currentCount > 0) {
      if (allHaveSavedPositions && !hasLayoutRun.current) {
        // All nodes have saved positions — restore exactly, no layout needed
        hasLayoutRun.current = true;
        // Fit to show all nodes with padding for toolbar
        cy.fit(cy.nodes(), 100);

      } else if (!hasLayoutRun.current && newNodeIds.length > 0) {
        // First load with no saved positions — run full cose layout
        hasLayoutRun.current = true;
        cy.layout({
          name: "cose",
          animate: true,
          animationDuration: 700,
          nodeRepulsion: 12000,
          idealEdgeLength: 200,
          edgeElasticity: 100,
          gravity: 0.2,
          numIter: 1200,
          fit: true,
          padding: 100,          // enough for toolbar
          nodeDimensionsIncludeLabels: false,
          nodeOverlap: 20,
          stop: () => {
            // After layout, save the computed positions
            const newPositions = loadPositions();
            cy.nodes().forEach(n => {
              newPositions[n.id()] = { ...n.position() };
            });
            savePositions(newPositions);
            savedPositions.current = newPositions;
          }
        }).run();

      } else if (hasLayoutRun.current && newNodeIds.length > 0) {
        // Subsequent node additions — place near existing graph
        const newNodes = cy.nodes().filter(n => newNodeIds.includes(n.id()));
        if (newNodes.length > 0) {
          const bb = cy.nodes().not(newNodes).boundingBox();
          newNodes.forEach((n, i) => {
            const x = (isFinite(bb.x2) ? bb.x2 : 400) + 200 + (i * 170);
            const y = (isFinite(bb.y1) ? bb.y1 : 300) + (i % 3) * 120;
            n.position({ x, y });

            // Save immediately
            const pos = loadPositions();
            pos[n.id()] = { x, y };
            savePositions(pos);
            savedPositions.current = pos;
          });
        }
      }
    }

    prevNodeCount.current = currentCount;

    // Rebuild style
    cy.style(buildStyle(violationSet));

  }, [nodes, edges, allViolations.length]);

  // ── Edge source highlight ─────────────────────────────
  useEffect(() => {
    const cy = cyRef.current;
    if (!cy) return;
    cy.nodes().removeClass("edge-source");
    if (edgeMode && edgeSourceId) {
      cy.getElementById(edgeSourceId).addClass("edge-source");
    }
  }, [edgeMode, edgeSourceId]);

  return (
    <div style={{ width: "100%", height: "100%", position: "relative", background: "#08080f" }}>
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `
          linear-gradient(rgba(255,255,255,0.025) 1px, transparent 1px),
          linear-gradient(90deg, rgba(255,255,255,0.025) 1px, transparent 1px)
        `,
        backgroundSize: "40px 40px",
        pointerEvents: "none",
        zIndex: 0
      }} />
      <div ref={ref} style={{ width: "100%", height: "100%", position: "relative", zIndex: 1 }} />
    </div>
  );
}
