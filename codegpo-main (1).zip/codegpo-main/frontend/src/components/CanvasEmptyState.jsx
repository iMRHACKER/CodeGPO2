export default function CanvasEmptyState({ onAddComponent, onLoadTemplate }) {
  return (
    <div style={{
      position: "absolute", inset: 0,
      display: "flex", alignItems: "center",
      justifyContent: "center",
      pointerEvents: "none",
      zIndex: 10
    }}>
      <div style={{
        textAlign: "center",
        pointerEvents: "auto",
        maxWidth: "420px",
        padding: "20px"
      }}>
        {/* Icon */}
        <div style={{
          width: "64px", height: "64px",
          borderRadius: "16px",
          background: "#12122a",
          border: "1px solid #1a1a35",
          display: "flex", alignItems: "center",
          justifyContent: "center",
          fontSize: "28px",
          margin: "0 auto 20px"
        }}>
          ◈
        </div>

        {/* Heading */}
        <div style={{
          fontSize: "18px", fontWeight: "700",
          color: "#e5e5e5", marginBottom: "10px"
        }}>
          Start your architecture
        </div>

        <div style={{
          fontSize: "13px", color: "#666",
          lineHeight: "1.7", marginBottom: "28px"
        }}>
          Add components like services, databases, and APIs.
          Connect them to map your architecture and detect
          governance violations automatically.
        </div>

        {/* Actions */}
        <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
          <button
            onClick={onAddComponent}
            style={{
              background: "#7c3aed",
              border: "none",
              color: "#fff",
              padding: "11px 22px",
              borderRadius: "9px",
              cursor: "pointer",
              fontSize: "13px",
              fontWeight: "600",
              transition: "all 0.15s"
            }}
            onMouseEnter={e => e.currentTarget.style.background = "#6d28d9"}
            onMouseLeave={e => e.currentTarget.style.background = "#7c3aed"}
          >
            + Add Component
          </button>

          <button
            onClick={onLoadTemplate}
            style={{
              background: "transparent",
              border: "1px solid #22224a",
              color: "#aaa",
              padding: "11px 22px",
              borderRadius: "9px",
              cursor: "pointer",
              fontSize: "13px",
              transition: "all 0.15s"
            }}
            onMouseEnter={e => {
              e.currentTarget.style.borderColor = "#333";
              e.currentTarget.style.color = "#e5e5e5";
            }}
            onMouseLeave={e => {
              e.currentTarget.style.borderColor = "#22224a";
              e.currentTarget.style.color = "#aaa";
            }}
          >
            ⊞ Use a Template
          </button>
        </div>

        {/* How it works */}
        <div style={{
          marginTop: "32px",
          padding: "16px",
          background: "#0d0d1f",
          border: "1px solid #161632",
          borderRadius: "10px",
          textAlign: "left"
        }}>
          <div style={{
            fontSize: "11px", color: "#555",
            fontWeight: "600", textTransform: "uppercase",
            letterSpacing: "0.8px", marginBottom: "12px"
          }}>
            How it works
          </div>
          {[
            { icon: "①", text: "Add components manually, or import from GitHub" },
            { icon: "②", text: "Connect them — violations are flagged automatically" },
            { icon: "③", text: "Approve or override each violation, with a reason — permanently recorded" },
            { icon: "④", text: "Download an audit-ready PDF report in one click" }
          ].map((step, i) => (
            <div key={i} style={{
              display: "flex", alignItems: "flex-start",
              gap: "10px", marginBottom: i < 3 ? "10px" : 0
            }}>
              <span style={{
                fontSize: "13px", color: "#333",
                fontWeight: "700", flexShrink: 0, marginTop: "1px"
              }}>
                {step.icon}
              </span>
              <span style={{ fontSize: "12px", color: "#666", lineHeight: "1.5" }}>
                {step.text}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
