import { useState } from "react";

const SECTIONS = [
  {
    id: "getting-started",
    icon: "⚡",
    title: "Getting Started",
    content: [
      {
        heading: "What is CodeGPO?",
        body: "CodeGPO is an AI-powered Architecture Governance Control Plane. It validates your software architecture against governance rules before AI-generated code enters production. Think of it as a linter — but for your entire system design."
      },
      {
        heading: "Quick Start",
        steps: [
          "Create a new project from the dashboard",
          "Add components using '+ Add Component' or load a template",
          "Connect components by clicking a node then clicking another",
          "Violations are detected instantly and shown in the inspector",
          "Fix violations to improve your health score"
        ]
      },
      {
        heading: "Adding Components",
        body: "Click '+ Add Component' in the toolbar. Enter a name (e.g. 'User Service') and a type (Service, Database, API, Queue, Cache, Gateway, Worker, User, External). Components appear as nodes on the canvas."
      },
      {
        heading: "Creating Connections",
        body: "Click any node to select it — it turns orange. Then click another node to create a connection (edge) between them. The governance engine instantly evaluates the connection. Click an arrow to inspect it."
      }
    ]
  },
  {
    id: "canvas",
    icon: "🗺",
    title: "Canvas & Navigation",
    content: [
      {
        heading: "Canvas Controls",
        steps: [
          "Scroll wheel — zoom in/out",
          "Click and drag background — pan the canvas",
          "Click a node — select it (turns orange)",
          "Click selected node + click another — create connection",
          "Click an arrow — inspect the connection",
          "Right-click — context menu (coming soon)"
        ]
      },
      {
        heading: "Node Search (Ctrl+F)",
        body: "Press Ctrl+F or click '⌕ Search' to open the search modal. Search by name or filter by type (Service, Database, API, etc.). Click any result to fly the camera to that node and highlight it in orange."
      },
      {
        heading: "Export PNG",
        body: "Click '↓ Export PNG' to download the current canvas as a high-resolution image. Great for documentation, presentations, or sharing with stakeholders who don't use CodeGPO."
      }
    ]
  },
  {
    id: "governance",
    icon: "🛡",
    title: "Governance Rules",
    content: [
      {
        heading: "Built-in Rules",
        body: "CodeGPO ships with 128+ governance rules across major compliance frameworks — GDPR, HIPAA, PCI-DSS, SOC2, DPDP Act 2023, RBI CSF, CERT-In, OWASP API Top 10, ISO 42001, ISO 27001, ISO 22301, SEBI CSCRF, IRDAI, Zero Trust, EU AI Act, MAS TRM, APRA, SOX, FedRAMP, NIST CSF, CIS Controls, NIS2, IT Act 2000, and CCPA. Rules are evaluated in real-time as you design your architecture, and new rules are added continuously."
      },
      {
        heading: "Rule: GOV-001 (Critical)",
        body: "Client → Database: Clients must never access databases directly. All data access must go through an API or Service layer to enforce security and abstraction."
      },
      {
        heading: "Rule: GOV-002 (High)",
        body: "Client → Queue: Clients cannot push directly to message queues. Messages must be published through a Service to maintain control and validation."
      },
      {
        heading: "Rule: GOV-003 (High)",
        body: "Database → outbound calls: Databases should be passive stores only. They must not initiate calls to Services, APIs, or external systems."
      },
      {
        heading: "Rule: GOV-004 (Critical)",
        body: "Gateway → Database: API Gateways must not query databases directly. Gateways should only route requests to Services."
      },
      {
        heading: "Rule: GOV-005 (Critical)",
        body: "External → Database: External third-party services must never have direct access to internal databases. This is a critical security boundary."
      },
      {
        heading: "Rule: GOV-006 (High)",
        body: "External → Queue: External services cannot write directly to internal queues. All external input must pass through a controlled Service."
      },
      {
        heading: "Rule: GOV-007 (Medium)",
        body: "Client → External: Clients should not call external services (e.g. Stripe, Twilio) directly. API keys would be exposed. Route through a backend Service."
      },
      {
        heading: "Rule: GOV-008 (Medium)",
        body: "Client → Cache: Clients must not access cache layers directly. Cache is an internal performance optimization, not a public interface."
      },
      {
        heading: "Custom Rules",
        body: "Click 'Rules' in the toolbar to open the Rules Panel. Click '+ Add Rule' to create your own governance rule. Set a source type, target type, severity level (Critical/High/Medium/Low), and a custom message. Custom rules are saved locally and persist between sessions."
      }
    ]
  },
  {
    id: "severity",
    icon: "🔴",
    title: "Violation Severity",
    content: [
      {
        heading: "Severity Levels",
        body: "Each violation has a severity level that reflects its impact on your architecture's security and quality."
      },
      {
        heading: "Critical (Red) — -20pts",
        body: "Immediate security or architectural danger. Examples: client accessing database directly, external service accessing internal database. Must be fixed before production."
      },
      {
        heading: "High (Orange) — -12pts",
        body: "Significant architectural concern that could lead to security issues or scaling problems. Should be fixed soon."
      },
      {
        heading: "Medium (Yellow) — -6pts",
        body: "Best practice violation that could cause maintainability or security issues over time. Plan to fix."
      },
      {
        heading: "Low (Blue) — -3pts",
        body: "Minor concern or code quality issue. Fix when convenient. Custom rules default to this level."
      }
    ]
  },
  {
    id: "score",
    icon: "📊",
    title: "Health Score",
    content: [
      {
        heading: "Architecture Health Score",
        body: "Your architecture gets a score from 0-100 based on violations and good practices. Click the score widget in the toolbar to see the full breakdown."
      },
      {
        heading: "Score Grades",
        steps: [
          "A (90-100) — Excellent architecture",
          "B (80-89) — Good with minor issues",
          "C (70-79) — Acceptable but needs work",
          "D (55-69) — Significant problems",
          "F (0-54) — Critical issues present"
        ]
      },
      {
        heading: "Deductions",
        body: "Each violation deducts points based on severity: Critical -20pts, High -12pts, Medium -6pts, Low -3pts. Multiple violations stack."
      },
      {
        heading: "Bonuses",
        steps: [
          "+8pts — No direct client-to-database connections",
          "+6pts — External services are properly isolated",
          "+5pts — API Gateway present in architecture",
          "+5pts — Service layer present",
          "+5pts — Async messaging (Queue) present",
          "+3pts — Caching layer present",
          "+3pts — Background workers present"
        ]
      }
    ]
  },
  {
    id: "templates",
    icon: "⊞",
    title: "Architecture Templates",
    content: [
      {
        heading: "Pre-built Templates",
        body: "Click '⊞ Templates' to open the Template Gallery. Choose from 6 professionally designed architecture templates to get started quickly."
      },
      {
        heading: "Available Templates",
        steps: [
          "E-Commerce Platform — 16 components, full shopping architecture",
          "Microservices App — 14 components, event-driven microservices",
          "Serverless Architecture — 12 components, AWS Lambda based",
          "Banking / Fintech App — 17 components, security-first design",
          "Simple REST API — 8 components, perfect starter template",
          "Real-time Chat App — 12 components, WebSocket architecture"
        ]
      },
      {
        heading: "Loading a Template",
        body: "Hover over a template to preview its components and health score. Click 'Load →' to replace your current canvas with the template. The template is automatically saved to your active project."
      }
    ]
  },
  {
    id: "diff",
    icon: "⊕",
    title: "Architecture Diff",
    content: [
      {
        heading: "What is Diff?",
        body: "Architecture Diff lets you save snapshots of your architecture at any point in time and compare them to see exactly what changed — like Git but for architecture diagrams."
      },
      {
        heading: "Saving a Snapshot",
        body: "Click '⊕ Diff / Snapshots' → enter a label (e.g. 'Before refactor', 'v1.2', 'Sprint 3') → click 'Save Snapshot'. Up to 20 snapshots are stored per project."
      },
      {
        heading: "Comparing Snapshots",
        body: "Select any saved snapshot from the list to instantly see a diff. The diff shows: added components (green), removed components (red), changed components (yellow), new connections, removed connections, new violations, and fixed violations."
      },
      {
        heading: "Use Cases",
        steps: [
          "Track architecture evolution over time",
          "Review changes before a sprint demo",
          "Verify that a refactor fixed violations",
          "Compare before/after a major redesign",
          "Document architecture decisions"
        ]
      }
    ]
  },
  {
    id: "share",
    icon: "⤴",
    title: "Share Architecture",
    content: [
      {
        heading: "Shareable Links",
        body: "Click '⤴ Share Link' to generate a read-only URL of your architecture. Anyone with the link can view your full architecture, components, connections, violations, and health score — no login required."
      },
      {
        heading: "How it Works",
        body: "The entire architecture is encoded directly into the URL using base64. No server is needed — the link works forever and never expires. Recipients see a beautiful read-only view."
      },
      {
        heading: "Share Via",
        steps: [
          "Copy link — paste anywhere",
          "Email — opens your mail client with the link",
          "Slack — copies a formatted Slack message",
          "Twitter/X — opens tweet composer"
        ]
      },
      {
        heading: "Large Architectures",
        body: "Very large architectures (20+ components) may produce long URLs. Some platforms truncate long URLs. In that case, use the Compliance PDF export instead for sharing."
      }
    ]
  },
  {
    id: "alerts",
    icon: "🔔",
    title: "Violation Alerts",
    content: [
      {
        heading: "Slack Alerts",
        body: "CodeGPO can send real-time alerts to Slack whenever new violations are detected. Click '🔔 Alert Settings' → Slack tab → paste your Incoming Webhook URL → enable."
      },
      {
        heading: "Setting up Slack",
        steps: [
          "Go to api.slack.com/apps",
          "Create new app → From scratch",
          "Enable Incoming Webhooks",
          "Add New Webhook to Workspace",
          "Select your channel and copy the URL",
          "Paste in CodeGPO Alert Settings → Test"
        ]
      },
      {
        heading: "Alert Rules",
        body: "Configure which severity levels trigger alerts. By default Critical and High violations trigger alerts. You can enable Medium and Low as well, or switch to digest mode for a daily summary."
      },
      {
        heading: "Alert History",
        body: "The History tab in Alert Settings shows all alerts sent, with timestamp, violation count, and whether they succeeded or failed."
      },
      {
        heading: "Email Alerts",
        body: "Email alerts require a backend service (FastAPI + SendGrid/SMTP). Configure your email address in the Email tab — the config is saved and ready to wire up to your backend."
      }
    ]
  },
  {
    id: "collab",
    icon: "⟳",
    title: "Real-time Collaboration",
    content: [
      {
        heading: "Live Collaboration",
        body: "Multiple team members can edit the same architecture simultaneously, like Figma. Changes sync instantly — add a node and everyone in the room sees it appear in real time."
      },
      {
        heading: "Starting the Collab Server",
        body: "Real-time collaboration works instantly — no local server needed. Click 'Live Collab' in the sidebar, create a room, and share the Room ID with your team. Available on Enterprise plan."
      },
      {
        heading: "Joining a Room",
        steps: [
          "Click '⟳ Live Collab' in toolbar",
          "Enter your name",
          "Enter a room ID (e.g. 'team-alpha')",
          "Click 'Join Room'",
          "Share the room ID with teammates",
          "They follow the same steps to join"
        ]
      },
      {
        heading: "Live Cursors",
        body: "Once connected you'll see colored cursor dots for every other user in the room, with their name attached. Move your mouse and teammates see your cursor move in real time."
      },
      {
        heading: "Sync Controls",
        body: "Click '↺ Push My Canvas to Everyone' to force-sync your current canvas to all users in the room. Useful if someone joined after you already built the architecture."
      }
    ]
  },
  {
    id: "vscode",
    icon: "💻",
    title: "VS Code Extension",
    content: [
      {
        heading: "What it Does",
        body: "The CodeGPO VS Code extension scans your open project files, detects architecture components automatically, evaluates governance violations, and shows them as red/yellow underlines directly in your code — like ESLint but for architecture."
      },
      {
        heading: "Installing",
        steps: [
          "Package: cd vscode-extension then npx vsce package",
          "In VS Code: Ctrl+Shift+X → Extensions",
          "Click '...' menu → Install from VSIX",
          "Select codegpo-0.1.0.vsix",
          "Reload VS Code"
        ]
      },
      {
        heading: "Using the Extension",
        steps: [
          "Open any project folder in VS Code",
          "Extension auto-scans after 1.5 seconds",
          "See health score in the bottom status bar",
          "Click shield icon in activity bar for sidebar",
          "Violations panel — click to jump to file",
          "Components panel — all detected components",
          "Ctrl+Shift+P → 'CodeGPO: Scan' to rescan"
        ]
      },
      {
        heading: "Auto-scan on Save",
        body: "Every time you save a file, CodeGPO automatically re-scans the workspace after a 2-second delay. The status bar and diagnostics update instantly."
      },
      {
        heading: "Settings",
        steps: [
          "codegpo.serverUrl — your CodeGPO URL (default: localhost:5173)",
          "codegpo.autoScan — enable/disable auto-scan on save",
          "codegpo.scanDelay — delay before auto-scan triggers (ms)"
        ]
      }
    ]
  },
  {
    id: "import",
    icon: "↑",
    title: "Import & Scan",
    content: [
      {
        heading: "Upload ZIP",
        body: "Click 'Upload Project' in the Import section. Select a ZIP file of your project. CodeGPO scans the files, detects components and connections, and builds the architecture graph automatically."
      },
      {
        heading: "GitHub URL",
        body: "Paste a GitHub repository URL. CodeGPO fetches and scans the repository, building the architecture from the codebase. Works with public repositories."
      },
      {
        heading: "What Gets Detected",
        steps: [
          "Services — Express, FastAPI, Flask, Spring Boot, Gin",
          "Databases — MongoDB, PostgreSQL, MySQL, Redis, Neo4j, SQLite",
          "Queues — Kafka, RabbitMQ, SQS, Bull/BullMQ, Celery",
          "Caches — Redis, Memcached, node-cache, LRU Cache",
          "Gateways — Nginx, Kong, Traefik, http-proxy",
          "Workers — Cron jobs, scheduled tasks, background processors",
          "External — Stripe, SendGrid, Twilio, AWS S3, Firebase"
        ]
      }
    ]
  },
  {
    id: "ai",
    icon: "✦",
    title: "AI Analysis",
    content: [
      {
        heading: "Architecture Explainer",
        body: "Click '✦ Explain Architecture' to open the AI panel. CodeGPO uses Ollama (local LLM) to analyze your architecture and generate a plain-English explanation of what it does, how it works, and what the violations mean."
      },
      {
        heading: "What Ollama Does",
        body: "Ollama runs AI models locally on your machine — no data leaves your computer. CodeGPO sends your architecture graph to Ollama and gets back a detailed architectural analysis and recommendations."
      },
      {
        heading: "Setting up Ollama",
        steps: [
          "Download Ollama from ollama.ai",
          "Install and run: ollama serve",
          "Pull a model: ollama pull llama3",
          "CodeGPO auto-connects to localhost:11434"
        ]
      },
      {
        heading: "Explanation History",
        body: "Every explanation is saved in the AI panel history. Scroll back to compare how Ollama described your architecture at different stages of design."
      }
    ]
  },
  {
    id: "reports",
    icon: "📄",
    title: "Reports & Export",
    content: [
      {
        heading: "Compliance PDF",
        body: "Click '↓ Compliance PDF' to generate a professional PDF report. The report includes your project name, all components, all connections, every violation with its rule ID and severity, and your health score."
      },
      {
        heading: "Export PNG",
        body: "Click '↓ Export PNG' to download a high-resolution image of your architecture canvas. Perfect for documentation, slide decks, or sharing with non-technical stakeholders."
      },
      {
        heading: "Audit Log",
        body: "Click 'Audit Log' to see a full history of all actions taken — nodes added, edges created, rules changed, files scanned, reports generated. Useful for compliance and team accountability."
      },
      {
        heading: "Share Link",
        body: "Use '⤴ Share Link' for a live read-only web view instead of a static image. Recipients can see the full interactive architecture with violation details."
      }
    ]
  },
  {
    id: "projects",
    icon: "📁",
    title: "Projects",
    content: [
      {
        heading: "Multi-Project Support",
        body: "CodeGPO supports multiple projects. From the dashboard you can create, open, rename, and delete projects. Each project has its own architecture graph, history, and snapshots."
      },
      {
        heading: "Saving",
        body: "Your architecture auto-saves to localStorage whenever you make changes. Click '↑ Save to Neo4j' to persist to the Neo4j database for team sharing and backup."
      },
      {
        heading: "Loading from Neo4j",
        body: "Click '↓ Load from Neo4j' to restore your architecture from the database. Requires the FastAPI backend running on localhost:8000."
      },
      {
        heading: "Switching Projects",
        body: "Click '← All Projects' to return to the dashboard. Your current architecture is auto-saved before navigating away. Select any project card to open it."
      }
    ]
  }
];

function Section({ section, isOpen, onToggle }) {
  return (
    <div style={{
      border: "1px solid #1a1a35",
      borderRadius: "10px",
      overflow: "hidden",
      marginBottom: "6px"
    }}>
      <button
        onClick={onToggle}
        style={{
          width: "100%",
          background: isOpen ? "#161632" : "#12122a",
          border: "none",
          padding: "13px 16px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          cursor: "pointer",
          transition: "background 0.15s"
        }}
        onMouseEnter={e => { if (!isOpen) e.currentTarget.style.background = "#141414"; }}
        onMouseLeave={e => { if (!isOpen) e.currentTarget.style.background = "#12122a"; }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <span style={{ fontSize: "16px" }}>{section.icon}</span>
          <span style={{ fontSize: "13px", fontWeight: "600", color: "#e5e5e5" }}>
            {section.title}
          </span>
        </div>
        <span style={{ color: "#444", fontSize: "14px", fontWeight: "300" }}>
          {isOpen ? "−" : "+"}
        </span>
      </button>

      {isOpen && (
        <div style={{ padding: "16px", background: "#0d0d1f" }}>
          {section.content.map((item, i) => (
            <div key={i} style={{
              marginBottom: i < section.content.length - 1 ? "18px" : 0,
              paddingBottom: i < section.content.length - 1 ? "18px" : 0,
              borderBottom: i < section.content.length - 1 ? "1px solid #141414" : "none"
            }}>
              <div style={{
                fontSize: "11px",
                fontWeight: "700",
                color: "#888",
                textTransform: "uppercase",
                letterSpacing: "0.5px",
                marginBottom: "7px"
              }}>
                {item.heading}
              </div>

              {item.body && (
                <p style={{
                  fontSize: "12px",
                  color: "#999",
                  lineHeight: "1.75",
                  margin: 0
                }}>
                  {item.body}
                </p>
              )}

              {item.steps && (
                <div style={{ display: "flex", flexDirection: "column", gap: "5px" }}>
                  {item.steps.map((step, j) => (
                    <div key={j} style={{
                      display: "flex",
                      gap: "8px",
                      fontSize: "12px",
                      color: "#999",
                      lineHeight: "1.6"
                    }}>
                      <span style={{
                        color: "#444",
                        minWidth: "16px",
                        fontWeight: "600",
                        flexShrink: 0
                      }}>
                        {j + 1}.
                      </span>
                      {step}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function UserGuide({ onClose }) {
  const [openSection, setOpenSection] = useState("getting-started");
  const [search, setSearch] = useState("");

  const filtered = search.trim()
    ? SECTIONS.filter(s =>
        s.title.toLowerCase().includes(search.toLowerCase()) ||
        s.content.some(c =>
          c.heading.toLowerCase().includes(search.toLowerCase()) ||
          (c.body && c.body.toLowerCase().includes(search.toLowerCase())) ||
          (c.steps && c.steps.some(step => step.toLowerCase().includes(search.toLowerCase())))
        )
      )
    : SECTIONS;

  return (
    <div style={{
      position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
      background: "rgba(0,0,0,0.8)",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 1000, padding: "20px"
    }}>
      <div style={{
        background: "#0d0d1f",
        border: "1px solid #22224a",
        borderRadius: "14px",
        width: "620px",
        maxHeight: "88vh",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden"
      }}>

        {/* Header */}
        <div style={{
          padding: "20px 22px 16px",
          borderBottom: "1px solid #202020",
          flexShrink: 0
        }}>
          <div style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
            marginBottom: "14px"
          }}>
            <div>
              <h2 style={{
                color: "#e5e5e5", margin: "0 0 4px",
                fontSize: "15px", fontWeight: "700"
              }}>
                ⚡ CodeGPO User Guide
              </h2>
              <p style={{ color: "#555", fontSize: "11px", margin: 0 }}>
                {SECTIONS.length} sections · All features documented
              </p>
            </div>
            <button onClick={onClose} style={{
              background: "transparent", border: "none",
              color: "#555", cursor: "pointer", fontSize: "20px",
              lineHeight: 1
            }}>×</button>
          </div>

          {/* Search */}
          <div style={{ position: "relative" }}>
            <span style={{
              position: "absolute", left: "10px", top: "50%",
              transform: "translateY(-50%)",
              fontSize: "12px", color: "#444"
            }}>⌕</span>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search guide..."
              style={{
                width: "100%", padding: "8px 12px 8px 28px",
                background: "#0d0d1f", border: "1px solid #22224a",
                color: "#e5e5e5", borderRadius: "8px",
                fontSize: "12px", outline: "none",
                boxSizing: "border-box"
              }}
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                style={{
                  position: "absolute", right: "8px", top: "50%",
                  transform: "translateY(-50%)",
                  background: "transparent", border: "none",
                  color: "#444", cursor: "pointer", fontSize: "14px"
                }}
              >×</button>
            )}
          </div>
        </div>

        {/* Quick nav pills */}
        {!search && (
          <div style={{
            padding: "10px 16px",
            borderBottom: "1px solid #161632",
            display: "flex", gap: "6px",
            flexWrap: "wrap", flexShrink: 0,
            background: "#12122a"
          }}>
            {SECTIONS.map(s => (
              <button
                key={s.id}
                onClick={() => setOpenSection(openSection === s.id ? null : s.id)}
                style={{
                  background: openSection === s.id ? "#1a1a35" : "transparent",
                  border: "1px solid " + (openSection === s.id ? "#2a2a55" : "#161632"),
                  color: openSection === s.id ? "#ccc" : "#555",
                  padding: "3px 10px", borderRadius: "20px",
                  cursor: "pointer", fontSize: "10px",
                  transition: "all 0.15s", fontWeight: "500"
                }}
                onMouseEnter={e => { if (openSection !== s.id) e.currentTarget.style.color = "#888"; }}
                onMouseLeave={e => { if (openSection !== s.id) e.currentTarget.style.color = "#555"; }}
              >
                {s.icon} {s.title}
              </button>
            ))}
          </div>
        )}

        {/* Content */}
        <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px" }}>
          {filtered.length === 0 && (
            <div style={{
              textAlign: "center", padding: "40px",
              color: "#444", fontSize: "13px"
            }}>
              No results for "{search}"
            </div>
          )}

          {filtered.map(section => (
            <Section
              key={section.id}
              section={section}
              isOpen={search ? true : openSection === section.id}
              onToggle={() => setOpenSection(
                openSection === section.id ? null : section.id
              )}
            />
          ))}
        </div>

        {/* Footer */}
        <div style={{
          padding: "12px 20px",
          borderTop: "1px solid #161632",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexShrink: 0,
          background: "#12122a"
        }}>
          <span style={{ fontSize: "11px", color: "#333" }}>
            CodeGPO — 672 rules · 26 frameworks · Live
          </span>
          <button
            onClick={onClose}
            style={{
              background: "#1a1a35", border: "1px solid #2a2a55",
              color: "#888", padding: "6px 16px",
              borderRadius: "6px", cursor: "pointer",
              fontSize: "12px", transition: "all 0.15s"
            }}
            onMouseEnter={e => e.currentTarget.style.color = "#ccc"}
            onMouseLeave={e => e.currentTarget.style.color = "#888"}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
