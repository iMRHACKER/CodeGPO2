import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

export function generateComplianceReport({ project, nodes, edges, allViolations, customRules }) {
  const doc = new jsPDF();
  const now = new Date();
  const dateStr = now.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  const timeStr = now.toLocaleTimeString("en-US");

  const DARK = [15, 23, 42];
  const CYAN = [0, 240, 255];
  const RED = [220, 38, 38];
  const GREEN = [34, 197, 94];
  const PURPLE = [124, 58, 237];
  const GRAY = [100, 116, 139];
  const WHITE = [255, 255, 255];
  const LIGHT = [226, 232, 240];

  // ── Cover / Header ───────────────────────────────────────────
  doc.setFillColor(...DARK);
  doc.rect(0, 0, 210, 50, "F");

  doc.setTextColor(...CYAN);
  doc.setFontSize(22);
  doc.setFont("helvetica", "bold");
  doc.text("⚡ CodeGPO", 14, 20);

  doc.setTextColor(...LIGHT);
  doc.setFontSize(11);
  doc.setFont("helvetica", "normal");
  doc.text("Architecture Governance Compliance Report", 14, 30);

  doc.setTextColor(...GRAY);
  doc.setFontSize(9);
  doc.text(`Generated: ${dateStr} at ${timeStr}`, 14, 40);

  // ── Project info ─────────────────────────────────────────────
  doc.setFillColor(20, 30, 50);
  doc.rect(0, 50, 210, 28, "F");

  doc.setTextColor(...LIGHT);
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.text(project?.name || "Untitled Project", 14, 63);

  if (project?.description) {
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...GRAY);
    doc.text(project.description, 14, 72);
  }

  // ── Summary boxes ────────────────────────────────────────────
  let y = 90;

  const boxes = [
    { label: "Components", value: nodes.length, color: CYAN },
    { label: "Connections", value: edges.length, color: PURPLE },
    { label: "Violations", value: allViolations.length, color: allViolations.length > 0 ? RED : GREEN },
    { label: "Custom Rules", value: customRules.filter(r => r.enabled).length, color: PURPLE },
    { label: "Status", value: allViolations.length === 0 ? "COMPLIANT" : "VIOLATIONS", color: allViolations.length === 0 ? GREEN : RED },
  ];

  const boxW = 36;
  const boxH = 22;
  const boxGap = 4;
  const startX = 14;

  boxes.forEach((box, i) => {
    const x = startX + i * (boxW + boxGap);
    doc.setFillColor(20, 30, 50);
    doc.roundedRect(x, y, boxW, boxH, 3, 3, "F");
    doc.setTextColor(...box.color);
    doc.setFontSize(14);
    doc.setFont("helvetica", "bold");
    doc.text(String(box.value), x + boxW / 2, y + 11, { align: "center" });
    doc.setTextColor(...GRAY);
    doc.setFontSize(7);
    doc.setFont("helvetica", "normal");
    doc.text(box.label, x + boxW / 2, y + 18, { align: "center" });
  });

  y += 34;

  // ── Architecture Components ──────────────────────────────────
  doc.setTextColor(...CYAN);
  doc.setFontSize(11);
  doc.setFont("helvetica", "bold");
  doc.text("Architecture Components", 14, y);
  y += 6;

  autoTable(doc, {
    startY: y,
    head: [["Component Name", "Type", "Connections In", "Connections Out", "Status"]],
    body: nodes.map(node => {
      const inEdges = edges.filter(e => e.target === node.id).length;
      const outEdges = edges.filter(e => e.source === node.id).length;
      const hasViolation = allViolations.some(v => v.source === node.id || v.target === node.id);
      return [
        node.name,
        node.type,
        inEdges,
        outEdges,
        hasViolation ? "⚠ INVOLVED IN VIOLATION" : "✓ Clean"
      ];
    }),
    styles: { fontSize: 8, textColor: LIGHT, fillColor: [15, 23, 42], lineColor: [30, 41, 59] },
    headStyles: { fillColor: [20, 30, 50], textColor: CYAN, fontStyle: "bold" },
    alternateRowStyles: { fillColor: [11, 15, 26] },
    columnStyles: {
      4: {
        textColor: (cell) => cell.raw?.toString().includes("VIOLATION") ? RED : GREEN
      }
    },
    margin: { left: 14, right: 14 }
  });

  y = doc.lastAutoTable.finalY + 12;

  // ── Connections ──────────────────────────────────────────────
  if (y > 240) { doc.addPage(); y = 20; }

  doc.setTextColor(...CYAN);
  doc.setFontSize(11);
  doc.setFont("helvetica", "bold");
  doc.text("Connections", 14, y);
  y += 6;

  const nodeMap = {};
  nodes.forEach(n => { nodeMap[n.id] = n; });

  autoTable(doc, {
    startY: y,
    head: [["From", "Type", "→", "To", "Type", "Governance Status"]],
    body: edges.map(edge => {
      const source = nodeMap[edge.source];
      const target = nodeMap[edge.target];
      const violation = allViolations.find(v => v.source === edge.source && v.target === edge.target);
      return [
        source?.name || edge.source,
        source?.type || "?",
        "→",
        target?.name || edge.target,
        target?.type || "?",
        violation ? `❌ ${violation.ruleId}` : "✅ Compliant"
      ];
    }),
    styles: { fontSize: 8, textColor: LIGHT, fillColor: [15, 23, 42], lineColor: [30, 41, 59] },
    headStyles: { fillColor: [20, 30, 50], textColor: CYAN, fontStyle: "bold" },
    alternateRowStyles: { fillColor: [11, 15, 26] },
    margin: { left: 14, right: 14 }
  });

  y = doc.lastAutoTable.finalY + 12;

  // ── Violations ───────────────────────────────────────────────
  if (allViolations.length > 0) {
    if (y > 220) { doc.addPage(); y = 20; }

    doc.setTextColor(...RED);
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text(`Governance Violations (${allViolations.length})`, 14, y);
    y += 6;

    autoTable(doc, {
      startY: y,
      head: [["Rule ID", "Type", "From", "To", "Violation Message", "Recommended Fix"]],
      body: allViolations.map(v => {
        const source = nodeMap[v.source];
        const target = nodeMap[v.target];
        const fix = getRecommendedFix(v.ruleId);
        return [
          v.ruleId,
          v.custom ? "Custom" : "Built-in",
          `${source?.name || v.source} (${source?.type || "?"})`,
          `${target?.name || v.target} (${target?.type || "?"})`,
          v.message,
          fix
        ];
      }),
      styles: { fontSize: 7, textColor: LIGHT, fillColor: [15, 23, 42], lineColor: [30, 41, 59] },
      headStyles: { fillColor: [40, 10, 10], textColor: [255, 100, 100], fontStyle: "bold" },
      alternateRowStyles: { fillColor: [20, 10, 10] },
      columnStyles: {
        0: { cellWidth: 18 },
        1: { cellWidth: 16 },
        2: { cellWidth: 28 },
        3: { cellWidth: 28 },
        4: { cellWidth: 50 },
        5: { cellWidth: 42 }
      },
      margin: { left: 14, right: 14 }
    });

    y = doc.lastAutoTable.finalY + 12;
  } else {
    if (y > 240) { doc.addPage(); y = 20; }
    doc.setFillColor(10, 25, 15);
    doc.roundedRect(14, y, 182, 16, 4, 4, "F");
    doc.setTextColor(...GREEN);
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("✅ No governance violations detected — architecture is fully compliant!", 105, y + 10, { align: "center" });
    y += 24;
  }

  // ── Custom Rules summary ─────────────────────────────────────
  const enabledRules = customRules.filter(r => r.enabled);
  if (enabledRules.length > 0) {
    if (y > 220) { doc.addPage(); y = 20; }

    doc.setTextColor(...PURPLE);
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text(`Active Custom Rules (${enabledRules.length})`, 14, y);
    y += 6;

    autoTable(doc, {
      startY: y,
      head: [["Rule ID", "Source Type", "Target Type", "Message"]],
      body: enabledRules.map(r => [r.ruleId, r.sourceType, r.targetType, r.message]),
      styles: { fontSize: 8, textColor: LIGHT, fillColor: [15, 23, 42], lineColor: [30, 41, 59] },
      headStyles: { fillColor: [30, 15, 50], textColor: [180, 130, 255], fontStyle: "bold" },
      alternateRowStyles: { fillColor: [11, 15, 26] },
      margin: { left: 14, right: 14 }
    });

    y = doc.lastAutoTable.finalY + 12;
  }

  // ── Footer on every page ─────────────────────────────────────
  const totalPages = doc.internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFillColor(...DARK);
    doc.rect(0, 285, 210, 12, "F");
    doc.setTextColor(...GRAY);
    doc.setFontSize(7);
    doc.text("Generated by CodeGPO — Architecture Governance Control Plane", 14, 292);
    doc.text(`Page ${i} of ${totalPages}`, 196, 292, { align: "right" });
  }

  // ── Save ─────────────────────────────────────────────────────
  const filename = `CodeGPO_Report_${(project?.name || "Project").replace(/\s+/g, "_")}_${now.toISOString().slice(0, 10)}.pdf`;
  doc.save(filename);
}

function getRecommendedFix(ruleId) {
  const fixes = {
    "GOV-001": "Add an API or Service layer between client and database",
    "GOV-002": "Route client requests through a Service before accessing Queue",
    "GOV-003": "Remove outgoing calls from Database — use polling or events instead",
    "GOV-004": "Add a Service layer between Gateway and Database",
    "GOV-005": "Expose an internal API for external services to use",
    "GOV-006": "Route external access to Queue through an internal Service",
    "GOV-007": "Move external API calls to a backend Service",
    "GOV-008": "Access Cache through a Service layer only",
  };
  return fixes[ruleId] || "Review architecture and add appropriate service layer";
}
