import { useState } from "react";
import { useCollabStore } from "../state/collabStore";
import { useGraphStore } from "../state/graphStore";

function Avatar({ name, color, size = 28 }) {
  return (
    <div style={{
      width: size, height: size,
      borderRadius: "50%",
      background: color,
      display: "flex", alignItems: "center", justifyContent: "center",
      fontSize: size * 0.4 + "px",
      fontWeight: "700",
      color: "#fff",
      flexShrink: 0,
      border: "2px solid #0d0d1f"
    }}>
      {name ? name[0].toUpperCase() : "?"}
    </div>
  );
}

export function CollabAvatars() {
  const { connected, users, userName, userColor } = useCollabStore();
  if (!connected) return null;

  const allUsers = [
    { name: userName || "You", color: userColor, isMe: true },
    ...users.map(u => ({ ...u, isMe: false }))
  ];

  return (
    <div style={{
      display: "flex",
      alignItems: "center",
      gap: "4px",
      padding: "4px 10px",
      background: "#12122a",
      border: "1px solid #1a1a35",
      borderRadius: "20px"
    }}>
      <div style={{
        width: "6px", height: "6px",
        borderRadius: "50%",
        background: "#5a9e6f",
        marginRight: "4px"
      }} />
      <div style={{ display: "flex", marginRight: "4px" }}>
        {allUsers.slice(0, 5).map((u, i) => (
          <div key={i} style={{ marginLeft: i > 0 ? "-6px" : 0, zIndex: allUsers.length - i }}>
            <Avatar name={u.name} color={u.color || "#555"} size={24} />
          </div>
        ))}
      </div>
      <span style={{ fontSize: "11px", color: "#888" }}>
        {allUsers.length} online
      </span>
    </div>
  );
}

export function CollabCursors() {
  const { cursors } = useCollabStore();

  return (
    <>
      {Object.entries(cursors).map(([id, cursor]) => {
        if (!cursor || cursor.x == null || cursor.y == null) return null;
        return (
          <div
            key={id}
            style={{
              position: "fixed",
              left: cursor.x,
              top: cursor.y,
              pointerEvents: "none",
              zIndex: 9999,
              transform: "translate(-2px, -2px)"
            }}
          >
            <div style={{
              width: "10px", height: "10px",
              borderRadius: "50%",
              background: cursor.color,
              border: "2px solid #fff"
            }} />
            <div style={{
              position: "absolute",
              top: "12px", left: "8px",
              background: cursor.color,
              color: "#fff",
              fontSize: "11px",
              fontWeight: "600",
              padding: "2px 6px",
              borderRadius: "4px",
              whiteSpace: "nowrap",
              fontFamily: "sans-serif"
            }}>
              {cursor.name}
            </div>
          </div>
        );
      })}
    </>
  );
}

function generateRoomId() {
  const words = [
    "alpha", "beta", "delta", "gamma", "sigma",
    "phoenix", "falcon", "eagle", "titan", "nova",
    "amber", "cobalt", "ember", "frost", "jade"
  ];
  const word = words[Math.floor(Math.random() * words.length)];
  const num = Math.floor(Math.random() * 900) + 100;
  return `${word}-${num}`;
}

export default function CollabPanel({ onClose }) {
  const {
    connected, connecting, roomId, userName,
    userColor, users, join, leave,
    sendFullSync
  } = useCollabStore();

  const { nodes, edges, setGraph } = useGraphStore();

  const [mode, setMode] = useState("choose"); // choose | create | join
  const [inputRoom, setInputRoom] = useState("");
  const [inputName, setInputName] = useState(userName || "");
  const [generatedRoom] = useState(generateRoomId());
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState("");

  const handleJoin = (roomToJoin) => {
    const finalRoom = roomToJoin || inputRoom.trim();
    if (!finalRoom) { setError("Enter a room ID"); return; }
    if (!inputName.trim()) { setError("Enter your name first"); return; }
    setError("");

    join(finalRoom, inputName.trim(), (syncData) => {
      if (syncData.nodes !== undefined && syncData.edges !== undefined) {
        setGraph(syncData.nodes, syncData.edges);
      } else if (syncData.type === "node_add") {
        useGraphStore.getState().addNodeDirect(syncData.node);
      } else if (syncData.type === "node_delete") {
        useGraphStore.getState().deleteNodeById(syncData.nodeId);
      } else if (syncData.type === "edge_add") {
        useGraphStore.getState().addEdgeDirect(syncData.edge);
      } else if (syncData.type === "edge_delete") {
        useGraphStore.getState().deleteEdgeByIds(syncData.source, syncData.target);
      }
    });
  };

  const handleCopyRoomId = (id) => {
    navigator.clipboard.writeText(id).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleCopyInviteLink = (id) => {
    const msg = `Join my CodeGPO architecture session!\nRoom ID: ${id}\n\n1. Open CodeGPO\n2. Click ⟳ Live Collab\n3. Enter your name\n4. Enter room ID: ${id}\n5. Click Join Room`;
    navigator.clipboard.writeText(msg).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const allUsers = connected
    ? [
        { name: inputName || "You", color: userColor, isMe: true },
        ...users
      ]
    : [];

  // ── Name input (always shown when not connected) ──────
  const NameInput = () => (
    <div style={{ marginBottom: "16px" }}>
      <div style={{
        fontSize: "11px", color: "#777",
        textTransform: "uppercase", letterSpacing: "0.8px",
        marginBottom: "6px", fontWeight: "600"
      }}>
        Your Name
      </div>
      <input
        value={inputName}
        onChange={e => setInputName(e.target.value)}
        placeholder="e.g. Sarah, Alex, John..."
        style={{
          width: "100%", padding: "10px 12px",
          background: "#0d0d1f", border: "1px solid #22224a",
          color: "#e5e5e5", borderRadius: "8px",
          fontSize: "12px", outline: "none",
          boxSizing: "border-box"
        }}
        onFocus={e => e.target.style.borderColor = "#333"}
        onBlur={e => e.target.style.borderColor = "#22224a"}
      />
    </div>
  );

  return (
    <div style={{
      position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
      background: "rgba(0,0,0,0.8)",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 1000, padding: "20px"
    }}>
      <div style={{
        background: "#0d0d1f",
        border: "1px solid #22224a",
        borderRadius: "14px",
        width: "500px",
        maxHeight: "90vh",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden"
      }}>

        {/* Header */}
        <div style={{
          padding: "18px 22px",
          borderBottom: "1px solid #202020",
          display: "flex", justifyContent: "space-between",
          alignItems: "center", flexShrink: 0
        }}>
          <div>
            <h2 style={{ color: "#e5e5e5", margin: 0, fontSize: "14px", fontWeight: "600" }}>
              Real-time Collaboration
            </h2>
            <p style={{ color: "#777", fontSize: "11px", margin: "4px 0 0" }}>
              Work on architectures together, live
            </p>
          </div>
          <button onClick={onClose} style={{
            background: "transparent", border: "none",
            color: "#666", cursor: "pointer", fontSize: "20px"
          }}>×</button>
        </div>

        <div style={{ flex: 1, overflowY: "auto", padding: "20px" }}>

          {/* ── CONNECTED STATE ─────────────────────── */}
          {connected && (
            <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>

              {/* Status */}
              <div style={{
                display: "flex", alignItems: "center", gap: "8px",
                padding: "12px 14px",
                background: "#0f1a12",
                border: "1px solid #1a2e1e",
                borderRadius: "8px"
              }}>
                <div style={{
                  width: "8px", height: "8px", borderRadius: "50%",
                  background: "#5a9e6f", flexShrink: 0
                }} />
                <span style={{ fontSize: "12px", color: "#5a9e6f", fontWeight: "500" }}>
                  Connected to room
                </span>
                <span style={{
                  fontFamily: "monospace", fontSize: "12px",
                  color: "#e5e5e5", fontWeight: "700",
                  background: "#12122a", padding: "2px 8px",
                  borderRadius: "4px", border: "1px solid #1a1a35"
                }}>
                  {roomId}
                </span>
              </div>

              {/* Online users */}
              <div>
                <div style={{
                  fontSize: "11px", color: "#777",
                  textTransform: "uppercase", letterSpacing: "0.8px",
                  marginBottom: "10px", fontWeight: "600"
                }}>
                  Online ({allUsers.length})
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  {allUsers.map((u, i) => (
                    <div key={i} style={{
                      display: "flex", alignItems: "center",
                      gap: "10px", padding: "10px 12px",
                      background: "#12122a",
                      border: "1px solid #1a1a35",
                      borderRadius: "8px"
                    }}>
                      <div style={{
                        width: "30px", height: "30px",
                        borderRadius: "50%",
                        background: u.color || "#555",
                        display: "flex", alignItems: "center",
                        justifyContent: "center",
                        fontSize: "13px", fontWeight: "700",
                        color: "#fff", flexShrink: 0
                      }}>
                        {u.name ? u.name[0].toUpperCase() : "?"}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: "13px", color: "#e5e5e5", fontWeight: "500" }}>
                          {u.name}
                          {u.isMe && (
                            <span style={{ fontSize: "11px", color: "#666", marginLeft: "6px" }}>
                              (you)
                            </span>
                          )}
                        </div>
                      </div>
                      <div style={{
                        width: "7px", height: "7px",
                        borderRadius: "50%", background: "#5a9e6f"
                      }} />
                    </div>
                  ))}

                  {allUsers.length === 1 && (
                    <div style={{
                      padding: "12px",
                      background: "#12122a",
                      border: "1px dashed #1a1a35",
                      borderRadius: "8px",
                      textAlign: "center",
                      fontSize: "12px", color: "#666"
                    }}>
                      Waiting for teammates to join...
                    </div>
                  )}
                </div>
              </div>

              {/* Invite section */}
              <div style={{
                padding: "14px",
                background: "#12122a",
                border: "1px solid #1a1a35",
                borderRadius: "10px"
              }}>
                <div style={{
                  fontSize: "11px", color: "#777",
                  textTransform: "uppercase", letterSpacing: "0.8px",
                  marginBottom: "10px", fontWeight: "600"
                }}>
                  Invite Teammates
                </div>
                <div style={{ fontSize: "12px", color: "#888", marginBottom: "10px" }}>
                  Share this room ID with your team:
                </div>
                <div style={{
                  display: "flex", gap: "8px", alignItems: "center",
                  padding: "10px 12px",
                  background: "#0d0d1f",
                  border: "1px solid #22224a",
                  borderRadius: "8px",
                  marginBottom: "10px"
                }}>
                  <span style={{
                    fontFamily: "monospace", fontSize: "16px",
                    fontWeight: "700", color: "#e5e5e5", flex: 1,
                    letterSpacing: "1px"
                  }}>
                    {roomId}
                  </span>
                  <button
                    onClick={() => handleCopyRoomId(roomId)}
                    style={{
                      background: copied ? "#0f1a12" : "#1a1a35",
                      border: "1px solid " + (copied ? "#1a2e1e" : "#2a2a55"),
                      color: copied ? "#5a9e6f" : "#aaa",
                      padding: "5px 12px", borderRadius: "6px",
                      cursor: "pointer", fontSize: "11px",
                      fontWeight: "600", transition: "all 0.2s",
                      flexShrink: 0
                    }}
                  >
                    {copied ? "✓ Copied!" : "Copy ID"}
                  </button>
                </div>
                <button
                  onClick={() => handleCopyInviteLink(roomId)}
                  style={{
                    width: "100%",
                    background: "transparent",
                    border: "1px solid #22224a",
                    color: "#888", padding: "8px",
                    borderRadius: "8px", cursor: "pointer",
                    fontSize: "12px", transition: "all 0.15s"
                  }}
                  onMouseEnter={e => { e.currentTarget.style.color = "#ccc"; e.currentTarget.style.borderColor = "#333"; }}
                  onMouseLeave={e => { e.currentTarget.style.color = "#888"; e.currentTarget.style.borderColor = "#22224a"; }}
                >
                  Copy Invite Message
                </button>

                <div style={{
                  marginTop: "12px",
                  padding: "10px 12px",
                  background: "#0d0d1f",
                  border: "1px solid #161632",
                  borderRadius: "8px",
                  fontSize: "11px", color: "#666",
                  lineHeight: "1.8"
                }}>
                  They need to:
                  <br />1. Open CodeGPO → click ⟳ Live Collab
                  <br />2. Enter their name
                  <br />3. Enter room ID: <span style={{ color: "#aaa", fontFamily: "monospace" }}>{roomId}</span>
                  <br />4. Click Join Room
                </div>
              </div>

              {/* Sync + Leave */}
              <button
                onClick={() => sendFullSync(nodes, edges)}
                style={{
                  background: "transparent",
                  border: "1px solid #22224a",
                  color: "#888", padding: "9px",
                  borderRadius: "8px", cursor: "pointer",
                  fontSize: "12px", transition: "all 0.15s"
                }}
                onMouseEnter={e => { e.currentTarget.style.color = "#ccc"; e.currentTarget.style.borderColor = "#333"; }}
                onMouseLeave={e => { e.currentTarget.style.color = "#888"; e.currentTarget.style.borderColor = "#22224a"; }}
              >
                ↺ Push My Canvas to Everyone
              </button>

              <button
                onClick={leave}
                style={{
                  background: "transparent",
                  border: "1px solid #2a1515",
                  color: "#854444", padding: "9px",
                  borderRadius: "8px", cursor: "pointer",
                  fontSize: "12px", transition: "all 0.15s"
                }}
                onMouseEnter={e => { e.currentTarget.style.background = "#1a1010"; e.currentTarget.style.color = "#cc6666"; }}
                onMouseLeave={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "#854444"; }}
              >
                Leave Room
              </button>
            </div>
          )}

          {/* ── CONNECTING STATE ────────────────────── */}
          {connecting && !connected && (
            <div style={{
              display: "flex", flexDirection: "column",
              alignItems: "center", justifyContent: "center",
              padding: "40px 20px", gap: "14px"
            }}>
              <div style={{
                width: "28px", height: "28px",
                border: "2px solid #22224a",
                borderTop: "2px solid #5a9e6f",
                borderRadius: "50%",
                animation: "spin 0.8s linear infinite"
              }} />
              <style>{"@keyframes spin { to { transform: rotate(360deg); } }"}</style>
              <div style={{ fontSize: "13px", color: "#888" }}>Connecting to room...</div>
              <div style={{ fontSize: "11px", color: "#666" }}>
                Make sure the collab server is running
              </div>
              <button
                onClick={leave}
                style={{
                  background: "transparent", border: "1px solid #22224a",
                  color: "#666", padding: "7px 16px",
                  borderRadius: "6px", cursor: "pointer", fontSize: "12px"
                }}
              >
                Cancel
              </button>
            </div>
          )}

          {/* ── NOT CONNECTED — CHOOSE MODE ─────────── */}
          {!connected && !connecting && mode === "choose" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>

              <NameInput />

              <div style={{
                fontSize: "11px", color: "#777",
                textTransform: "uppercase", letterSpacing: "0.8px",
                marginBottom: "4px", fontWeight: "600"
              }}>
                What do you want to do?
              </div>

              {/* Create Room card */}
              <button
                onClick={() => setMode("create")}
                style={{
                  background: "#12122a",
                  border: "1px solid #1a1a35",
                  borderRadius: "10px",
                  padding: "18px 16px",
                  cursor: "pointer",
                  textAlign: "left",
                  transition: "all 0.15s",
                  width: "100%"
                }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = "#2a2a55"; e.currentTarget.style.background = "#141414"; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = "#1a1a35"; e.currentTarget.style.background = "#12122a"; }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                  <div style={{
                    width: "40px", height: "40px",
                    borderRadius: "10px",
                    background: "#0f1a12",
                    border: "1px solid #1a2e1e",
                    display: "flex", alignItems: "center",
                    justifyContent: "center",
                    fontSize: "18px", flexShrink: 0
                  }}>
                    ✦
                  </div>
                  <div>
                    <div style={{ fontSize: "13px", fontWeight: "600", color: "#e5e5e5", marginBottom: "4px" }}>
                      Create a Room
                    </div>
                    <div style={{ fontSize: "11px", color: "#777", lineHeight: "1.5" }}>
                      Start a new session. Share the room ID with teammates so they can join.
                    </div>
                  </div>
                  <div style={{ color: "#444", fontSize: "16px", marginLeft: "auto", flexShrink: 0 }}>
                    →
                  </div>
                </div>
              </button>

              {/* Join Room card */}
              <button
                onClick={() => setMode("join")}
                style={{
                  background: "#12122a",
                  border: "1px solid #1a1a35",
                  borderRadius: "10px",
                  padding: "18px 16px",
                  cursor: "pointer",
                  textAlign: "left",
                  transition: "all 0.15s",
                  width: "100%"
                }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = "#2a2a55"; e.currentTarget.style.background = "#141414"; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = "#1a1a35"; e.currentTarget.style.background = "#12122a"; }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                  <div style={{
                    width: "40px", height: "40px",
                    borderRadius: "10px",
                    background: "#111020",
                    border: "1px solid #1e1e2e",
                    display: "flex", alignItems: "center",
                    justifyContent: "center",
                    fontSize: "18px", flexShrink: 0
                  }}>
                    ⟳
                  </div>
                  <div>
                    <div style={{ fontSize: "13px", fontWeight: "600", color: "#e5e5e5", marginBottom: "4px" }}>
                      Join a Room
                    </div>
                    <div style={{ fontSize: "11px", color: "#777", lineHeight: "1.5" }}>
                      Got a room ID from a teammate? Enter it here to join their session.
                    </div>
                  </div>
                  <div style={{ color: "#444", fontSize: "16px", marginLeft: "auto", flexShrink: 0 }}>
                    →
                  </div>
                </div>
              </button>

              {/* Server setup reminder */}
              <div style={{
                padding: "12px 14px",
                background: "#12122a",
                border: "1px solid #1a1a35",
                borderRadius: "8px",
                marginTop: "4px"
              }}>
                <div style={{
                  fontSize: "11px", color: "#777",
                  fontWeight: "600", marginBottom: "8px",
                  textTransform: "uppercase", letterSpacing: "0.8px"
                }}>
                  Before you start
                </div>
                <div style={{
                  fontFamily: "monospace",
                  fontSize: "11px", color: "#888",
                  background: "#0d0d1f",
                  border: "1px solid #161632",
                  borderRadius: "6px",
                  padding: "8px 12px",
                  lineHeight: "1.8"
                }}>
                  cd F:\CodeGPOPro\backend<br />
                  python collab_server.py
                </div>
                <div style={{ fontSize: "11px", color: "#666", marginTop: "7px" }}>
                  Run this in a separate terminal to enable collaboration
                </div>
              </div>
            </div>
          )}

          {/* ── CREATE ROOM ─────────────────────────── */}
          {!connected && !connecting && mode === "create" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>

              <button
                onClick={() => setMode("choose")}
                style={{
                  background: "transparent", border: "none",
                  color: "#666", cursor: "pointer",
                  fontSize: "12px", textAlign: "left",
                  padding: "0", display: "flex",
                  alignItems: "center", gap: "6px"
                }}
              >
                ← Back
              </button>

              <NameInput />

              <div style={{
                fontSize: "11px", color: "#777",
                textTransform: "uppercase", letterSpacing: "0.8px",
                marginBottom: "2px", fontWeight: "600"
              }}>
                Your Room ID
              </div>

              {/* Auto-generated room ID */}
              <div style={{
                padding: "16px",
                background: "#12122a",
                border: "1px solid #1a1a35",
                borderRadius: "10px"
              }}>
                <div style={{ fontSize: "11px", color: "#666", marginBottom: "10px" }}>
                  We generated a unique room ID for you:
                </div>
                <div style={{
                  display: "flex", alignItems: "center",
                  gap: "10px",
                  padding: "12px 14px",
                  background: "#0d0d1f",
                  border: "1px solid #22224a",
                  borderRadius: "8px",
                  marginBottom: "10px"
                }}>
                  <span style={{
                    fontFamily: "monospace",
                    fontSize: "18px", fontWeight: "800",
                    color: "#e5e5e5", flex: 1,
                    letterSpacing: "1px"
                  }}>
                    {generatedRoom}
                  </span>
                  <button
                    onClick={() => handleCopyRoomId(generatedRoom)}
                    style={{
                      background: copied ? "#0f1a12" : "#1a1a35",
                      border: "1px solid " + (copied ? "#1a2e1e" : "#2a2a55"),
                      color: copied ? "#5a9e6f" : "#aaa",
                      padding: "5px 12px", borderRadius: "6px",
                      cursor: "pointer", fontSize: "11px",
                      fontWeight: "600", transition: "all 0.2s",
                      flexShrink: 0
                    }}
                  >
                    {copied ? "✓ Copied!" : "Copy"}
                  </button>
                </div>
                <div style={{ fontSize: "11px", color: "#666", lineHeight: "1.7" }}>
                  Share this ID with teammates before clicking Create.
                  They'll use it to join your room.
                </div>
              </div>

              {/* Or use custom room ID */}
              <div>
                <div style={{
                  fontSize: "11px", color: "#666",
                  marginBottom: "6px"
                }}>
                  Or use a custom room ID:
                </div>
                <input
                  value={inputRoom}
                  onChange={e => setInputRoom(e.target.value)}
                  placeholder="e.g. team-alpha, project-x, sprint-3"
                  style={{
                    width: "100%", padding: "10px 12px",
                    background: "#0d0d1f", border: "1px solid #22224a",
                    color: "#e5e5e5", borderRadius: "8px",
                    fontSize: "12px", outline: "none",
                    boxSizing: "border-box"
                  }}
                  onFocus={e => e.target.style.borderColor = "#333"}
                  onBlur={e => e.target.style.borderColor = "#22224a"}
                />
              </div>

              {error && (
                <div style={{ fontSize: "12px", color: "#cc6666" }}>{error}</div>
              )}

              <button
                onClick={() => handleJoin(inputRoom.trim() || generatedRoom)}
                style={{
                  background: "#1a1a35", border: "1px solid #2a2a55",
                  color: "#e5e5e5", padding: "11px",
                  borderRadius: "8px", cursor: "pointer",
                  fontSize: "13px", fontWeight: "600",
                  transition: "all 0.15s"
                }}
                onMouseEnter={e => e.currentTarget.style.background = "#22224a"}
                onMouseLeave={e => e.currentTarget.style.background = "#1a1a35"}
              >
                ✦ Create Room & Join
              </button>
            </div>
          )}

          {/* ── JOIN ROOM ───────────────────────────── */}
          {!connected && !connecting && mode === "join" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>

              <button
                onClick={() => setMode("choose")}
                style={{
                  background: "transparent", border: "none",
                  color: "#666", cursor: "pointer",
                  fontSize: "12px", textAlign: "left",
                  padding: "0", display: "flex",
                  alignItems: "center", gap: "6px"
                }}
              >
                ← Back
              </button>

              <NameInput />

              <div>
                <div style={{
                  fontSize: "11px", color: "#777",
                  textTransform: "uppercase", letterSpacing: "0.8px",
                  marginBottom: "6px", fontWeight: "600"
                }}>
                  Room ID
                </div>
                <input
                  value={inputRoom}
                  onChange={e => setInputRoom(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && handleJoin()}
                  placeholder="Enter room ID from your teammate"
                  autoFocus
                  style={{
                    width: "100%", padding: "10px 12px",
                    background: "#0d0d1f", border: "1px solid #22224a",
                    color: "#e5e5e5", borderRadius: "8px",
                    fontSize: "13px", outline: "none",
                    boxSizing: "border-box",
                    fontFamily: "monospace", fontWeight: "600",
                    letterSpacing: "0.5px"
                  }}
                  onFocus={e => e.target.style.borderColor = "#333"}
                  onBlur={e => e.target.style.borderColor = "#22224a"}
                />
                <div style={{ fontSize: "11px", color: "#666", marginTop: "6px" }}>
                  Ask the room creator to share their room ID with you
                </div>
              </div>

              {error && (
                <div style={{ fontSize: "12px", color: "#cc6666" }}>{error}</div>
              )}

              <button
                onClick={() => handleJoin()}
                style={{
                  background: "#1a1a35", border: "1px solid #2a2a55",
                  color: "#e5e5e5", padding: "11px",
                  borderRadius: "8px", cursor: "pointer",
                  fontSize: "13px", fontWeight: "600",
                  transition: "all 0.15s"
                }}
                onMouseEnter={e => e.currentTarget.style.background = "#22224a"}
                onMouseLeave={e => e.currentTarget.style.background = "#1a1a35"}
              >
                ⟳ Join Room
              </button>

              {/* Recent rooms (could be stored in localStorage) */}
              <div style={{
                padding: "12px 14px",
                background: "#12122a",
                border: "1px solid #1a1a35",
                borderRadius: "8px"
              }}>
                <div style={{
                  fontSize: "11px", color: "#666",
                  marginBottom: "8px"
                }}>
                  Don't have a room ID yet?
                </div>
                <div style={{ fontSize: "11px", color: "#777", lineHeight: "1.7" }}>
                  Ask the person who created the session to share their room ID.
                  They can find it in the Invite Teammates section after creating a room.
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
