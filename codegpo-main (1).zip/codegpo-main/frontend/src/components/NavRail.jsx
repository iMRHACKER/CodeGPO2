function LogoMark({ size = 20 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
      <path d="M50 4 L92 27 V73 L50 96 L8 73 V27 Z" stroke="url(#logoGrad)" strokeWidth="6" />
      <circle cx="50" cy="24" r="8" stroke="url(#logoGrad)" strokeWidth="5" fill="#0a0a18" />
      <circle cx="76" cy="42" r="8" stroke="url(#logoGrad)" strokeWidth="5" fill="#0a0a18" />
      <circle cx="50" cy="76" r="8" stroke="url(#logoGrad)" strokeWidth="5" fill="#0a0a18" />
      <circle cx="24" cy="42" r="8" stroke="url(#logoGrad)" strokeWidth="5" fill="#0a0a18" />
      <path d="M50 32 L72 40 M72 48 L52 70 M48 70 L28 48 M28 40 L46 32" stroke="url(#logoGrad)" strokeWidth="4" />
      <defs>
        <linearGradient id="logoGrad" x1="0" y1="0" x2="100" y2="100">
          <stop offset="0%" stopColor="#a78bfa" />
          <stop offset="100%" stopColor="#6d28d9" />
        </linearGradient>
      </defs>
    </svg>
  );
}

const NAV_ITEMS = [
  { id: "dashboard",   icon: "▦", label: "Dashboard" },
  { id: "editor",      icon: "◫", label: "Architecture" },
  { id: "findings",    icon: "◉", label: "Findings" },
  { id: "settings",    icon: "⚙", label: "Settings" },
];

export default function NavRail({ active, onNavigate, onOpenSettings }) {
  return (
    <div style={{
      width: "84px", flexShrink: 0, background: "#0a0a18",
      borderRight: "1px solid #1a1a35", display: "flex", flexDirection: "column",
      alignItems: "center", padding: "18px 0", gap: "4px",
    }}>
      <div style={{ marginBottom: "22px" }}><LogoMark size={22} /></div>
      {NAV_ITEMS.map(item => {
        const isActive = active === item.id;
        return (
          <button
            key={item.id}
            onClick={() => item.id === "settings" ? onOpenSettings?.() : onNavigate(item.id)}
            style={{
              display: "flex", flexDirection: "column", alignItems: "center", gap: "3px",
              width: "68px", padding: "10px 4px", borderRadius: "10px", cursor: "pointer",
              background: isActive ? "#7c3aed22" : "transparent",
              border: isActive ? "1px solid #7c3aed44" : "1px solid transparent",
              color: isActive ? "#a78bfa" : "#5f5f85",
            }}
          >
            <span style={{ fontSize: "16px" }}>{item.icon}</span>
            <span style={{ fontSize: "9px", fontWeight: "600" }}>{item.label}</span>
          </button>
        );
      })}
    </div>
  );
}
