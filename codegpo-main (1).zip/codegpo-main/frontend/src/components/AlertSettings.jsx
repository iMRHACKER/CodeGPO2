import { useState } from "react";
import { useAlertStore } from "../state/alertStore";

function timeAgo(isoString) {
  const diff = Date.now() - new Date(isoString).getTime();
  const mins = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(diff / 86400000)}d ago`;
}

function Toggle({ value, onChange, label, desc }) {
  return (
    <div
      onClick={() => onChange(!value)}
      style={{
        display: "flex", alignItems: "center",
        justifyContent: "space-between",
        padding: "10px 12px",
        background: "#12122a",
        border: "1px solid #1a1a35",
        borderRadius: "8px",
        cursor: "pointer",
        transition: "border-color 0.15s"
      }}
    >
      <div>
        <div style={{ fontSize: "12.5px", color: "#ccc", fontWeight: "500" }}>{label}</div>
        {desc && <div style={{ fontSize: "10px", color: "#555", marginTop: "2px" }}>{desc}</div>}
      </div>
      <div style={{
        width: "36px", height: "20px",
        background: value ? "#5a9e6f" : "#22224a",
        border: "1px solid " + (value ? "#4a8a5f" : "#2a2a55"),
        borderRadius: "10px",
        position: "relative",
        transition: "all 0.2s",
        flexShrink: 0
      }}>
        <div style={{
          width: "14px", height: "14px",
          background: "#fff",
          borderRadius: "50%",
          position: "absolute",
          top: "2px",
          left: value ? "18px" : "2px",
          transition: "left 0.2s"
        }} />
      </div>
    </div>
  );
}

function SeverityToggle({ severity, value, onChange, color }) {
  return (
    <button
      onClick={() => onChange(!value)}
      style={{
        flex: 1,
        padding: "8px 4px",
        background: value ? color + "20" : "transparent",
        border: "1px solid " + (value ? color + "44" : "#1a1a35"),
        color: value ? color : "#444",
        borderRadius: "6px",
        cursor: "pointer",
        fontSize: "11px",
        fontWeight: value ? "700" : "400",
        transition: "all 0.15s"
      }}
    >
      {severity}
    </button>
  );
}

export default function AlertSettings({ onClose }) {
  const { config, updateConfig, sendTestSlack, history, sending } = useAlertStore();
  const [tab, setTab] = useState("slack");
  const [testResult, setTestResult] = useState(null);
  const [testLoading, setTestLoading] = useState(false);

  const handleTestSlack = async () => {
    if (!config.slackWebhook) {
      setTestResult({ success: false, msg: "Enter a webhook URL first" });
      return;
    }
    setTestLoading(true);
    setTestResult(null);
    const success = await sendTestSlack();
    setTestResult({
      success,
      msg: success
        ? "Test message sent successfully!"
        : "Failed — check your webhook URL. Note: CORS may block browser requests. Test from backend instead."
    });
    setTestLoading(false);
  };

  return (
    <div style={{
      position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
      background: "rgba(0,0,0,0.8)",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 1000, padding: "20px"
    }}>
      <div style={{
        background: "#0d0d1f",
        border: "1px solid #22224a",
        borderRadius: "14px",
        width: "560px",
        maxHeight: "88vh",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden"
      }}>

        {/* Header */}
        <div style={{
          padding: "18px 22px",
          borderBottom: "1px solid #202020",
          display: "flex", justifyContent: "space-between",
          alignItems: "center", flexShrink: 0
        }}>
          <div>
            <h2 style={{ color: "#e5e5e5", margin: 0, fontSize: "14px", fontWeight: "600" }}>
              Violation Alerts
            </h2>
            <p style={{ color: "#555", fontSize: "11px", margin: "4px 0 0" }}>
              Get notified when governance violations are detected
            </p>
          </div>
          <button onClick={onClose} style={{
            background: "transparent", border: "none",
            color: "#555", cursor: "pointer", fontSize: "20px"
          }}>×</button>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", borderBottom: "1px solid #202020", flexShrink: 0 }}>
          {[
            { key: "slack", label: "Slack" },
            { key: "email", label: "Email" },
            { key: "rules", label: "Alert Rules" },
            { key: "history", label: `History (${history.length})` }
          ].map(t => (
            <button key={t.key} onClick={() => setTab(t.key)} style={{
              flex: 1, background: "transparent", border: "none",
              borderBottom: `2px solid ${tab === t.key ? "#e5e5e5" : "transparent"}`,
              color: tab === t.key ? "#e5e5e5" : "#555",
              padding: "10px 6px", cursor: "pointer",
              fontSize: "11.5px",
              fontWeight: tab === t.key ? "600" : "400",
              transition: "all 0.15s", borderRadius: 0
            }}>
              {t.label}
            </button>
          ))}
        </div>

        <div style={{ flex: 1, overflowY: "auto", padding: "20px" }}>

          {/* Slack tab */}
          {tab === "slack" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
              <Toggle
                value={config.slackEnabled}
                onChange={v => updateConfig({ slackEnabled: v })}
                label="Enable Slack Alerts"
                desc="Send violation alerts to a Slack channel"
              />

              <div>
                <div style={{
                  fontSize: "10px", color: "#555",
                  textTransform: "uppercase", letterSpacing: "0.8px",
                  marginBottom: "6px", fontWeight: "600"
                }}>
                  Webhook URL
                </div>
                <input
                  value={config.slackWebhook}
                  onChange={e => updateConfig({ slackWebhook: e.target.value })}
                  placeholder="https://hooks.slack.com/services/..."
                  style={{
                    width: "100%", padding: "10px 12px",
                    background: "#0d0d1f", border: "1px solid #22224a",
                    color: "#e5e5e5", borderRadius: "8px",
                    fontSize: "12px", outline: "none",
                    boxSizing: "border-box", fontFamily: "monospace"
                  }}
                />
                <div style={{ fontSize: "10px", color: "#444", marginTop: "5px", lineHeight: "1.6" }}>
                  Go to Slack → Apps → Incoming Webhooks → Add to Slack → Copy URL
                </div>
              </div>

              <button
                onClick={handleTestSlack}
                disabled={testLoading || sending}
                style={{
                  background: "transparent",
                  border: "1px solid #22224a",
                  color: testLoading ? "#444" : "#888",
                  padding: "9px 16px", borderRadius: "8px",
                  cursor: testLoading ? "not-allowed" : "pointer",
                  fontSize: "12px", transition: "all 0.15s"
                }}
                onMouseEnter={e => { if (!testLoading) e.currentTarget.style.color = "#ccc"; }}
                onMouseLeave={e => { e.currentTarget.style.color = testLoading ? "#444" : "#888"; }}
              >
                {testLoading ? "Sending test..." : "Send Test Message"}
              </button>

              {testResult && (
                <div style={{
                  padding: "10px 12px",
                  background: testResult.success ? "#0f1a12" : "#1a1212",
                  border: "1px solid " + (testResult.success ? "#1a2e1e" : "#2e1f1f"),
                  borderRadius: "8px",
                  fontSize: "12px",
                  color: testResult.success ? "#5a9e6f" : "#cc6666",
                  lineHeight: "1.6"
                }}>
                  {testResult.success ? "✓ " : "✕ "}{testResult.msg}
                </div>
              )}

              {/* How to set up */}
              <div style={{
                padding: "14px",
                background: "#12122a",
                border: "1px solid #1a1a35",
                borderRadius: "8px"
              }}>
                <div style={{
                  fontSize: "10px", color: "#555",
                  textTransform: "uppercase", letterSpacing: "0.8px",
                  marginBottom: "10px", fontWeight: "600"
                }}>
                  How to set up
                </div>
                {[
                  "Go to api.slack.com/apps",
                  "Create a new app → From scratch",
                  "Enable Incoming Webhooks",
                  "Add New Webhook to Workspace",
                  "Select your channel and copy the URL",
                  "Paste it above and click test"
                ].map((step, i) => (
                  <div key={i} style={{
                    display: "flex", gap: "8px",
                    padding: "5px 0",
                    borderBottom: i < 5 ? "1px solid #141414" : "none",
                    fontSize: "11px", color: "#777"
                  }}>
                    <span style={{
                      color: "#444", minWidth: "16px",
                      fontWeight: "600"
                    }}>{i + 1}.</span>
                    {step}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Email tab */}
          {tab === "email" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
              <Toggle
                value={config.emailEnabled}
                onChange={v => updateConfig({ emailEnabled: v })}
                label="Enable Email Alerts"
                desc="Receive violation alerts via email"
              />

              <div>
                <div style={{
                  fontSize: "10px", color: "#555",
                  textTransform: "uppercase", letterSpacing: "0.8px",
                  marginBottom: "6px", fontWeight: "600"
                }}>
                  Email Address
                </div>
                <input
                  value={config.emailAddress}
                  onChange={e => updateConfig({ emailAddress: e.target.value })}
                  placeholder="team@company.com"
                  type="email"
                  style={{
                    width: "100%", padding: "10px 12px",
                    background: "#0d0d1f", border: "1px solid #22224a",
                    color: "#e5e5e5", borderRadius: "8px",
                    fontSize: "12px", outline: "none",
                    boxSizing: "border-box"
                  }}
                />
              </div>

              <Toggle
                value={config.digestMode}
                onChange={v => updateConfig({ digestMode: v })}
                label="Daily Digest Mode"
                desc="Get one summary email per day instead of instant alerts"
              />

              <div style={{
                padding: "14px",
                background: "#1a1a10",
                border: "1px solid #2e2e14",
                borderRadius: "8px",
                fontSize: "12px", color: "#888",
                lineHeight: "1.7"
              }}>
                <div style={{ color: "#f59e0b", fontWeight: "600", marginBottom: "6px" }}>
                  ⚠ Backend Required
                </div>
                Email alerts require a backend service to send emails.
                Connect your FastAPI backend with SendGrid or SMTP to enable this feature.
                The config is saved and ready — just wire up the API endpoint.
              </div>
            </div>
          )}

          {/* Alert rules tab */}
          {tab === "rules" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
              <div>
                <div style={{
                  fontSize: "10px", color: "#555",
                  textTransform: "uppercase", letterSpacing: "0.8px",
                  marginBottom: "10px", fontWeight: "600"
                }}>
                  Alert on Severity
                </div>
                <div style={{ display: "flex", gap: "6px" }}>
                  <SeverityToggle
                    severity="Critical"
                    value={config.alertOnCritical}
                    onChange={v => updateConfig({ alertOnCritical: v })}
                    color="#ff3b3b"
                  />
                  <SeverityToggle
                    severity="High"
                    value={config.alertOnHigh}
                    onChange={v => updateConfig({ alertOnHigh: v })}
                    color="#f97316"
                  />
                  <SeverityToggle
                    severity="Medium"
                    value={config.alertOnMedium}
                    onChange={v => updateConfig({ alertOnMedium: v })}
                    color="#f59e0b"
                  />
                  <SeverityToggle
                    severity="Low"
                    value={config.alertOnLow}
                    onChange={v => updateConfig({ alertOnLow: v })}
                    color="#6699cc"
                  />
                </div>
                <div style={{ fontSize: "10px", color: "#444", marginTop: "8px" }}>
                  Alerts are only sent for selected severity levels
                </div>
              </div>

              <Toggle
                value={config.alertOnCritical && config.alertOnHigh}
                onChange={v => updateConfig({ alertOnCritical: v, alertOnHigh: v })}
                label="Auto-alert on new violations"
                desc="Automatically send alert when a new violation is detected"
              />

              <div style={{
                padding: "12px",
                background: "#12122a",
                border: "1px solid #1a1a35",
                borderRadius: "8px"
              }}>
                <div style={{ fontSize: "11px", color: "#666", lineHeight: "1.8" }}>
                  <div style={{ color: "#ccc", fontWeight: "600", marginBottom: "6px" }}>
                    Current alert config:
                  </div>
                  <div>Slack: {config.slackEnabled ? "✓ Enabled" : "✕ Disabled"}</div>
                  <div>Email: {config.emailEnabled ? "✓ Enabled" : "✕ Disabled"}</div>
                  <div>Alert on: {[
                    config.alertOnCritical && "Critical",
                    config.alertOnHigh && "High",
                    config.alertOnMedium && "Medium",
                    config.alertOnLow && "Low"
                  ].filter(Boolean).join(", ") || "None"}</div>
                </div>
              </div>
            </div>
          )}

          {/* History tab */}
          {tab === "history" && (
            <div>
              {history.length === 0 && (
                <div style={{
                  textAlign: "center", padding: "40px 20px",
                  color: "#444", fontSize: "13px"
                }}>
                  <div style={{ fontSize: "28px", marginBottom: "12px", opacity: 0.3 }}>🔔</div>
                  No alerts sent yet
                </div>
              )}
              <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                {history.map(entry => (
                  <div key={entry.id} style={{
                    padding: "10px 12px",
                    background: "#12122a",
                    border: "1px solid " + (entry.success ? "#1a2e1e" : "#2e1f1f"),
                    borderLeft: "3px solid " + (entry.success ? "#5a9e6f" : "#cc6666"),
                    borderRadius: "8px",
                    display: "flex",
                    alignItems: "center",
                    gap: "10px"
                  }}>
                    <span style={{ fontSize: "14px" }}>
                      {entry.type === "slack" || entry.type === "slack_test" ? "💬" : "📧"}
                    </span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: "12px", color: "#ccc", fontWeight: "500" }}>
                        {entry.type === "slack_test" ? "Slack Test" : entry.type === "slack" ? "Slack Alert" : "Email Alert"}
                        {entry.violationCount > 0 && (
                          <span style={{ color: "#666", fontWeight: "400" }}>
                            {" — "}{entry.violationCount} violation{entry.violationCount > 1 ? "s" : ""}
                          </span>
                        )}
                      </div>
                      {entry.error && (
                        <div style={{ fontSize: "10px", color: "#cc6666", marginTop: "2px" }}>
                          {entry.error}
                        </div>
                      )}
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "3px" }}>
                      <span style={{
                        fontSize: "10px",
                        color: entry.success ? "#4a7c59" : "#854444",
                        fontWeight: "600"
                      }}>
                        {entry.success ? "Sent" : "Failed"}
                      </span>
                      <span style={{ fontSize: "10px", color: "#444" }}>
                        {timeAgo(entry.timestamp)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
