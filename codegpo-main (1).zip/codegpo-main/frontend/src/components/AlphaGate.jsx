import { useState } from "react";

const STORAGE_KEY = "codegpo_alpha_access";
const BACKEND_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

export function checkAccess() {
  try {
    return localStorage.getItem(STORAGE_KEY) === "granted";
  } catch { return false; }
}

export default function AlphaGate({ onAccess }) {
  const [code, setCode]       = useState("");
  const [error, setError]     = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async () => {
    if (!code.trim()) {
      setError("Please enter an invite code");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const res = await fetch(`${BACKEND_URL}/auth/validate-code`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: code.trim() })
      });

      if (res.ok) {
        localStorage.setItem(STORAGE_KEY, "granted");
        setSuccess(true);
        setTimeout(() => onAccess(), 1500);
      } else {
        const data = await res.json().catch(() => ({}));
        setError(data.detail || "Invalid invite code. Request access at codegpo.com");
        setLoading(false);
      }
    } catch {
      setError("Cannot reach server. Make sure the backend is running.");
      setLoading(false);
    }
  };

  return (
    <div style={{
      width: "100vw", height: "100vh",
      background: "radial-gradient(circle at 30% 20%, #050b14, #000)",
      display: "flex", flexDirection: "column",
      alignItems: "center", justifyContent: "center",
      position: "relative", overflow: "hidden"
    }}>
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `
          linear-gradient(rgba(0,240,255,0.03) 1px, transparent 1px),
          linear-gradient(90deg, rgba(0,240,255,0.03) 1px, transparent 1px)
        `,
        backgroundSize: "40px 40px",
        pointerEvents: "none"
      }} />

      <div style={{
        position: "absolute", top: "20%", left: "50%",
        transform: "translateX(-50%)",
        width: "600px", height: "300px",
        background: "radial-gradient(ellipse, rgba(0,240,255,0.05) 0%, transparent 70%)",
        pointerEvents: "none"
      }} />

      <div style={{
        background: "rgba(11, 15, 26, 0.9)",
        border: "1px solid rgba(0,240,255,0.2)",
        borderRadius: "20px",
        padding: "48px 40px",
        width: "420px",
        textAlign: "center",
        position: "relative",
        backdropFilter: "blur(10px)",
        boxShadow: "0 0 60px rgba(0,240,255,0.05)"
      }}>
        <div style={{ fontSize: "40px", marginBottom: "8px" }}>⚡</div>

        <div style={{
          fontSize: "28px", fontWeight: "800",
          color: "#00f0ff", letterSpacing: "3px", marginBottom: "4px"
        }}>
          CodeGPO
        </div>

        <div style={{
          fontSize: "11px", color: "#334155",
          letterSpacing: "2px", textTransform: "uppercase", marginBottom: "8px"
        }}>
          Private Alpha
        </div>

        <div style={{
          display: "inline-block",
          background: "rgba(124,58,237,0.15)",
          border: "1px solid rgba(124,58,237,0.3)",
          color: "#a78bfa", fontSize: "10px",
          padding: "4px 12px", borderRadius: "20px",
          marginBottom: "32px", letterSpacing: "1px"
        }}>
          INVITE ONLY
        </div>

        <div style={{
          color: "#64748b", fontSize: "13px",
          marginBottom: "28px", lineHeight: "1.6"
        }}>
          Architecture Governance Control Plane.<br />
          Enter your invite code to get early access.
        </div>

        {success ? (
          <div style={{
            padding: "20px",
            background: "rgba(34,197,94,0.1)",
            border: "1px solid rgba(34,197,94,0.3)",
            borderRadius: "12px",
            color: "#22c55e", fontSize: "14px", fontWeight: "600"
          }}>
            ✅ Access granted! Welcome to CodeGPO Alpha...
          </div>
        ) : (
          <>
            <input
              value={code}
              onChange={e => { setCode(e.target.value); setError(""); }}
              onKeyDown={e => e.key === "Enter" && handleSubmit()}
              placeholder="Enter invite code"
              autoFocus
              style={{
                width: "100%", padding: "14px 16px",
                background: "rgba(2, 6, 23, 0.8)",
                border: `1px solid ${error ? "#ff3b3b" : "#1e293b"}`,
                color: "#e2e8f0", borderRadius: "10px",
                fontSize: "14px", outline: "none",
                textAlign: "center", letterSpacing: "2px",
                textTransform: "uppercase", boxSizing: "border-box",
                marginBottom: "12px", transition: "border-color 0.2s",
                fontFamily: "monospace"
              }}
              onFocus={e => e.target.style.borderColor = "#00f0ff44"}
              onBlur={e => e.target.style.borderColor = error ? "#ff3b3b" : "#1e293b"}
            />

            {error && (
              <div style={{ color: "#ff3b3b", fontSize: "12px", marginBottom: "12px" }}>
                ❌ {error}
              </div>
            )}

            <button
              onClick={handleSubmit}
              disabled={loading}
              style={{
                width: "100%", padding: "14px",
                background: loading ? "#1e293b" : "linear-gradient(135deg, #00f0ff, #7c3aed)",
                border: "none", borderRadius: "10px",
                color: loading ? "#64748b" : "#000",
                fontSize: "14px", fontWeight: "700",
                cursor: loading ? "not-allowed" : "pointer",
                letterSpacing: "1px", transition: "all 0.2s"
              }}
            >
              {loading ? "⏳ Verifying..." : "Request Access →"}
            </button>
          </>
        )}

        <div style={{ marginTop: "24px", fontSize: "11px", color: "#1e293b" }}>
          Don't have a code? Apply at codegpo.com
        </div>
      </div>

      <div style={{
        position: "absolute", bottom: "24px",
        color: "#1e293b", fontSize: "11px", letterSpacing: "1px"
      }}>
        CODEGPO © 2026 — PRIVATE ALPHA
      </div>
    </div>
  );
}
