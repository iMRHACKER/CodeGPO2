import { useState, useEffect, useRef } from "react";

const COMPONENT_CATEGORIES = [
  {
    label: "Entry Points",
    types: [
      { type:"User",      icon:"◎",  color:"#f59e0b", bg:"#1f160a", desc:"End user, browser, web client" },
      { type:"Mobile",    icon:"📱", color:"#f59e0b", bg:"#1f160a", desc:"iOS/Android mobile app" },
      { type:"Frontend",  icon:"▣",  color:"#f59e0b", bg:"#1f160a", desc:"React/Vue/Next.js web app" },
      { type:"Admin",     icon:"🔧", color:"#94a3b8", bg:"#141820", desc:"Internal ops/admin dashboard" },
      { type:"IoT",       icon:"📡", color:"#10b981", bg:"#0a1f14", desc:"EV, sensor, GPS, edge device" },
    ]
  },
  {
    label: "Infrastructure",
    types: [
      { type:"Gateway",   icon:"◉",  color:"#f97316", bg:"#1f110a", desc:"API Gateway, Nginx, Kong, load balancer" },
      { type:"Auth",      icon:"🔒", color:"#a78bfa", bg:"#160a2e", desc:"Auth0, Keycloak, OAuth, JWT service" },
      { type:"Service",   icon:"⚙",  color:"#7c3aed", bg:"#1a0a2e", desc:"Backend microservice or application" },
      { type:"API",       icon:"◈",  color:"#22c55e", bg:"#0a1f0f", desc:"REST, GraphQL or gRPC endpoint" },
      { type:"Worker",    icon:"↻",  color:"#8b5cf6", bg:"#160a2e", desc:"Background job, cron, Lambda, serverless" },
      { type:"CDN",       icon:"🌐", color:"#f97316", bg:"#1f110a", desc:"CloudFront, Cloudflare, Akamai" },
    ]
  },
  {
    label: "Data",
    types: [
      { type:"Database",  icon:"🗄", color:"#0ea5e9", bg:"#0a1929", desc:"PostgreSQL, MongoDB, MySQL, DynamoDB" },
      { type:"Cache",     icon:"⚡", color:"#06b6d4", bg:"#0a1f22", desc:"Redis, Memcached, in-memory store" },
      { type:"Queue",     icon:"⇌",  color:"#ec4899", bg:"#1f0a18", desc:"Kafka, RabbitMQ, SQS, Pub/Sub" },
      { type:"Search",    icon:"🔍", color:"#06b6d4", bg:"#0a1f22", desc:"Elasticsearch, OpenSearch, Algolia" },
      { type:"Storage",   icon:"🗂",  color:"#64748b", bg:"#111820", desc:"S3, GCS, Azure Blob, file storage" },
      { type:"Secrets",   icon:"🔑", color:"#f59e0b", bg:"#1f160a", desc:"HashiCorp Vault, AWS KMS, Secrets Manager" },
    ]
  },
  {
    label: "External & Observability",
    types: [
      { type:"External",  icon:"⊕",  color:"#64748b", bg:"#111820", desc:"Stripe, Twilio, SendGrid, any 3rd party" },
      { type:"Payment",   icon:"💳", color:"#10b981", bg:"#0a1f14", desc:"Razorpay, Stripe, PayU, payment gateway" },
      { type:"Monitoring",icon:"📊", color:"#f97316", bg:"#1f110a", desc:"Datadog, Grafana, Prometheus, ELK, Sentry" },
      { type:"Analytics", icon:"📈", color:"#a78bfa", bg:"#160a2e", desc:"Segment, Mixpanel, Amplitude, BigQuery" },
      { type:"AI",        icon:"🤖", color:"#22c55e", bg:"#0a1f0f", desc:"ML model, AI inference, LLM, OpenAI" },
    ]
  },
];

const ALL_TYPES = COMPONENT_CATEGORIES.flatMap(c => c.types);

const PLACEHOLDERS = {
  User:"web-client", Mobile:"rider-app", Frontend:"customer-portal",
  Admin:"ops-dashboard", IoT:"ev-vehicle-sensor", Gateway:"api-gateway",
  Auth:"auth-service", Service:"payment-service", API:"users-api",
  Worker:"email-worker", CDN:"cloudfront-cdn", Database:"postgres-main",
  Cache:"redis-cache", Queue:"kafka-events", Search:"elasticsearch",
  Storage:"s3-documents", Secrets:"vault", External:"stripe",
  Payment:"razorpay", Monitoring:"datadog", Analytics:"mixpanel", AI:"inference-service",
};

export default function AddComponentModal({ onAdd, onClose }) {
  const [selectedType, setSelectedType] = useState(null);
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const nameRef = useRef(null);

  useEffect(() => {
    if (selectedType && nameRef.current) setTimeout(() => nameRef.current?.focus(), 50);
  }, [selectedType]);

  useEffect(() => {
    const handler = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const handleSubmit = () => {
    if (!selectedType) { setError("Pick a component type"); return; }
    if (!name.trim()) { setError("Enter a name"); return; }
    onAdd(selectedType.type, name.trim());
    onClose();
  };

  const filteredCategories = search.trim()
    ? [{ label: "Results", types: ALL_TYPES.filter(t =>
        t.type.toLowerCase().includes(search.toLowerCase()) ||
        t.desc.toLowerCase().includes(search.toLowerCase())
      )}]
    : COMPONENT_CATEGORIES;

  const cfg = selectedType;

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.85)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:2000, padding:"20px" }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background:"#0d0d1f", border:"1px solid #22224a", borderRadius:"16px", width:"600px", maxHeight:"90vh", overflow:"hidden", display:"flex", flexDirection:"column", boxShadow:"0 25px 80px rgba(0,0,0,0.6)" }}>

        {/* Header */}
        <div style={{ padding:"18px 22px 14px", borderBottom:"1px solid #1a1a35", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div>
            <h2 style={{ color:"#e5e5e5", margin:0, fontSize:"15px", fontWeight:"600" }}>Add Component</h2>
            <p style={{ color:"#555", fontSize:"11px", margin:"3px 0 0" }}>{ALL_TYPES.length} types across {COMPONENT_CATEGORIES.length} categories</p>
          </div>
          <button onClick={onClose} style={{ background:"transparent", border:"none", color:"#555", cursor:"pointer", fontSize:"20px" }}
            onMouseEnter={e=>e.currentTarget.style.color="#aaa"} onMouseLeave={e=>e.currentTarget.style.color="#555"}>×</button>
        </div>

        {/* Search */}
        <div style={{ padding:"10px 22px 0" }}>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search components... (e.g. IoT, Kafka, Auth)"
            style={{ width:"100%", padding:"8px 12px", background:"#12122a", border:"1px solid #22224a", borderRadius:"8px", color:"#ccc", fontSize:"12px", outline:"none", boxSizing:"border-box" }}
            onFocus={e=>e.target.style.borderColor="#333"} onBlur={e=>e.target.style.borderColor="#22224a"}
          />
        </div>

        {/* Type grid with categories */}
        <div style={{ padding:"12px 22px", overflowY:"auto", flex:1, scrollbarWidth:"thin", scrollbarColor:"#2a2a55 transparent" }}>
          {filteredCategories.map(cat => (
            <div key={cat.label} style={{ marginBottom:"16px" }}>
              <div style={{ fontSize:"9px", color:"#555", letterSpacing:"1.5px", textTransform:"uppercase", fontWeight:"700", marginBottom:"8px", paddingBottom:"4px", borderBottom:"1px solid #161632" }}>
                {cat.label}
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:"6px" }}>
                {cat.types.map(t => {
                  const isSelected = selectedType?.type === t.type;
                  return (
                    <button key={t.type} onClick={() => { setSelectedType(t); setError(""); }}
                      style={{ background: isSelected ? t.bg : "#12122a", border:`1.5px solid ${isSelected ? t.color : "#1a1a35"}`, borderRadius:"10px", padding:"10px 10px", cursor:"pointer", textAlign:"left", transition:"all 0.15s", position:"relative", overflow:"hidden" }}
                      onMouseEnter={e => { if(!isSelected){ e.currentTarget.style.borderColor="#2a2a55"; e.currentTarget.style.background="#141414"; }}}
                      onMouseLeave={e => { if(!isSelected){ e.currentTarget.style.borderColor="#1a1a35"; e.currentTarget.style.background="#12122a"; }}}>

                      {isSelected && <div style={{ position:"absolute", top:0, left:0, right:0, height:"2px", background:t.color }} />}

                      <div style={{ display:"flex", alignItems:"center", gap:"8px", marginBottom:"4px" }}>
                        <div style={{ width:"26px", height:"26px", borderRadius:"6px", background:t.color+"22", border:`1px solid ${t.color}44`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:"13px", flexShrink:0 }}>
                          {t.icon}
                        </div>
                        <span style={{ fontSize:"11px", fontWeight:"600", color: isSelected ? t.color : "#ccc" }}>{t.type}</span>
                        {isSelected && (
                          <div style={{ marginLeft:"auto", width:"14px", height:"14px", borderRadius:"50%", background:t.color, display:"flex", alignItems:"center", justifyContent:"center", fontSize:"9px", color:"#fff", fontWeight:"700" }}>✓</div>
                        )}
                      </div>
                      <div style={{ fontSize:"10px", color: isSelected ? "#888" : "#555", lineHeight:"1.4" }}>{t.desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Name input */}
          <div style={{ overflow:"hidden", maxHeight: selectedType ? "110px" : "0px", transition:"max-height 0.25s ease", opacity: selectedType ? 1 : 0 }}>
            <div style={{ padding:"14px", background: cfg ? cfg.bg : "#12122a", border:`1px solid ${cfg ? cfg.color+"44" : "#1a1a35"}`, borderRadius:"10px", marginTop:"4px" }}>
              <div style={{ fontSize:"10px", color: cfg?.color || "#777", fontWeight:"700", textTransform:"uppercase", letterSpacing:"0.8px", marginBottom:"8px", display:"flex", alignItems:"center", gap:"6px" }}>
                <span>{cfg?.icon}</span><span>{cfg?.type} Name</span>
              </div>
              <input ref={nameRef} value={name} onChange={e => { setName(e.target.value); setError(""); }} onKeyDown={e => e.key === "Enter" && handleSubmit()}
                placeholder={`e.g. ${PLACEHOLDERS[cfg?.type] || cfg?.type?.toLowerCase() || "my-component"}`}
                style={{ width:"100%", padding:"9px 12px", background:"#0d0d1f", border:`1px solid ${cfg ? cfg.color+"33" : "#22224a"}`, borderRadius:"8px", color:"#e5e5e5", fontSize:"13px", fontWeight:"500", outline:"none", boxSizing:"border-box" }}
                onFocus={e => e.target.style.borderColor = cfg?.color || "#555"}
                onBlur={e => e.target.style.borderColor = cfg ? cfg.color+"33" : "#22224a"}
              />
            </div>
          </div>

          {error && <div style={{ fontSize:"12px", color:"#cc6666", marginTop:"8px", padding:"8px 12px", background:"#1a1010", border:"1px solid #2a1515", borderRadius:"6px" }}>{error}</div>}
        </div>

        {/* Footer */}
        <div style={{ padding:"12px 20px", borderTop:"1px solid #1a1a35", display:"flex", gap:"10px", justifyContent:"flex-end" }}>
          <button onClick={onClose} style={{ background:"transparent", border:"1px solid #22224a", color:"#777", padding:"9px 20px", borderRadius:"8px", cursor:"pointer", fontSize:"13px" }}
            onMouseEnter={e=>e.currentTarget.style.borderColor="#333"} onMouseLeave={e=>e.currentTarget.style.borderColor="#22224a"}>Cancel</button>
          <button onClick={handleSubmit} style={{ background: cfg ? cfg.color : "#333", border:"none", color:"#fff", padding:"9px 24px", borderRadius:"8px", cursor:"pointer", fontSize:"13px", fontWeight:"600", opacity:(!selectedType||!name.trim())?0.4:1 }}>
            Add {cfg?.type || "Component"}
          </button>
        </div>
      </div>
    </div>
  );
}
