import { useState, useEffect } from "react";
import { useGraphStore } from "../state/graphStore";
import { getGitHubConfig } from "./GitHubSettings";

const BACKEND = import.meta.env.VITE_API_URL || "http://localhost:8000";

// ── File entry in preview list ────────────────────────────
function FileEntry({ file }) {
  const [expanded, setExpanded] = useState(false);

  const EXT_COLORS = {
    sql:       { color: "#0ea5e9", icon: "🗄" },
    orm:       { color: "#7c3aed", icon: "🧱" },
    migration: { color: "#f59e0b", icon: "🔃" },
    prisma:    { color: "#22c55e", icon: "◈"  },
    openapi:   { color: "#0da8ff", icon: "📄" },
    mongo:     { color: "#22c55e", icon: "🍃" },
  };

  const cfg = EXT_COLORS[file.artifact_type] || { color: "#888", icon: "◆" };

  return (
    <div style={{
      background: "#12122a", border: "1px solid #1a1a35",
      borderRadius: "8px", overflow: "hidden", marginBottom: "6px"
    }}>
      <button
        onClick={() => setExpanded(!expanded)}
        style={{
          width: "100%", background: "transparent", border: "none",
          padding: "10px 14px", cursor: "pointer",
          display: "flex", alignItems: "center", gap: "10px", textAlign: "left"
        }}
      >
        <span style={{ fontSize: "14px" }}>{cfg.icon}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontSize: "11.5px", fontWeight: "600", color: "#ccc",
            fontFamily: "monospace",
            whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"
          }}>
            {file.path}
          </div>
          <div style={{ fontSize: "10px", color: "#555", marginTop: "2px" }}>
            {file.node} · {file.artifact_type.toUpperCase()}
          </div>
        </div>
        <span style={{
          fontSize: "9.5px", fontWeight: "700", padding: "2px 7px",
          borderRadius: "4px", background: cfg.color + "18",
          color: cfg.color, border: `1px solid ${cfg.color}44`
        }}>
          {file.artifact_type}
        </span>
        <span style={{
          color: "#444", fontSize: "12px",
          transform: expanded ? "rotate(180deg)" : "none",
          transition: "transform 0.2s", display: "inline-block"
        }}>▾</span>
      </button>

      {expanded && file.preview && (
        <div style={{ borderTop: "1px solid #161632" }}>
          <pre style={{
            background: "#0d0d1f", margin: 0, padding: "12px 14px",
            fontSize: "10.5px", color: "#888",
            fontFamily: "'IBM Plex Mono', monospace",
            lineHeight: "1.6", overflowX: "auto",
            maxHeight: "200px", overflowY: "auto",
            scrollbarWidth: "thin", scrollbarColor: "#2a2a55 transparent"
          }}>
            {file.preview}
          </pre>
        </div>
      )}
    </div>
  );
}

// ── Step indicator ────────────────────────────────────────
function Step({ number, label, status }) {
  const colors = {
    pending: { bg: "#12122a",    border: "#1a1a35", text: "#555",    dot: "#333"    },
    active:  { bg: "#111829", border: "#1e3a5f", text: "#0ea5e9", dot: "#0ea5e9" },
    done:    { bg: "#111a13", border: "#1e2e22", text: "#5a9e6f", dot: "#5a9e6f" },
    error:   { bg: "#1a1010", border: "#2e1a1a", text: "#cc6666", dot: "#cc6666" },
  };
  const c = colors[status] || colors.pending;

  return (
    <div style={{
      display: "flex", alignItems: "center", gap: "12px",
      padding: "10px 14px",
      background: c.bg, border: `1px solid ${c.border}`,
      borderRadius: "8px", marginBottom: "6px"
    }}>
      <div style={{
        width: "24px", height: "24px", borderRadius: "50%",
        background: c.dot + "22", border: `2px solid ${c.dot}`,
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: "11px", fontWeight: "700", color: c.dot, flexShrink: 0
      }}>
        {status === "done" ? "✓" : status === "error" ? "✕" : number}
      </div>
      <div style={{ fontSize: "12.5px", color: c.text, fontWeight: "500" }}>{label}</div>
      {status === "active" && (
        <div style={{
          marginLeft: "auto", width: "14px", height: "14px",
          border: "2px solid #0ea5e9", borderTopColor: "transparent",
          borderRadius: "50%", animation: "spin 0.8s linear infinite"
        }} />
      )}
    </div>
  );
}

// ── Main AutoPRPanel ──────────────────────────────────────
export default function AutoPRPanel({ onClose, onOpenGitHubSettings }) {
  const { nodes, edges } = useGraphStore();

  const [tab, setTab]           = useState("preview");
  const [preview, setPreview]   = useState(null);
  const [result, setResult]     = useState(null);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");
  const [ghConfig, setGhConfig] = useState(null);
  const [prTitle, setPrTitle]   = useState("");
  const [steps, setSteps]       = useState([]);
  const [showDesc, setShowDesc] = useState(false);

  const userGhConfig = getGitHubConfig();

  const getGitHubPayload = () => {
    if (!userGhConfig) return {};
    return {
      githubToken: userGhConfig.token,
      githubOwner: userGhConfig.owner,
      githubRepo:  userGhConfig.repo,
    };
  };

  useEffect(() => {
    const isUserConfigured = !!(userGhConfig?.token && userGhConfig?.owner && userGhConfig?.repo);

    if (isUserConfigured) {
      setGhConfig({
        configured: true,
        owner:      userGhConfig.owner,
        repo:       userGhConfig.repo,
        source:     "user",
        repoUrl:    `https://github.com/${userGhConfig.owner}/${userGhConfig.repo}`
      });
    } else {
      fetch(`${BACKEND}/pr/config`)
        .then(r => r.json())
        .then(d => setGhConfig(d))
        .catch(() => setGhConfig({ configured: false }));
    }
  }, []);

  const eligibleNodes = nodes.filter(n =>
    ["database","db","api","rest","sql","mongo","nosql","graphql"]
      .some(t => (n.type || "").toLowerCase().includes(t))
  );

  useEffect(() => {
    if (nodes.length > 0) handlePreview();
  }, []);

  const handlePreview = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`${BACKEND}/pr/preview`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nodes, edges, ...getGitHubPayload() })
      });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.detail || "Preview failed");
      }
      const data = await res.json();
      setPreview(data);
      if (!prTitle) setPrTitle(data.pr_title || "");
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePR = async () => {
    if (!ghConfig?.configured) {
      setError("GitHub not connected. Click 'Connect GitHub' to add your token.");
      return;
    }

    setTab("create");
    setLoading(true);
    setError("");
    setResult(null);

    const stepDefs = [
      "Generating schemas from graph",
      "Creating GitHub branch",
      "Committing generated files",
      "Opening Pull Request",
    ];
    setSteps(stepDefs.map((label, i) => ({ label, status: i === 0 ? "active" : "pending" })));

    const advanceStep = (stepIndex) => {
      setSteps(prev => prev.map((s, i) => {
        if (i === stepIndex)     return { ...s, status: "done"   };
        if (i === stepIndex + 1) return { ...s, status: "active" };
        return s;
      }));
    };

    const timers = [];
    [2000, 3500, 5000].forEach((delay, i) => {
      timers.push(setTimeout(() => advanceStep(i), delay));
    });

    try {
      const res = await fetch(`${BACKEND}/pr/create`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nodes, edges,
          title: prTitle || undefined,
          ...getGitHubPayload()
        })
      });

      timers.forEach(t => clearTimeout(t));

      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        setSteps(prev => prev.map(s =>
          s.status === "active" ? { ...s, status: "error" } : s
        ));
        throw new Error(d.detail || "PR creation failed");
      }

      const data = await res.json();
      setSteps(stepDefs.map(label => ({ label, status: "done" })));
      setResult(data);
      setTab("result");
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.88)",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 3000, padding: "20px"
    }}
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>

      <div style={{
        background: "#0d0d1f", border: "1px solid #22224a",
        borderRadius: "16px", width: "760px", maxHeight: "90vh",
        display: "flex", flexDirection: "column", overflow: "hidden",
        boxShadow: "0 30px 80px rgba(0,0,0,0.7)"
      }}>

        {/* Header */}
        <div style={{
          padding: "20px 24px 16px", borderBottom: "1px solid #1a1a35",
          display: "flex", justifyContent: "space-between", alignItems: "flex-start"
        }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <span style={{ fontSize: "18px" }}>🔀</span>
              <h2 style={{ color: "#e5e5e5", margin: 0, fontSize: "16px", fontWeight: "700" }}>
                Auto Pull Request
              </h2>
              <span style={{
                fontSize: "9.5px", fontWeight: "700", letterSpacing: "1px",
                background: "rgba(34,197,94,0.12)", border: "1px solid rgba(34,197,94,0.3)",
                color: "#22c55e", padding: "2px 8px", borderRadius: "4px"
              }}>INTENT-DRIVEN</span>
            </div>
            <p style={{ color: "#555", fontSize: "12px", margin: "5px 0 0" }}>
              Materializes approved architectural intent into governed code — opened as a GitHub PR
            </p>
          </div>
          <button onClick={onClose} style={{
            background: "transparent", border: "none",
            color: "#555", cursor: "pointer", fontSize: "20px"
          }}>×</button>
        </div>

        {/* GitHub config status */}
        <div style={{
          padding: "10px 24px", borderBottom: "1px solid #161632",
          display: "flex", alignItems: "center", gap: "10px"
        }}>
          <div style={{
            width: "7px", height: "7px", borderRadius: "50%",
            background: ghConfig?.configured ? "#22c55e" : "#f59e0b",
            flexShrink: 0
          }} />
          {ghConfig?.configured ? (
            <span style={{ fontSize: "11.5px", color: "#5a9e6f", flex: 1 }}>
              GitHub connected →
              <a href={ghConfig.repoUrl} target="_blank" rel="noreferrer"
                style={{ color: "#0ea5e9", textDecoration: "none", marginLeft: "6px" }}>
                {ghConfig.owner}/{ghConfig.repo}
              </a>
              {ghConfig.source === "user" && (
                <span style={{ color: "#555", fontSize: "10px", marginLeft: "8px" }}>
                  (your token)
                </span>
              )}
            </span>
          ) : (
            <span style={{ fontSize: "11.5px", color: "#f59e0b", flex: 1 }}>
              GitHub not connected
            </span>
          )}
          <button
            onClick={onOpenGitHubSettings}
            style={{
              background: "transparent",
              border: "1px solid #333", color: "#888",
              padding: "4px 12px", borderRadius: "6px",
              cursor: "pointer", fontSize: "11px"
            }}
          >
            🐙 {ghConfig?.configured ? "Change" : "Connect GitHub"}
          </button>
        </div>

        {/* Stats */}
        <div style={{
          padding: "12px 24px", borderBottom: "1px solid #161632",
          display: "flex", gap: "24px", alignItems: "center"
        }}>
          <div>
            <span style={{ fontSize: "18px", fontWeight: "700", color: "#e5e5e5" }}>{nodes.length}</span>
            <span style={{ fontSize: "11px", color: "#555", marginLeft: "5px" }}>components</span>
          </div>
          <div>
            <span style={{ fontSize: "18px", fontWeight: "700", color: "#0ea5e9" }}>{eligibleNodes.length}</span>
            <span style={{ fontSize: "11px", color: "#555", marginLeft: "5px" }}>schema-eligible</span>
          </div>
          {preview && (
            <div>
              <span style={{ fontSize: "18px", fontWeight: "700", color: "#22c55e" }}>{preview.files_count}</span>
              <span style={{ fontSize: "11px", color: "#555", marginLeft: "5px" }}>files to commit</span>
            </div>
          )}
          <div style={{ marginLeft: "auto", display: "flex", gap: "8px" }}>
            {tab === "preview" && (
              <button
                onClick={handleCreatePR}
                disabled={loading || !preview?.files_count}
                style={{
                  background: (!preview?.files_count || loading)
                    ? "#1a1a35"
                    : "linear-gradient(135deg, #22c55e, #0ea5e9)",
                  border: "none",
                  color: (!preview?.files_count || loading) ? "#555" : "#fff",
                  padding: "9px 20px", borderRadius: "8px",
                  cursor: (!preview?.files_count || loading) ? "not-allowed" : "pointer",
                  fontSize: "13px", fontWeight: "700"
                }}
              >
                🔀 Open PR on GitHub
              </button>
            )}
            {tab === "result" && result?.pr_url && (
              <a href={result.pr_url} target="_blank" rel="noreferrer"
                style={{
                  background: "linear-gradient(135deg, #22c55e, #0ea5e9)",
                  color: "#fff", padding: "9px 20px", borderRadius: "8px",
                  textDecoration: "none", fontSize: "13px", fontWeight: "700",
                  display: "inline-block"
                }}
              >
                ↗ View PR on GitHub
              </a>
            )}
          </div>
        </div>

        {/* Body */}
        <div style={{
          flex: 1, overflowY: "auto", padding: "16px 24px",
          scrollbarWidth: "thin", scrollbarColor: "#2a2a55 transparent"
        }}>
          {error && (() => {
            const is404    = error.includes("404") || error.includes("Not Found");
            const is401    = error.includes("401") || error.includes("Unauthorized") || error.includes("Bad credentials");
            const is422    = error.includes("422") || error.includes("Unprocessable");
            const ghConfig = (() => { try { return JSON.parse(localStorage.getItem("codegpo_github_config") || "null"); } catch { return null; } })();
            const owner    = ghConfig?.owner || "";
            const repo     = ghConfig?.repo  || "";

            let hint = null;
            if (is404) {
              hint = (
                <div style={{ marginTop: "10px", lineHeight: "1.7" }}>
                  <strong style={{ color: "#e5c07b" }}>Repo not found on GitHub.</strong><br />
                  Make sure <code style={{ background: "#2a1a00", padding: "1px 5px", borderRadius: "3px", color: "#f59e0b" }}>{owner}/{repo}</code> exists and your token has <code style={{ background: "#2a1a00", padding: "1px 5px", borderRadius: "3px", color: "#f59e0b" }}>repo</code> scope.<br />
                  <a href={`https://github.com/new`} target="_blank" rel="noreferrer"
                    style={{ color: "#0ea5e9", fontSize: "11px" }}>
                    → Create the repo on GitHub
                  </a>
                  {" · "}
                  <span
                    onClick={onOpenGitHubSettings}
                    style={{ color: "#a78bfa", fontSize: "11px", cursor: "pointer", textDecoration: "underline" }}>
                    Update GitHub settings
                  </span>
                </div>
              );
            } else if (is401) {
              hint = (
                <div style={{ marginTop: "10px" }}>
                  <strong style={{ color: "#e5c07b" }}>Token rejected.</strong> It may be expired or missing <code style={{ background: "#2a1a00", padding: "1px 5px", borderRadius: "3px", color: "#f59e0b" }}>repo</code> scope.{" "}
                  <span onClick={onOpenGitHubSettings} style={{ color: "#a78bfa", cursor: "pointer", textDecoration: "underline" }}>
                    Update token →
                  </span>
                </div>
              );
            } else if (is422) {
              hint = (
                <div style={{ marginTop: "10px" }}>
                  <strong style={{ color: "#e5c07b" }}>Branch already exists or PR already open.</strong> Try again in a moment — a new timestamp branch will be created.
                </div>
              );
            }

            return (
              <div style={{
                padding: "12px 16px", marginBottom: "16px",
                background: "#1a1010", border: "1px solid #2e1a1a",
                borderLeft: "3px solid #cc6666",
                borderRadius: "8px", fontSize: "12.5px", color: "#cc8888"
              }}>
                ⚠ {error}
                {hint}
              </div>
            );
          })()}

          {tab === "preview" && (
            <div>
              {loading && !preview && (
                <div style={{ textAlign: "center", padding: "40px", color: "#555" }}>
                  <div style={{ fontSize: "28px", marginBottom: "12px" }}>⏳</div>
                  <div>Building preview...</div>
                </div>
              )}

              {!loading && !preview && eligibleNodes.length === 0 && (
                <div style={{ textAlign: "center", padding: "48px 24px", color: "#444" }}>
                  <div style={{ fontSize: "48px", marginBottom: "16px", opacity: 0.4 }}>🔀</div>
                  <div style={{ fontSize: "14px", fontWeight: "600", color: "#666", marginBottom: "8px" }}>
                    No schema-eligible components
                  </div>
                  <div style={{ fontSize: "12px", color: "#444", lineHeight: "1.6" }}>
                    Add Database or API components to your architecture to generate a PR.
                  </div>
                </div>
              )}

              {preview && (
                <div>
                  <div style={{ marginBottom: "20px" }}>
                    <div style={{ fontSize: "10px", color: "#555", textTransform: "uppercase", letterSpacing: "0.8px", marginBottom: "6px", fontWeight: "600" }}>
                      PR Title
                    </div>
                    <input
                      value={prTitle}
                      onChange={e => setPrTitle(e.target.value)}
                      style={{
                        width: "100%", padding: "10px 14px",
                        background: "#12122a", border: "1px solid #22224a",
                        color: "#e5e5e5", borderRadius: "8px",
                        fontSize: "13px", boxSizing: "border-box", outline: "none"
                      }}
                      onFocus={e => e.target.style.borderColor = "#333"}
                      onBlur={e => e.target.style.borderColor = "#22224a"}
                    />
                  </div>

                  <div style={{ marginBottom: "20px" }}>
                    <div style={{ fontSize: "10px", color: "#555", textTransform: "uppercase", letterSpacing: "0.8px", marginBottom: "6px", fontWeight: "600" }}>Branch</div>
                    <div style={{
                      fontFamily: "monospace", fontSize: "12px", color: "#0ea5e9",
                      background: "#12122a", border: "1px solid #1a1a35",
                      padding: "8px 12px", borderRadius: "6px"
                    }}>
                      {preview.branch_name}
                    </div>
                  </div>

                  <div style={{ marginBottom: "20px" }}>
                    <div style={{
                      fontSize: "10px", color: "#555", textTransform: "uppercase",
                      letterSpacing: "0.8px", marginBottom: "10px", fontWeight: "600",
                      display: "flex", justifyContent: "space-between"
                    }}>
                      <span>Files to commit ({preview.files_count})</span>
                      <span style={{ color: "#444", textTransform: "none", letterSpacing: 0 }}>click to preview</span>
                    </div>
                    {preview.files?.map((f, i) => <FileEntry key={i} file={f} />)}
                  </div>

                  <div>
                    <button
                      onClick={() => setShowDesc(!showDesc)}
                      style={{
                        background: "transparent", border: "none", color: "#555",
                        cursor: "pointer", fontSize: "10px", textTransform: "uppercase",
                        letterSpacing: "0.8px", fontWeight: "600",
                        padding: "0 0 8px", display: "flex", alignItems: "center", gap: "6px"
                      }}
                    >
                      PR Description {showDesc ? "▲" : "▼"}
                    </button>
                    {showDesc && (
                      <pre style={{
                        background: "#0d0d1f", border: "1px solid #1a1a35", borderRadius: "8px",
                        padding: "14px", fontSize: "11px", color: "#888",
                        fontFamily: "monospace", lineHeight: "1.6",
                        overflowX: "auto", maxHeight: "280px", overflowY: "auto",
                        whiteSpace: "pre-wrap",
                        scrollbarWidth: "thin", scrollbarColor: "#2a2a55 transparent"
                      }}>
                        {preview.pr_description}
                      </pre>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {tab === "create" && (
            <div>
              <div style={{ fontSize: "13px", color: "#666", marginBottom: "20px" }}>Creating PR on GitHub...</div>
              {steps.map((step, i) => (
                <Step key={i} number={i + 1} label={step.label} status={step.status} />
              ))}
            </div>
          )}

          {tab === "result" && result && (
            <div>
              <div style={{
                padding: "20px 24px", marginBottom: "20px",
                background: "linear-gradient(135deg, rgba(34,197,94,0.08), rgba(14,165,233,0.08))",
                border: "1px solid rgba(34,197,94,0.3)",
                borderRadius: "12px", textAlign: "center"
              }}>
                <div style={{ fontSize: "32px", marginBottom: "10px" }}>🎉</div>
                <div style={{ fontSize: "15px", fontWeight: "700", color: "#22c55e", marginBottom: "6px" }}>
                  Pull Request #{result.pr_number} Created
                </div>
                <div style={{ fontSize: "12px", color: "#555", marginBottom: "16px" }}>{result.pr_title}</div>
                <a href={result.pr_url} target="_blank" rel="noreferrer"
                  style={{
                    display: "inline-block",
                    background: "linear-gradient(135deg, #22c55e, #0ea5e9)",
                    color: "#fff", padding: "10px 24px", borderRadius: "8px",
                    textDecoration: "none", fontSize: "13px", fontWeight: "700"
                  }}
                >↗ Open on GitHub</a>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "10px", marginBottom: "20px" }}>
                {[
                  { label: "Branch",  value: result.branch,        color: "#0ea5e9" },
                  { label: "Files",   value: result.files_count,   color: "#22c55e" },
                  { label: "Schemas", value: result.schemas_count, color: "#a78bfa" },
                ].map(s => (
                  <div key={s.label} style={{
                    background: "#12122a", border: "1px solid #1a1a35",
                    borderRadius: "8px", padding: "12px", textAlign: "center"
                  }}>
                    <div style={{ fontSize: "18px", fontWeight: "700", color: s.color }}>{s.value}</div>
                    <div style={{ fontSize: "10px", color: "#555", marginTop: "3px" }}>{s.label}</div>
                  </div>
                ))}
              </div>

              <div>
                <div style={{ fontSize: "10px", color: "#555", textTransform: "uppercase", letterSpacing: "0.8px", marginBottom: "8px", fontWeight: "600" }}>
                  Committed Files ({result.committed_files?.length || 0})
                </div>
                {result.committed_files?.map((f, i) => (
                  <div key={i} style={{
                    fontFamily: "monospace", fontSize: "11px", color: "#5a9e6f",
                    padding: "5px 10px", background: "#111a13", border: "1px solid #1e2e22",
                    borderRadius: "5px", marginBottom: "4px",
                    display: "flex", alignItems: "center", gap: "8px"
                  }}>
                    <span style={{ color: "#3a6a43" }}>✓</span>{f}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{
          padding: "12px 24px", borderTop: "1px solid #161632",
          display: "flex", justifyContent: "space-between", alignItems: "center"
        }}>
          <div style={{ fontSize: "11px", color: "#333", fontFamily: "monospace" }}>
            CodeGPO — Auto Pull Request Engine
          </div>
          <div style={{ fontSize: "11px", color: "#333" }}>
            Materialized from approved intent · not AI-generated
          </div>
        </div>
      </div>
    </div>
  );
}
