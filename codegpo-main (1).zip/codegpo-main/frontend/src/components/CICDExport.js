/**
 * CodeGPO — CI/CD Integration Templates
 * Generates GitHub Actions, GitLab CI, Bitbucket Pipelines YAML
 * Uses /api/governance/evaluate backend endpoint
 */

const API_URL = import.meta.env.VITE_API_URL || "https://codegpo-production-9548.up.railway.app";

export function generateGitHubActionsYAML(projectName = "my-project") {
  return `# CodeGPO Architecture Governance Gate
# Blocks merge if CRITICAL violations are detected
# Add this file to: .github/workflows/codegpo.yml

name: CodeGPO Governance Check

on:
  pull_request:
    branches: [main, master, develop]
  push:
    branches: [main, master]

jobs:
  governance:
    name: Architecture Governance
    runs-on: ubuntu-latest

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Load CodeGPO Architecture
        id: governance
        run: |
          # Load your saved architecture JSON
          # Option 1: Store architecture in repo as codegpo.json
          if [ -f "codegpo.json" ]; then
            ARCH=$(cat codegpo.json)
          else
            echo "No codegpo.json found. Skipping governance check."
            exit 0
          fi

          # Call CodeGPO governance evaluate API — returns a plain list of violations,
          # each with an "accountability" object (status: unresolved / approved / overridden).
          RESPONSE=$(curl -s -X POST \\
            "${API_URL}/api/governance/evaluate" \\
            -H "Content-Type: application/json" \\
            -H "Authorization: Bearer \${{ secrets.CODEGPO_TOKEN }}" \\
            -d "\$ARCH")

          # Only violations that are CRITICAL *and* still unresolved block the merge.
          # A named Approve/Override recorded in CodeGPO counts as passing.
          VIOLATIONS=\$(echo "\$RESPONSE" | python3 -c "import sys,json; v=json.load(sys.stdin); print(len(v))")
          CRITICAL=\$(echo "\$RESPONSE" | python3 -c "
import sys, json
v = json.load(sys.stdin)
print(len([x for x in v if x.get('severity') == 'CRITICAL' and (x.get('accountability') or {}).get('status') == 'unresolved']))
")

          echo "violations=\$VIOLATIONS" >> \$GITHUB_OUTPUT
          echo "critical=\$CRITICAL" >> \$GITHUB_OUTPUT

          echo "## CodeGPO Governance Report" >> \$GITHUB_STEP_SUMMARY
          echo "- Total Violations: \$VIOLATIONS" >> \$GITHUB_STEP_SUMMARY
          echo "- Unresolved Critical: \$CRITICAL" >> \$GITHUB_STEP_SUMMARY

      - name: Block on Unresolved Critical Violations
        if: steps.governance.outputs.critical > 0
        run: |
          echo "🚫 BLOCKED: \${{ steps.governance.outputs.critical }} unresolved CRITICAL violation(s)."
          echo "Approve, override (with a reason), or fix them in CodeGPO before merging."
          echo "Open: ${API_URL}"
          exit 1

      - name: Warn on Remaining Violations
        if: steps.governance.outputs.critical == 0 && steps.governance.outputs.violations > 0
        run: |
          echo "⚠️ WARNING: \${{ steps.governance.outputs.violations }} violation(s) total (none blocking — either non-critical or already approved/overridden)."
          echo "Review in CodeGPO: ${API_URL}"

      - name: Governance Passed
        if: steps.governance.outputs.violations == 0
        run: echo "✅ Architecture governance passed. No violations detected."

  auto-sync-architecture:
    name: Sync Architecture Diagram
    if: github.event_name == 'push'
    runs-on: ubuntu-latest
    steps:
      - name: Re-scan repo and update CodeGPO diagram
        run: |
          # Runs only on push to main/master — re-scans package.json / requirements.txt
          # and updates the architecture diagram in CodeGPO automatically.
          # No one needs to open the web app or re-import manually.
          curl -s -X POST \\
            "${API_URL}/architecture/auto-scan" \\
            -H "Content-Type: application/json" \\
            -H "Authorization: Bearer \${{ secrets.CODEGPO_TOKEN }}" \\
            -d "{\\"owner\\": \\"\${{ github.repository_owner }}\\", \\"repo\\": \\"\${{ github.event.repository.name }}\\", \\"branch\\": \\"\${{ github.ref_name }}\\"}"
`;
}

export function generateGitLabCIYAML() {
  return `# CodeGPO Architecture Governance Gate
# Add to: .gitlab-ci.yml

codegpo-governance:
  stage: test
  image: curlimages/curl:latest
  script:
    - |
      if [ ! -f "codegpo.json" ]; then
        echo "No codegpo.json found. Skipping."
        exit 0
      fi
      RESPONSE=$(curl -s -X POST \\
        "${API_URL}/api/governance/evaluate" \\
        -H "Content-Type: application/json" \\
        -H "Authorization: Bearer \$CODEGPO_TOKEN" \\
        -d @codegpo.json)
      # Only violations that are CRITICAL *and* still unresolved block the pipeline.
      # A named Approve/Override recorded in CodeGPO counts as passing.
      CRITICAL=$(echo \$RESPONSE | python3 -c "
import sys, json
v = json.load(sys.stdin)
print(len([x for x in v if x.get('severity') == 'CRITICAL' and (x.get('accountability') or {}).get('status') == 'unresolved']))
")
      if [ "\$CRITICAL" -gt "0" ]; then
        echo "🚫 BLOCKED: \$CRITICAL unresolved CRITICAL violation(s)"
        echo "Approve, override (with a reason), or fix them in CodeGPO before merging."
        exit 1
      fi
      echo "✅ Governance passed"
  only:
    - merge_requests
    - main
`;
}

export function downloadCICDTemplate(type = "github") {
  const content = type === "github" ? generateGitHubActionsYAML() : generateGitLabCIYAML();
  const filename = type === "github" ? "codegpo.yml" : ".gitlab-ci-codegpo.yml";
  const blob = new Blob([content], { type: "text/yaml" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

export function exportArchitectureJSON(nodes, edges, projectName = "project") {
  const payload = { nodes, edges, project_name: projectName, exported_at: new Date().toISOString() };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "codegpo.json"; a.click();
  URL.revokeObjectURL(url);
}
