/**
 * CodeGPO Auth Modal
 * File: frontend/src/components/AuthModal.jsx
 * 
 * Login / Register modal with JWT auth
 */
import { useState } from "react";

const API_BASE = import.meta.env.VITE_API_URL || "https://codegpo-production-9548.up.railway.app";

function getPasswordStrength(pwd) {
  if (!pwd) return null;
  let score = 0;
  if (pwd.length >= 8) score++;
  if (/[A-Z]/.test(pwd)) score++;
  if (/[0-9]/.test(pwd)) score++;
  if (/[^A-Za-z0-9]/.test(pwd)) score++;
  if (score <= 1) return { label: "Weak", color: "#EF4444" };
  if (score === 2) return { label: "Fair", color: "#F97316" };
  if (score === 3) return { label: "Good", color: "#F59E0B" };
  return { label: "Strong", color: "#22C55E" };
}

export default function AuthModal({ onSuccess, onClose }) {
  const [mode, setMode] = useState("login"); // login | register
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showResend, setShowResend] = useState(false);
  const [form, setForm] = useState({
    email: "", password: "", name: "", org_name: ""
  });

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const endpoint = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const body = mode === "login"
        ? { email: form.email, password: form.password }
        : { email: form.email, password: form.password, name: form.name, org_name: form.org_name };

      const res = await fetch(`${API_BASE}${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "Authentication failed");

      localStorage.setItem("codegpo_token", data.access_token);
      localStorage.setItem("codegpo_user", JSON.stringify(data.user));
      onSuccess?.(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const input = (label, key, type = "text", placeholder = "") => (
    <div style={{ marginBottom: 12 }}>
      <label style={{ display: "block", fontSize: 11, color: "#94A3B8", marginBottom: 4, textTransform: "uppercase", letterSpacing: 1 }}>
        {label}
      </label>
      <input
        type={type}
        value={form[key]}
        onChange={e => update(key, e.target.value)}
        placeholder={placeholder}
        style={{
          width: "100%", background: "#1A1A35", border: "1px solid #2A2A4A",
          borderRadius: 6, padding: "9px 12px", color: "#CBD5E1",
          fontSize: 13, outline: "none", boxSizing: "border-box",
        }}
      />
    </div>
  );

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 1000, fontFamily: "Inter, sans-serif",
    }}>
      <div style={{
        background: "#0D0D1A", border: "1px solid #2A2A4A", borderRadius: 12,
        width: 420, padding: 32, position: "relative",
      }}>
        {/* Header */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 22, fontWeight: 800, color: "#fff", marginBottom: 4 }}>
            ⚡ CodeGPO
          </div>
          <div style={{ fontSize: 13, color: "#475569" }}>
            Architecture as Law. Governance as Code.
          </div>
        </div>

        {/* Tab switcher */}
        <div style={{ display: "flex", gap: 8, marginBottom: 24 }}>
          {["login", "register"].map(m => (
            <button key={m} onClick={() => { setMode(m); setError(""); }}
              style={{
                flex: 1, padding: "8px", borderRadius: 6, cursor: "pointer",
                fontWeight: 600, fontSize: 13, border: "1px solid",
                background: mode === m ? "#2D1A5A" : "#141428",
                borderColor: mode === m ? "#7C3AED" : "#2A2A4A",
                color: mode === m ? "#A78BFA" : "#475569",
              }}>
              {m === "login" ? "Sign In" : "Create Account"}
            </button>
          ))}
        </div>

        {/* Form */}
        <form onSubmit={submit}>
          {mode === "register" && input("Full Name", "name", "text", "Your name")}
          {input("Email", "email", "email", "you@company.com")}
          {input("Password", "password", "password", "••••••••")}
          {!isLogin && form.password && (() => {
            const s = getPasswordStrength(form.password);
            return s ? (
              <div style={{ fontSize:"11px", color: s.color, marginTop:"-8px", marginBottom:"8px" }}>
                Password strength: {s.label}
                {s.label === "Weak" && " — min 8 chars, 1 uppercase, 1 number"}
              </div>
            ) : null;
          })()}
          {mode === "register" && input("Organization / Company *", "org_name", "text", "Your company or team name")}
          {mode === "register" && (
            <div style={{ marginBottom: 12 }}>
              <label style={{ display: "block", fontSize: 11, color: "#94A3B8", marginBottom: 4, textTransform: "uppercase", letterSpacing: 1 }}>
                Access Code (optional)
              </label>
              <input
                type="text"
                placeholder="ALPHA-001 or ZYPP-PILOT"
                style={{
                  width: "100%", background: "#1A1A35", border: "1px solid #2A2A4A",
                  borderRadius: 6, padding: "9px 12px", color: "#7C3AED",
                  fontSize: 13, outline: "none", boxSizing: "border-box",
                  fontFamily: "monospace", letterSpacing: 2,
                }}
              />
              <div style={{ fontSize: 11, color: "#334155", marginTop: 4 }}>
                Enter your access code to unlock paid features
              </div>
            </div>
          )}

          {error && (
            <div style={{
              background: "#2A0A0A", border: "1px solid #EF4444",
              borderRadius: 6, padding: "8px 12px", marginBottom: 12,
              fontSize: 12, color: "#FCA5A5",
            }}>
              {error}
            </div>
          )}

          <button type="submit" disabled={loading}
            style={{
              width: "100%", background: loading ? "#2D1A5A" : "#7C3AED",
              border: "none", borderRadius: 6, padding: "10px",
              color: "#fff", fontSize: 14, fontWeight: 700, cursor: loading ? "not-allowed" : "pointer",
              marginTop: 4,
            }}>
            {loading ? "Please wait..." : mode === "login" ? "Sign In" : "Create Account"}
          </button>
        </form>

        {/* Close */}
        {onClose && (
          <button onClick={onClose} style={{
            position: "absolute", top: 16, right: 16,
            background: "none", border: "none", color: "#475569",
            cursor: "pointer", fontSize: 18,
          }}>✕</button>
        )}

        {/* Footer */}
        <div style={{ marginTop: 20, textAlign: "center", fontSize: 11, color: "#334155" }}>
          {mode === "login" ? "Don't have an account? " : "Already have an account? "}
          <span
            onClick={() => { setMode(mode === "login" ? "register" : "login"); setError(""); }}
            style={{ color: "#7C3AED", cursor: "pointer" }}>
            {mode === "login" ? "Create one" : "Sign in"}
          </span>
        </div>
      </div>
    </div>
  );
}
