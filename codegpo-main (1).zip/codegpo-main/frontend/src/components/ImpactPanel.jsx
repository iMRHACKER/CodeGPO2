import { useState, useEffect } from "react";
import { useGraphStore } from "../state/graphStore";

function getTypeColor(type) {
  if (!type) return "#555";
  const t = type.toLowerCase();
  if (["user","client","browser","frontend"].some(k => t.includes(k))) return "#f59e0b";
  if (["database","db","sql","mongo"].some(k => t.includes(k)))        return "#0ea5e9";
  if (["api","rest","graphql"].some(k => t.includes(k)))               return "#22c55e";
  if (["service","microservice"].some(k => t.includes(k)))             return "#7c3aed";
  if (["queue","kafka","rabbit","sqs"].some(k => t.includes(k)))       return "#ec4899";
  if (["gateway","proxy","nginx"].some(k => t.includes(k)))            return "#f97316";
  if (["worker","job","cron"].some(k => t.includes(k)))                return "#8b5cf6";
  if (["external","vendor"].some(k => t.includes(k)))                  return "#64748b";
  if (["cache"].some(k => t.includes(k)))                              return "#06b6d4";
  return "#888";
}

// ── BFS to find all downstream nodes ─────────────────────
function findDownstream(startId, edges, nodes) {
  const visited = new Set();
  const queue   = [startId];
  const result  = []; // { node, depth, path }
  const pathMap = { [startId]: [startId] };

  while (queue.length > 0) {
    const current = queue.shift();
    if (visited.has(current)) continue;
    visited.add(current);

    const children = edges
      .filter(e => e.source === current)
      .map(e => e.target);

    for (const childId of children) {
      if (!visited.has(childId)) {
        const childNode = nodes.find(n => n.id === childId);
        if (childNode) {
          const depth = (pathMap[current] || []).length;
          pathMap[childId] = [...(pathMap[current] || []), childId];
          result.push({ node: childNode, depth, path: pathMap[childId] });
          queue.push(childId);
        }
      }
    }
  }

  return result;
}

// ── BFS to find all upstream nodes ───────────────────────
function findUpstream(startId, edges, nodes) {
  const visited = new Set();
  const queue   = [startId];
  const result  = [];

  while (queue.length > 0) {
    const current = queue.shift();
    if (visited.has(current)) continue;
    visited.add(current);

    const parents = edges
      .filter(e => e.target === current)
      .map(e => e.source);

    for (const parentId of parents) {
      if (!visited.has(parentId)) {
        const parentNode = nodes.find(n => n.id === parentId);
        if (parentNode) {
          result.push({ node: parentNode });
          queue.push(parentId);
        }
      }
    }
  }

  return result;
}

// ── Risk level for a node ─────────────────────────────────
function getRiskLevel(node, violations) {
  const nodeViolations = violations.filter(
    v => v.source === node.id || v.target === node.id
  );
  if (nodeViolations.length >= 2) return "critical";
  if (nodeViolations.length === 1) return "high";
  const t = (node.type || "").toLowerCase();
  if (["database","db"].some(k => t.includes(k))) return "medium";
  if (node.compliance_scope) return "medium";
  return "low";
}

const RISK_COLORS = {
  critical: { color: "#ef4444", bg: "#1a0808", label: "CRITICAL" },
  high:     { color: "#f97316", bg: "#1a1008", label: "HIGH"     },
  medium:   { color: "#f59e0b", bg: "#1a1508", label: "MEDIUM"   },
  low:      { color: "#22c55e", bg: "#0a1f0f", label: "LOW"      },
};

// ── Single affected node row ──────────────────────────────
function AffectedNodeRow({ node, depth, violations }) {
  const color = getTypeColor(node.type);
  const risk  = getRiskLevel(node, violations);
  const rc    = RISK_COLORS[risk];
  const nodeViolations = violations.filter(
    v => v.source === node.id || v.target === node.id
  );

  return (
    <div style={{
      padding: "10px 12px",
      background: "#12122a",
      border: `1px solid ${nodeViolations.length > 0 ? "#2e1f1f" : "#1a1a35"}`,
      borderLeft: `3px solid ${nodeViolations.length > 0 ? rc.color : color}`,
      borderRadius: "7px",
      marginLeft: `${Math.min(depth - 1, 3) * 14}px`,
      display: "flex", alignItems: "center", gap: "10px"
    }}>
      {/* Depth connector */}
      {depth > 1 && (
        <span style={{ color: "#333", fontSize: "10px", marginLeft: "-4px" }}>└</span>
      )}
      <div style={{
        width: "8px", height: "8px", borderRadius: "50%",
        background: color, flexShrink: 0
      }} />
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: "12.5px", fontWeight: "600", color: "#ccc" }}>
          {node.name}
        </div>
        <div style={{ fontSize: "10px", color: "#555", marginTop: "1px" }}>
          {node.type}
          {node.owner ? ` · ${node.owner}` : ""}
        </div>
      </div>
      <div style={{ display: "flex", gap: "5px", alignItems: "center" }}>
        {node.compliance_scope && (
          <span style={{
            fontSize: "9px", color: "#0ea5e9",
            background: "rgba(14,165,233,0.1)",
            border: "1px solid rgba(14,165,233,0.3)",
            padding: "1px 5px", borderRadius: "3px", fontWeight: "700"
          }}>
            {node.compliance_scope.toUpperCase().split(",")[0]}
          </span>
        )}
        <span style={{
          fontSize: "9.5px", fontWeight: "700",
          padding: "2px 6px", borderRadius: "4px",
          background: rc.bg, color: rc.color,
          border: `1px solid ${rc.color}33`
        }}>
          {rc.label}
        </span>
        {nodeViolations.length > 0 && (
          <span style={{
            fontSize: "10px", color: "#854444",
            background: "#2a1515",
            padding: "2px 6px", borderRadius: "4px", fontWeight: "600"
          }}>
            {nodeViolations.length} violation{nodeViolations.length > 1 ? "s" : ""}
          </span>
        )}
      </div>
    </div>
  );
}

// ── Main ImpactPanel ──────────────────────────────────────
export default function ImpactPanel({ onClose }) {
  const { selectedNode, nodes, edges, violations } = useGraphStore();
  const [view, setView] = useState("downstream");

  if (!selectedNode) return null;

  const downstream = findDownstream(selectedNode.id, edges, nodes);
  const upstream   = findUpstream(selectedNode.id, edges, nodes);

  const downstreamWithViolations = downstream.filter(
    ({ node }) => violations.some(v => v.source === node.id || v.target === node.id)
  );

  const criticalCount = downstream.filter(
    ({ node }) => getRiskLevel(node, violations) === "critical"
  ).length;

  const highCount = downstream.filter(
    ({ node }) => ["critical", "high"].includes(getRiskLevel(node, violations))
  ).length;

  const color = getTypeColor(selectedNode.type);

  return (
    <div style={{
      position: "fixed", top: 0, right: 0, bottom: 0,
      width: "380px",
      background: "#0d0d1f",
      borderLeft: "1px solid #22224a",
      zIndex: 450, display: "flex", flexDirection: "column",
      overflow: "hidden"
    }}>

      {/* Header */}
      <div style={{ padding: "16px", borderBottom: "1px solid #202020", flexShrink: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <span style={{ fontSize: "16px" }}>⚡</span>
              <div style={{ fontSize: "13px", fontWeight: "700", color: "#e5e5e5" }}>
                Change Impact
              </div>
            </div>
            <div style={{ fontSize: "11px", color: "#555", marginTop: "3px" }}>
              If <span style={{ color }}>{selectedNode.name}</span> changes, what's affected?
            </div>
          </div>
          <button onClick={onClose} style={{
            background: "transparent", border: "none",
            color: "#555", cursor: "pointer", fontSize: "20px"
          }}>×</button>
        </div>

        {/* Risk summary */}
        <div style={{
          display: "grid", gridTemplateColumns: "1fr 1fr 1fr",
          gap: "8px", marginTop: "14px", paddingTop: "12px",
          borderTop: "1px solid #161632"
        }}>
          <div style={{
            textAlign: "center", padding: "8px",
            background: "#12122a", border: "1px solid #1a1a35", borderRadius: "7px"
          }}>
            <div style={{ fontSize: "18px", fontWeight: "700", color: "#e5e5e5" }}>
              {downstream.length}
            </div>
            <div style={{ fontSize: "10px", color: "#555", marginTop: "2px" }}>Downstream</div>
          </div>
          <div style={{
            textAlign: "center", padding: "8px",
            background: criticalCount > 0 ? "#1a0808" : "#12122a",
            border: `1px solid ${criticalCount > 0 ? "#2e1010" : "#1a1a35"}`,
            borderRadius: "7px"
          }}>
            <div style={{ fontSize: "18px", fontWeight: "700", color: criticalCount > 0 ? "#ef4444" : "#555" }}>
              {criticalCount}
            </div>
            <div style={{ fontSize: "10px", color: "#555", marginTop: "2px" }}>Critical</div>
          </div>
          <div style={{
            textAlign: "center", padding: "8px",
            background: downstreamWithViolations.length > 0 ? "#1a1008" : "#12122a",
            border: `1px solid ${downstreamWithViolations.length > 0 ? "#2e1a10" : "#1a1a35"}`,
            borderRadius: "7px"
          }}>
            <div style={{
              fontSize: "18px", fontWeight: "700",
              color: downstreamWithViolations.length > 0 ? "#f97316" : "#555"
            }}>
              {downstreamWithViolations.length}
            </div>
            <div style={{ fontSize: "10px", color: "#555", marginTop: "2px" }}>Violated</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", borderBottom: "1px solid #161632", flexShrink: 0 }}>
        {[
          { id: "downstream", label: `Downstream (${downstream.length})` },
          { id: "upstream",   label: `Upstream (${upstream.length})`     },
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setView(t.id)}
            style={{
              flex: 1, padding: "10px 4px",
              background: view === t.id ? "#12122a" : "transparent",
              border: "none",
              borderBottom: view === t.id ? "2px solid #f59e0b" : "2px solid transparent",
              color: view === t.id ? "#ccc" : "#555",
              cursor: "pointer", fontSize: "11px", fontWeight: "600"
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Body */}
      <div style={{
        flex: 1, overflowY: "auto", padding: "14px 16px",
        scrollbarWidth: "thin", scrollbarColor: "#2a2a55 transparent",
        display: "flex", flexDirection: "column", gap: "6px"
      }}>

        {view === "downstream" && (
          <>
            {downstream.length === 0 ? (
              <div style={{
                padding: "20px", background: "#12122a",
                border: "1px solid #1a1a35", borderRadius: "8px",
                textAlign: "center", color: "#444", fontSize: "12px"
              }}>
                No downstream dependencies.<br />
                <span style={{ fontSize: "11px", color: "#333" }}>
                  This component doesn't send data to anything.
                </span>
              </div>
            ) : (
              <>
                {criticalCount > 0 && (
                  <div style={{
                    padding: "10px 12px", marginBottom: "4px",
                    background: "#1a0808", border: "1px solid #2e1010",
                    borderLeft: "3px solid #ef4444",
                    borderRadius: "7px", fontSize: "12px", color: "#cc8888"
                  }}>
                    ⚠ {criticalCount} critical component{criticalCount > 1 ? "s" : ""} affected — changes here could cascade to production
                  </div>
                )}
                {downstream.map(({ node, depth }, i) => (
                  <AffectedNodeRow
                    key={node.id + i}
                    node={node}
                    depth={depth}
                    violations={violations}
                  />
                ))}
              </>
            )}
          </>
        )}

        {view === "upstream" && (
          <>
            {upstream.length === 0 ? (
              <div style={{
                padding: "20px", background: "#12122a",
                border: "1px solid #1a1a35", borderRadius: "8px",
                textAlign: "center", color: "#444", fontSize: "12px"
              }}>
                No upstream dependencies.<br />
                <span style={{ fontSize: "11px", color: "#333" }}>
                  Nothing depends on this component.
                </span>
              </div>
            ) : (
              <>
                <div style={{ fontSize: "11px", color: "#555", marginBottom: "6px" }}>
                  These components send data to <span style={{ color }}>{selectedNode.name}</span>
                </div>
                {upstream.map(({ node }, i) => (
                  <AffectedNodeRow
                    key={node.id + i}
                    node={node}
                    depth={1}
                    violations={violations}
                  />
                ))}
              </>
            )}
          </>
        )}
      </div>

      {/* Footer */}
      <div style={{
        padding: "10px 16px", borderTop: "1px solid #161632",
        fontSize: "10px", color: "#333"
      }}>
        Change impact analysis — based on live graph connections
      </div>
    </div>
  );
}
