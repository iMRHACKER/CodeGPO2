import { useState } from "react";
import { useGraphStore } from "../state/graphStore";
import { apiFetch } from "../api/graphApi";

const BACKEND = import.meta.env.VITE_API_URL || "http://localhost:8000";

const LANGUAGES = ["python", "javascript", "typescript", "java", "go", "rust"];

const FIX_GUIDES = {
  "GOV-001": "Use Repository pattern — create a class that wraps DB operations",
  "GOV-002": "Use os.getenv('KEY') instead of hardcoded values",
  "GOV-003": "Replace eval()/exec() with safe alternatives",
  "GOV-004": "Replace SELECT * with specific column names",
  "GOV-005": "Replace 'except Exception' with specific exceptions like 'except ValueError'",
  "GOV-006": "Replace print() with logging.info() or logging.error()",
  "GOV-007": "Replace http:// with https://",
  "GOV-008": "Remove TODO/FIXME comments or create proper tickets",
};

function ViolationBadge({ severity }) {
  const colors = {
    CRITICAL: { bg: "#1a0505", border: "#5a1a1a", text: "#ff6b6b" },
    HIGH:     { bg: "#1a1005", border: "#5a3a0a", text: "#f59e0b" },
    MEDIUM:   { bg: "#0a0a1a", border: "#1a1a5a", text: "#60a5fa" },
    LOW:      { bg: "#0a1a0a", border: "#1a4a1a", text: "#6ee7b7" },
  };
  const c = colors[severity] || colors.LOW;
  return (
    <span style={{
      fontSize: "10px", fontWeight: "700", padding: "2px 8px",
      borderRadius: "4px", background: c.bg, border: `1px solid ${c.border}`,
      color: c.text, letterSpacing: "0.5px", flexShrink: 0
    }}>
      {severity}
    </span>
  );
}

export default function CodeGenPanel({ onClose }) {
  const { nodes, edges } = useGraphStore();
  const [requirement, setRequirement] = useState("");
  const [language, setLanguage] = useState("python");
  const [provider, setProvider] = useState("groq");
  const [loading, setLoading] = useState(false);
  const [fixing, setFixing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  const callGenerate = async (req_text) => {
    const res = await apiFetch(`/codegen/generate`, {
      method: "POST",
      body: JSON.stringify({
        requirement: req_text,
        language,
        provider,
        architecture_context: nodes.length > 0 ? { nodes, edges } : null
      })
    });
    if (!res || !res.ok) throw new Error("Generation failed");
    return await res.json();
  };

  const handleGenerate = async () => {
    if (!requirement.trim()) return;
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const data = await callGenerate(requirement.trim());
      setResult(data);
    } catch (e) {
      setError(e.message || "Failed to generate code");
    } finally {
      setLoading(false);
    }
  };

  const handleAutoFix = async () => {
    if (!result || result.violations.length === 0) return;
    setFixing(true);
    setError("");
    try {
      // Wait 8 seconds to avoid Groq rate limit
      await new Promise(resolve => setTimeout(resolve, 8000));
      const violationList = result.violations.map(v => `- ${v.ruleId}: ${v.message}`).join("\n");
      const fixReq = `Fix ALL governance violations in this code and return ONLY the corrected code:\n\nCODE:\n${result.code}\n\nVIOLATIONS TO FIX:\n${violationList}`;
      const data = await callGenerate(fixReq);
      setResult(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setFixing(false);
    }
  };

  const handleCopy = () => {
    if (result?.code) {
      navigator.clipboard.writeText(result.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const scoreColor = result
    ? result.compliance_score >= 80 ? "#22c55e"
    : result.compliance_score >= 60 ? "#f59e0b" : "#ef4444"
    : "#555";

  const criticalCount = result ? result.violations.filter(v => v.severity === "CRITICAL").length : 0;
  const highCount = result ? result.violations.filter(v => v.severity === "HIGH").length : 0;

  return (
    <div style={{
      position: "fixed", inset: 0,
      background: "rgba(0,0,0,0.88)",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 3000, padding: "20px"
    }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: "#0d0d1f", border: "1px solid #22224a",
        borderRadius: "16px", width: "820px", maxHeight: "92vh",
        display: "flex", flexDirection: "column", overflow: "hidden",
        boxShadow: "0 30px 80px rgba(0,0,0,0.7)"
      }}>

        {/* Header */}
        <div style={{
          padding: "20px 24px 16px", borderBottom: "1px solid #1a1a35",
          display: "flex", justifyContent: "space-between", alignItems: "flex-start"
        }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <span style={{ fontSize: "20px" }}>⚡</span>
              <h2 style={{ color: "#e5e5e5", margin: 0, fontSize: "16px", fontWeight: "700" }}>
                Governed Code Generator
              </h2>
              <span style={{
                fontSize: "9.5px", fontWeight: "700", letterSpacing: "1px",
                background: "rgba(124,58,237,0.15)", border: "1px solid rgba(124,58,237,0.4)",
                color: "#a78bfa", padding: "2px 8px", borderRadius: "4px"
              }}>CODEGPO</span>
            </div>
            <p style={{ color: "#555", fontSize: "12px", margin: "5px 0 0" }}>
              AI generates code → CodeGPO governance check → Compliant code delivered
            </p>
          </div>
          <button onClick={onClose} style={{ background: "transparent", border: "none", color: "#555", cursor: "pointer", fontSize: "20px" }}>×</button>
        </div>

        <div style={{
          flex: 1, overflowY: "auto", padding: "20px 24px",
          scrollbarWidth: "thin", scrollbarColor: "#2a2a55 transparent"
        }}>

          {/* Requirement Input */}
          <div style={{ marginBottom: "16px" }}>
            <div style={{ fontSize: "11px", color: "#555", marginBottom: "8px", letterSpacing: "0.5px", textTransform: "uppercase" }}>
              What do you want to build?
            </div>
            <textarea
              value={requirement}
              onChange={e => setRequirement(e.target.value)}
              placeholder="e.g. Create a user authentication service with JWT tokens and password hashing..."
              rows={4}
              style={{
                width: "100%", background: "#0d0d1f",
                border: "1px solid #1a1a35", borderRadius: "10px",
                padding: "14px", color: "#e5e5e5", fontSize: "13px",
                resize: "vertical", outline: "none", fontFamily: "inherit",
                lineHeight: "1.6", boxSizing: "border-box"
              }}
              onFocus={e => e.target.style.borderColor = "#7c3aed"}
              onBlur={e => e.target.style.borderColor = "#1a1a35"}
            />
          </div>

          {/* Controls */}
          <div style={{ display: "flex", gap: "12px", marginBottom: "20px", flexWrap: "wrap" }}>
            <div style={{ flex: 1, minWidth: "140px" }}>
              <div style={{ fontSize: "11px", color: "#555", marginBottom: "6px", textTransform: "uppercase", letterSpacing: "0.5px" }}>Language</div>
              <select value={language} onChange={e => setLanguage(e.target.value)} style={{
                width: "100%", background: "#0d0d1f", border: "1px solid #1a1a35",
                borderRadius: "8px", padding: "9px 12px", color: "#ccc",
                fontSize: "13px", outline: "none", cursor: "pointer"
              }}>
                {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
              </select>
            </div>

            <div style={{ flex: 1, minWidth: "140px" }}>
              <div style={{ fontSize: "11px", color: "#555", marginBottom: "6px", textTransform: "uppercase", letterSpacing: "0.5px" }}>AI Provider</div>
              <div style={{ display: "flex", gap: "8px" }}>
                {["groq", "gemini"].map(p => (
                  <button key={p} onClick={() => setProvider(p)} style={{
                    flex: 1, padding: "9px 12px", borderRadius: "8px",
                    border: `1px solid ${provider === p ? "#7c3aed" : "#1a1a35"}`,
                    background: provider === p ? "rgba(124,58,237,0.15)" : "#0d0d1f",
                    color: provider === p ? "#a78bfa" : "#666",
                    cursor: "pointer", fontSize: "12px", fontWeight: "600"
                  }}>
                    {p === "groq" ? "⚡ Groq" : "◈ Gemini"}
                  </button>
                ))}
              </div>
            </div>

            {nodes.length > 0 && (
              <div style={{ flex: 1, minWidth: "140px" }}>
                <div style={{ fontSize: "11px", color: "#555", marginBottom: "6px", textTransform: "uppercase", letterSpacing: "0.5px" }}>Architecture</div>
                <div style={{
                  padding: "9px 12px", borderRadius: "8px",
                  border: "1px solid #1a2e1e", background: "#0f1a12",
                  fontSize: "12px", color: "#5a9e6f"
                }}>✓ {nodes.length} nodes loaded</div>
              </div>
            )}
          </div>

          {/* Generate Button */}
          <button
            onClick={handleGenerate}
            disabled={loading || !requirement.trim()}
            style={{
              width: "100%", padding: "14px",
              background: loading || !requirement.trim()
                ? "#1a1a35"
                : "linear-gradient(135deg, #7c3aed, #0ea5e9)",
              border: "none", borderRadius: "10px",
              color: loading || !requirement.trim() ? "#555" : "#fff",
              fontSize: "14px", fontWeight: "700",
              cursor: loading || !requirement.trim() ? "not-allowed" : "pointer",
              marginBottom: "20px"
            }}
          >
            {loading ? "⏳ Generating & Governing..." : "⚡ Generate Governed Code"}
          </button>

          {/* Error */}
          {error && (
            <div style={{
              padding: "12px 16px", background: "#1a1010",
              border: "1px solid #2e1a1a", borderLeft: "3px solid #cc6666",
              borderRadius: "8px", fontSize: "12.5px", color: "#cc8888", marginBottom: "16px"
            }}>⚠ {error}</div>
          )}

          {/* Result */}
          {result && (
            <div>
              {/* Score Card */}
              <div style={{
                display: "flex", gap: "16px", marginBottom: "16px",
                padding: "16px", background: "#12122a",
                border: "1px solid #1a1a35", borderRadius: "12px", alignItems: "center"
              }}>
                <div style={{ textAlign: "center", minWidth: "80px" }}>
                  <div style={{ fontSize: "36px", fontWeight: "800", color: scoreColor, lineHeight: 1 }}>
                    {result.compliance_score}
                  </div>
                  <div style={{ fontSize: "11px", color: "#555" }}>/ 100</div>
                  <div style={{ fontSize: "10px", color: scoreColor, fontWeight: "600", marginTop: "4px" }}>
                    {result.is_compliant ? "COMPLIANT ✓" : "VIOLATIONS ⚠"}
                  </div>
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: "13px", fontWeight: "600", color: "#e5e5e5", marginBottom: "6px" }}>
                    CodeGPO Governance Report
                  </div>
                  <div style={{ fontSize: "12px", color: "#666" }}>
                    Provider: <span style={{ color: "#888" }}>{result.provider}</span>
                    {" · "}Language: <span style={{ color: "#888" }}>{result.language}</span>
                    {" · "}Violations: <span style={{ color: result.violations.length > 0 ? "#f59e0b" : "#5a9e6f" }}>{result.violations.length}</span>
                  </div>
                  {nodes.length > 0 && (
                    <div style={{ fontSize: "11px", color: "#5a9e6f", marginTop: "4px" }}>
                      ✓ Architecture context applied — {nodes.length} nodes considered
                    </div>
                  )}
                </div>
              </div>

              {/* Violations */}
              {result.violations.length > 0 && (
                <div style={{ marginBottom: "16px" }}>
                  <div style={{ fontSize: "11px", color: "#555", marginBottom: "8px", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                    Governance Violations Found
                  </div>

                  {result.violations.map((v, i) => (
                    <div key={i} style={{
                      padding: "10px 12px", marginBottom: "6px",
                      background: "#12122a", border: "1px solid #1a1a35",
                      borderLeft: `3px solid ${v.severity === "CRITICAL" ? "#ef4444" : v.severity === "HIGH" ? "#f59e0b" : v.severity === "MEDIUM" ? "#60a5fa" : "#6ee7b7"}`,
                      borderRadius: "6px"
                    }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "4px" }}>
                        <ViolationBadge severity={v.severity} />
                        <span style={{ fontSize: "11px", color: "#555" }}>{v.ruleId}</span>
                      </div>
                      <div style={{ fontSize: "12px", color: "#aaa", marginBottom: "4px" }}>{v.message}</div>
                      {FIX_GUIDES[v.ruleId] && (
                        <div style={{ fontSize: "11px", color: "#5a7a6f", fontStyle: "italic" }}>
                          💡 Fix: {FIX_GUIDES[v.ruleId]}
                        </div>
                      )}
                    </div>
                  ))}

                  {/* Auto Fix Button */}
                  <button
                    onClick={handleAutoFix}
                    disabled={fixing}
                    style={{
                      width: "100%", padding: "12px", marginTop: "8px",
                      background: fixing ? "#1a1a35" : "rgba(239,68,68,0.1)",
                      border: `1px solid ${fixing ? "#22224a" : "rgba(239,68,68,0.35)"}`,
                      color: fixing ? "#555" : "#f87171",
                      borderRadius: "8px", cursor: fixing ? "not-allowed" : "pointer",
                      fontSize: "13px", fontWeight: "700", transition: "all 0.2s"
                    }}
                  >
                    {fixing ? "⏳ Auto-Fixing... (please wait)" : "🔧 Auto-Fix All Violations"}
                  </button>
                </div>
              )}

              {/* Generated Code */}
              <div>
                <div style={{
                  display: "flex", justifyContent: "space-between",
                  alignItems: "center", marginBottom: "8px"
                }}>
                  <div style={{ fontSize: "11px", color: "#555", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                    {result.is_compliant ? "✓ Governed Code — Ready to Use" : "⚠ Code with Remaining Violations"}
                  </div>
                  <button onClick={handleCopy} style={{
                    background: copied ? "#0f1a12" : "#1a1a35",
                    border: `1px solid ${copied ? "#1a2e1e" : "#2a2a55"}`,
                    color: copied ? "#5a9e6f" : "#888",
                    padding: "5px 12px", borderRadius: "6px",
                    cursor: "pointer", fontSize: "11px", fontWeight: "600"
                  }}>
                    {copied ? "✓ Copied!" : "Copy Code"}
                  </button>
                </div>
                <pre style={{
                  background: "#08080f", border: "1px solid #161632",
                  borderRadius: "10px", padding: "16px",
                  overflowX: "auto", overflowY: "auto", maxHeight: "400px",
                  margin: 0, fontSize: "12px", lineHeight: "1.7",
                  color: "#c9d1d9", fontFamily: "'IBM Plex Mono', 'Fira Code', monospace",
                  whiteSpace: "pre", scrollbarWidth: "thin",
                  scrollbarColor: "#2a2a55 transparent"
                }}>
                  <code>{result.code}</code>
                </pre>
              </div>

              {/* Regenerate */}
              <button onClick={handleGenerate} disabled={loading} style={{
                width: "100%", padding: "10px", marginTop: "12px",
                background: "transparent", border: "1px solid #22224a",
                color: "#666", borderRadius: "8px",
                cursor: loading ? "not-allowed" : "pointer", fontSize: "12px"
              }}>
                ↺ Regenerate
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
