import { useState } from "react";

const API = import.meta.env.VITE_API_URL || "https://codegpo-production-9548.up.railway.app";
const PLAN_LABEL = { free:"Free", pro:"Pro", developer:"Pro", team:"Pro", enterprise:"Enterprise", custom:"Custom" };
const PLAN_COLOR = { free:"#64748B", pro:"#7C3AED", developer:"#7C3AED", team:"#7C3AED", enterprise:"#F97316", custom:"#06B6D4" };

export default function UserSettings({ user, onClose, onLogout }) {
  const [tab, setTab]               = useState("profile");
  const [name, setName]             = useState(user ? user.name || "" : "");
  const [oldPass, setOldPass]       = useState("");
  const [newPass, setNewPass]       = useState("");
  const [confirmPass, setConfirmPass] = useState("");
  const [deleteConfirm, setDeleteConfirm] = useState("");
  const [loading, setLoading]       = useState(false);
  const [msg, setMsg]               = useState(null);

  const email = user ? user.email || "" : "";
  const plan  = user ? user.plan  || "free" : "free";
  const label = PLAN_LABEL[plan] || "Free";
  const color = PLAN_COLOR[plan] || "#64748B";
  const token = localStorage.getItem("codegpo_token");

  function showMsg(text, ok) {
    setMsg({ text, ok: ok !== false });
    setTimeout(function(){ setMsg(null); }, 3000);
  }

  async function callAPI(path, method, body) {
    var opts = {
      method: method || "GET",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + token }
    };
    if (body) opts.body = JSON.stringify(body);
    var r = await fetch(API + path, opts);
    var d = await r.json();
    if (!r.ok) throw new Error(d.detail || "Error");
    return d;
  }

  async function saveProfile() {
    if (!name.trim()) { showMsg("Name cannot be empty", false); return; }
    setLoading(true);
    try {
      await callAPI("/api/auth/me/update", "POST", { name: name.trim() });
      var stored = JSON.parse(localStorage.getItem("codegpo_user") || "{}");
      localStorage.setItem("codegpo_user", JSON.stringify(Object.assign({}, stored, { name: name.trim() })));
      showMsg("Profile updated");
    } catch(e) { showMsg(e.message, false); }
    setLoading(false);
  }

  async function changePassword() {
    if (!oldPass || !newPass || !confirmPass) { showMsg("Fill all fields", false); return; }
    if (newPass.length < 6) { showMsg("Min 6 characters", false); return; }
    if (newPass !== confirmPass) { showMsg("Passwords don't match", false); return; }
    setLoading(true);
    try {
      await callAPI("/api/auth/me/change-password", "POST", { old_password: oldPass, new_password: newPass });
      showMsg("Password changed");
      setOldPass(""); setNewPass(""); setConfirmPass("");
    } catch(e) { showMsg(e.message, false); }
    setLoading(false);
  }

  async function deleteAccount() {
    if (deleteConfirm !== email) { showMsg("Email doesn't match", false); return; }
    setLoading(true);
    try {
      await callAPI("/api/auth/me/delete", "DELETE");
      localStorage.clear();
      if (onLogout) onLogout();
    } catch(e) { showMsg(e.message, false); }
    setLoading(false);
  }

  var INP  = { width:"100%", padding:"10px 14px", background:"#08080F", border:"1px solid #1E1E3A", borderRadius:"8px", color:"#CBD5E1", fontSize:"13px", outline:"none", boxSizing:"border-box", marginBottom:"14px" };
  var LBL  = { display:"block", fontSize:"11px", color:"#475569", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" };
  var BTN  = { padding:"10px 20px", background:"#7C3AED", border:"none", borderRadius:"8px", color:"#fff", fontSize:"13px", fontWeight:"600", cursor:"pointer", width:"100%" };
  var CARD = { background:"#08080F", border:"1px solid #1A1A35", borderRadius:"12px", padding:"16px", marginBottom:"14px" };
  var TABS = ["Profile","Password","Plan","Danger"];

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.85)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:3000 }}
      onClick={function(e){ if(e.target === e.currentTarget) onClose(); }}>
      <div style={{ background:"#0D0D1F", border:"1px solid #1A1A35", borderRadius:"16px", width:"500px", maxHeight:"88vh", display:"flex", flexDirection:"column", overflow:"hidden" }}>

        <div style={{ padding:"18px 22px", borderBottom:"1px solid #1A1A35", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div>
            <div style={{ fontSize:"15px", fontWeight:"700", color:"#E2E8F0" }}>Account Settings</div>
            <div style={{ fontSize:"11px", color:"#475569", marginTop:"2px" }}>{email}</div>
          </div>
          <button onClick={onClose} style={{ background:"none", border:"none", color:"#475569", fontSize:"22px", cursor:"pointer" }}>x</button>
        </div>

        <div style={{ display:"flex", borderBottom:"1px solid #1A1A35" }}>
          {TABS.map(function(t) {
            var active = tab === t.toLowerCase();
            return (
              <button key={t} onClick={function(){ setTab(t.toLowerCase()); }}
                style={{ flex:1, padding:"12px 4px", background:"none", border:"none", borderBottom: active ? "2px solid #7C3AED" : "2px solid transparent", color: active ? "#A78BFA" : "#475569", fontSize:"12px", fontWeight:"600", cursor:"pointer" }}>
                {t === "Danger" ? "Danger" : t}
              </button>
            );
          })}
        </div>

        <div style={{ padding:"22px", overflowY:"auto", flex:1 }}>

          {tab === "profile" && (
            <div>
              <label style={LBL}>Full Name</label>
              <input style={INP} value={name} onChange={function(e){ setName(e.target.value); }} placeholder="Your name" />
              <label style={LBL}>Email</label>
              <input style={Object.assign({}, INP, { opacity:0.5 })} value={email} disabled />
              <div style={{ fontSize:"11px", color:"#334155", marginBottom:"14px" }}>Email cannot be changed</div>
              <button style={BTN} onClick={saveProfile} disabled={loading}>{loading ? "Saving..." : "Save Profile"}</button>
            </div>
          )}

          {tab === "password" && (
            <div>
              <label style={LBL}>Current Password</label>
              <input style={INP} type="password" value={oldPass} onChange={function(e){ setOldPass(e.target.value); }} placeholder="Current password" />
              <label style={LBL}>New Password</label>
              <input style={INP} type="password" value={newPass} onChange={function(e){ setNewPass(e.target.value); }} placeholder="New password" />
              <label style={LBL}>Confirm New Password</label>
              <input style={INP} type="password" value={confirmPass} onChange={function(e){ setConfirmPass(e.target.value); }} placeholder="Confirm password" />
              <button style={BTN} onClick={changePassword} disabled={loading}>{loading ? "Changing..." : "Change Password"}</button>
            </div>
          )}

          {tab === "plan" && (
            <div>
              <div style={Object.assign({}, CARD, { border:"1px solid " + color + "44" })}>
                <div style={{ fontSize:"11px", color:"#475569", textTransform:"uppercase", letterSpacing:"1px", marginBottom:"8px" }}>Current Plan</div>
                <div style={{ fontSize:"24px", fontWeight:"800", color:color }}>{label}</div>
              </div>

              {plan === "free" && (
                <div style={CARD}>
                  <div style={{ fontSize:"12px", color:"#475569", marginBottom:"10px" }}>Free plan limits:</div>
                  {["10 nodes max","5 connections max","No PDF reports","No AI explain","No GitHub PR"].map(function(f){
                    return <div key={f} style={{ fontSize:"12px", color:"#EF4444", marginBottom:"5px" }}>x {f}</div>;
                  })}
                </div>
              )}

              {(plan === "pro" || plan === "developer" || plan === "team") && (
                <div style={CARD}>
                  {["Unlimited nodes & connections","PDF compliance reports","AI explain violations","GitHub PR gate","Schema generation"].map(function(f){
                    return <div key={f} style={{ fontSize:"12px", color:"#22C55E", marginBottom:"5px" }}>✓ {f}</div>;
                  })}
                </div>
              )}

              {(plan === "enterprise" || plan === "custom") && (
                <div style={CARD}>
                  {["Everything in Pro","Real-time team collaboration","Custom policy rules","Priority support","Onboarding call"].map(function(f){
                    return <div key={f} style={{ fontSize:"12px", color:"#22C55E", marginBottom:"5px" }}>✓ {f}</div>;
                  })}
                </div>
              )}

              {plan === "free" && (
                <a href="mailto:harsh@codegpo.com?subject=Upgrade to Pro"
                  style={{ display:"block", textAlign:"center", textDecoration:"none", padding:"10px", background:"#7C3AED", borderRadius:"8px", color:"#fff", fontSize:"13px", fontWeight:"600" }}>
                  Upgrade to Pro - Rs.999/month
                </a>
              )}
              {(plan === "pro" || plan === "developer" || plan === "team") && (
                <a href="mailto:harsh@codegpo.com?subject=Upgrade to Enterprise"
                  style={{ display:"block", textAlign:"center", textDecoration:"none", padding:"10px", background:"#F97316", borderRadius:"8px", color:"#fff", fontSize:"13px", fontWeight:"600" }}>
                  Upgrade to Enterprise - Rs.4999/month
                </a>
              )}
            </div>
          )}

          {tab === "danger" && (
            <div style={Object.assign({}, CARD, { background:"#1C0A0A", border:"1px solid #EF444433" })}>
              <div style={{ fontSize:"13px", fontWeight:"700", color:"#EF4444", marginBottom:"8px" }}>Delete Account</div>
              <div style={{ fontSize:"12px", color:"#94A3B8", marginBottom:"16px" }}>Permanently deletes your account and all data. Cannot be undone.</div>
              <label style={LBL}>Type your email: {email}</label>
              <input style={Object.assign({}, INP, { borderColor:"#EF444433" })} value={deleteConfirm} onChange={function(e){ setDeleteConfirm(e.target.value); }} placeholder={email} />
              <button style={{ padding:"10px", background: deleteConfirm === email ? "#EF4444" : "#333", border:"none", borderRadius:"8px", color:"#fff", fontSize:"13px", cursor: deleteConfirm === email ? "pointer" : "not-allowed", width:"100%" }}
                onClick={deleteAccount} disabled={loading || deleteConfirm !== email}>
                {loading ? "Deleting..." : "Delete My Account"}
              </button>
            </div>
          )}

          {msg && (
            <div style={{ marginTop:"16px", padding:"10px 14px", background: msg.ok ? "#0A2D1A" : "#2D0A0A", borderRadius:"8px", fontSize:"12px", color: msg.ok ? "#22C55E" : "#EF4444" }}>
              {msg.text}
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
