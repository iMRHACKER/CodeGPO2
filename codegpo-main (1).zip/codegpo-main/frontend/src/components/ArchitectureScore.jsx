import { useMemo } from "react";
import { useGraphStore } from "../state/graphStore";
import { useRulesStore } from "../state/rulesStore";
import { calculateScore } from "../core/architectureScore";
import { SEVERITY } from "../core/governanceEngine";
import SeverityBadge from "./SeverityBadge";

function ScoreRing({ score, grade, gradeColor, size = 120 }) {
  const radius = (size - 16) / 2;
  const circumference = 2 * Math.PI * radius;
  const filled = (score / 100) * circumference;
  const empty = circumference - filled;

  return (
    <div style={{ position: "relative", width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#1a1a35" strokeWidth="8" />
        <circle
          cx={size / 2} cy={size / 2} r={radius}
          fill="none" stroke={gradeColor} strokeWidth="8"
          strokeDasharray={`${filled} ${empty}`}
          strokeLinecap="round"
          style={{ transition: "stroke-dasharray 0.6s ease" }}
        />
      </svg>
      <div style={{
        position: "absolute", inset: 0,
        display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center"
      }}>
        <div style={{ fontSize: "28px", fontWeight: "800", color: gradeColor, lineHeight: 1 }}>
          {score}
        </div>
        <div style={{ fontSize: "11px", color: "#555", marginTop: "2px" }}>/ 100</div>
      </div>
    </div>
  );
}

export default function ArchitectureScore({ onClose }) {
  const { nodes, edges, violations } = useGraphStore();
  const { evaluateCustomRules } = useRulesStore();

  const customViolations = evaluateCustomRules(nodes, edges);
  const allViolations = [...violations, ...customViolations];

  const result = useMemo(
    () => calculateScore(nodes, edges, allViolations),
    [nodes.length, edges.length, allViolations.length]
  );

  // Empty state
  if (!result || nodes.length === 0) {
    return (
      <div style={{
        position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
        background: "rgba(0,0,0,0.75)",
        display: "flex", alignItems: "center", justifyContent: "center",
        zIndex: 1000
      }} onClick={e => e.target === e.currentTarget && onClose()}>
        <div style={{
          background: "#0d0d1f", border: "1px solid #22224a",
          borderRadius: "12px", padding: "40px",
          textAlign: "center", color: "#555", fontSize: "13px",
          maxWidth: "360px"
        }}>
          <div style={{ fontSize: "32px", marginBottom: "16px", opacity: 0.4 }}>📊</div>
          <div style={{ color: "#888", marginBottom: "8px", fontWeight: "600" }}>No Score Yet</div>
          Add some components to your architecture to calculate a health score.
          <br />
          <button onClick={onClose} style={{
            marginTop: "20px", background: "#1a1a35",
            border: "1px solid #2a2a55", color: "#ccc",
            padding: "8px 20px", borderRadius: "8px",
            cursor: "pointer", fontSize: "12px"
          }}>
            Close
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
      background: "rgba(0,0,0,0.8)",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 1000, padding: "20px"
    }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: "#0d0d1f", border: "1px solid #22224a",
        borderRadius: "14px", width: "560px",
        maxHeight: "88vh", overflowY: "auto",
        scrollbarWidth: "thin", scrollbarColor: "#2a2a55 transparent"
      }}>

        {/* Header */}
        <div style={{
          padding: "20px 22px", borderBottom: "1px solid #202020",
          display: "flex", justifyContent: "space-between", alignItems: "center"
        }}>
          <div>
            <h2 style={{ color: "#e5e5e5", margin: 0, fontSize: "14px", fontWeight: "600" }}>
              Architecture Health Score
            </h2>
            <p style={{ color: "#555", fontSize: "11px", margin: "4px 0 0" }}>
              {nodes.length} components · {edges.length} connections · {allViolations.length} violations
            </p>
          </div>
          <button onClick={onClose} style={{
            background: "transparent", border: "none",
            color: "#555", cursor: "pointer", fontSize: "20px"
          }}>×</button>
        </div>

        <div style={{ padding: "22px" }}>

          {/* Score hero */}
          <div style={{
            display: "flex", alignItems: "center",
            gap: "28px", padding: "20px",
            background: "#12122a", border: "1px solid #1a1a35",
            borderRadius: "12px", marginBottom: "20px"
          }}>
            <ScoreRing score={result.score} grade={result.grade} gradeColor={result.gradeColor} />
            <div>
              <div style={{ display: "flex", alignItems: "baseline", gap: "10px", marginBottom: "6px" }}>
                <span style={{ fontSize: "40px", fontWeight: "800", color: result.gradeColor, lineHeight: 1 }}>
                  {result.grade}
                </span>
                <span style={{ fontSize: "16px", color: result.gradeColor, fontWeight: "600" }}>
                  {result.status}
                </span>
              </div>
              <div style={{ fontSize: "12px", color: "#666", lineHeight: "1.8" }}>
                <div>−{result.totalDeducted} pts from {result.violationCount} violation{result.violationCount !== 1 ? "s" : ""}</div>
                <div>+{result.totalBonused} pts from good practices</div>
                {result.criticalCount > 0 && (
                  <div style={{ color: "#cc6666", marginTop: "4px", fontWeight: "500" }}>
                    ⚠ {result.criticalCount} critical issue{result.criticalCount !== 1 ? "s" : ""} need immediate attention
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Hurting score */}
          {result.deductions?.length > 0 && (
            <div style={{ marginBottom: "20px" }}>
              <div style={{ fontSize: "10px", color: "#555", letterSpacing: "1px", textTransform: "uppercase", fontWeight: "600", marginBottom: "10px" }}>
                Hurting Your Score
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                {result.deductions.map((d, i) => (
                  <div key={i} style={{
                    display: "flex", alignItems: "center", gap: "10px",
                    padding: "10px 12px", background: "#12122a",
                    border: "1px solid #1a1a35",
                    borderLeft: `3px solid ${SEVERITY[d.severity]?.color || "#555"}`,
                    borderRadius: "6px"
                  }}>
                    <SeverityBadge severity={d.severity} />
                    <span style={{ fontSize: "12px", color: "#aaa", flex: 1 }}>{d.label}</span>
                    <span style={{ fontSize: "12px", fontWeight: "700", color: "#cc6666", minWidth: "40px", textAlign: "right" }}>
                      −{d.points}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Helping score */}
          {result.bonuses?.length > 0 && (
            <div style={{ marginBottom: "20px" }}>
              <div style={{ fontSize: "10px", color: "#555", letterSpacing: "1px", textTransform: "uppercase", fontWeight: "600", marginBottom: "10px" }}>
                Helping Your Score
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                {result.bonuses.map((b, i) => (
                  <div key={i} style={{
                    display: "flex", alignItems: "center", gap: "10px",
                    padding: "10px 12px", background: "#12122a",
                    border: "1px solid #1a1a35", borderLeft: "3px solid #5a9e6f",
                    borderRadius: "6px"
                  }}>
                    <span style={{ fontSize: "12px", color: "#aaa", flex: 1 }}>✓ {b.label}</span>
                    <span style={{ fontSize: "12px", fontWeight: "700", color: "#5a9e6f", minWidth: "40px", textAlign: "right" }}>
                      +{b.points}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* How to improve */}
          {(() => {
            const missing = [
              { id: "HAS_GATEWAY",        label: "Add an API Gateway for centralized routing and auth" },
              { id: "HAS_SERVICE_LAYER",  label: "Add a Service layer to separate business logic" },
              { id: "HAS_QUEUE",          label: "Add async messaging for decoupled communication" },
              { id: "HAS_CACHE",          label: "Add a caching layer to reduce database load" },
              { id: "HAS_WORKER",         label: "Add background workers for heavy async tasks" },
              { id: "NO_DIRECT_CLIENT_DB",label: "Remove direct client-to-database connections" },
              { id: "EXTERNAL_ISOLATED",  label: "Isolate external services from internal infrastructure" },
            ].filter(p => !result.bonuses?.find(b => b.id === p.id));

            if (missing.length === 0) return null;

            return (
              <div>
                <div style={{ fontSize: "10px", color: "#555", letterSpacing: "1px", textTransform: "uppercase", fontWeight: "600", marginBottom: "10px" }}>
                  How to Improve
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: "5px" }}>
                  {missing.slice(0, 4).map((p, i) => (
                    <div key={i} style={{
                      padding: "9px 12px", background: "#0f1a12",
                      border: "1px solid #1a2e1e", borderRadius: "6px",
                      fontSize: "12px", color: "#7aaa8a",
                      display: "flex", alignItems: "center", gap: "8px"
                    }}>
                      <span style={{ color: "#4a7c59" }}>→</span>
                      {p.label}
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}

        </div>
      </div>
    </div>
  );
}
