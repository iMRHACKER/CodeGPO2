import { useState, useEffect } from "react";
import { useGraphStore } from "../state/graphStore";
import { evaluateGovernance, approveViolation, getAccountabilityLog } from "../api/graphApi";

// Stable key matching backend's violation_id logic (ruleId + source + target)
function violationKey(v) {
  return `${v.ruleId}|${v.source || ""}|${v.target || ""}`;
}

const RULE_EXPLANATIONS = {
  "GOV-001": {
    why: "Direct client-to-database connections bypass all security layers. Any user could potentially run arbitrary queries, expose sensitive data, or corrupt records without any validation or authentication.",
    policy: "All database access must go through a Service or API layer that enforces authentication, authorization, input validation, and rate limiting.",
    fix: "Add an API or Service between this client and the database."
  },
  "GOV-002": {
    why: "Clients directly publishing to queues can flood the system with unvalidated messages, cause denial-of-service attacks, or inject malicious payloads into your event pipeline.",
    policy: "Message queues should only receive messages from trusted internal services, not external clients.",
    fix: "Route client requests through a backend Service that validates and publishes to the queue."
  },
  "GOV-003": {
    why: "Databases are passive data stores. When a database initiates outbound calls it creates tight coupling, makes the system harder to debug, and can cause cascading failures.",
    policy: "Databases must remain passive. All data retrieval and writes should be initiated by Services, not by the database itself.",
    fix: "Remove outbound calls from the database. Use event triggers or polling from the Service layer instead."
  },
  "GOV-004": {
    why: "API Gateways exist to handle cross-cutting concerns like auth, rate limiting, and routing. Directly accessing the database bypasses your entire service layer and exposes the data store.",
    policy: "Gateways should route requests to Services only. They must never access databases directly.",
    fix: "Route this connection through the appropriate Service that handles the business logic."
  },
  "GOV-005": {
    why: "External services are outside your trust boundary. Allowing them direct access to your database gives third parties unrestricted access to all your data.",
    policy: "External services must interact with your system only through public-facing APIs that enforce authentication and return only permitted data.",
    fix: "Expose a dedicated API endpoint for this external service with proper auth and data scoping."
  },
  "GOV-006": {
    why: "External services writing directly to internal queues can inject unvalidated events, cause system instability, or be exploited to trigger unintended workflows.",
    policy: "Internal queues are trusted infrastructure. Only internal services should publish to them.",
    fix: "Create an internal Service that receives external requests and publishes validated events to the queue."
  },
  "GOV-007": {
    why: "Clients calling external services directly exposes your API keys, creates CORS vulnerabilities, and makes it impossible to audit or throttle third-party calls.",
    policy: "All calls to external services must be proxied through your backend to keep credentials secure and maintain control.",
    fix: "Move this external call to a backend Service that acts as a secure proxy."
  },
  "GOV-008": {
    why: "Cache contains potentially sensitive data and has no authentication. Direct client access can expose cached data, allow cache poisoning attacks, or bypass security controls.",
    policy: "Cache layers should only be accessed by trusted backend services, never directly by clients.",
    fix: "Access cache through a Service layer that validates requests before reading or writing."
  },
  "GOV-009": {
    why: "GDPR requires that personal data remains within compliant systems. Sending PII to non-GDPR-compliant external services violates data residency and processing requirements.",
    policy: "GDPR: Personal data must only flow to services that are GDPR-compliant and have a valid Data Processing Agreement.",
    fix: "Remove this connection or ensure the target service is GDPR-compliant and tagged accordingly."
  },
  "GOV-010": {
    why: "HIPAA requires that Protected Health Information (PHI) is only accessible through authenticated, audited access paths. Direct access bypasses required safeguards.",
    policy: "HIPAA: PHI databases must only be accessed through authenticated Services or Gateways with full audit logging.",
    fix: "Add an authenticated Service layer between this component and the PHI database."
  },
  "GOV-011": {
    why: "SOC2 requires all external connections to be monitored and logged. Direct external-to-service connections bypass your monitoring gateway.",
    policy: "SOC2: All external traffic must route through a monitored API Gateway that logs all requests.",
    fix: "Route this external connection through your API Gateway."
  },
  "GOV-012": {
    why: "ISO 27001 requires that classified data stores are protected from direct access by untrusted sources. This creates an information security risk.",
    policy: "ISO 27001: Classified data stores must not be directly reachable from untrusted or external sources.",
    fix: "Add a Service or Gateway layer to protect this classified data store."
  },

  // ── New Architecture Rules ─────────────────────────────
  "GOV-013": { why: "IoT devices are untrusted endpoints. Direct database access means a single compromised device can expose your entire data layer.", policy: "IoT/Edge devices must never access databases directly. All device data must flow through an authenticated IoT Gateway.", fix: "Add an IoT Gateway (AWS IoT Core, Azure IoT Hub) that authenticates devices before routing data to services." },
  "GOV-014": { why: "Secrets in client-accessible code are fully exposed. Any user can read API keys, tokens, and credentials from browser memory or source.", policy: "Secrets must only be accessed server-side via environment variables or a dedicated secrets management service.", fix: "Move all secrets to server-side. Use a Secrets Manager (Vault, AWS Secrets Manager) accessible only by backend services." },
  "GOV-015": { why: "Exposed admin panels are primary targets for credential stuffing, brute force, and admin takeover attacks.", policy: "Admin interfaces must be protected by VPN, IP allowlisting, or a hardened authenticated gateway — never directly on the internet.", fix: "Put the admin panel behind VPN or IP allowlisting. Add MFA. Remove from public internet exposure." },
  "GOV-016": { why: "Unauthenticated device-to-queue access allows message injection, replay attacks, and data poisoning of your entire event pipeline.", policy: "IoT devices must authenticate via certificates (mTLS) through an IoT Gateway before any messages are accepted.", fix: "Add an IoT Gateway with device certificate authentication. Validate all device messages before enqueuing." },
  "GOV-017": { why: "Direct worker-to-worker calls create synchronous coupling in async pipelines, causing cascading failures when one worker is slow or down.", policy: "Workers must communicate asynchronously via message queues, never by calling each other directly.", fix: "Publish a completion event to a Queue. Let the downstream Worker consume it independently." },
  "GOV-018": { why: "External services writing directly to internal queues can inject unvalidated events and bypass all security controls.", policy: "Only internal authenticated services should publish to internal queues.", fix: "Route external requests through an API Gateway that validates and then publishes to the queue." },
  "GOV-019": { why: "Gateways are routing layers, not data access layers. Direct DB access from a gateway bypasses your entire service architecture.", policy: "Gateways must route to Services only. Business logic and data access belongs in the Service layer.", fix: "Add a Service between the Gateway and Database to handle business logic and data access." },
  "GOV-020": { why: "Client-to-queue bypasses authentication, rate limiting, and message validation. Malicious users can flood or poison your event queue.", policy: "Queues are internal infrastructure. Clients must only interact with queues through validated API endpoints.", fix: "Add an API endpoint that authenticates the client request before publishing to the queue." },
  "GOV-021": { why: "Cache write-back without business logic validation can corrupt your database with unvalidated data.", policy: "All database writes must go through a Service layer that enforces business rules and validation.", fix: "Route cache write-back through a Service that validates data before writing to the database." },
  "GOV-022": { why: "Gateway chaining adds unnecessary latency, complexity, and creates multiple single points of failure.", policy: "Use a single Gateway layer. For internal service routing, use a service mesh (Istio, Linkerd).", fix: "Consolidate to one gateway. Use service mesh for internal routing between services." },
  "GOV-023": { why: "Clients calling workers directly creates synchronous coupling for inherently async operations.", policy: "All worker invocations from clients must go through an API or Queue as intermediary.", fix: "Create an API endpoint that enqueues the job. Return a job ID to the client for status polling." },
  "GOV-024": { why: "Direct cache access from clients can return stale, unvalidated, or sensitive cached data without authorization checks.", policy: "Cache must only be accessed by trusted backend services that validate and authorize access.", fix: "Add a Service layer that reads from cache, validates the data, and enforces authorization before returning to client." },
  "GOV-025": { why: "Raw database output in monitoring/logs can expose PII, credentials, and sensitive business data to logging systems.", policy: "All data flowing to monitoring systems must be sanitized and masked before transmission.", fix: "Implement structured logging with PII masking middleware before forwarding to monitoring systems." },
  "GOV-026": { why: "Auth services forwarding data to external services may inadvertently leak identity tokens, session data, or user credentials.", policy: "Auth service external integrations must be explicitly scoped and only share minimal required data.", fix: "Audit all data sent to external services from Auth. Ensure only non-sensitive tokens are shared." },
  "GOV-027": { why: "IoT devices authenticating directly to auth services bypass fleet-level access policies and device management controls.", policy: "Device authentication must go through an IoT Gateway that manages device certificates and fleet policies.", fix: "Use mTLS device certificates via IoT Gateway for device authentication. Don't expose auth service to devices." },
  "GOV-028": { why: "Admin panels with direct DB access create no audit trail of admin actions, enabling undetected data manipulation.", policy: "All admin database operations must go through a Service that logs every action with user context and timestamp.", fix: "Add an Admin API Service that proxies all DB operations and logs every action for audit compliance." },
  "GOV-029": { why: "Direct service-to-external calls without circuit breaking can cascade failures across your entire system when the external service is slow or down.", policy: "All external service calls should have circuit breaking, timeouts, and retry policies.", fix: "Add a service mesh (Istio) or use a Gateway with circuit breaking configured for this external connection." },
  "GOV-030": { why: "Device data bypassing your platform means no control over data residency, no ability to audit, and vendor lock-in risk.", policy: "All device telemetry must flow through your internal platform before any external forwarding.", fix: "Route device telemetry through your platform first. Apply data masking and residency controls before forwarding." },

  // ── Compliance Rules ───────────────────────────────────
  "GDPR-001": { why: "GDPR Article 44 prohibits transfer of personal data to countries without adequate data protection.", policy: "GDPR Art. 44: Personal data must only be transferred to GDPR-compliant processors or countries with adequacy decisions.", fix: "Use Standard Contractual Clauses (SCCs) or ensure the processor is in an EU adequacy-list country. Mark the external service as gdpr-compliant." },
  "GDPR-002": { why: "GDPR Article 5(1)(c) requires data minimisation — only necessary personal data should reach the client.", policy: "GDPR Art. 5(1)(c): Data minimisation principle requires filtering PII before it reaches client applications.", fix: "Add a Service layer that masks or removes unnecessary personal fields before returning data to the client." },
  "GDPR-003": { why: "GDPR Article 32 requires appropriate technical security measures including access control for personal data.", policy: "GDPR Art. 32: Personal data stores must be protected by authentication and access control mechanisms.", fix: "Ensure all access paths to this personal data store go through an authenticated Service or Gateway." },
  "GDPR-004": { why: "GDPR Article 30 requires records of processing activities and audit logs for all personal data processing.", policy: "GDPR Art. 30: Maintain records of all personal data processing. Audit logging is mandatory.", fix: "Add a centralized logging/monitoring system. Log all access to personal data with user context." },
  "GDPR-005": { why: "GDPR Article 17 grants users the right to erasure. Without a service layer, implementing deletion requests is impossible.", policy: "GDPR Art. 17: Must be able to process data erasure requests programmatically via a Data Management Service.", fix: "Add a Data Management Service that can process GDPR erasure requests, portability exports, and access requests." },
  "HIPAA-001": { why: "HIPAA Technical Safeguards §164.312(a)(1) require access control for all electronic PHI systems.", policy: "HIPAA §164.312(a)(1): PHI systems must implement access control. Only authenticated services may access PHI databases.", fix: "Route all PHI database access through an authenticated Service with audit logging enabled." },
  "HIPAA-002": { why: "HIPAA §164.314 requires Business Associate Agreements before sharing PHI with any external party.", policy: "HIPAA §164.314: PHI cannot be shared with external parties without a signed Business Associate Agreement.", fix: "Verify and document BAA with this external processor. Encrypt PHI in transit using TLS 1.2+." },
  "HIPAA-003": { why: "HIPAA §164.312(e)(1) requires PHI to be encrypted in transit.", policy: "HIPAA §164.312(e)(1): All PHI transmitted to clients must use encryption (TLS 1.2+).", fix: "Enforce HTTPS only. Implement TLS 1.2+ on all channels carrying PHI. Consider field-level encryption." },
  "HIPAA-004": { why: "HIPAA §164.312(b) requires audit controls — hardware/software to record and examine PHI access activity.", policy: "HIPAA §164.312(b): Audit controls must record all access to PHI systems.", fix: "Add SIEM/monitoring system. Configure audit logging for all PHI database access with user, timestamp, and action." },
  "HIPAA-005": { why: "HIPAA §164.312(d) requires entity authentication before granting access to PHI systems.", policy: "HIPAA §164.312(d): All users and systems must authenticate before accessing PHI.", fix: "Implement MFA-capable authentication service for all PHI system access. Use role-based access control." },
  "HIPAA-006": { why: "HIPAA §164.312(e)(1) requires technical security measures to guard against unauthorized PHI transmission.", policy: "HIPAA §164.312(e)(1): PHI transmission must be encrypted and only through secure channels.", fix: "Add API Gateway with TLS termination. Enforce HTTPS. Encrypt all PHI in transit and at rest." },
  "PCI-001": { why: "PCI-DSS Requirement 1.3 mandates network isolation of the Cardholder Data Environment from all untrusted networks.", policy: "PCI-DSS v4.0 Req. 1.3: CDE must be isolated. No direct access from untrusted networks or clients.", fix: "Isolate payment components in a separate network segment. Use tokenization. Route all payment flows through authenticated Service." },
  "PCI-002": { why: "PCI-DSS Requirement 12.8 requires monitoring service providers who have access to cardholder data.", policy: "PCI-DSS v4.0 Req. 12.8: All third parties with cardholder data access must be PCI-DSS compliant.", fix: "Verify PCI-DSS compliance of this third party. Get written compliance confirmation. Tag as pci-compliant." },
  "PCI-003": { why: "PCI-DSS Requirement 3 requires protection of stored cardholder data with strict access controls.", policy: "PCI-DSS v4.0 Req. 3: Cardholder data stores must have layered access controls and encryption at rest.", fix: "Route all payment DB access through authenticated Service. Enable AES-256 encryption at rest." },
  "PCI-004": { why: "PCI-DSS Requirement 10 mandates audit trails for all access to cardholder data environments.", policy: "PCI-DSS v4.0 Req. 10: Audit logs required for all CDE access. Retain for 12 months minimum.", fix: "Implement centralized logging for all CDE components. Configure real-time alerts. Retain logs 12 months." },
  "PCI-005": { why: "PCI-DSS Requirement 8 requires unique identification and authentication for all CDE access.", policy: "PCI-DSS v4.0 Req. 8: MFA required for all CDE access. No shared accounts.", fix: "Implement MFA authentication service for CDE. Assign unique IDs. Disable shared/generic accounts." },
  "PCI-006": { why: "PCI-DSS Requirement 1 requires network security controls around the Cardholder Data Environment.", policy: "PCI-DSS v4.0 Req. 1: Firewall/gateway required around CDE. Document all network flows.", fix: "Add API Gateway or WAF to isolate CDE. Document and approve all allowed network flows." },
  "PCI-007": { why: "PCI-DSS Requirement 3.5 requires strong cryptography to protect stored cardholder data.", policy: "PCI-DSS v4.0 Req. 3.5: AES-256 or RSA-2048 minimum for stored cardholder data.", fix: "Enable AES-256 encryption at rest. Use HSM for encryption key management." },
  "SOC2-001": { why: "SOC2 CC6.6 requires logical access controls and monitoring of all external network traffic.", policy: "SOC2 CC6.6: External connections must route through monitored API Gateway with logging and alerting.", fix: "Route all external traffic through API Gateway. Enable request logging, alerting, and rate limiting." },
  "SOC2-002": { why: "SOC2 CC6.1 requires logical access controls to protect information assets.", policy: "SOC2 CC6.1: Authentication required before allowing client access to internal services.", fix: "Implement JWT/OAuth authentication before allowing client access to this service." },
  "SOC2-003": { why: "SOC2 CC7.2 requires monitoring and detection systems to identify security events.", policy: "SOC2 CC7.2: Continuous monitoring required to detect and respond to security events.", fix: "Add SIEM/monitoring system (Datadog, Splunk). Configure alerts for anomalous access patterns." },
  "SOC2-004": { why: "SOC2 CC6.1 requires logical access controls implemented across all information systems.", policy: "SOC2 CC6.1: Logical access controls must protect all information assets.", fix: "Implement authentication service with MFA. Enforce role-based access control." },
  "SOC2-005": { why: "SOC2 CC6.7 requires protection of confidential information including credentials and secrets.", policy: "SOC2 CC6.7: Credentials must be managed via secrets management system, never hardcoded.", fix: "Add HashiCorp Vault or AWS Secrets Manager. Rotate all credentials. Audit secrets access." },
  "ISO27001-001": { why: "ISO 27001 Control A.9.4 requires access control to prevent unauthorized access to information systems.", policy: "ISO/IEC 27001:2022 A.9.4: Classified data stores must require authentication for all access.", fix: "Enforce network segmentation. All access to classified data must require strong authentication." },
  "ISO27001-002": { why: "ISO 27001 A.13.2 requires policies for secure information transfer to external parties.", policy: "ISO/IEC 27001:2022 A.13.2: Information transfer agreements required before sharing with external parties.", fix: "Establish NDA/DPA with external party before transfer. Encrypt data in transit." },
  "ISO27001-003": { why: "ISO 27001 Control A.12.4 requires event logging for all information processing systems.", policy: "ISO/IEC 27001:2022 A.12.4: Audit logging mandatory for all system events.", fix: "Implement centralized logging. Enable audit trails for all system access." },
  "ISO27001-004": { why: "ISO 27001 A.9.2 requires a formal user access management process.", policy: "ISO/IEC 27001:2022 A.9.2: Formal IAM process required for user registration and access.", fix: "Implement Identity and Access Management (IAM) with role-based access control." },
  "ISO27001-005": { why: "ISO 27001 A.9.4.3 requires password management systems to ensure credential quality.", policy: "ISO/IEC 27001:2022 A.9.4.3: Password management systems required for all information systems.", fix: "Add Secrets Management (HashiCorp Vault, AWS Secrets Manager) to your architecture." },
  "DPDP-001": { why: "India's DPDP Act 2023 Section 16 restricts cross-border personal data transfers to non-approved countries.", policy: "DPDP Act 2023 S.16: Personal data of Indian users can only be transferred to MeitY-approved countries.", fix: "Store Indian personal data within India OR ensure processor is in MeitY-approved country list. Get explicit consent." },
  "DPDP-002": { why: "DPDP Act 2023 Section 6 requires free, informed, specific, and unconditional consent before processing personal data.", policy: "DPDP Act 2023 S.6: Explicit consent required before any personal data processing.", fix: "Add a Consent Service that records user consent before personal data is processed or shared." },
  "DPDP-003": { why: "DPDP Act 2023 Section 8 requires Data Fiduciaries to implement security safeguards for personal data.", policy: "DPDP Act 2023 S.8: Security safeguards and accountability mechanisms mandatory for Data Fiduciaries.", fix: "Add Auth Service and Consent Manager. Implement security controls per DPDP requirements." },
  "DPDP-004": { why: "DPDP Act 2023 Section 8(6) requires notification of data breaches to the Data Protection Board and affected persons.", policy: "DPDP Act 2023 S.8(6): Breach detection and notification mechanisms are mandatory.", fix: "Add security monitoring to detect breaches. Configure automated notification workflows within DPDP timeframes." },
  "RBI-001": { why: "RBI Cybersecurity Framework mandates real-time monitoring of all external access to critical banking systems.", policy: "RBI CSF Annex I: All external access to critical banking infrastructure must go through monitored security gateway.", fix: "Add WAF and IDS/IPS as mandatory security controls. Log all external access in real-time SIEM." },
  "RBI-002": { why: "RBI mandates strict data localisation — customer financial data must stay within India and be protected from external access.", policy: "RBI CSF: Customer financial data must not be directly accessible from untrusted sources. Data must stay in India.", fix: "Implement layered security: WAF → Gateway → Auth → Service → Database. Store data in India only." },
  "RBI-003": { why: "RBI requires audit trails for all transfers of customer financial data to third parties.", policy: "RBI CSF Annex IV: All financial data transfers must be audited and comply with RBI data localisation requirements.", fix: "Verify third-party RBI compliance. Maintain audit logs of all data transfers. Ensure data stays in India." },
  "RBI-004": { why: "RBI Cybersecurity Framework requires 24x7 Security Operations Centre monitoring for critical banking systems.", policy: "RBI CSF Annex III: 24x7 SOC monitoring mandatory for all regulated banking infrastructure.", fix: "Implement SOC with SIEM. Configure real-time alerting. Ensure 24x7 coverage for all critical systems." },
  "RBI-005": { why: "RBI mandates perimeter security controls including WAF and DDoS protection for all banking systems.", policy: "RBI CSF: Perimeter security controls (WAF, DDoS protection) are mandatory for all banking platforms.", fix: "Implement WAF and DDoS protection as mandatory perimeter controls. Add API Gateway for all external traffic." },
  "CERTIN-001": { why: "CERT-In Directions 2022 require comprehensive ICT system logs and 6-hour incident reporting to CERT-In.", policy: "CERT-In Directions 2022: All ICT system access must be logged. Incidents reported within 6 hours.", fix: "Enable detailed access logging for all external connections. Configure SIEM for real-time alerts. Retain logs 180 days." },
  "CERTIN-002": { why: "CERT-In Directions 2022 require ICT system logs retained for 180 days in India-based storage.", policy: "CERT-In Directions 2022: Log retention minimum 180 days within India jurisdiction.", fix: "Add centralized log management with India-based storage. Ensure 180+ day retention period." },
  "ITACT-001": { why: "IT Act 2000 Section 43A requires body corporates to implement reasonable security practices for sensitive personal data.", policy: "IT Act 2000 S.43A: Reasonable security practices (ISO 27001-aligned) mandatory for sensitive personal data.", fix: "Implement ISO 27001-aligned security. Encrypt personal data at rest and in transit. Document security practices." },
  "CCPA-001": { why: "CCPA requires businesses to ensure service providers receiving California consumer data comply with CCPA.", policy: "CCPA §1798.100: All service providers receiving personal information must be CCPA-compliant with written agreements.", fix: "Ensure this service provider has a CCPA-compliant Data Processing Agreement. Verify compliance status." },
  "CCPA-002": { why: "CCPA gives California consumers the right to opt-out of sale or sharing of their personal information.", policy: "CCPA §1798.120: Must provide opt-out mechanism for sale/sharing of personal information.", fix: "Implement opt-out mechanism. Display required 'Do Not Sell or Share My Personal Information' link." },
  "NIST-001": { why: "NIST CSF 2.0 Protect function requires managed remote access with multi-factor authentication.", policy: "NIST CSF 2.0 PR.AC-3: Remote access must be managed, controlled, and use MFA.", fix: "Implement Zero Trust architecture. Authenticate every connection. Log all access. Enforce least privilege." },
  "NIST-002": { why: "NIST CSF 2.0 Detect function requires continuous monitoring to identify cybersecurity events.", policy: "NIST CSF 2.0 DE.CM-1: Continuous monitoring required for all information assets and networks.", fix: "Connect to SIEM/monitoring system. Enable anomaly detection. Configure incident alerting." },
  "NIST-003": { why: "NIST CSF 2.0 Detect function requires continuous monitoring to identify anomalies and cybersecurity events.", policy: "NIST CSF 2.0 DE.CM: Continuous monitoring of assets and networks is required.", fix: "Add monitoring system. Implement anomaly detection. Configure automated incident alerting and response." },
  "NIST-004": { why: "NIST CSF 2.0 Protect function requires managed identities and credentials.", policy: "NIST CSF 2.0 PR.AC-1: Identities and credentials must be issued, managed, verified, revoked, and audited.", fix: "Implement Identity Provider (IdP) with MFA. Use least-privilege access model. Audit all account activity." },
  "CIS-001": { why: "CIS Control 5 (Account Management) requires managed accounts and access control for all systems.", policy: "CIS Controls v8 Control 5: Managed accounts with MFA and least-privilege access required.", fix: "Implement authentication with MFA. Use role-based access control. Enforce least-privilege." },
  "CIS-002": { why: "CIS Control 8 (Audit Log Management) requires collection and retention of audit logs from all systems.", policy: "CIS Controls v8 Control 8: Centralized audit log collection and 90-day minimum retention required.", fix: "Connect to centralized log management. Retain logs 90+ days. Review logs weekly." },
  "CIS-003": { why: "CIS Control 8 requires centralized audit log management across all infrastructure.", policy: "CIS Controls v8 Control 8: All audit logs must be centrally collected, reviewed, and retained.", fix: "Implement SIEM with centralized logging. Review logs weekly. Retain minimum 90 days." },
  "CIS-004": { why: "CIS Controls 5 and 6 require inventory of all accounts and strict access control privileges.", policy: "CIS Controls v8 Controls 5 & 6: Account inventory required. MFA mandatory for all admin access.", fix: "Implement IAM system. Disable unused accounts. Enforce MFA for all privileged access." },
  "CIS-005": { why: "CIS Control 12 requires network infrastructure defense with firewalls and network access controls.", policy: "CIS Controls v8 Control 12: Network boundary defense required with monitored perimeter controls.", fix: "Add API Gateway, WAF, and network segmentation. Monitor all perimeter traffic." }
};

const FRAMEWORK_COLORS = {
  "GDPR":    { color: "#0ea5e9", bg: "#0a1929", label: "GDPR" },
  "HIPAA":   { color: "#22c55e", bg: "#0a1f0f", label: "HIPAA" },
  "SOC2":    { color: "#f59e0b", bg: "#1a1508", label: "SOC2" },
  "ISO27001":{ color: "#a78bfa", bg: "#160a2e", label: "ISO 27001" },
};

function getTypeColor(type) {
  if (!type) return "#555";
  const t = type.toLowerCase();
  if (["user","client","browser","frontend","mobileapp"].some(k => t.includes(k))) return "#f59e0b";
  if (["database","db","sql","mongo","redis","neo4j"].some(k => t.includes(k))) return "#0ea5e9";
  if (["api","rest","graphql"].some(k => t.includes(k))) return "#22c55e";
  if (["service","microservice"].some(k => t.includes(k))) return "#7c3aed";
  if (["queue","kafka","rabbit","sqs"].some(k => t.includes(k))) return "#ec4899";
  if (["gateway","proxy","nginx"].some(k => t.includes(k))) return "#f97316";
  if (["worker","job","cron"].some(k => t.includes(k))) return "#8b5cf6";
  if (["external","vendor"].some(k => t.includes(k))) return "#64748b";
  if (["cache","memcached"].some(k => t.includes(k))) return "#06b6d4";
  return "#888";
}

// ── Editable field ────────────────────────────────────────
function EditableField({ label, value, placeholder, onChange, multiline = false }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft]     = useState(value || "");

  const handleSave = () => {
    onChange(draft);
    setEditing(false);
  };

  if (editing) {
    return (
      <div style={{ marginBottom: "10px" }}>
        <div style={{ fontSize: "10px", color: "#555", textTransform: "uppercase", letterSpacing: "0.8px", marginBottom: "4px", fontWeight: "600" }}>
          {label}
        </div>
        {multiline ? (
          <textarea
            value={draft}
            onChange={e => setDraft(e.target.value)}
            autoFocus
            rows={3}
            style={{
              width: "100%", padding: "8px 10px",
              background: "#12122a", border: "1px solid #333",
              color: "#e5e5e5", borderRadius: "6px",
              fontSize: "12px", resize: "vertical",
              boxSizing: "border-box", fontFamily: "inherit"
            }}
          />
        ) : (
          <input
            value={draft}
            onChange={e => setDraft(e.target.value)}
            autoFocus
            onKeyDown={e => { if (e.key === "Enter") handleSave(); if (e.key === "Escape") setEditing(false); }}
            style={{
              width: "100%", padding: "7px 10px",
              background: "#12122a", border: "1px solid #333",
              color: "#e5e5e5", borderRadius: "6px",
              fontSize: "12px", boxSizing: "border-box"
            }}
          />
        )}
        <div style={{ display: "flex", gap: "6px", marginTop: "6px" }}>
          <button onClick={handleSave} style={{
            background: "#1a2e1e", border: "1px solid #2a4a2e",
            color: "#5a9e6f", padding: "4px 12px", borderRadius: "5px",
            cursor: "pointer", fontSize: "11px"
          }}>Save</button>
          <button onClick={() => setEditing(false)} style={{
            background: "transparent", border: "1px solid #22224a",
            color: "#555", padding: "4px 10px", borderRadius: "5px",
            cursor: "pointer", fontSize: "11px"
          }}>Cancel</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ marginBottom: "10px" }}>
      <div style={{ fontSize: "10px", color: "#555", textTransform: "uppercase", letterSpacing: "0.8px", marginBottom: "4px", fontWeight: "600" }}>
        {label}
      </div>
      <button
        onClick={() => { setDraft(value || ""); setEditing(true); }}
        style={{
          width: "100%", textAlign: "left", background: "#12122a",
          border: "1px solid #161632", borderRadius: "6px",
          padding: "7px 10px", cursor: "pointer",
          color: value ? "#bbb" : "#444",
          fontSize: "12px", lineHeight: "1.5",
          transition: "border-color 0.15s"
        }}
        onMouseEnter={e => e.currentTarget.style.borderColor = "#333"}
        onMouseLeave={e => e.currentTarget.style.borderColor = "#161632"}
      >
        {value || <span style={{ fontStyle: "italic" }}>{placeholder}</span>}
        <span style={{ float: "right", color: "#333", fontSize: "10px" }}>✎</span>
      </button>
    </div>
  );
}

export default function NodeDetailPanel({ onClose }) {
  const { selectedNode, nodes, edges, violations } = useGraphStore();
  const [activeSection, setActiveSection] = useState("connections");

  // ── Accountability state ─────────────────────────────────
  const [accountabilityMap, setAccountabilityMap] = useState({}); // key -> {status, approvedBy, reason, timestamp}
  const [openApprovalKey, setOpenApprovalKey] = useState(null);   // which violation's form is open
  const [approvalDecision, setApprovalDecision] = useState("approved"); // "approved" | "overridden"
  const [reasonDraft, setReasonDraft] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const [historyKey, setHistoryKey] = useState(null);      // which violation's history is open
  const [historyRecords, setHistoryRecords] = useState([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  const refreshAccountability = async () => {
    if (!selectedNode) return;
    try {
      const backendViolations = await evaluateGovernance(nodes, edges);
      const map = {};
      (backendViolations || []).forEach(v => {
        map[violationKey(v)] = v.accountability || { status: "unresolved" };
      });
      setAccountabilityMap(map);
    } catch {
      // Backend unreachable — accountability badges just won't show, rest of UI still works
    }
  };

  useEffect(() => {
    if (activeSection === "violations" && selectedNode) {
      refreshAccountability();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeSection, selectedNode?.id]);

  const submitDecision = async (v) => {
    if (!reasonDraft.trim() || reasonDraft.trim().length < 3) {
      setSubmitError("Reason must be at least 3 characters — this becomes a permanent audit record.");
      return;
    }
    setSubmitting(true);
    setSubmitError("");
    try {
      await approveViolation({
        rule_id: v.ruleId,
        source: v.source,
        target: v.target,
        decision: approvalDecision,
        reason: reasonDraft.trim(),
      });
      setOpenApprovalKey(null);
      setReasonDraft("");
      await refreshAccountability();
      if (historyKey === violationKey(v)) {
        await loadHistory(v);   // history panel open — keep it fresh with the new entry
      }
    } catch (e) {
      setSubmitError(e.message || "Failed to record decision");
    } finally {
      setSubmitting(false);
    }
  };

  const loadHistory = async (v) => {
    const key = violationKey(v);
    if (historyKey === key) {
      setHistoryKey(null);   // toggle closed
      return;
    }
    setHistoryKey(key);
    setHistoryLoading(true);
    try {
      const vid = accountabilityMap[key]?.violationId; // not stored directly, recompute via log filter fallback
      const res = await getAccountabilityLog(); // org-wide log; filter client-side by rule/source/target
      const filtered = (res.records || []).filter(
        r => r.rule_id === v.ruleId && r.source === (v.source || "") && r.target === (v.target || "")
      );
      setHistoryRecords(filtered);
    } catch {
      setHistoryRecords([]);
    } finally {
      setHistoryLoading(false);
    }
  };

  if (!selectedNode) return null;

  const color = getTypeColor(selectedNode.type);

  const outgoing = edges.filter(e => e.source === selectedNode.id)
    .map(e => ({ edge: e, target: nodes.find(n => n.id === e.target) }))
    .filter(x => x.target);

  const incoming = edges.filter(e => e.target === selectedNode.id)
    .map(e => ({ edge: e, source: nodes.find(n => n.id === e.source) }))
    .filter(x => x.source);

  const nodeViolations = violations.filter(
    v => v.source === selectedNode.id || v.target === selectedNode.id
  );

  // Update node fields in store
  const updateNodeField = (field, value) => {
    const store = useGraphStore.getState();
    const updated = store.nodes.map(n =>
      n.id === selectedNode.id ? { ...n, [field]: value } : n
    );
    const edges = store.edges;
    // Save locally and re-evaluate
    try {
      localStorage.setItem("codegpo_graph", JSON.stringify({ nodes: updated, edges }));
    } catch {}
    useGraphStore.setState({ nodes: updated, selectedNode: { ...selectedNode, [field]: value } });
    store.evaluateViolations(updated, edges);
  };

  const sections = [
    { id: "connections", label: "Connections", count: outgoing.length + incoming.length },
    { id: "intent",      label: "Intent",      count: null },
    { id: "violations",  label: "Violations",  count: nodeViolations.length },
  ];

  return (
    <div style={{
      position: "fixed", top: 0, right: 0, bottom: 0,
      width: "360px", background: "#0d0d1f",
      borderLeft: "1px solid #22224a",
      zIndex: 400, display: "flex", flexDirection: "column", overflow: "hidden"
    }}>

      {/* Header */}
      <div style={{ padding: "16px", borderBottom: "1px solid #1a1a35", flexShrink: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <div style={{ width: "10px", height: "10px", borderRadius: "50%", background: color, flexShrink: 0 }} />
            <div>
              <div style={{ fontSize: "14px", fontWeight: "700", color: "#e5e5e5" }}>
                {selectedNode.name}
              </div>
              <div style={{ fontSize: "11px", color: color, marginTop: "2px", fontWeight: "500" }}>
                {selectedNode.type}
              </div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: "transparent", border: "none", color: "#555", cursor: "pointer", fontSize: "20px" }}>×</button>
        </div>

        {/* Compliance badges */}
        {selectedNode.compliance_scope && (
          <div style={{ display: "flex", gap: "5px", marginTop: "10px", flexWrap: "wrap" }}>
            {selectedNode.compliance_scope.split(",").map(tag => {
              const t = tag.trim().toUpperCase();
              const cfg = FRAMEWORK_COLORS[t] || { color: "#888", bg: "#12122a", label: t };
              return (
                <span key={t} style={{
                  fontSize: "9.5px", fontWeight: "700", letterSpacing: "0.8px",
                  padding: "2px 8px", borderRadius: "4px",
                  background: cfg.bg, color: cfg.color,
                  border: `1px solid ${cfg.color}44`
                }}>
                  {cfg.label}
                </span>
              );
            })}
          </div>
        )}

        {/* Stats */}
        <div style={{ display: "flex", gap: "16px", marginTop: "14px", paddingTop: "12px", borderTop: "1px solid #161632" }}>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: "16px", fontWeight: "700", color: "#e5e5e5" }}>{outgoing.length}</div>
            <div style={{ fontSize: "10px", color: "#555", marginTop: "2px" }}>Outgoing</div>
          </div>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: "16px", fontWeight: "700", color: "#e5e5e5" }}>{incoming.length}</div>
            <div style={{ fontSize: "10px", color: "#555", marginTop: "2px" }}>Incoming</div>
          </div>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: "16px", fontWeight: "700", color: nodeViolations.length > 0 ? "#cc6666" : "#5a9e6f" }}>
              {nodeViolations.length}
            </div>
            <div style={{ fontSize: "10px", color: "#555", marginTop: "2px" }}>Violations</div>
          </div>
        </div>
      </div>

      {/* Section tabs */}
      <div style={{ display: "flex", borderBottom: "1px solid #161632", flexShrink: 0 }}>
        {sections.map(s => (
          <button
            key={s.id}
            onClick={() => setActiveSection(s.id)}
            style={{
              flex: 1, padding: "10px 4px",
              background: activeSection === s.id ? "#12122a" : "transparent",
              border: "none",
              borderBottom: activeSection === s.id ? "2px solid #0ea5e9" : "2px solid transparent",
              color: activeSection === s.id ? "#ccc" : "#555",
              cursor: "pointer", fontSize: "11px", fontWeight: "600",
              display: "flex", alignItems: "center", justifyContent: "center", gap: "5px"
            }}
          >
            {s.label}
            {s.count !== null && s.count > 0 && (
              <span style={{
                background: s.id === "violations" ? "#3a1515" : "#1a1a35",
                color: s.id === "violations" ? "#cc6666" : "#888",
                fontSize: "10px", padding: "1px 5px", borderRadius: "10px"
              }}>
                {s.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Body */}
      <div style={{
        flex: 1, overflowY: "auto", padding: "14px 16px",
        scrollbarWidth: "thin", scrollbarColor: "#2a2a2a transparent"
      }}>

        {/* CONNECTIONS tab */}
        {activeSection === "connections" && (
          <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
            {outgoing.length > 0 && (
              <div>
                <div style={{ fontSize: "10px", color: "#555", letterSpacing: "1px", textTransform: "uppercase", marginBottom: "8px", fontWeight: "600" }}>
                  Sends to
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  {outgoing.map(({ edge, target }) => {
                    const violation = violations.find(v => v.source === edge.source && v.target === edge.target);
                    return (
                      <div key={edge.target} style={{
                        padding: "10px 12px", background: "#12122a",
                        border: `1px solid ${violation ? "#2e1f1f" : "#1a1a35"}`,
                        borderLeft: `3px solid ${violation ? "#7a3535" : getTypeColor(target.type)}`,
                        borderRadius: "6px", display: "flex", alignItems: "center", gap: "10px"
                      }}>
                        <div style={{ width: "7px", height: "7px", borderRadius: "50%", background: getTypeColor(target.type), flexShrink: 0 }} />
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: "12.5px", color: "#ccc", fontWeight: "500" }}>{target.name}</div>
                          <div style={{ fontSize: "10px", color: "#555", marginTop: "1px" }}>{target.type}</div>
                        </div>
                        {violation ? (
                          <span style={{ fontSize: "10px", color: "#854444", background: "#2a1515", padding: "2px 6px", borderRadius: "4px", fontWeight: "600" }}>
                            {violation.ruleId}
                          </span>
                        ) : (
                          <span style={{ fontSize: "10px", color: "#4a7c59", background: "#162118", padding: "2px 6px", borderRadius: "4px" }}>OK</span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {incoming.length > 0 && (
              <div>
                <div style={{ fontSize: "10px", color: "#555", letterSpacing: "1px", textTransform: "uppercase", marginBottom: "8px", fontWeight: "600" }}>
                  Receives from
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  {incoming.map(({ edge, source }) => {
                    const violation = violations.find(v => v.source === edge.source && v.target === edge.target);
                    return (
                      <div key={edge.source} style={{
                        padding: "10px 12px", background: "#12122a",
                        border: `1px solid ${violation ? "#2e1f1f" : "#1a1a35"}`,
                        borderLeft: `3px solid ${violation ? "#7a3535" : getTypeColor(source.type)}`,
                        borderRadius: "6px", display: "flex", alignItems: "center", gap: "10px"
                      }}>
                        <div style={{ width: "7px", height: "7px", borderRadius: "50%", background: getTypeColor(source.type), flexShrink: 0 }} />
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: "12.5px", color: "#ccc", fontWeight: "500" }}>{source.name}</div>
                          <div style={{ fontSize: "10px", color: "#555", marginTop: "1px" }}>{source.type}</div>
                        </div>
                        {violation ? (
                          <span style={{ fontSize: "10px", color: "#854444", background: "#2a1515", padding: "2px 6px", borderRadius: "4px", fontWeight: "600" }}>
                            {violation.ruleId}
                          </span>
                        ) : (
                          <span style={{ fontSize: "10px", color: "#4a7c59", background: "#162118", padding: "2px 6px", borderRadius: "4px" }}>OK</span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {outgoing.length === 0 && incoming.length === 0 && (
              <div style={{ padding: "20px", background: "#12122a", border: "1px solid #1e1e1e", borderRadius: "8px", textAlign: "center", color: "#444", fontSize: "12px" }}>
                No connections yet.<br />
                <span style={{ fontSize: "11px", color: "#333" }}>Click this node then click another to connect.</span>
              </div>
            )}

            {nodeViolations.length === 0 && (outgoing.length > 0 || incoming.length > 0) && (
              <div style={{ padding: "12px", background: "#111a13", border: "1px solid #1e2e22", borderRadius: "8px", fontSize: "12px", color: "#5a9e6f", lineHeight: "1.6" }}>
                ✓ All connections are compliant with governance policies.
              </div>
            )}
          </div>
        )}

        {/* INTENT tab */}
        {activeSection === "intent" && (
          <div>
            <div style={{ fontSize: "11px", color: "#444", marginBottom: "16px", lineHeight: "1.6" }}>
              Define why this component exists. This context is used by CodeGPO's GraphRAG to constrain AI and generate accurate schemas.
            </div>

            <EditableField
              label="Semantic Intent"
              value={selectedNode.intent}
              placeholder="Why does this component exist? e.g. Stores user authentication data and session tokens"
              onChange={v => updateNodeField("intent", v)}
              multiline
            />
            <EditableField
              label="Owner / Team"
              value={selectedNode.owner}
              placeholder="e.g. Platform Team / @john"
              onChange={v => updateNodeField("owner", v)}
            />
            <EditableField
              label="Team / Squad"
              value={selectedNode.team}
              placeholder="e.g. Auth Squad"
              onChange={v => updateNodeField("team", v)}
            />
            <EditableField
              label="Compliance Scope"
              value={selectedNode.compliance_scope}
              placeholder="e.g. gdpr,hipaa (comma-separated)"
              onChange={v => updateNodeField("compliance_scope", v)}
            />
            <EditableField
              label="Criticality"
              value={selectedNode.criticality}
              placeholder="low / medium / high / critical"
              onChange={v => updateNodeField("criticality", v)}
            />

            <div style={{ fontSize: "10px", color: "#333", marginTop: "16px", padding: "10px 12px", background: "#12122a", borderRadius: "6px", lineHeight: "1.6" }}>
              💡 Tip: Adding intent and compliance scope enables CodeGPO to enforce GDPR, HIPAA, SOC2 and ISO 27001 rules on this component and generate accurate schemas.
            </div>
          </div>
        )}

        {/* VIOLATIONS tab */}
        {activeSection === "violations" && (
          <div>
            {nodeViolations.length === 0 ? (
              <div style={{ padding: "20px", background: "#111a13", border: "1px solid #1e2e22", borderRadius: "8px", fontSize: "13px", color: "#5a9e6f", textAlign: "center" }}>
                ✓ No violations on this component.
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                {nodeViolations.map((v, i) => {
                  const explanation  = RULE_EXPLANATIONS[v.ruleId];
                  const sourceNode   = nodes.find(n => n.id === v.source);
                  const targetNode   = nodes.find(n => n.id === v.target);
                  const isSource     = v.source === selectedNode.id;
                  const fwCfg        = v.framework ? FRAMEWORK_COLORS[v.framework] : null;

                  return (
                    <div key={i} style={{
                      background: "#1a1212", border: "1px solid #2e1f1f",
                      borderLeft: "3px solid #7a3535", borderRadius: "8px", padding: "12px"
                    }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px" }}>
                        <span style={{ fontSize: "10px", fontWeight: "700", color: "#cc6666", background: "#2a1818", padding: "2px 8px", borderRadius: "4px" }}>
                          {v.ruleId}
                        </span>
                        {fwCfg && (
                          <span style={{ fontSize: "9.5px", fontWeight: "700", color: fwCfg.color, background: fwCfg.bg, padding: "2px 7px", borderRadius: "4px", border: `1px solid ${fwCfg.color}44` }}>
                            {fwCfg.label}
                          </span>
                        )}
                        <span style={{ fontSize: "11px", color: "#666" }}>
                          {sourceNode?.name} → {targetNode?.name}
                        </span>
                      </div>

                      <div style={{ marginBottom: "10px" }}>
                        <div style={{ fontSize: "10px", color: "#555", letterSpacing: "0.8px", textTransform: "uppercase", marginBottom: "4px", fontWeight: "600" }}>What's happening</div>
                        <p style={{ fontSize: "12px", color: "#bbb", lineHeight: "1.7", margin: 0 }}>
                          {isSource
                            ? `${selectedNode.name} is sending data directly to ${targetNode?.name}.`
                            : `${sourceNode?.name} is sending data directly to ${selectedNode.name}.`}
                          {" "}{v.message}.
                        </p>
                      </div>

                      {explanation && (
                        <>
                          <div style={{ marginBottom: "10px" }}>
                            <div style={{ fontSize: "10px", color: "#555", letterSpacing: "0.8px", textTransform: "uppercase", marginBottom: "4px", fontWeight: "600" }}>Why this is a problem</div>
                            <p style={{ fontSize: "12px", color: "#bbb", lineHeight: "1.7", margin: 0 }}>{explanation.why}</p>
                          </div>
                          <div style={{ marginBottom: "10px" }}>
                            <div style={{ fontSize: "10px", color: "#555", letterSpacing: "0.8px", textTransform: "uppercase", marginBottom: "4px", fontWeight: "600" }}>Governance Policy</div>
                            <p style={{ fontSize: "12px", color: "#bbb", lineHeight: "1.7", margin: 0 }}>{explanation.policy}</p>
                          </div>
                          <div style={{ padding: "8px 10px", background: "#111a13", border: "1px solid #1e2e22", borderRadius: "6px" }}>
                            <div style={{ fontSize: "10px", color: "#4a7c59", letterSpacing: "0.8px", textTransform: "uppercase", marginBottom: "3px", fontWeight: "600" }}>Recommended Fix</div>
                            <p style={{ fontSize: "12px", color: "#aaa", lineHeight: "1.6", margin: 0 }}>{explanation.fix}</p>
                          </div>
                        </>
                      )}

                      {/* ── Accountability ───────────────────────────── */}
                      {(() => {
                        const key = violationKey(v);
                        const acc = accountabilityMap[key];
                        const status = acc?.status || "unresolved";
                        const statusCfg = {
                          unresolved: { label: "Unresolved",  color: "#cc6666", bg: "#2a1818" },
                          approved:   { label: "Approved",    color: "#5a9e6f", bg: "#111a13" },
                          overridden: { label: "Overridden",  color: "#d4a44c", bg: "#2a2210" },
                        }[status];
                        const isOpen = openApprovalKey === key;

                        return (
                          <div style={{ marginTop: "10px", paddingTop: "10px", borderTop: "1px solid #2e1f1f" }}>
                            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "8px" }}>
                              <span style={{
                                fontSize: "10px", fontWeight: "700", color: statusCfg.color,
                                background: statusCfg.bg, padding: "3px 9px", borderRadius: "4px",
                                border: `1px solid ${statusCfg.color}44`, letterSpacing: "0.4px"
                              }}>
                                {statusCfg.label}
                              </span>

                              {!isOpen && (
                                <div style={{ display: "flex", gap: "6px" }}>
                                  {status === "unresolved" ? (
                                    <>
                                      <button
                                        onClick={() => { setOpenApprovalKey(key); setApprovalDecision("approved"); setSubmitError(""); }}
                                        style={{ fontSize: "11px", padding: "4px 10px", borderRadius: "5px", border: "1px solid #2e4a35", background: "#111a13", color: "#5a9e6f", cursor: "pointer" }}
                                      >
                                        Approve
                                      </button>
                                      <button
                                        onClick={() => { setOpenApprovalKey(key); setApprovalDecision("overridden"); setSubmitError(""); }}
                                        style={{ fontSize: "11px", padding: "4px 10px", borderRadius: "5px", border: "1px solid #4a3d1f", background: "#2a2210", color: "#d4a44c", cursor: "pointer" }}
                                      >
                                        Override
                                      </button>
                                    </>
                                  ) : (
                                    <>
                                      <button
                                        onClick={() => loadHistory(v)}
                                        style={{ fontSize: "10.5px", padding: "3px 9px", borderRadius: "5px", border: "1px solid #333", background: "transparent", color: "#777", cursor: "pointer" }}
                                      >
                                        {historyKey === key ? "Hide history" : "View history"}
                                      </button>
                                      <button
                                        onClick={() => { setOpenApprovalKey(key); setApprovalDecision(status === "approved" ? "overridden" : "approved"); setSubmitError(""); }}
                                        style={{ fontSize: "10.5px", padding: "3px 9px", borderRadius: "5px", border: "1px solid #333", background: "transparent", color: "#888", cursor: "pointer" }}
                                      >
                                        Revise decision
                                      </button>
                                    </>
                                  )}
                                </div>
                              )}
                            </div>

                            {status !== "unresolved" && acc?.approvedBy && (
                              <div style={{ fontSize: "11px", color: "#888", marginTop: "6px", lineHeight: "1.6" }}>
                                By <strong style={{ color: "#aaa" }}>{acc.approvedBy}</strong>
                                {acc.timestamp ? ` on ${new Date(acc.timestamp).toLocaleString()}` : ""}
                                {acc.reason ? <div style={{ marginTop: "2px", color: "#999", fontStyle: "italic" }}>"{acc.reason}"</div> : null}
                              </div>
                            )}

                            {historyKey === key && (
                              <div style={{ marginTop: "10px", paddingTop: "10px", borderTop: "1px dashed #2e1f1f" }}>
                                <div style={{ fontSize: "10px", color: "#555", letterSpacing: "0.8px", textTransform: "uppercase", marginBottom: "6px", fontWeight: "600" }}>
                                  Full decision history (newest first — nothing is ever deleted)
                                </div>
                                {historyLoading ? (
                                  <div style={{ fontSize: "11px", color: "#666" }}>Loading…</div>
                                ) : historyRecords.length === 0 ? (
                                  <div style={{ fontSize: "11px", color: "#666" }}>No prior decisions found.</div>
                                ) : (
                                  <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                                    {historyRecords.map((r) => (
                                      <div key={r.id} style={{ fontSize: "11px", color: "#999", lineHeight: "1.6", padding: "6px 8px", background: "#141010", borderRadius: "5px", border: "1px solid #241a1a" }}>
                                        <span style={{
                                          fontWeight: "700",
                                          color: r.decision === "approved" ? "#5a9e6f" : "#d4a44c",
                                        }}>
                                          {r.decision === "approved" ? "Approved" : "Overridden"}
                                        </span>
                                        {" by "}<strong style={{ color: "#bbb" }}>{r.approved_by_email}</strong>
                                        {" on "}{new Date(r.timestamp).toLocaleString()}
                                        {r.reason ? <div style={{ marginTop: "2px", fontStyle: "italic", color: "#888" }}>"{r.reason}"</div> : null}
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            )}

                            {isOpen && (
                              <div style={{ marginTop: "10px" }}>
                                <div style={{ fontSize: "10px", color: "#555", letterSpacing: "0.8px", textTransform: "uppercase", marginBottom: "5px", fontWeight: "600" }}>
                                  Reason for {approvalDecision === "approved" ? "approval" : "override"} (required — this is permanent)
                                </div>
                                <textarea
                                  value={reasonDraft}
                                  onChange={(e) => setReasonDraft(e.target.value)}
                                  placeholder="e.g. Reviewed with security team, tracked in JIRA-4521, temporary exception for Q3 migration"
                                  rows={3}
                                  style={{
                                    width: "100%", boxSizing: "border-box", fontSize: "12px", padding: "8px",
                                    borderRadius: "6px", border: "1px solid #333", background: "#0f0f0f",
                                    color: "#ddd", resize: "vertical", fontFamily: "inherit"
                                  }}
                                />
                                {submitError && (
                                  <div style={{ fontSize: "11px", color: "#cc6666", marginTop: "5px" }}>{submitError}</div>
                                )}
                                <div style={{ display: "flex", gap: "8px", marginTop: "8px" }}>
                                  <button
                                    disabled={submitting}
                                    onClick={() => submitDecision(v)}
                                    style={{
                                      fontSize: "12px", padding: "6px 14px", borderRadius: "6px", border: "none",
                                      background: approvalDecision === "approved" ? "#2e4a35" : "#4a3d1f",
                                      color: "#fff", cursor: submitting ? "default" : "pointer", opacity: submitting ? 0.6 : 1,
                                    }}
                                  >
                                    {submitting ? "Recording…" : `Confirm ${approvalDecision === "approved" ? "Approval" : "Override"}`}
                                  </button>
                                  <button
                                    disabled={submitting}
                                    onClick={() => { setOpenApprovalKey(null); setReasonDraft(""); setSubmitError(""); }}
                                    style={{ fontSize: "12px", padding: "6px 14px", borderRadius: "6px", border: "1px solid #333", background: "transparent", color: "#888", cursor: "pointer" }}
                                  >
                                    Cancel
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })()}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
