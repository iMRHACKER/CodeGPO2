export default function UpgradeModal({ onClose, reason = "nodes" }) {

  const PLANS = [
    {
      name: "Free",
      price: "₹0",
      period: "",
      color: "#94A3B8",
      current: true,
      features: ["10 nodes", "5 connections", "Basic governance rules", "No PDF report", "No AI explain"],
    },
    {
      name: "Pro",
      price: "₹999",
      period: "/month",
      color: "#7C3AED",
      highlight: true,
      features: ["Unlimited nodes", "Unlimited connections", "82+ governance rules", "PDF compliance report", "AI explain violations", "GitHub PR integration", "Priority support"],
    },
    {
      name: "Enterprise",
      price: "₹4,999",
      period: "/month",
      color: "#F59E0B",
      features: ["Everything in Pro", "Custom compliance rules", "Team collaboration", "SSO integration", "Dedicated support", "Custom frameworks", "SLA guarantee"],
    },
  ];

  const REASON_TEXT = {
    nodes:  "You've reached the 10 node limit on the Free plan.",
    edges:  "You've reached the 5 connection limit on the Free plan.",
    pdf:    "PDF compliance reports are available on Pro and Enterprise plans.",
    ai:     "AI violation explain is available on Pro and Enterprise plans.",
    github: "GitHub PR integration is available on Pro and Enterprise plans.",
    schema: "Schema generation is available on Pro and Enterprise plans.",
    cicd: "CI/CD integration templates are available on Pro and Enterprise plans.",
    collab: "Real-time team collaboration is available on the Enterprise plan.",
  };

  return (
    <div style={{
      position: "fixed", inset: 0,
      background: "rgba(0,0,0,0.85)",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 2000, padding: "20px"
    }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: "#0D0D1F", border: "1px solid #1A1A35",
        borderRadius: "16px", width: "680px",
        maxHeight: "90vh", overflowY: "auto",
      }}>
        {/* Header */}
        <div style={{ padding: "24px 28px 0", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontSize: "10px", color: "#7C3AED", fontWeight: "700", letterSpacing: "2px", textTransform: "uppercase", marginBottom: "6px" }}>
              Upgrade Required
            </div>
            <h2 style={{ color: "#fff", fontSize: "20px", fontWeight: "800", margin: 0 }}>
              Unlock Full CodeGPO
            </h2>
            <p style={{ color: "#475569", fontSize: "13px", marginTop: "6px" }}>
              {REASON_TEXT[reason] || REASON_TEXT.nodes}
            </p>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", color: "#475569", cursor: "pointer", fontSize: "22px" }}>×</button>
        </div>

        {/* Plans */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "12px", padding: "24px 28px" }}>
          {PLANS.map(plan => (
            <div key={plan.name} style={{
              background: plan.highlight ? "linear-gradient(135deg, rgba(124,58,237,0.15), rgba(14,165,233,0.08))" : "#08080F",
              border: `1px solid ${plan.highlight ? "#7C3AED" : "#1A1A35"}`,
              borderRadius: "12px", padding: "20px",
              position: "relative",
            }}>
              {plan.highlight && (
                <div style={{
                  position: "absolute", top: "-10px", left: "50%", transform: "translateX(-50%)",
                  background: "#7C3AED", color: "#fff", fontSize: "9px", fontWeight: "700",
                  padding: "3px 12px", borderRadius: "20px", letterSpacing: "1px", whiteSpace: "nowrap"
                }}>MOST POPULAR</div>
              )}

              <div style={{ marginBottom: "16px" }}>
                <div style={{ fontSize: "14px", fontWeight: "700", color: plan.color, marginBottom: "8px" }}>{plan.name}</div>
                <div style={{ display: "flex", alignItems: "baseline", gap: "2px" }}>
                  <span style={{ fontSize: "24px", fontWeight: "800", color: "#fff" }}>{plan.price}</span>
                  <span style={{ fontSize: "12px", color: "#475569" }}>{plan.period}</span>
                </div>
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: "8px", marginBottom: "20px" }}>
                {plan.features.map((f, i) => (
                  <div key={i} style={{ display: "flex", gap: "8px", alignItems: "flex-start" }}>
                    <span style={{ color: plan.current ? "#475569" : plan.color, fontSize: "12px", marginTop: "1px", flexShrink: 0 }}>
                      {plan.current ? "·" : "✓"}
                    </span>
                    <span style={{ fontSize: "12px", color: plan.current ? "#475569" : "#94A3B8", lineHeight: "1.4" }}>{f}</span>
                  </div>
                ))}
              </div>

              {plan.current ? (
                <div style={{ textAlign: "center", padding: "10px", background: "#1A1A35", borderRadius: "8px", fontSize: "12px", color: "#475569" }}>
                  Current Plan
                </div>
              ) : (
                <a href={`mailto:harsh@codegpo.com?subject=Upgrade to ${plan.name}&body=Hi Harsh, I'd like to upgrade to the ${plan.name} plan (${plan.price}/month).`}
                  style={{
                    display: "block", textAlign: "center", padding: "10px",
                    background: plan.highlight ? "#7C3AED" : "transparent",
                    border: `1px solid ${plan.highlight ? "#7C3AED" : "#1A1A35"}`,
                    borderRadius: "8px", fontSize: "12px", fontWeight: "700",
                    color: plan.highlight ? "#fff" : "#94A3B8",
                    textDecoration: "none", cursor: "pointer",
                    transition: "all 0.15s"
                  }}>
                  Contact for {plan.name} →
                </a>
              )}
            </div>
          ))}
        </div>

        <div style={{ padding: "0 28px 24px", textAlign: "center" }}>
          <p style={{ fontSize: "12px", color: "#334155" }}>
            Questions? Email <a href="mailto:harsh@codegpo.com" style={{ color: "#7C3AED" }}>harsh@codegpo.com</a>
          </p>
        </div>
      </div>
    </div>
  );
}
