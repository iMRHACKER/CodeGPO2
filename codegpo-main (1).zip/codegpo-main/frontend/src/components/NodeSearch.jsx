import { useState, useEffect, useRef } from "react";
import { useGraphStore } from "../state/graphStore";

const TYPE_FILTERS = [
  { label: "All",      value: null,           color: "#888" },
  { label: "User",     value: "user",         color: "#f59e0b" },
  { label: "Service",  value: "service",      color: "#7c3aed" },
  { label: "API",      value: "api",          color: "#22c55e" },
  { label: "Database", value: "database",     color: "#0ea5e9" },
  { label: "Queue",    value: "queue",        color: "#ec4899" },
  { label: "Gateway",  value: "gateway",      color: "#f97316" },
  { label: "Worker",   value: "worker",       color: "#8b5cf6" },
  { label: "Cache",    value: "cache",        color: "#06b6d4" },
  { label: "External", value: "external",     color: "#64748b" },
];

export default function NodeSearch({ onClose, onFocus }) {
  const { nodes, edges, violations } = useGraphStore();
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState(null);
  const inputRef = useRef(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  // Filter nodes
  const filtered = nodes.filter(n => {
    const matchQuery = !query.trim() ||
      n.name.toLowerCase().includes(query.toLowerCase()) ||
      n.type.toLowerCase().includes(query.toLowerCase());

    const matchType = !typeFilter ||
      n.type.toLowerCase().includes(typeFilter.toLowerCase());

    return matchQuery && matchType;
  });

  const getNodeViolations = (nodeId) =>
    violations.filter(v => v.source === nodeId || v.target === nodeId);

  const getNodeConnections = (nodeId) =>
    edges.filter(e => e.source === nodeId || e.target === nodeId).length;

  function getTypeColor(type) {
    if (!type) return "#555";
    const t = type.toLowerCase();
    if (["user","client","browser","frontend"].some(k => t.includes(k))) return "#f59e0b";
    if (["database","db","sql","mongo","redis"].some(k => t.includes(k))) return "#0ea5e9";
    if (["api","rest","graphql"].some(k => t.includes(k))) return "#22c55e";
    if (["service","microservice"].some(k => t.includes(k))) return "#7c3aed";
    if (["queue","kafka","rabbit","sqs"].some(k => t.includes(k))) return "#ec4899";
    if (["gateway","proxy","nginx","load"].some(k => t.includes(k))) return "#f97316";
    if (["worker","job","cron"].some(k => t.includes(k))) return "#8b5cf6";
    if (["external","vendor"].some(k => t.includes(k))) return "#64748b";
    if (["cache","memcached"].some(k => t.includes(k))) return "#06b6d4";
    return "#888";
  }

  return (
    <div style={{
      position: "fixed",
      top: 0, left: 0, right: 0, bottom: 0,
      background: "rgba(0,0,0,0.7)",
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "center",
      zIndex: 1000,
      paddingTop: "80px"
    }}
      onClick={onClose}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: "#0d0d1f",
          border: "1px solid #22224a",
          borderRadius: "14px",
          width: "560px",
          maxHeight: "70vh",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          boxShadow: "0 20px 60px rgba(0,0,0,0.5)"
        }}
      >
        {/* Search input */}
        <div style={{
          padding: "14px 16px",
          borderBottom: "1px solid #1a1a35",
          display: "flex",
          alignItems: "center",
          gap: "10px"
        }}>
          <span style={{ color: "#444", fontSize: "14px", flexShrink: 0 }}>⌕</span>
          <input
            ref={inputRef}
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => {
              if (e.key === "Escape") onClose();
              if (e.key === "Enter" && filtered.length > 0) {
                onFocus(filtered[0].id);
                onClose();
              }
            }}
            placeholder="Search components by name or type..."
            style={{
              flex: 1,
              background: "transparent",
              border: "none",
              color: "#e5e5e5",
              fontSize: "14px",
              outline: "none",
              fontFamily: "inherit"
            }}
          />
          {(query || typeFilter) && (
            <button
              onClick={() => { setQuery(""); setTypeFilter(null); }}
              style={{
                background: "transparent", border: "none",
                color: "#444", cursor: "pointer",
                fontSize: "16px", padding: "0",
                flexShrink: 0
              }}
            >×</button>
          )}
          <span style={{ fontSize: "11px", color: "#444", flexShrink: 0 }}>
            {filtered.length}/{nodes.length}
          </span>
        </div>

        {/* Type filters */}
        <div style={{
          padding: "10px 16px",
          borderBottom: "1px solid #161632",
          display: "flex",
          gap: "5px",
          flexWrap: "wrap"
        }}>
          {TYPE_FILTERS.map(f => {
            const isActive = typeFilter === f.value;
            const count = f.value === null
              ? nodes.length
              : nodes.filter(n => n.type?.toLowerCase().includes(f.value)).length;

            if (count === 0 && f.value !== null) return null;

            return (
              <button
                key={f.label}
                onClick={() => setTypeFilter(isActive ? null : f.value)}
                style={{
                  background: isActive ? "#1a1a35" : "transparent",
                  border: `1px solid ${isActive ? f.color + "44" : "#1a1a35"}`,
                  color: isActive ? f.color : "#555",
                  padding: "3px 10px",
                  borderRadius: "20px",
                  cursor: "pointer",
                  fontSize: "11px",
                  fontWeight: isActive ? "600" : "400",
                  transition: "all 0.15s",
                  display: "flex",
                  alignItems: "center",
                  gap: "5px"
                }}
              >
                {f.value && (
                  <span style={{
                    width: "5px", height: "5px",
                    borderRadius: "50%",
                    background: isActive ? f.color : "#333",
                    display: "inline-block"
                  }} />
                )}
                {f.label}
                <span style={{ color: isActive ? f.color + "99" : "#333" }}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Results */}
        <div style={{
          overflowY: "auto",
          flex: 1,
          scrollbarWidth: "thin",
          scrollbarColor: "#2a2a55 transparent"
        }}>
          {nodes.length === 0 && (
            <div style={{
              padding: "40px 20px",
              textAlign: "center",
              color: "#444", fontSize: "13px"
            }}>
              No components in this project yet.<br />
              <span style={{ fontSize: "11px", color: "#333" }}>
                Add components to search through them.
              </span>
            </div>
          )}

          {nodes.length > 0 && filtered.length === 0 && (
            <div style={{
              padding: "40px 20px",
              textAlign: "center",
              color: "#444", fontSize: "13px"
            }}>
              No components match "{query}"
            </div>
          )}

          {filtered.map((node, i) => {
            const nodeViolations = getNodeViolations(node.id);
            const connections = getNodeConnections(node.id);
            const color = getTypeColor(node.type);

            return (
              <div
                key={node.id}
                onClick={() => { onFocus(node.id); onClose(); }}
                style={{
                  padding: "12px 16px",
                  borderBottom: "1px solid #141414",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: "12px",
                  transition: "background 0.1s"
                }}
                onMouseEnter={e => e.currentTarget.style.background = "#12122a"}
                onMouseLeave={e => e.currentTarget.style.background = "transparent"}
              >
                {/* Type dot */}
                <div style={{
                  width: "32px", height: "32px",
                  borderRadius: "8px",
                  background: color + "15",
                  border: `1px solid ${color}30`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0
                }}>
                  <div style={{
                    width: "8px", height: "8px",
                    borderRadius: "50%",
                    background: color
                  }} />
                </div>

                {/* Info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{
                    fontSize: "13px", fontWeight: "600",
                    color: "#e5e5e5", marginBottom: "3px"
                  }}>
                    {highlightMatch(node.name, query)}
                  </div>
                  <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
                    <span style={{
                      fontSize: "10px", color: color,
                      background: color + "15",
                      padding: "1px 6px", borderRadius: "4px",
                      fontWeight: "600"
                    }}>
                      {node.type}
                    </span>
                    <span style={{ fontSize: "11px", color: "#444" }}>
                      {connections} connection{connections !== 1 ? "s" : ""}
                    </span>
                    {nodeViolations.length > 0 && (
                      <span style={{
                        fontSize: "11px", color: "#cc6666",
                        display: "flex", alignItems: "center", gap: "3px"
                      }}>
                        ⚠ {nodeViolations.length} violation{nodeViolations.length > 1 ? "s" : ""}
                      </span>
                    )}
                    {nodeViolations.length === 0 && connections > 0 && (
                      <span style={{ fontSize: "11px", color: "#4a7c59" }}>
                        ✓ compliant
                      </span>
                    )}
                  </div>
                </div>

                {/* Focus arrow */}
                <span style={{ color: "#333", fontSize: "14px", flexShrink: 0 }}>→</span>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div style={{
          padding: "8px 16px",
          borderTop: "1px solid #161632",
          display: "flex",
          gap: "16px",
          flexShrink: 0
        }}>
          {[
            { key: "↵ Enter", label: "focus first" },
            { key: "Esc", label: "close" },
          ].map(k => (
            <div key={k.key} style={{ display: "flex", gap: "5px", alignItems: "center" }}>
              <kbd style={{
                background: "#1a1a35", border: "1px solid #2a2a55",
                color: "#666", padding: "1px 6px",
                borderRadius: "4px", fontSize: "10px",
                fontFamily: "monospace"
              }}>
                {k.key}
              </kbd>
              <span style={{ fontSize: "10px", color: "#444" }}>{k.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function highlightMatch(text, query) {
  if (!query.trim()) return text;
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return text;
  return (
    <>
      {text.slice(0, idx)}
      <mark style={{
        background: "#f59e0b33",
        color: "#f59e0b",
        borderRadius: "2px",
        padding: "0 1px"
      }}>
        {text.slice(idx, idx + query.length)}
      </mark>
      {text.slice(idx + query.length)}
    </>
  );
}
