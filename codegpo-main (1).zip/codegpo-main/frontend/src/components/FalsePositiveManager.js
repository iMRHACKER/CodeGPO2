/**
 * CodeGPO — False Positive / Violation Acknowledgment Manager
 * Users can acknowledge, suppress or add notes to violations
 * Stored in localStorage — persists across sessions
 */

const STORAGE_KEY = "codegpo_acknowledged_violations";

export function getAcknowledged() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}"); } catch { return {}; }
}

export function acknowledgeViolation(violationKey, reason = "", expiryDays = 30) {
  const ack = getAcknowledged();
  ack[violationKey] = {
    reason,
    acknowledgedAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + expiryDays * 86400000).toISOString(),
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(ack));
}

export function unacknowledgeViolation(violationKey) {
  const ack = getAcknowledged();
  delete ack[violationKey];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(ack));
}

export function isAcknowledged(violationKey) {
  const ack = getAcknowledged();
  const entry = ack[violationKey];
  if (!entry) return false;
  // Check expiry
  if (entry.expiresAt && new Date(entry.expiresAt) < new Date()) {
    unacknowledgeViolation(violationKey);
    return false;
  }
  return true;
}

export function makeViolationKey(sourceId, targetId, ruleId) {
  return `${sourceId}__${targetId}__${ruleId}`;
}

export function filterAcknowledgedViolations(violations) {
  return violations.filter(v => {
    const key = makeViolationKey(v.source, v.target, v.ruleId);
    return !isAcknowledged(key);
  });
}

export function getAcknowledgedCount() {
  const ack = getAcknowledged();
  return Object.keys(ack).filter(k => isAcknowledged(k)).length;
}
