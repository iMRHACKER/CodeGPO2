import { useState } from "react";
import { useDiffStore } from "../state/diffStore";
import { useGraphStore } from "../state/graphStore";
import { useProjectStore } from "../state/projectStore";
import { useRulesStore } from "../state/rulesStore";
import SeverityBadge from "./SeverityBadge";

function timeAgo(isoString) {
  const diff = Date.now() - new Date(isoString).getTime();
  const mins = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}

function DiffSection({ title, items, color, bg, border, renderItem }) {
  const [open, setOpen] = useState(true);
  if (items.length === 0) return null;

  return (
    <div style={{ marginBottom: "14px" }}>
      <button
        onClick={() => setOpen(!open)}
        style={{
          background: "transparent", border: "none",
          width: "100%", textAlign: "left",
          display: "flex", alignItems: "center",
          justifyContent: "space-between",
          padding: "8px 0", cursor: "pointer"
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <div style={{
            width: "6px", height: "6px",
            borderRadius: "50%", background: color
          }} />
          <span style={{
            fontSize: "11px", fontWeight: "600",
            color: "#ccc", letterSpacing: "0.3px"
          }}>
            {title}
          </span>
          <span style={{
            fontSize: "10px", color: color,
            background: bg, border: `1px solid ${border}`,
            padding: "1px 6px", borderRadius: "10px",
            fontWeight: "700"
          }}>
            {items.length}
          </span>
        </div>
        <span style={{ color: "#333", fontSize: "14px" }}>{open ? "−" : "+"}</span>
      </button>

      {open && (
        <div style={{ display: "flex", flexDirection: "column", gap: "4px", paddingLeft: "14px" }}>
          {items.map((item, i) => (
            <div key={i} style={{
              padding: "8px 12px",
              background: bg,
              border: `1px solid ${border}`,
              borderLeft: `3px solid ${color}`,
              borderRadius: "6px",
              fontSize: "12px", color: "#bbb",
              lineHeight: "1.5"
            }}>
              {renderItem(item)}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function ArchitectureDiff({ onClose }) {
  const { snapshots, saveSnapshot, deleteSnapshot, computeDiff, getProjectSnapshots } = useDiffStore();
  const { nodes, edges, violations } = useGraphStore();
  const { evaluateCustomRules } = useRulesStore();
  const { getActiveProject } = useProjectStore();

  const activeProject = getActiveProject();
  const customViolations = evaluateCustomRules(nodes, edges);
  const allViolations = [...violations, ...customViolations];

  const projectSnapshots = getProjectSnapshots(activeProject?.id || "");

  const [selectedSnapshotId, setSelectedSnapshotId] = useState(null);
  const [diff, setDiff] = useState(null);
  const [snapshotLabel, setSnapshotLabel] = useState("");
  const [saving, setSaving] = useState(false);
  const [tab, setTab] = useState("compare"); // compare | snapshots

  const handleSaveSnapshot = () => {
    setSaving(true);
    saveSnapshot({
      projectId: activeProject?.id || "default",
      projectName: activeProject?.name || "Untitled",
      nodes, edges,
      violations: allViolations,
      label: snapshotLabel.trim() || `Snapshot — ${new Date().toLocaleString()}`
    });
    setSnapshotLabel("");
    setTimeout(() => setSaving(false), 400);
  };

  const handleCompare = (snapshotId) => {
    const snapshot = snapshots.find(s => s.id === snapshotId);
    if (!snapshot) return;

    setSelectedSnapshotId(snapshotId);

    const current = {
      nodes, edges,
      violations: allViolations
    };

    const result = computeDiff(snapshot, current);
    setDiff(result);
    setTab("compare");
  };

  const selectedSnapshot = snapshots.find(s => s.id === selectedSnapshotId);

  return (
    <div style={{
      position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
      background: "rgba(0,0,0,0.8)",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 1000, padding: "20px"
    }}>
      <div style={{
        background: "#0d0d1f",
        border: "1px solid #22224a",
        borderRadius: "14px",
        width: "700px",
        maxHeight: "88vh",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden"
      }}>

        {/* Header */}
        <div style={{
          padding: "18px 22px",
          borderBottom: "1px solid #202020",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexShrink: 0
        }}>
          <div>
            <h2 style={{ color: "#e5e5e5", margin: 0, fontSize: "14px", fontWeight: "600" }}>
              Architecture Diff
            </h2>
            <p style={{ color: "#555", fontSize: "11px", margin: "4px 0 0" }}>
              Compare your current architecture to a saved snapshot
            </p>
          </div>
          <button
            onClick={onClose}
            style={{
              background: "transparent", border: "none",
              color: "#555", cursor: "pointer", fontSize: "20px"
            }}
          >×</button>
        </div>

        {/* Tabs */}
        <div style={{
          display: "flex",
          borderBottom: "1px solid #202020",
          flexShrink: 0
        }}>
          {[
            { key: "compare", label: "Compare" },
            { key: "snapshots", label: `Snapshots (${projectSnapshots.length})` }
          ].map(t => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              style={{
                flex: 1,
                background: "transparent", border: "none",
                borderBottom: `2px solid ${tab === t.key ? "#e5e5e5" : "transparent"}`,
                color: tab === t.key ? "#e5e5e5" : "#555",
                padding: "11px", cursor: "pointer",
                fontSize: "12.5px",
                fontWeight: tab === t.key ? "600" : "400",
                transition: "all 0.15s", borderRadius: 0
              }}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Compare tab */}
        {tab === "compare" && (
          <div style={{ flex: 1, overflowY: "auto", padding: "20px" }}>

            {/* Current state summary */}
            <div style={{
              display: "grid", gridTemplateColumns: "1fr 1fr",
              gap: "10px", marginBottom: "20px"
            }}>
              <div style={{
                padding: "14px",
                background: "#12122a", border: "1px solid #1a1a35",
                borderRadius: "8px"
              }}>
                <div style={{
                  fontSize: "10px", color: "#555",
                  textTransform: "uppercase", letterSpacing: "1px",
                  marginBottom: "10px", fontWeight: "600"
                }}>
                  Current State
                </div>
                <div style={{ display: "flex", gap: "16px" }}>
                  <div>
                    <div style={{ fontSize: "20px", fontWeight: "700", color: "#e5e5e5" }}>
                      {nodes.length}
                    </div>
                    <div style={{ fontSize: "10px", color: "#555" }}>components</div>
                  </div>
                  <div>
                    <div style={{ fontSize: "20px", fontWeight: "700", color: "#e5e5e5" }}>
                      {edges.length}
                    </div>
                    <div style={{ fontSize: "10px", color: "#555" }}>connections</div>
                  </div>
                  <div>
                    <div style={{
                      fontSize: "20px", fontWeight: "700",
                      color: allViolations.length > 0 ? "#cc6666" : "#5a9e6f"
                    }}>
                      {allViolations.length}
                    </div>
                    <div style={{ fontSize: "10px", color: "#555" }}>violations</div>
                  </div>
                </div>
              </div>

              <div style={{
                padding: "14px",
                background: selectedSnapshot ? "#12122a" : "#0d0d1f",
                border: `1px solid ${selectedSnapshot ? "#1a1a35" : "#141414"}`,
                borderRadius: "8px"
              }}>
                <div style={{
                  fontSize: "10px", color: "#555",
                  textTransform: "uppercase", letterSpacing: "1px",
                  marginBottom: "10px", fontWeight: "600"
                }}>
                  Comparing To
                </div>
                {selectedSnapshot ? (
                  <div>
                    <div style={{ fontSize: "12px", color: "#ccc", marginBottom: "6px", fontWeight: "500" }}>
                      {selectedSnapshot.label}
                    </div>
                    <div style={{ display: "flex", gap: "16px" }}>
                      <div>
                        <div style={{ fontSize: "20px", fontWeight: "700", color: "#e5e5e5" }}>
                          {selectedSnapshot.nodeCount}
                        </div>
                        <div style={{ fontSize: "10px", color: "#555" }}>components</div>
                      </div>
                      <div>
                        <div style={{ fontSize: "20px", fontWeight: "700", color: "#e5e5e5" }}>
                          {selectedSnapshot.edgeCount}
                        </div>
                        <div style={{ fontSize: "10px", color: "#555" }}>connections</div>
                      </div>
                      <div>
                        <div style={{
                          fontSize: "20px", fontWeight: "700",
                          color: selectedSnapshot.violationCount > 0 ? "#cc6666" : "#5a9e6f"
                        }}>
                          {selectedSnapshot.violationCount}
                        </div>
                        <div style={{ fontSize: "10px", color: "#555" }}>violations</div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div style={{ fontSize: "12px", color: "#444", marginTop: "8px" }}>
                    Select a snapshot to compare →
                  </div>
                )}
              </div>
            </div>

            {/* Snapshot selector */}
            {projectSnapshots.length > 0 && (
              <div style={{ marginBottom: "20px" }}>
                <div style={{
                  fontSize: "10px", color: "#555",
                  textTransform: "uppercase", letterSpacing: "1px",
                  marginBottom: "8px", fontWeight: "600"
                }}>
                  Select Snapshot to Compare
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: "5px" }}>
                  {projectSnapshots.map(snap => (
                    <div
                      key={snap.id}
                      onClick={() => handleCompare(snap.id)}
                      style={{
                        padding: "10px 12px",
                        background: selectedSnapshotId === snap.id ? "#1a1a2a" : "#12122a",
                        border: `1px solid ${selectedSnapshotId === snap.id ? "#2a2a4a" : "#1a1a35"}`,
                        borderRadius: "8px",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        transition: "all 0.15s"
                      }}
                    >
                      <div>
                        <div style={{ fontSize: "12.5px", color: "#ccc", fontWeight: "500" }}>
                          {snap.label}
                        </div>
                        <div style={{ fontSize: "10px", color: "#444", marginTop: "2px" }}>
                          {snap.nodeCount} components · {snap.edgeCount} connections · {snap.violationCount} violations
                        </div>
                      </div>
                      <div style={{ fontSize: "10px", color: "#444", flexShrink: 0 }}>
                        {timeAgo(snap.timestamp)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {projectSnapshots.length === 0 && (
              <div style={{
                padding: "30px", textAlign: "center",
                border: "1px dashed #1a1a35", borderRadius: "8px",
                marginBottom: "20px"
              }}>
                <div style={{ fontSize: "28px", marginBottom: "10px", opacity: 0.3 }}>⊘</div>
                <div style={{ fontSize: "13px", color: "#555", marginBottom: "6px" }}>
                  No snapshots yet
                </div>
                <div style={{ fontSize: "11px", color: "#333" }}>
                  Save a snapshot below to start comparing
                </div>
              </div>
            )}

            {/* Diff results */}
            {diff && (
              <div style={{
                background: "#12122a",
                border: "1px solid #1a1a35",
                borderRadius: "10px",
                padding: "16px",
                marginBottom: "20px"
              }}>
                <div style={{
                  display: "flex", alignItems: "center",
                  justifyContent: "space-between", marginBottom: "16px"
                }}>
                  <div style={{
                    fontSize: "12px", fontWeight: "600", color: "#ccc"
                  }}>
                    Changes since snapshot
                  </div>
                  <div style={{ display: "flex", gap: "8px" }}>
                    {diff.summary.totalChanges === 0 && diff.newViolations.length === 0 && diff.fixedViolations.length === 0 ? (
                      <span style={{
                        fontSize: "11px", color: "#5a9e6f",
                        background: "#0f1a12", border: "1px solid #1a2e1e",
                        padding: "2px 10px", borderRadius: "20px"
                      }}>
                        ✓ No changes
                      </span>
                    ) : (
                      <span style={{
                        fontSize: "11px", color: "#f59e0b",
                        background: "#2a2010", border: "1px solid #4a3510",
                        padding: "2px 10px", borderRadius: "20px"
                      }}>
                        {diff.summary.totalChanges} change{diff.summary.totalChanges !== 1 ? "s" : ""}
                      </span>
                    )}
                    {diff.summary.healthDelta !== 0 && (
                      <span style={{
                        fontSize: "11px",
                        color: diff.summary.healthDelta > 0 ? "#cc6666" : "#5a9e6f",
                        background: diff.summary.healthDelta > 0 ? "#1a1010" : "#0f1a12",
                        border: `1px solid ${diff.summary.healthDelta > 0 ? "#2a1515" : "#1a2e1e"}`,
                        padding: "2px 10px", borderRadius: "20px"
                      }}>
                        {diff.summary.healthDelta > 0 ? "+" : ""}{diff.summary.healthDelta} violations
                      </span>
                    )}
                  </div>
                </div>

                {!diff.hasChanges && diff.fixedViolations.length === 0 && (
                  <div style={{ fontSize: "12px", color: "#444", textAlign: "center", padding: "20px" }}>
                    Your architecture is identical to the selected snapshot.
                  </div>
                )}

                <DiffSection
                  title="Added Components"
                  items={diff.addedNodes}
                  color="#5a9e6f"
                  bg="#0f1a12"
                  border="#1a2e1e"
                  renderItem={n => (
                    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                      <span style={{ color: "#5a9e6f", fontWeight: "700" }}>+</span>
                      <span style={{ fontWeight: "500", color: "#ccc" }}>{n.name}</span>
                      <span style={{ color: "#555" }}>{n.type}</span>
                    </div>
                  )}
                />

                <DiffSection
                  title="Removed Components"
                  items={diff.removedNodes}
                  color="#cc6666"
                  bg="#1a1212"
                  border="#2e1f1f"
                  renderItem={n => (
                    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                      <span style={{ color: "#cc6666", fontWeight: "700" }}>−</span>
                      <span style={{ fontWeight: "500", color: "#ccc", textDecoration: "line-through" }}>{n.name}</span>
                      <span style={{ color: "#555" }}>{n.type}</span>
                    </div>
                  )}
                />

                <DiffSection
                  title="Changed Components"
                  items={diff.changedNodes}
                  color="#f59e0b"
                  bg="#2a2010"
                  border="#4a3510"
                  renderItem={n => (
                    <div>
                      <span style={{ color: "#888", textDecoration: "line-through", fontSize: "11px" }}>
                        {n.old.name} ({n.old.type})
                      </span>
                      <span style={{ color: "#f59e0b", margin: "0 6px" }}>→</span>
                      <span style={{ color: "#ccc", fontWeight: "500" }}>
                        {n.new.name} ({n.new.type})
                      </span>
                    </div>
                  )}
                />

                <DiffSection
                  title="Added Connections"
                  items={diff.addedEdges}
                  color="#5a9e6f"
                  bg="#0f1a12"
                  border="#1a2e1e"
                  renderItem={e => (
                    <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                      <span style={{ color: "#5a9e6f", fontWeight: "700" }}>+</span>
                      <span style={{ color: "#ccc" }}>{e.sourceName}</span>
                      <span style={{ color: "#444" }}>→</span>
                      <span style={{ color: "#ccc" }}>{e.targetName}</span>
                    </div>
                  )}
                />

                <DiffSection
                  title="Removed Connections"
                  items={diff.removedEdges}
                  color="#cc6666"
                  bg="#1a1212"
                  border="#2e1f1f"
                  renderItem={e => (
                    <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                      <span style={{ color: "#cc6666", fontWeight: "700" }}>−</span>
                      <span style={{ color: "#888", textDecoration: "line-through" }}>{e.sourceName}</span>
                      <span style={{ color: "#444" }}>→</span>
                      <span style={{ color: "#888", textDecoration: "line-through" }}>{e.targetName}</span>
                    </div>
                  )}
                />

                <DiffSection
                  title="New Violations"
                  items={diff.newViolations}
                  color="#cc6666"
                  bg="#1a1212"
                  border="#2e1f1f"
                  renderItem={v => (
                    <div style={{ display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap" }}>
                      <span style={{
                        fontSize: "10px", fontWeight: "700",
                        color: "#cc6666", background: "#2a1818",
                        padding: "1px 6px", borderRadius: "4px"
                      }}>
                        {v.ruleId}
                      </span>
                      <SeverityBadge severity={v.severity} />
                      <span style={{ color: "#bbb", fontSize: "11px" }}>{v.message}</span>
                    </div>
                  )}
                />

                <DiffSection
                  title="Fixed Violations"
                  items={diff.fixedViolations}
                  color="#5a9e6f"
                  bg="#0f1a12"
                  border="#1a2e1e"
                  renderItem={v => (
                    <div style={{ display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap" }}>
                      <span style={{ color: "#5a9e6f", fontWeight: "700" }}>✓</span>
                      <span style={{
                        fontSize: "10px", fontWeight: "700",
                        color: "#5a9e6f", background: "#162118",
                        padding: "1px 6px", borderRadius: "4px"
                      }}>
                        {v.ruleId}
                      </span>
                      <span style={{ color: "#bbb", fontSize: "11px" }}>{v.message}</span>
                    </div>
                  )}
                />
              </div>
            )}

            {/* Save snapshot */}
            <div style={{
              background: "#12122a",
              border: "1px solid #1a1a35",
              borderRadius: "10px",
              padding: "16px"
            }}>
              <div style={{
                fontSize: "12px", color: "#ccc",
                fontWeight: "600", marginBottom: "10px"
              }}>
                Save Current State as Snapshot
              </div>
              <div style={{ display: "flex", gap: "8px" }}>
                <input
                  value={snapshotLabel}
                  onChange={e => setSnapshotLabel(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && handleSaveSnapshot()}
                  placeholder="Label (e.g. Before refactor, v1.2, Sprint 3)"
                  style={{
                    flex: 1, padding: "9px 12px",
                    background: "#0d0d1f", border: "1px solid #22224a",
                    color: "#e5e5e5", borderRadius: "8px",
                    fontSize: "12px", outline: "none"
                  }}
                />
                <button
                  onClick={handleSaveSnapshot}
                  disabled={saving || nodes.length === 0}
                  style={{
                    background: saving ? "#161632" : "#1a1a35",
                    border: "1px solid #2a2a55",
                    color: saving ? "#444" : "#ccc",
                    padding: "9px 18px", borderRadius: "8px",
                    cursor: saving || nodes.length === 0 ? "not-allowed" : "pointer",
                    fontSize: "12px", fontWeight: "500",
                    flexShrink: 0, transition: "all 0.15s"
                  }}
                >
                  {saving ? "Saving..." : "Save Snapshot"}
                </button>
              </div>
              {nodes.length === 0 && (
                <div style={{ fontSize: "11px", color: "#444", marginTop: "6px" }}>
                  Add components before saving a snapshot.
                </div>
              )}
            </div>
          </div>
        )}

        {/* Snapshots tab */}
        {tab === "snapshots" && (
          <div style={{ flex: 1, overflowY: "auto", padding: "16px 20px" }}>
            {projectSnapshots.length === 0 && (
              <div style={{
                textAlign: "center", padding: "50px 20px",
                color: "#444", fontSize: "13px"
              }}>
                <div style={{ fontSize: "28px", marginBottom: "12px", opacity: 0.3 }}>⊘</div>
                No snapshots saved yet for this project.
              </div>
            )}
            <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
              {projectSnapshots.map(snap => (
                <div key={snap.id} style={{
                  padding: "12px 14px",
                  background: "#12122a", border: "1px solid #1a1a35",
                  borderRadius: "8px",
                  display: "flex", alignItems: "center",
                  justifyContent: "space-between", gap: "12px"
                }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: "12.5px", color: "#ccc", fontWeight: "500", marginBottom: "4px" }}>
                      {snap.label}
                    </div>
                    <div style={{ display: "flex", gap: "14px" }}>
                      <span style={{ fontSize: "11px", color: "#555" }}>{snap.nodeCount} components</span>
                      <span style={{ fontSize: "11px", color: "#555" }}>{snap.edgeCount} connections</span>
                      <span style={{
                        fontSize: "11px",
                        color: snap.violationCount > 0 ? "#854444" : "#4a7c59"
                      }}>
                        {snap.violationCount} violations
                      </span>
                    </div>
                  </div>
                  <div style={{ fontSize: "10px", color: "#444", flexShrink: 0 }}>
                    {timeAgo(snap.timestamp)}
                  </div>
                  <button
                    onClick={() => { handleCompare(snap.id); setTab("compare"); }}
                    style={{
                      background: "#1a1a35", border: "1px solid #2a2a55",
                      color: "#ccc", padding: "5px 12px",
                      borderRadius: "6px", cursor: "pointer",
                      fontSize: "11px", flexShrink: 0
                    }}
                  >
                    Compare →
                  </button>
                  <button
                    onClick={() => {
                      if (confirm("Delete this snapshot?")) deleteSnapshot(snap.id);
                    }}
                    style={{
                      background: "transparent", border: "none",
                      color: "#333", cursor: "pointer",
                      fontSize: "15px", transition: "color 0.15s",
                      flexShrink: 0
                    }}
                    onMouseEnter={e => e.currentTarget.style.color = "#cc6666"}
                    onMouseLeave={e => e.currentTarget.style.color = "#333"}
                  >
                    🗑
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
