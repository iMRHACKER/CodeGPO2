import { useState } from "react";
import { encodeArchitecture, buildShareUrl } from "../core/shareEncoder";
import { useGraphStore } from "../state/graphStore";
import { useProjectStore } from "../state/projectStore";
import { useRulesStore } from "../state/rulesStore";
import { calculateScore } from "../core/architectureScore";

export default function ShareModal({ onClose, allViolations }) {
  const { nodes, edges } = useGraphStore();
  const { getActiveProject } = useProjectStore();
  const { evaluateCustomRules } = useRulesStore();

  const activeProject = getActiveProject();
  const score = calculateScore(nodes, edges, allViolations);

  const [copied, setCopied] = useState(false);
  const [tab, setTab] = useState("link"); // link | preview

  const encoded = encodeArchitecture({
    project: activeProject,
    nodes, edges,
    violations: allViolations,
    score
  });

  const shareUrl = encoded ? buildShareUrl(encoded) : null;

  const handleCopy = () => {
    if (!shareUrl) return;
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  const charCount = shareUrl?.length || 0;
  const isLarge = charCount > 4000;

  return (
    <div style={{
      position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
      background: "rgba(0,0,0,0.8)",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 1000, padding: "20px"
    }}>
      <div style={{
        background: "#0d0d1f",
        border: "1px solid #22224a",
        borderRadius: "14px",
        width: "560px",
        maxHeight: "88vh",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden"
      }}>

        {/* Header */}
        <div style={{
          padding: "18px 22px",
          borderBottom: "1px solid #202020",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexShrink: 0
        }}>
          <div>
            <h2 style={{ color: "#e5e5e5", margin: 0, fontSize: "14px", fontWeight: "600" }}>
              Share Architecture
            </h2>
            <p style={{ color: "#555", fontSize: "11px", margin: "4px 0 0" }}>
              Generate a read-only link — no login required
            </p>
          </div>
          <button onClick={onClose} style={{
            background: "transparent", border: "none",
            color: "#555", cursor: "pointer", fontSize: "20px"
          }}>×</button>
        </div>

        {/* Tabs */}
        <div style={{
          display: "flex", borderBottom: "1px solid #202020", flexShrink: 0
        }}>
          {[
            { key: "link", label: "Share Link" },
            { key: "preview", label: "Preview" }
          ].map(t => (
            <button key={t.key} onClick={() => setTab(t.key)} style={{
              flex: 1, background: "transparent", border: "none",
              borderBottom: `2px solid ${tab === t.key ? "#e5e5e5" : "transparent"}`,
              color: tab === t.key ? "#e5e5e5" : "#555",
              padding: "11px", cursor: "pointer",
              fontSize: "12.5px",
              fontWeight: tab === t.key ? "600" : "400",
              transition: "all 0.15s", borderRadius: 0
            }}>
              {t.label}
            </button>
          ))}
        </div>

        <div style={{ flex: 1, overflowY: "auto", padding: "22px" }}>

          {tab === "link" && (
            <div>
              {nodes.length === 0 ? (
                <div style={{
                  textAlign: "center", padding: "40px 20px",
                  color: "#555", fontSize: "13px"
                }}>
                  Add some components before sharing.
                </div>
              ) : (
                <>
                  {/* What's included */}
                  <div style={{
                    display: "grid", gridTemplateColumns: "1fr 1fr 1fr",
                    gap: "8px", marginBottom: "20px"
                  }}>
                    {[
                      { label: "Components", value: nodes.length, color: "#6699cc" },
                      { label: "Connections", value: edges.length, color: "#7c3aed" },
                      { label: "Violations", value: allViolations.length, color: allViolations.length > 0 ? "#cc6666" : "#5a9e6f" },
                    ].map(s => (
                      <div key={s.label} style={{
                        padding: "12px", background: "#12122a",
                        border: "1px solid #1a1a35", borderRadius: "8px",
                        textAlign: "center"
                      }}>
                        <div style={{
                          fontSize: "20px", fontWeight: "700",
                          color: s.color, marginBottom: "4px"
                        }}>
                          {s.value}
                        </div>
                        <div style={{ fontSize: "10px", color: "#555" }}>{s.label}</div>
                      </div>
                    ))}
                  </div>

                  {/* Score badge */}
                  {score && (
                    <div style={{
                      display: "flex", alignItems: "center", gap: "12px",
                      padding: "12px 14px",
                      background: "#12122a", border: "1px solid #1a1a35",
                      borderRadius: "8px", marginBottom: "20px"
                    }}>
                      <div style={{
                        fontSize: "24px", fontWeight: "800",
                        color: score.gradeColor
                      }}>
                        {score.grade}
                      </div>
                      <div>
                        <div style={{ fontSize: "12px", color: "#ccc", fontWeight: "500" }}>
                          Health Score: {score.score}/100 — {score.status}
                        </div>
                        <div style={{ fontSize: "11px", color: "#555", marginTop: "2px" }}>
                          Included in the shared link
                        </div>
                      </div>
                    </div>
                  )}

                  {/* What's shared notice */}
                  <div style={{
                    padding: "10px 12px",
                    background: "#0f1a12",
                    border: "1px solid #1a2e1e",
                    borderRadius: "8px",
                    marginBottom: "20px"
                  }}>
                    <div style={{ fontSize: "11px", color: "#5a9e6f", lineHeight: "1.7" }}>
                      ✓ Read-only — recipients cannot edit<br />
                      ✓ No login required to view<br />
                      ✓ Works forever — data is in the URL<br />
                      ✓ Includes architecture, violations & score
                    </div>
                  </div>

                  {/* URL box */}
                  <div style={{
                    background: "#12122a",
                    border: "1px solid #1a1a35",
                    borderRadius: "8px",
                    padding: "12px",
                    marginBottom: "12px",
                    fontFamily: "monospace",
                    fontSize: "11px",
                    color: "#666",
                    wordBreak: "break-all",
                    lineHeight: "1.6",
                    maxHeight: "80px",
                    overflowY: "auto"
                  }}>
                    {shareUrl}
                  </div>

                  {isLarge && (
                    <div style={{
                      padding: "8px 12px",
                      background: "#2a2010",
                      border: "1px solid #4a3510",
                      borderRadius: "6px",
                      fontSize: "11px", color: "#f59e0b",
                      marginBottom: "12px", lineHeight: "1.6"
                    }}>
                      ⚠ Large architecture ({charCount.toLocaleString()} chars). Some platforms
                      may truncate long URLs. Consider exporting PDF instead.
                    </div>
                  )}

                  <button
                    onClick={handleCopy}
                    style={{
                      width: "100%", padding: "11px",
                      background: copied ? "#0f1a12" : "#1a1a35",
                      border: `1px solid ${copied ? "#1a2e1e" : "#2a2a55"}`,
                      color: copied ? "#5a9e6f" : "#e5e5e5",
                      borderRadius: "8px", cursor: "pointer",
                      fontSize: "13px", fontWeight: "600",
                      transition: "all 0.2s"
                    }}
                  >
                    {copied ? "✓ Copied to clipboard!" : "Copy Share Link"}
                  </button>

                  <div style={{
                    marginTop: "16px", padding: "12px",
                    background: "#12122a", border: "1px solid #1a1a35",
                    borderRadius: "8px"
                  }}>
                    <div style={{
                      fontSize: "11px", color: "#555",
                      marginBottom: "8px", fontWeight: "600",
                      textTransform: "uppercase", letterSpacing: "0.8px"
                    }}>
                      Share via
                    </div>
                    <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
                      {[
                        {
                          label: "Email",
                          action: () => window.open(
                            `mailto:?subject=CodeGPO Architecture: ${activeProject?.name || "Untitled"}&body=View my architecture here: ${shareUrl}`
                          )
                        },
                        {
                          label: "Slack",
                          action: () => navigator.clipboard.writeText(
                            `🏗️ Check out my architecture on CodeGPO:\n${shareUrl}`
                          ).then(() => alert("Slack message copied!"))
                        },
                        {
                          label: "Twitter/X",
                          action: () => window.open(
                            `https://twitter.com/intent/tweet?text=Check out my software architecture built with CodeGPO!&url=${encodeURIComponent(shareUrl)}`
                          )
                        }
                      ].map(btn => (
                        <button
                          key={btn.label}
                          onClick={btn.action}
                          style={{
                            background: "transparent",
                            border: "1px solid #22224a",
                            color: "#888", padding: "6px 14px",
                            borderRadius: "6px", cursor: "pointer",
                            fontSize: "12px", transition: "all 0.15s"
                          }}
                          onMouseEnter={e => { e.currentTarget.style.color = "#ccc"; e.currentTarget.style.borderColor = "#333"; }}
                          onMouseLeave={e => { e.currentTarget.style.color = "#888"; e.currentTarget.style.borderColor = "#22224a"; }}
                        >
                          {btn.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {tab === "preview" && (
            <div>
              <div style={{
                fontSize: "11px", color: "#555",
                marginBottom: "14px", lineHeight: "1.6"
              }}>
                This is what the recipient will see when they open your link.
              </div>

              {/* Simulated share view */}
              <div style={{
                background: "#0d0d1f",
                border: "1px solid #1a1a35",
                borderRadius: "10px",
                overflow: "hidden"
              }}>
                {/* Fake header */}
                <div style={{
                  padding: "12px 16px",
                  background: "#12122a",
                  borderBottom: "1px solid #161632",
                  display: "flex", alignItems: "center",
                  justifyContent: "space-between"
                }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <span style={{ fontSize: "14px" }}>⚡</span>
                    <span style={{ fontSize: "13px", fontWeight: "600", color: "#e5e5e5" }}>CodeGPO</span>
                    <span style={{
                      fontSize: "9px", color: "#555",
                      background: "#161632", border: "1px solid #22224a",
                      padding: "1px 6px", borderRadius: "4px"
                    }}>READ ONLY</span>
                  </div>
                  <span style={{ fontSize: "11px", color: "#444" }}>
                    {activeProject?.name || "Untitled Project"}
                  </span>
                </div>

                <div style={{ padding: "16px" }}>
                  {/* Stats */}
                  <div style={{
                    display: "grid", gridTemplateColumns: "repeat(4, 1fr)",
                    gap: "8px", marginBottom: "14px"
                  }}>
                    {[
                      { label: "Components", val: nodes.length },
                      { label: "Connections", val: edges.length },
                      { label: "Violations", val: allViolations.length },
                      { label: "Score", val: score ? `${score.score}/100` : "N/A" },
                    ].map(s => (
                      <div key={s.label} style={{
                        padding: "8px",
                        background: "#0d0d1f",
                        border: "1px solid #1a1a35",
                        borderRadius: "6px",
                        textAlign: "center"
                      }}>
                        <div style={{ fontSize: "14px", fontWeight: "700", color: "#e5e5e5" }}>
                          {s.val}
                        </div>
                        <div style={{ fontSize: "9px", color: "#555" }}>{s.label}</div>
                      </div>
                    ))}
                  </div>

                  {/* Node list preview */}
                  <div style={{
                    fontSize: "10px", color: "#444",
                    marginBottom: "8px", letterSpacing: "1px",
                    textTransform: "uppercase", fontWeight: "600"
                  }}>
                    Components
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
                    {nodes.slice(0, 6).map(n => (
                      <div key={n.id} style={{
                        display: "flex", alignItems: "center",
                        gap: "8px", padding: "6px 8px",
                        background: "#12122a", borderRadius: "5px"
                      }}>
                        <div style={{
                          width: "6px", height: "6px",
                          borderRadius: "50%",
                          background: getTypeColor(n.type)
                        }} />
                        <span style={{ fontSize: "12px", color: "#bbb" }}>{n.name}</span>
                        <span style={{ fontSize: "10px", color: "#444", marginLeft: "auto" }}>{n.type}</span>
                      </div>
                    ))}
                    {nodes.length > 6 && (
                      <div style={{ fontSize: "11px", color: "#444", padding: "4px 8px" }}>
                        +{nodes.length - 6} more components
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function getTypeColor(type) {
  if (!type) return "#555";
  const t = type.toLowerCase();
  if (["user","client","browser","frontend"].some(k => t.includes(k))) return "#f59e0b";
  if (["database","db","sql","mongo","redis"].some(k => t.includes(k))) return "#0ea5e9";
  if (["api","rest"].some(k => t.includes(k))) return "#22c55e";
  if (["service","microservice"].some(k => t.includes(k))) return "#7c3aed";
  if (["queue","kafka","rabbit"].some(k => t.includes(k))) return "#ec4899";
  if (["gateway","proxy","nginx"].some(k => t.includes(k))) return "#f97316";
  if (["worker","job","cron"].some(k => t.includes(k))) return "#8b5cf6";
  if (["external","vendor"].some(k => t.includes(k))) return "#64748b";
  if (["cache"].some(k => t.includes(k))) return "#06b6d4";
  return "#888";
}
