import { useState } from "react";
import { TEMPLATES } from "../data/templates";
import { DEMO_TEMPLATES, loadTemplateSeed } from "../data/demoSeed";
import { useGraphStore } from "../state/graphStore";
import { useProjectStore } from "../state/projectStore";
import { useAuditStore, ACTION_TYPES } from "../state/auditStore";
import { calculateScore } from "../core/architectureScore";
import { evaluateGraph } from "../core/governanceEngine";

export default function TemplateGallery({ onClose, onLoaded }) {
  const [hoverId, setHoverId] = useState(null);
  const [loadingId, setLoadingId] = useState(null);
  const [preview, setPreview] = useState(null);

  const { setGraph } = useGraphStore();
  const { saveActiveGraph, getActiveProject } = useProjectStore();
  const { record } = useAuditStore();
  const activeProject = getActiveProject();

  const handleLoad = (template) => {
    setLoadingId(template.id);

    // Support both TEMPLATES format and DEMO_TEMPLATES (seed) format
    let nodes, edges;
    if (template.seed) {
      // Demo seed format — IDs already set, no prefix needed
      nodes = template.seed.nodes;
      edges = template.seed.edges;
    } else {
      // Old template format — prefix IDs
      nodes = template.nodes.map(n => ({ ...n, id: `${template.id}-${n.id}` }));
      edges = template.edges.map(e => ({
        source: `${template.id}-${e.source}`,
        target: `${template.id}-${e.target}`,
      }));
    }

    setTimeout(() => {
      setGraph(nodes, edges);
      if (activeProject) saveActiveGraph(nodes, edges);
      record(
        ACTION_TYPES.SCAN_COMPLETED,
        `Loaded template: ${template.name}`,
        activeProject?.name
      );
      setLoadingId(null);
      onClose();
      if (onLoaded) onLoaded();
    }, 400);
  };

  const getPreviewScore = (template) => {
    const nodes = template.seed
      ? template.seed.nodes
      : template.nodes.map(n => ({ ...n, id: `prev-${n.id}` }));
    const edges = template.seed
      ? template.seed.edges
      : template.edges.map(e => ({ source: `prev-${e.source}`, target: `prev-${e.target}` }));
    const violations = evaluateGraph(nodes, edges);
    return calculateScore(nodes, edges, violations);
  };

  // Merge demo templates + existing templates, demo first
  const allTemplates = [...DEMO_TEMPLATES, ...TEMPLATES];

  const TAG_COLORS = {
    popular:  { color: "#6699cc", bg: "#0f1a2a", border: "#1a2e44" },
    complex:  { color: "#a78bfa", bg: "#1a1228", border: "#2e1f44" },
    advanced: { color: "#f97316", bg: "#2a1a0a", border: "#4a2a10" },
    cloud:    { color: "#0ea5e9", bg: "#0a1a2a", border: "#102a3a" },
    secure:   { color: "#5a9e6f", bg: "#0f1a12", border: "#1a2e1e" },
    starter:  { color: "#f59e0b", bg: "#2a2010", border: "#4a3510" },
    simple:   { color: "#888",    bg: "#161632", border: "#2a2a55" },
    realtime: { color: "#ec4899", bg: "#2a1020", border: "#4a1535" },
  };

  return (
    <div style={{
      position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
      background: "rgba(0,0,0,0.8)",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 1000, padding: "20px"
    }}>
      <div style={{
        background: "#0d0d1f",
        border: "1px solid #22224a",
        borderRadius: "14px",
        width: "760px",
        maxHeight: "88vh",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden"
      }}>

        {/* Header */}
        <div style={{
          padding: "20px 22px",
          borderBottom: "1px solid #202020",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexShrink: 0
        }}>
          <div>
            <h2 style={{ color: "#e5e5e5", margin: 0, fontSize: "14px", fontWeight: "600" }}>
              Architecture Templates
            </h2>
            <p style={{ color: "#555", fontSize: "11px", margin: "4px 0 0" }}>
              Load a pre-built architecture and customize it
            </p>
          </div>
          <button
            onClick={onClose}
            style={{
              background: "transparent", border: "none",
              color: "#555", cursor: "pointer", fontSize: "20px"
            }}
          >×</button>
        </div>

        <div style={{
          display: "flex", flex: 1, overflow: "hidden"
        }}>

          {/* Template list */}
          <div style={{
            flex: 1, overflowY: "auto", padding: "16px",
            scrollbarWidth: "thin", scrollbarColor: "#2a2a55 transparent",
            display: "flex", flexDirection: "column", gap: "8px"
          }}>
            {/* Section: Demo Templates */}
            <div style={{ fontSize:"10px", color:"#555", letterSpacing:"1px", textTransform:"uppercase", fontWeight:"600", padding:"4px 4px 8px", borderBottom:"1px solid #161632", marginBottom:"4px" }}>
              ⚡ Demo Architectures
            </div>
            {DEMO_TEMPLATES.map(template => {
              const score = getPreviewScore(template);
              const isHovered = hoverId === template.id;
              const isLoading = loadingId === template.id;
              return (
                <div key={template.id} onMouseEnter={() => { setHoverId(template.id); setPreview(template); }} onMouseLeave={() => setHoverId(null)}
                  style={{ padding:"14px 16px", background: isHovered ? "#12122a" : "transparent", border:`1px solid ${isHovered ? "#2a2a55" : "#161632"}`, borderRadius:"10px", cursor:"pointer", transition:"all 0.15s", display:"flex", alignItems:"center", gap:"14px" }}>
                  <div style={{ width:"42px", height:"42px", background:"#0d0d1f", border:"1px solid #1a1a35", borderRadius:"10px", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"20px", flexShrink:0 }}>
                    {template.icon}
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:"8px", marginBottom:"4px" }}>
                      <span style={{ fontSize:"13px", fontWeight:"600", color:"#e5e5e5" }}>{template.name}</span>
                      {template.tags?.map(tag => (
                        <span key={tag} style={{ fontSize:"9px", fontWeight:"600", color:"#7c3aed", background:"rgba(124,58,237,0.1)", border:"1px solid rgba(124,58,237,0.2)", padding:"1px 6px", borderRadius:"4px", letterSpacing:"0.5px" }}>{tag.toUpperCase()}</span>
                      ))}
                    </div>
                    <div style={{ fontSize:"11px", color:"#555", marginBottom:"6px" }}>{template.description}</div>
                    <div style={{ display:"flex", gap:"14px" }}>
                      <span style={{ fontSize:"11px", color:"#444" }}>{template.seed.nodes.length} components</span>
                      <span style={{ fontSize:"11px", color:"#444" }}>{template.seed.edges.length} connections</span>
                      {score && <span style={{ fontSize:"11px", color:score.gradeColor, fontWeight:"600" }}>Score {score.score}/100</span>}
                    </div>
                  </div>
                  <button onClick={() => handleLoad(template)} disabled={isLoading}
                    style={{ background: isLoading ? "#161632" : "linear-gradient(135deg,rgba(124,58,237,0.15),rgba(14,165,233,0.1))", border:"1px solid rgba(124,58,237,0.3)", color: isLoading ? "#444" : "#a78bfa", padding:"7px 16px", borderRadius:"8px", cursor: isLoading ? "not-allowed" : "pointer", fontSize:"12px", fontWeight:"500", flexShrink:0, minWidth:"70px" }}>
                    {isLoading ? "Loading..." : "Load →"}
                  </button>
                </div>
              );
            })}

            {/* Section: Community Templates */}
            <div style={{ fontSize:"10px", color:"#555", letterSpacing:"1px", textTransform:"uppercase", fontWeight:"600", padding:"16px 4px 8px", borderBottom:"1px solid #161632", marginBottom:"4px", marginTop:"8px" }}>
              📦 Community Templates
            </div>
            {TEMPLATES.map(template => {
              const score = getPreviewScore(template);
              const isHovered = hoverId === template.id;
              const isLoading = loadingId === template.id;

              return (
                <div
                  key={template.id}
                  onMouseEnter={() => { setHoverId(template.id); setPreview(template); }}
                  onMouseLeave={() => setHoverId(null)}
                  style={{
                    padding: "14px 16px",
                    background: isHovered ? "#12122a" : "transparent",
                    border: `1px solid ${isHovered ? "#2a2a55" : "#161632"}`,
                    borderRadius: "10px",
                    cursor: "pointer",
                    transition: "all 0.15s",
                    display: "flex",
                    alignItems: "center",
                    gap: "14px"
                  }}
                >
                  {/* Icon */}
                  <div style={{
                    width: "42px", height: "42px",
                    background: "#0d0d1f",
                    border: "1px solid #1a1a35",
                    borderRadius: "10px",
                    display: "flex", alignItems: "center",
                    justifyContent: "center", fontSize: "20px",
                    flexShrink: 0
                  }}>
                    {template.icon}
                  </div>

                  {/* Info */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{
                      display: "flex", alignItems: "center",
                      gap: "8px", marginBottom: "4px"
                    }}>
                      <span style={{
                        fontSize: "13px", fontWeight: "600",
                        color: "#e5e5e5"
                      }}>
                        {template.name}
                      </span>
                      {template.tags?.map(tag => {
                        const tc = TAG_COLORS[tag] || TAG_COLORS.simple;
                        return (
                          <span key={tag} style={{
                            fontSize: "9px", fontWeight: "600",
                            color: tc.color, background: tc.bg,
                            border: `1px solid ${tc.border}`,
                            padding: "1px 6px", borderRadius: "4px",
                            letterSpacing: "0.5px"
                          }}>
                            {tag.toUpperCase()}
                          </span>
                        );
                      })}
                    </div>
                    <div style={{ fontSize: "11px", color: "#555", marginBottom: "8px" }}>
                      {template.description}
                    </div>
                    <div style={{ display: "flex", gap: "14px" }}>
                      <span style={{ fontSize: "11px", color: "#444" }}>
                        {template.seed ? template.seed.nodes.length : template.nodes.length} components
                      </span>
                      <span style={{ fontSize: "11px", color: "#444" }}>
                        {template.seed ? template.seed.edges.length : template.edges.length} connections
                      </span>
                      {score && (
                        <span style={{
                          fontSize: "11px",
                          color: score.gradeColor,
                          fontWeight: "600"
                        }}>
                          Score {score.score}/100
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Load button */}
                  <button
                    onClick={() => handleLoad(template)}
                    disabled={isLoading}
                    style={{
                      background: isLoading ? "#161632" : "#1a1a35",
                      border: "1px solid #2a2a55",
                      color: isLoading ? "#444" : "#ccc",
                      padding: "7px 16px",
                      borderRadius: "8px",
                      cursor: isLoading ? "not-allowed" : "pointer",
                      fontSize: "12px",
                      fontWeight: "500",
                      flexShrink: 0,
                      transition: "all 0.15s",
                      minWidth: "70px"
                    }}
                    onMouseEnter={e => {
                      if (!isLoading) {
                        e.currentTarget.style.background = "#22224a";
                        e.currentTarget.style.color = "#e5e5e5";
                      }
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.background = isLoading ? "#161632" : "#1a1a35";
                      e.currentTarget.style.color = isLoading ? "#444" : "#ccc";
                    }}
                  >
                    {isLoading ? "Loading..." : "Load →"}
                  </button>
                </div>
              );
            })}
          </div>

          {/* Preview panel */}
          {preview && (
            <div style={{
              width: "240px",
              borderLeft: "1px solid #161632",
              padding: "16px",
              overflowY: "auto",
              flexShrink: 0,
              scrollbarWidth: "thin",
              scrollbarColor: "#2a2a55 transparent"
            }}>
              <div style={{
                fontSize: "10px", color: "#555",
                letterSpacing: "1px", textTransform: "uppercase",
                fontWeight: "600", marginBottom: "12px"
              }}>
                Preview
              </div>

              <div style={{ fontSize: "24px", marginBottom: "8px" }}>
                {preview.icon}
              </div>
              <div style={{
                fontSize: "13px", fontWeight: "600",
                color: "#e5e5e5", marginBottom: "6px"
              }}>
                {preview.name}
              </div>
              <div style={{
                fontSize: "11px", color: "#666",
                lineHeight: "1.7", marginBottom: "16px"
              }}>
                {preview.description}
              </div>

              {/* Component list */}
              <div style={{
                fontSize: "10px", color: "#555",
                letterSpacing: "1px", textTransform: "uppercase",
                fontWeight: "600", marginBottom: "8px"
              }}>
                Components
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
                {(preview.seed ? preview.seed.nodes : preview.nodes).map(n => (
                  <div key={n.id} style={{
                    display: "flex", alignItems: "center",
                    gap: "8px", padding: "4px 0",
                    borderBottom: "1px solid #141414"
                  }}>
                    <div style={{
                      width: "6px", height: "6px",
                      borderRadius: "50%",
                      background: getTypeColor(n.type),
                      flexShrink: 0
                    }} />
                    <span style={{ fontSize: "11px", color: "#bbb" }}>{n.name}</span>
                    <span style={{ fontSize: "10px", color: "#444", marginLeft: "auto" }}>
                      {n.type}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function getTypeColor(type) {
  if (!type) return "#555";
  const t = type.toLowerCase();
  if (["user","client","browser","frontend"].some(k => t.includes(k))) return "#f59e0b";
  if (["database","db","sql","mongo","redis"].some(k => t.includes(k))) return "#0ea5e9";
  if (["api","rest"].some(k => t.includes(k))) return "#22c55e";
  if (["service","microservice"].some(k => t.includes(k))) return "#7c3aed";
  if (["queue","kafka","rabbit","sqs"].some(k => t.includes(k))) return "#ec4899";
  if (["gateway","proxy","nginx","load"].some(k => t.includes(k))) return "#f97316";
  if (["worker","job","cron"].some(k => t.includes(k))) return "#8b5cf6";
  if (["external","vendor"].some(k => t.includes(k))) return "#64748b";
  if (["cache","memcached"].some(k => t.includes(k))) return "#06b6d4";
  return "#888";
}
