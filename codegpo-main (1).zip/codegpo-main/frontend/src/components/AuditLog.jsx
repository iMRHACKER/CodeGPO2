import { useState } from "react";
import { useAuditStore, ACTION_LABELS, ACTION_COLORS, ACTION_ICONS } from "../state/auditStore";

function timeAgo(isoString) {
  const diff = Date.now() - new Date(isoString).getTime();
  const mins = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}

function ExplanationCard({ exp }) {
  const [open, setOpen] = useState(false);

  return (
    <div style={{
      background: "#12122a",
      border: "1px solid #22224a",
      borderRadius: "8px",
      marginBottom: "8px",
      overflow: "hidden"
    }}>
      {/* Header */}
      <div
        onClick={() => setOpen(!open)}
        style={{
          padding: "12px 14px",
          cursor: "pointer",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          gap: "10px"
        }}
      >
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: "12.5px", fontWeight: "600", color: "#ccc", marginBottom: "4px" }}>
            {exp.projectName || "Untitled Project"}
          </div>
          <div style={{ display: "flex", gap: "12px" }}>
            <span style={{ fontSize: "11px", color: "#555" }}>{exp.nodeCount} components</span>
            <span style={{ fontSize: "11px", color: "#555" }}>{exp.edgeCount} connections</span>
            {exp.violationCount > 0 && (
              <span style={{ fontSize: "11px", color: "#854444" }}>{exp.violationCount} violations</span>
            )}
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "4px" }}>
          <span style={{ fontSize: "10px", color: "#444" }}>{timeAgo(exp.timestamp)}</span>
          <span style={{ fontSize: "14px", color: "#333" }}>{open ? "−" : "+"}</span>
        </div>
      </div>

      {/* Expanded content */}
      {open && exp.sections && (
        <div style={{ borderTop: "1px solid #161632" }}>
          {Object.entries(exp.sections).map(([key, value]) => (
            value ? (
              <div key={key} style={{
                padding: "12px 14px",
                borderBottom: "1px solid #0d0d1f"
              }}>
                <div style={{
                  fontSize: "10px", color: "#555",
                  letterSpacing: "1px", textTransform: "uppercase",
                  marginBottom: "6px", fontWeight: "600"
                }}>{key}</div>
                <p style={{
                  fontSize: "12px", color: "#aaa",
                  lineHeight: "1.8", margin: 0,
                  whiteSpace: "pre-wrap"
                }}>{value}</p>
              </div>
            ) : null
          ))}
        </div>
      )}
    </div>
  );
}

export default function AuditLog({ onClose }) {
  const { log, explanations, clearLog, clearExplanations } = useAuditStore();
  const [tab, setTab] = useState("activity");
  const [filter, setFilter] = useState("ALL");

  const filtered = filter === "ALL" ? log : log.filter(e => e.action === filter);

  const filters = ["ALL", "NODE_ADDED", "EDGE_ADDED", "SCAN_COMPLETED", "ARCHITECTURE_EXPLAINED", "GRAPH_SAVED"];

  return (
    <div style={{
      position: "fixed",
      top: 0, left: 0, right: 0, bottom: 0,
      background: "rgba(0,0,0,0.75)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      zIndex: 1000
    }}>
      <div style={{
        background: "#0d0d1f",
        border: "1px solid #22224a",
        borderRadius: "12px",
        width: "620px",
        maxHeight: "82vh",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden"
      }}>
        {/* Header */}
        <div style={{
          padding: "18px 20px",
          borderBottom: "1px solid #202020",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexShrink: 0
        }}>
          <div>
            <h2 style={{ color: "#e5e5e5", margin: 0, fontSize: "14px", fontWeight: "600" }}>History</h2>
            <div style={{ color: "#555", fontSize: "11px", marginTop: "3px" }}>
              {log.length} activities · {explanations.length} explanations saved
            </div>
          </div>
          <button
            onClick={onClose}
            style={{
              background: "transparent", border: "none",
              color: "#555", cursor: "pointer", fontSize: "20px"
            }}
          >×</button>
        </div>

        {/* Tabs */}
        <div style={{
          display: "flex",
          borderBottom: "1px solid #202020",
          flexShrink: 0
        }}>
          {[
            { key: "activity", label: `Activity (${log.length})` },
            { key: "explanations", label: `Explanations (${explanations.length})` }
          ].map(t => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              style={{
                flex: 1,
                background: "transparent",
                border: "none",
                borderBottom: `2px solid ${tab === t.key ? "#e5e5e5" : "transparent"}`,
                color: tab === t.key ? "#e5e5e5" : "#555",
                padding: "12px",
                cursor: "pointer",
                fontSize: "12.5px",
                fontWeight: tab === t.key ? "600" : "400",
                transition: "all 0.15s",
                borderRadius: 0
              }}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Activity tab */}
        {tab === "activity" && (
          <>
            {/* Filter row */}
            <div style={{
              padding: "10px 20px",
              borderBottom: "1px solid #161632",
              display: "flex",
              gap: "6px",
              flexWrap: "wrap",
              flexShrink: 0
            }}>
              {filters.map(f => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  style={{
                    background: filter === f ? "#22224a" : "transparent",
                    border: `1px solid ${filter === f ? "#333" : "#1a1a35"}`,
                    color: filter === f ? "#e5e5e5" : "#555",
                    padding: "3px 10px",
                    borderRadius: "20px",
                    cursor: "pointer",
                    fontSize: "11px",
                    fontWeight: filter === f ? "600" : "400"
                  }}
                >
                  {f === "ALL" ? "All" : ACTION_LABELS[f] || f}
                </button>
              ))}
            </div>

            {/* Log entries */}
            <div style={{ overflowY: "auto", flex: 1, padding: "8px 20px" }}>
              {filtered.length === 0 && (
                <div style={{ textAlign: "center", color: "#444", padding: "50px 20px", fontSize: "13px" }}>
                  No activity yet
                </div>
              )}
              {filtered.map((entry, i) => (
                <div key={entry.id} style={{
                  display: "flex", gap: "12px",
                  padding: "10px 0",
                  borderBottom: i < filtered.length - 1 ? "1px solid #181818" : "none",
                  alignItems: "flex-start"
                }}>
                  <div style={{
                    fontSize: "12px",
                    color: ACTION_COLORS[entry.action] || "#666",
                    minWidth: "16px",
                    marginTop: "1px"
                  }}>
                    {ACTION_ICONS[entry.action] || "·"}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                      <span style={{
                        fontSize: "12.5px", fontWeight: "500",
                        color: ACTION_COLORS[entry.action] || "#ccc"
                      }}>
                        {ACTION_LABELS[entry.action] || entry.action}
                      </span>
                      {entry.projectName && (
                        <span style={{
                          fontSize: "10px", color: "#444",
                          background: "#161632",
                          padding: "1px 6px", borderRadius: "4px"
                        }}>
                          {entry.projectName}
                        </span>
                      )}
                    </div>
                    {entry.detail && (
                      <div style={{ fontSize: "11px", color: "#555", marginTop: "2px" }}>
                        {entry.detail}
                      </div>
                    )}
                  </div>
                  <div style={{ fontSize: "10px", color: "#3a3a3a", minWidth: "55px", textAlign: "right" }}>
                    {timeAgo(entry.timestamp)}
                  </div>
                </div>
              ))}
            </div>

            {log.length > 0 && (
              <div style={{ padding: "10px 20px", borderTop: "1px solid #161632", flexShrink: 0 }}>
                <button
                  onClick={() => { if (confirm("Clear all activity?")) clearLog(); }}
                  style={{
                    background: "transparent", border: "1px solid #2a1515",
                    color: "#7a3535", padding: "6px 14px",
                    borderRadius: "6px", cursor: "pointer", fontSize: "11px"
                  }}
                >
                  Clear Activity
                </button>
              </div>
            )}
          </>
        )}

        {/* Explanations tab */}
        {tab === "explanations" && (
          <div style={{ overflowY: "auto", flex: 1, padding: "14px 20px" }}>
            {explanations.length === 0 && (
              <div style={{ textAlign: "center", color: "#444", padding: "50px 20px" }}>
                <div style={{ fontSize: "28px", marginBottom: "12px", opacity: 0.3 }}>✦</div>
                <div style={{ fontSize: "13px", marginBottom: "6px", color: "#666" }}>No explanations yet</div>
                <div style={{ fontSize: "11px", color: "#444" }}>
                  Use "Explain Architecture" to generate and save explanations
                </div>
              </div>
            )}
            {explanations.map(exp => (
              <ExplanationCard key={exp.id} exp={exp} />
            ))}
            {explanations.length > 0 && (
              <button
                onClick={() => { if (confirm("Clear all saved explanations?")) clearExplanations(); }}
                style={{
                  background: "transparent", border: "1px solid #2a1515",
                  color: "#7a3535", padding: "6px 14px",
                  borderRadius: "6px", cursor: "pointer",
                  fontSize: "11px", marginTop: "8px"
                }}
              >
                Clear Explanations
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
