import { useMemo } from "react";
import SeverityBadge from "./SeverityBadge";

function getTypeColor(type) {
  if (!type) return "#555";
  const t = type.toLowerCase();
  if (t.includes("user") || t.includes("client") || t.includes("browser") || t.includes("frontend")) return "#f59e0b";
  if (t.includes("database") || t.includes("db") || t.includes("sql") || t.includes("mongo") || t.includes("redis")) return "#0ea5e9";
  if (t.includes("api") || t.includes("rest")) return "#22c55e";
  if (t.includes("service") || t.includes("microservice")) return "#7c3aed";
  if (t.includes("queue") || t.includes("kafka") || t.includes("rabbit")) return "#ec4899";
  if (t.includes("gateway") || t.includes("proxy") || t.includes("nginx")) return "#f97316";
  if (t.includes("worker") || t.includes("job") || t.includes("cron")) return "#8b5cf6";
  if (t.includes("external") || t.includes("vendor")) return "#64748b";
  if (t.includes("cache")) return "#06b6d4";
  return "#888";
}

function SectionTitle({ children, color }) {
  return (
    <h2 style={{
      fontSize: "12px",
      color: color || "#555",
      textTransform: "uppercase",
      letterSpacing: "1px",
      fontWeight: "600",
      margin: "0 0 12px 0"
    }}>
      {children}
    </h2>
  );
}

function StatBox({ label, value, color }) {
  return (
    <div style={{
      padding: "16px",
      background: "#12122a",
      border: "1px solid #1a1a35",
      borderRadius: "10px",
      textAlign: "center"
    }}>
      <div style={{ fontSize: "24px", fontWeight: "800", color: color, marginBottom: "6px" }}>
        {value}
      </div>
      <div style={{ fontSize: "11px", color: "#555" }}>{label}</div>
    </div>
  );
}

function NodeCard({ node, violations }) {
  const hasViolation = violations.some(v => v.source === node.id || v.target === node.id);
  const violationCount = violations.filter(v => v.source === node.id || v.target === node.id).length;
  const color = getTypeColor(node.type);

  return (
    <div style={{
      padding: "12px 14px",
      background: "#12122a",
      border: "1px solid " + (hasViolation ? "#2e1f1f" : "#1a1a35"),
      borderLeft: "3px solid " + (hasViolation ? "#7a3535" : color),
      borderRadius: "8px"
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "4px" }}>
        <div style={{ width: "7px", height: "7px", borderRadius: "50%", background: color, flexShrink: 0 }} />
        <span style={{ fontSize: "12.5px", fontWeight: "600", color: "#e5e5e5" }}>
          {node.name}
        </span>
      </div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{
          fontSize: "10px",
          color: color,
          background: color + "15",
          padding: "1px 6px",
          borderRadius: "4px",
          fontWeight: "600"
        }}>
          {node.type}
        </span>
        {hasViolation && (
          <span style={{ fontSize: "10px", color: "#854444" }}>
            {violationCount} violation{violationCount > 1 ? "s" : ""}
          </span>
        )}
      </div>
    </div>
  );
}

function EdgeRow({ edge, nodeMap, violations }) {
  const src = nodeMap[edge.source];
  const tgt = nodeMap[edge.target];
  const violation = violations.find(v => v.source === edge.source && v.target === edge.target);
  const srcColor = getTypeColor(src ? src.type : "");
  const tgtColor = getTypeColor(tgt ? tgt.type : "");

  return (
    <div style={{
      padding: "10px 14px",
      background: "#12122a",
      border: "1px solid " + (violation ? "#2e1f1f" : "#161632"),
      borderRadius: "7px",
      display: "flex",
      alignItems: "center",
      gap: "10px"
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: "6px", flex: 1, flexWrap: "wrap" }}>
        <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: srcColor, flexShrink: 0 }} />
        <span style={{ fontSize: "12px", color: "#ccc" }}>{src ? src.name : edge.source}</span>
        <span style={{ color: "#444", fontSize: "12px" }}>to</span>
        <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: tgtColor, flexShrink: 0 }} />
        <span style={{ fontSize: "12px", color: "#ccc" }}>{tgt ? tgt.name : edge.target}</span>
      </div>
      {violation ? (
        <span style={{
          fontSize: "10px",
          color: "#854444",
          background: "#2a1515",
          border: "1px solid #3a1f1f",
          padding: "2px 7px",
          borderRadius: "4px",
          fontWeight: "600",
          flexShrink: 0
        }}>
          {violation.ruleId}
        </span>
      ) : (
        <span style={{ fontSize: "10px", color: "#4a7c59", flexShrink: 0 }}>OK</span>
      )}
    </div>
  );
}

function ViolationCard({ violation, nodeMap }) {
  const src = nodeMap[violation.source];
  const tgt = nodeMap[violation.target];

  return (
    <div style={{
      padding: "14px",
      background: "#1a1212",
      border: "1px solid #2e1f1f",
      borderLeft: "3px solid #7a3535",
      borderRadius: "8px"
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px", flexWrap: "wrap" }}>
        <span style={{
          fontSize: "10px",
          fontWeight: "700",
          color: "#cc6666",
          background: "#2a1818",
          padding: "2px 8px",
          borderRadius: "4px"
        }}>
          {violation.ruleId}
        </span>
        <SeverityBadge severity={violation.severity} />
        <span style={{ fontSize: "11px", color: "#666" }}>
          {src ? src.name : violation.source} to {tgt ? tgt.name : violation.target}
        </span>
      </div>
      <p style={{ fontSize: "12px", color: "#bbb", lineHeight: "1.7", margin: 0 }}>
        {violation.message}
      </p>
    </div>
  );
}

function TryButton() {
  const href = window.location.origin + window.location.pathname;

  const handleClick = () => {
    window.location.href = href;
  };

  return (
    <button
      onClick={handleClick}
      style={{
        fontSize: "11px",
        color: "#555",
        textDecoration: "none",
        background: "#161632",
        border: "1px solid #22224a",
        padding: "5px 12px",
        borderRadius: "6px",
        cursor: "pointer"
      }}
    >
      Try CodeGPO
    </button>
  );
}

export default function SharedView({ data }) {
  const { project, nodes, edges, violations, score, timestamp } = data;

  const nodeMap = useMemo(() => {
    const m = {};
    nodes.forEach(n => { m[n.id] = n; });
    return m;
  }, [nodes]);

  const sharedDate = timestamp
    ? new Date(timestamp).toLocaleDateString("en-US", {
        year: "numeric", month: "long", day: "numeric"
      })
    : "Unknown date";

  const violationCount = violations ? violations.length : 0;
  const scoreValue = score ? (score.s + "/100") : "N/A";
  const scoreColor = score
    ? (score.s >= 80 ? "#5a9e6f" : score.s >= 60 ? "#f59e0b" : "#cc6666")
    : "#555";

  const projectName = project && project.name ? project.name : "Untitled Project";
  const projectDesc = project && project.desc ? project.desc : null;

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0d0d1f",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif",
      color: "#e5e5e5",
      WebkitFontSmoothing: "antialiased"
    }}>

      {/* Top bar */}
      <div style={{
        background: "#12122a",
        borderBottom: "1px solid #1a1a35",
        padding: "12px 24px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <span style={{ fontSize: "16px", color: "#e5e5e5" }}>CodeGPO</span>
          <span style={{
            fontSize: "9px",
            color: "#555",
            background: "#161632",
            border: "1px solid #22224a",
            padding: "2px 8px",
            borderRadius: "4px",
            letterSpacing: "1px"
          }}>
            READ ONLY
          </span>
        </div>
        <div style={{ fontSize: "11px", color: "#444" }}>
          {"Shared on " + sharedDate}
        </div>
      </div>

      {/* Main content */}
      <div style={{ maxWidth: "900px", margin: "0 auto", padding: "40px 24px" }}>

        {/* Project header */}
        <div style={{ marginBottom: "32px" }}>
          <h1 style={{
            fontSize: "24px",
            fontWeight: "700",
            color: "#e5e5e5",
            margin: "0 0 8px 0",
            letterSpacing: "-0.3px"
          }}>
            {projectName}
          </h1>
          {projectDesc && (
            <p style={{ fontSize: "13px", color: "#666", margin: 0 }}>
              {projectDesc}
            </p>
          )}
        </div>

        {/* Stats */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: "10px",
          marginBottom: "32px"
        }}>
          <StatBox label="Components" value={nodes.length} color="#6699cc" />
          <StatBox label="Connections" value={edges.length} color="#7c3aed" />
          <StatBox label="Violations" value={violationCount} color={violationCount > 0 ? "#cc6666" : "#5a9e6f"} />
          <StatBox label="Health Score" value={scoreValue} color={scoreColor} />
        </div>

        {/* Components */}
        <div style={{ marginBottom: "32px" }}>
          <SectionTitle>{"Components (" + nodes.length + ")"}</SectionTitle>
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
            gap: "8px"
          }}>
            {nodes.map(function(n) {
              return (
                <NodeCard key={n.id} node={n} violations={violations || []} />
              );
            })}
          </div>
        </div>

        {/* Connections */}
        <div style={{ marginBottom: "32px" }}>
          <SectionTitle>{"Connections (" + edges.length + ")"}</SectionTitle>
          <div style={{ display: "flex", flexDirection: "column", gap: "5px" }}>
            {edges.map(function(e, i) {
              return (
                <EdgeRow key={i} edge={e} nodeMap={nodeMap} violations={violations || []} />
              );
            })}
          </div>
        </div>

        {/* Violations */}
        {violationCount > 0 && (
          <div style={{ marginBottom: "32px" }}>
            <SectionTitle color="#854444">{"Violations (" + violationCount + ")"}</SectionTitle>
            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
              {violations.map(function(v, i) {
                return (
                  <ViolationCard key={i} violation={v} nodeMap={nodeMap} />
                );
              })}
            </div>
          </div>
        )}

        {/* Compliant message */}
        {violationCount === 0 && (
          <div style={{
            padding: "16px 20px",
            background: "#0f1a12",
            border: "1px solid #1a2e1e",
            borderRadius: "10px",
            marginBottom: "32px",
            fontSize: "13px",
            color: "#5a9e6f",
            display: "flex",
            alignItems: "center",
            gap: "10px"
          }}>
            <span>Fully compliant</span>
            <span style={{ color: "#4a7c59", fontSize: "12px" }}>
              No governance violations detected in this architecture.
            </span>
          </div>
        )}

        {/* Footer */}
        <div style={{
          borderTop: "1px solid #161632",
          paddingTop: "20px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between"
        }}>
          <div style={{ fontSize: "11px", color: "#333" }}>
            Generated by CodeGPO
          </div>
          <TryButton />
        </div>

      </div>
    </div>
  );
}
