import { useState, useEffect } from "react";

const STORAGE_KEY = "codegpo_github_config";
const BACKEND     = "http://localhost:8000";

export function getGitHubConfig() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
  } catch { return null; }
}

export function clearGitHubConfig() {
  localStorage.removeItem(STORAGE_KEY);
}

export default function GitHubSettings({ onClose }) {
  const [token,  setToken]  = useState("");
  const [owner,  setOwner]  = useState("");
  const [repo,   setRepo]   = useState("");
  const [status, setStatus] = useState("idle"); // idle | testing | success | error
  const [error,  setError]  = useState("");
  const [saved,  setSaved]  = useState(false);

  // Load existing config
  useEffect(() => {
    const cfg = getGitHubConfig();
    if (cfg) {
      setToken(cfg.token  || "");
      setOwner(cfg.owner  || "");
      setRepo(cfg.repo    || "");
      setSaved(true);
    }
  }, []);

  const handleTest = () => {
    setError("");
    if (!token || !owner || !repo) {
      setStatus("error");
      setError("All three fields are required");
      return;
    }

    // Validate token format client-side (no network call needed)
    const validTokenPattern = /^(ghp_|github_pat_|gho_|ghu_|ghs_)[A-Za-z0-9_]{10,}$/;
    if (!validTokenPattern.test(token.trim())) {
      setStatus("error");
      setError("Token format looks wrong — it should start with ghp_, github_pat_, etc.");
      return;
    }

    if (owner.includes("/")) {
      setStatus("error");
      setError("GitHub Username should be just your username, no slashes (e.g. MR.HACKER)");
      return;
    }

    if (repo.includes("/")) {
      setStatus("error");
      setError("Repository Name should be just the repo name, no slashes (e.g. CODETEST)");
      return;
    }

    setStatus("success");
    setError(`Fields look valid — ${owner}/${repo}. Click Save & Connect to store your token.`);
  };

  const handleSave = () => {
    if (!token || !owner || !repo) {
      setError("All three fields are required");
      return;
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ token, owner, repo }));
    setSaved(true);
    setStatus("idle");
    onClose();
  };

  const handleDisconnect = () => {
    clearGitHubConfig();
    setToken(""); setOwner(""); setRepo("");
    setSaved(false);
    setStatus("idle");
    setError("");
  };

  const inputStyle = {
    width: "100%", padding: "10px 14px",
    background: "#0d0d1f", border: "1px solid #22224a",
    color: "#e5e5e5", borderRadius: "8px",
    fontSize: "13px", boxSizing: "border-box",
    outline: "none", fontFamily: "monospace",
    transition: "border-color 0.15s"
  };

  return (
    <div style={{
      position: "fixed", inset: 0,
      background: "rgba(0,0,0,0.88)",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 3000, padding: "20px"
    }}
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <div style={{
        background: "#0d0d1f", border: "1px solid #22224a",
        borderRadius: "16px", width: "520px",
        boxShadow: "0 30px 80px rgba(0,0,0,0.7)",
        overflow: "hidden"
      }}>

        {/* Header */}
        <div style={{
          padding: "20px 24px 16px",
          borderBottom: "1px solid #1a1a35",
          display: "flex", justifyContent: "space-between", alignItems: "center"
        }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <span style={{ fontSize: "18px" }}>🐙</span>
              <h2 style={{ color: "#e5e5e5", margin: 0, fontSize: "16px", fontWeight: "700" }}>
                Connect GitHub
              </h2>
            </div>
            <p style={{ color: "#555", fontSize: "12px", margin: "5px 0 0" }}>
              Required for Auto Pull Request — your token stays in your browser only
            </p>
          </div>
          <button onClick={onClose} style={{
            background: "transparent", border: "none",
            color: "#555", cursor: "pointer", fontSize: "20px"
          }}>×</button>
        </div>

        {/* Body */}
        <div style={{ padding: "24px" }}>

          {/* Connected banner */}
          {saved && (
            <div style={{
              padding: "12px 16px", marginBottom: "20px",
              background: "#111a13", border: "1px solid #1e2e22",
              borderLeft: "3px solid #22c55e",
              borderRadius: "8px", fontSize: "12px", color: "#5a9e6f",
              display: "flex", justifyContent: "space-between", alignItems: "center"
            }}>
              <span>✓ GitHub connected — {owner}/{repo}</span>
              <button
                onClick={handleDisconnect}
                style={{
                  background: "transparent", border: "1px solid #2e1a1a",
                  color: "#cc6666", padding: "3px 10px", borderRadius: "5px",
                  cursor: "pointer", fontSize: "11px"
                }}
              >
                Disconnect
              </button>
            </div>
          )}

          {/* Step 1: Create token */}
          <div style={{
            padding: "14px 16px", marginBottom: "20px",
            background: "#12122a", border: "1px solid #1a1a35",
            borderRadius: "10px"
          }}>
            <div style={{
              fontSize: "10px", color: "#555", textTransform: "uppercase",
              letterSpacing: "0.8px", fontWeight: "600", marginBottom: "10px"
            }}>
              Step 1 — Create a GitHub Personal Access Token
            </div>
            <ol style={{ margin: 0, paddingLeft: "18px", color: "#888", fontSize: "12px", lineHeight: "2" }}>
              <li>Go to <a href="https://github.com/settings/tokens/new" target="_blank" rel="noreferrer"
                  style={{ color: "#0ea5e9" }}>github.com/settings/tokens/new</a></li>
              <li>Name it <code style={{ color: "#a78bfa", background: "#1a1228", padding: "1px 5px", borderRadius: "3px" }}>CodeGPO</code></li>
              <li>Set expiry to 90 days</li>
              <li>Under <strong style={{ color: "#ccc" }}>Scopes</strong>, check <code style={{ color: "#a78bfa", background: "#1a1228", padding: "1px 5px", borderRadius: "3px" }}>repo</code></li>
              <li>Click <strong style={{ color: "#ccc" }}>Generate token</strong> — copy it immediately</li>
            </ol>
          </div>

          {/* Step 2: Fields */}
          <div style={{
            fontSize: "10px", color: "#555", textTransform: "uppercase",
            letterSpacing: "0.8px", fontWeight: "600", marginBottom: "14px"
          }}>
            Step 2 — Enter your details
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "20px" }}>
            <div>
              <div style={{ fontSize: "11px", color: "#666", marginBottom: "5px" }}>
                Personal Access Token
              </div>
              <input
                type="password"
                value={token}
                onChange={e => { setToken(e.target.value); setStatus("idle"); }}
                placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                style={inputStyle}
                onFocus={e => e.target.style.borderColor = "#333"}
                onBlur={e => e.target.style.borderColor = "#22224a"}
              />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
              <div>
                <div style={{ fontSize: "11px", color: "#666", marginBottom: "5px" }}>
                  GitHub Username
                </div>
                <input
                  value={owner}
                  onChange={e => { setOwner(e.target.value); setStatus("idle"); }}
                  placeholder="your-username"
                  style={inputStyle}
                  onFocus={e => e.target.style.borderColor = "#333"}
                  onBlur={e => e.target.style.borderColor = "#22224a"}
                />
              </div>
              <div>
                <div style={{ fontSize: "11px", color: "#666", marginBottom: "5px" }}>
                  Repository Name
                </div>
                <input
                  value={repo}
                  onChange={e => { setRepo(e.target.value); setStatus("idle"); }}
                  placeholder="codegpo-schemas"
                  style={inputStyle}
                  onFocus={e => e.target.style.borderColor = "#333"}
                  onBlur={e => e.target.style.borderColor = "#22224a"}
                />
              </div>
            </div>
          </div>

          {/* Status message */}
          {error && (
            <div style={{
              padding: "10px 14px", marginBottom: "16px", borderRadius: "8px",
              background: status === "success" ? "#111a13" : "#1a1010",
              border: `1px solid ${status === "success" ? "#1e2e22" : "#2e1a1a"}`,
              borderLeft: `3px solid ${status === "success" ? "#22c55e" : "#cc6666"}`,
              fontSize: "12px",
              color: status === "success" ? "#5a9e6f" : "#cc8888"
            }}>
              {status === "success" ? "✓" : "⚠"} {error}
            </div>
          )}

          {/* Privacy note */}
          <div style={{
            padding: "10px 14px", marginBottom: "20px",
            background: "#12122a", border: "1px solid #1a1a35", borderRadius: "8px",
            fontSize: "11px", color: "#555", lineHeight: "1.6"
          }}>
            🔒 Your token is stored only in your browser's localStorage. It is never sent to CodeGPO servers — it goes directly to GitHub's API when you open a PR.
          </div>

          {/* Actions */}
          <div style={{ display: "flex", gap: "10px", justifyContent: "flex-end" }}>
            <button
              onClick={handleTest}
              disabled={status === "testing"}
              style={{
                background: "transparent",
                border: "1px solid #333", color: "#888",
                padding: "9px 18px", borderRadius: "8px",
                cursor: "pointer",
                fontSize: "13px"
              }}
            >
              "✓ Validate Fields"
            </button>
            <button
              onClick={handleSave}
              disabled={!token || !owner || !repo}
              style={{
                background: (!token || !owner || !repo)
                  ? "#1a1a35"
                  : "linear-gradient(135deg, #22c55e, #0ea5e9)",
                border: "none",
                color: (!token || !owner || !repo) ? "#555" : "#fff",
                padding: "9px 24px", borderRadius: "8px",
                cursor: (!token || !owner || !repo) ? "not-allowed" : "pointer",
                fontSize: "13px", fontWeight: "700"
              }}
            >
              Save & Connect
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
