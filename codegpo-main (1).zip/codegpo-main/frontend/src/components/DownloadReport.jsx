import { create } from "zustand";
import { evaluateGraph } from "../core/governanceEngine";
import { saveGraph as saveGraphApi, loadGraph as loadGraphApi, evaluateGovernance } from "../api/graphApi";

const STORAGE_KEY = "codegpo_graph";
const API_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

function loadGraph() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : { nodes: [], edges: [] };
  } catch { return { nodes: [], edges: [] }; }
}

function saveGraphLocal(nodes, edges) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ nodes, edges }));
  } catch {}
}

const { nodes: _initNodes, edges: _initEdges } = loadGraph();
const _initViolations = evaluateGraph(_initNodes, _initEdges);

// Debounce the authoritative backend re-check so rapid edits don't spam the API.
let _syncTimer = null;
let _syncSeq = 0;

export const useGraphStore = create((set, get) => ({
  nodes:       _initNodes,
  edges:       _initEdges,
  violations:  _initViolations,
  violationsSource: "local", // "local" (instant, ~33 checks) | "backend" (authoritative, full rule set)
  selectedNode: null,
  selectedEdge: null,
  edgeMode:    false,
  edgeSourceId: null,

  // Instant, client-side pass for immediate visual feedback (edge highlighting etc.)
  // while the authoritative backend result is fetched in the background.
  evaluateViolations: (nodes, edges) => {
    const violations = evaluateGraph(nodes, edges);
    set({ violations, violationsSource: "local" });

    // Kick off the authoritative backend check (debounced), which runs the
    // full rule set — this is what NodeDetailPanel and reports must trust.
    const seq = ++_syncSeq;
    if (_syncTimer) clearTimeout(_syncTimer);
    _syncTimer = setTimeout(async () => {
      try {
        const backendViolations = await evaluateGovernance(nodes, edges);
        // If a newer edit started a fresher sync in the meantime, drop this stale result.
        if (seq !== _syncSeq) return;
        if (Array.isArray(backendViolations)) {
          set({ violations: backendViolations, violationsSource: "backend" });
        }
      } catch {
        // Backend unreachable — keep showing the local (partial) result rather than nothing.
      }
    }, 400);

    return violations;
  },

  addNode: (type, name) => {
    const node = {
      id: `node-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      type, name, intent: "", owner: "", team: "",
      criticality: "", compliance_scope: "", fields: "[]"
    };
    const nodes = [...get().nodes, node];
    const edges = get().edges;
    saveGraphLocal(nodes, edges);
    set({ nodes });
    get().evaluateViolations(nodes, edges);
    return node;
  },

  updateNode: (nodeId, updates) => {
    const nodes = get().nodes.map(n => n.id === nodeId ? { ...n, ...updates } : n);
    const edges = get().edges;
    saveGraphLocal(nodes, edges);
    const updatedSelected = get().selectedNode?.id === nodeId
      ? { ...get().selectedNode, ...updates } : get().selectedNode;
    set({ nodes, selectedNode: updatedSelected });
    get().evaluateViolations(nodes, edges);
  },

  deleteSelected: () => {
    const { selectedNode, selectedEdge, nodes, edges } = get();
    let newNodes = nodes;
    let newEdges = edges;
    if (selectedNode) {
      newNodes = nodes.filter(n => n.id !== selectedNode.id);
      newEdges = edges.filter(e => e.source !== selectedNode.id && e.target !== selectedNode.id);
    }
    if (selectedEdge) {
      newEdges = edges.filter(e => !(e.source === selectedEdge.source && e.target === selectedEdge.target));
    }
    saveGraphLocal(newNodes, newEdges);
    set({ nodes: newNodes, edges: newEdges, selectedNode: null, selectedEdge: null });
    get().evaluateViolations(newNodes, newEdges);
  },

  startEdge: (sourceId) => set({ edgeMode: true, edgeSourceId: sourceId }),

  finishEdge: (targetId) => {
    const { edgeSourceId, edges, nodes } = get();
    if (!edgeSourceId || edgeSourceId === targetId) {
      set({ edgeMode: false, edgeSourceId: null });
      return;
    }
    const exists = edges.find(e => e.source === edgeSourceId && e.target === targetId);
    if (!exists) {
      const newEdges = [...edges, { source: edgeSourceId, target: targetId }];
      saveGraphLocal(nodes, newEdges);
      set({ edges: newEdges, edgeMode: false, edgeSourceId: null });
      get().evaluateViolations(nodes, newEdges);
    } else {
      set({ edgeMode: false, edgeSourceId: null });
    }
  },

  cancelEdge: () => set({ edgeMode: false, edgeSourceId: null }),

  selectNode: (nodeId) => {
    const node = get().nodes.find(n => n.id === nodeId) || null;
    set({ selectedNode: node, selectedEdge: null });
  },

  selectEdge: (edgeData) => set({ selectedEdge: edgeData, selectedNode: null }),

  // ── Neo4j sync (with auth token) ─────────────────────
  saveToNeo4j: async () => {
    try {
      const { nodes, edges } = get();
      await saveGraphApi(nodes, edges);
    } catch (err) {
      console.warn("Neo4j save failed (offline?):", err.message);
    }
  },

  loadFromNeo4j: async () => {
    try {
      const data = await loadGraphApi();
      const nodes = data.nodes || [];
      const edges = data.edges || [];
      saveGraphLocal(nodes, edges);
      set({ nodes, edges });
      get().evaluateViolations(nodes, edges);
    } catch (err) {
      console.warn("Neo4j load failed (offline?):", err.message);
    }
  },

  setGraph: (nodes, edges) => {
    saveGraphLocal(nodes, edges);
    set({ nodes, edges });
    get().evaluateViolations(nodes, edges);
  },

  addNodeDirect: (node) => {
    const nodes = [...get().nodes];
    if (!nodes.find(n => n.id === node.id)) {
      nodes.push(node);
      const edges = get().edges;
      saveGraphLocal(nodes, edges);
      set({ nodes });
      get().evaluateViolations(nodes, edges);
    }
  },

  deleteNodeById: (nodeId) => {
    const nodes = get().nodes.filter(n => n.id !== nodeId);
    const edges = get().edges.filter(e => e.source !== nodeId && e.target !== nodeId);
    saveGraphLocal(nodes, edges);
    set({ nodes, edges });
    get().evaluateViolations(nodes, edges);
  },

  addEdgeDirect: (edge) => {
    const edges = [...get().edges];
    const exists = edges.find(e => e.source === edge.source && e.target === edge.target);
    if (!exists) {
      edges.push(edge);
      const nodes = get().nodes;
      saveGraphLocal(nodes, edges);
      set({ edges });
      get().evaluateViolations(nodes, edges);
    }
  },

  deleteEdgeByIds: (source, target) => {
    const edges = get().edges.filter(e => !(e.source === source && e.target === target));
    const nodes = get().nodes;
    saveGraphLocal(nodes, edges);
    set({ edges });
    get().evaluateViolations(nodes, edges);
  },

  clearGraph: () => {
    saveGraphLocal([], []);
    set({ nodes: [], edges: [], violations: [], selectedNode: null, selectedEdge: null });
  }
}));
