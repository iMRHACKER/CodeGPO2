import { useState, useEffect } from "react";
import {
  getCustomPolicies, saveCustomPolicy,
  deleteCustomPolicy, POLICY_TEMPLATE
} from "./CustomPolicyEngine";

const SEVERITIES = ["CRITICAL", "HIGH", "MEDIUM", "LOW"];
const NODE_TYPES  = [null,"User","Mobile","Frontend","Admin","IoT","Gateway","Auth",
  "Service","API","Worker","CDN","Database","Cache","Queue","Search",
  "Storage","Secrets","External","Payment","Monitoring","Analytics","AI"];

const BLANK = () => ({
  ...POLICY_TEMPLATE,
  id: `CUSTOM-${Date.now()}`,
  conditions: { sourceType:null, targetType:null, sourceNameContains:null, targetNameContains:null }
});

export default function CustomPolicyModal({ onClose, onPoliciesChange }) {
  const [policies, setPolicies]   = useState([]);
  const [editing, setEditing]     = useState(null); // null | policy object
  const [saved, setSaved]         = useState(false);

  useEffect(() => { setPolicies(getCustomPolicies()); }, []);

  const handleSave = () => {
    if (!editing.name.trim()) return;
    const updated = saveCustomPolicy(editing);
    setPolicies(updated);
    setEditing(null);
    onPoliciesChange?.(updated);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleDelete = (id) => {
    if (!confirm("Delete this rule?")) return;
    const updated = deleteCustomPolicy(id);
    setPolicies(updated);
    onPoliciesChange?.(updated);
  };

  const handleToggle = (policy) => {
    const updated = saveCustomPolicy({ ...policy, enabled: !policy.enabled });
    setPolicies(getCustomPolicies());
    onPoliciesChange?.(getCustomPolicies());
  };

  const SEV_COLOR = { CRITICAL:"#EF4444", HIGH:"#F97316", MEDIUM:"#F59E0B", LOW:"#22C55E" };

  return (
    <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.85)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:2000,padding:"20px" }}
      onClick={e => e.target===e.currentTarget && onClose()}>
      <div style={{ background:"#0D0D1F",border:"1px solid #1A1A35",borderRadius:"16px",width:"680px",maxHeight:"90vh",display:"flex",flexDirection:"column",overflow:"hidden" }}>

        {/* Header */}
        <div style={{ padding:"18px 22px",borderBottom:"1px solid #1A1A35",display:"flex",justifyContent:"space-between",alignItems:"center" }}>
          <div>
            <div style={{ fontSize:"15px",fontWeight:"700",color:"#E2E8F0" }}>Custom Policy Rules</div>
            <div style={{ fontSize:"11px",color:"#475569",marginTop:"2px" }}>{policies.length} rules · Your own governance logic</div>
          </div>
          <div style={{ display:"flex",gap:"8px" }}>
            <button onClick={() => setEditing(BLANK())}
              style={{ padding:"7px 16px",background:"#7C3AED",border:"none",borderRadius:"8px",color:"#fff",fontSize:"12px",fontWeight:"700",cursor:"pointer" }}>
              + New Rule
            </button>
            <button onClick={onClose} style={{ background:"none",border:"none",color:"#475569",fontSize:"20px",cursor:"pointer" }}>×</button>
          </div>
        </div>

        <div style={{ overflowY:"auto",flex:1,padding:"16px 22px",scrollbarWidth:"thin",scrollbarColor:"#1A1A35 transparent" }}>

          {/* Edit form */}
          {editing && (
            <div style={{ background:"#08080F",border:"1px solid #1A1A35",borderRadius:"12px",padding:"18px",marginBottom:"18px" }}>
              <div style={{ fontSize:"12px",fontWeight:"700",color:"#7C3AED",letterSpacing:"1px",marginBottom:"14px" }}>
                {editing.id.startsWith("CUSTOM-1") && policies.every(p=>p.id!==editing.id) ? "CREATE RULE" : "EDIT RULE"}
              </div>

              {/* Name + Severity */}
              <div style={{ display:"grid",gridTemplateColumns:"1fr 140px",gap:"10px",marginBottom:"10px" }}>
                <div>
                  <div style={{ fontSize:"10px",color:"#475569",marginBottom:"4px",textTransform:"uppercase" }}>Rule Name *</div>
                  <input value={editing.name} onChange={e=>setEditing({...editing,name:e.target.value})}
                    placeholder="e.g. No Mobile to Database"
                    style={{ width:"100%",padding:"8px 12px",background:"#0D0D1F",border:"1px solid #1A1A35",borderRadius:"8px",color:"#CBD5E1",fontSize:"13px",outline:"none",boxSizing:"border-box" }}/>
                </div>
                <div>
                  <div style={{ fontSize:"10px",color:"#475569",marginBottom:"4px",textTransform:"uppercase" }}>Severity</div>
                  <select value={editing.severity} onChange={e=>setEditing({...editing,severity:e.target.value})}
                    style={{ width:"100%",padding:"8px 12px",background:"#0D0D1F",border:"1px solid #1A1A35",borderRadius:"8px",color:SEV_COLOR[editing.severity],fontSize:"13px",outline:"none" }}>
                    {SEVERITIES.map(s=><option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>

              {/* Conditions */}
              <div style={{ fontSize:"10px",color:"#475569",marginBottom:"6px",textTransform:"uppercase",letterSpacing:"0.5px" }}>When this connection exists</div>
              <div style={{ display:"grid",gridTemplateColumns:"1fr auto 1fr",gap:"8px",alignItems:"center",marginBottom:"10px" }}>
                <div>
                  <div style={{ fontSize:"10px",color:"#475569",marginBottom:"4px" }}>Source Type</div>
                  <select value={editing.conditions.sourceType||""} onChange={e=>setEditing({...editing,conditions:{...editing.conditions,sourceType:e.target.value||null}})}
                    style={{ width:"100%",padding:"7px 10px",background:"#0D0D1F",border:"1px solid #1A1A35",borderRadius:"8px",color:"#CBD5E1",fontSize:"12px",outline:"none" }}>
                    <option value="">Any type</option>
                    {NODE_TYPES.filter(Boolean).map(t=><option key={t} value={t}>{t}</option>)}
                  </select>
                  <input value={editing.conditions.sourceNameContains||""} onChange={e=>setEditing({...editing,conditions:{...editing.conditions,sourceNameContains:e.target.value||null}})}
                    placeholder="Name contains (optional)"
                    style={{ width:"100%",padding:"7px 10px",background:"#0D0D1F",border:"1px solid #1A1A35",borderRadius:"8px",color:"#CBD5E1",fontSize:"12px",outline:"none",marginTop:"6px",boxSizing:"border-box" }}/>
                </div>
                <div style={{ textAlign:"center",color:"#475569",fontSize:"18px",marginTop:"10px" }}>→</div>
                <div>
                  <div style={{ fontSize:"10px",color:"#475569",marginBottom:"4px" }}>Target Type</div>
                  <select value={editing.conditions.targetType||""} onChange={e=>setEditing({...editing,conditions:{...editing.conditions,targetType:e.target.value||null}})}
                    style={{ width:"100%",padding:"7px 10px",background:"#0D0D1F",border:"1px solid #1A1A35",borderRadius:"8px",color:"#CBD5E1",fontSize:"12px",outline:"none" }}>
                    <option value="">Any type</option>
                    {NODE_TYPES.filter(Boolean).map(t=><option key={t} value={t}>{t}</option>)}
                  </select>
                  <input value={editing.conditions.targetNameContains||""} onChange={e=>setEditing({...editing,conditions:{...editing.conditions,targetNameContains:e.target.value||null}})}
                    placeholder="Name contains (optional)"
                    style={{ width:"100%",padding:"7px 10px",background:"#0D0D1F",border:"1px solid #1A1A35",borderRadius:"8px",color:"#CBD5E1",fontSize:"12px",outline:"none",marginTop:"6px",boxSizing:"border-box" }}/>
                </div>
              </div>

              {/* Message + Fix */}
              <div style={{ marginBottom:"10px" }}>
                <div style={{ fontSize:"10px",color:"#475569",marginBottom:"4px",textTransform:"uppercase" }}>Violation Message</div>
                <input value={editing.message} onChange={e=>setEditing({...editing,message:e.target.value})}
                  placeholder="e.g. Mobile apps must not access databases directly"
                  style={{ width:"100%",padding:"8px 12px",background:"#0D0D1F",border:"1px solid #1A1A35",borderRadius:"8px",color:"#CBD5E1",fontSize:"13px",outline:"none",boxSizing:"border-box" }}/>
              </div>
              <div style={{ marginBottom:"14px" }}>
                <div style={{ fontSize:"10px",color:"#475569",marginBottom:"4px",textTransform:"uppercase" }}>Fix / Recommendation</div>
                <input value={editing.fix} onChange={e=>setEditing({...editing,fix:e.target.value})}
                  placeholder="e.g. Add an API layer between mobile and database"
                  style={{ width:"100%",padding:"8px 12px",background:"#0D0D1F",border:"1px solid #1A1A35",borderRadius:"8px",color:"#CBD5E1",fontSize:"13px",outline:"none",boxSizing:"border-box" }}/>
              </div>

              <div style={{ display:"flex",gap:"8px" }}>
                <button onClick={handleSave}
                  style={{ padding:"8px 20px",background:"#7C3AED",border:"none",borderRadius:"8px",color:"#fff",fontSize:"13px",fontWeight:"600",cursor:"pointer" }}>
                  Save Rule
                </button>
                <button onClick={() => setEditing(null)}
                  style={{ padding:"8px 16px",background:"transparent",border:"1px solid #1A1A35",borderRadius:"8px",color:"#475569",fontSize:"13px",cursor:"pointer" }}>
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Rules list */}
          {policies.length === 0 && !editing ? (
            <div style={{ textAlign:"center",padding:"40px",color:"#334155" }}>
              <div style={{ fontSize:"32px",marginBottom:"12px" }}>📋</div>
              <div style={{ fontSize:"13px" }}>No custom rules yet</div>
              <div style={{ fontSize:"11px",marginTop:"4px" }}>Click "+ New Rule" to create your first policy</div>
            </div>
          ) : (
            policies.map(p => (
              <div key={p.id} style={{ background:p.enabled?"#0A0A18":"transparent",border:`1px solid ${p.enabled?"#1A1A35":"#0D0D20"}`,borderRadius:"10px",padding:"12px 16px",marginBottom:"8px",display:"flex",alignItems:"center",gap:"12px",opacity:p.enabled?1:0.5 }}>
                <div style={{ flex:1,minWidth:0 }}>
                  <div style={{ display:"flex",alignItems:"center",gap:"8px",marginBottom:"4px" }}>
                    <span style={{ fontSize:"10px",fontWeight:"700",color:SEV_COLOR[p.severity],background:"rgba(0,0,0,0.3)",padding:"2px 8px",borderRadius:"4px" }}>{p.severity}</span>
                    <span style={{ fontSize:"13px",fontWeight:"600",color:"#E2E8F0" }}>{p.name}</span>
                    {p.id.startsWith("CUSTOM") && <span style={{ fontSize:"9px",color:"#334155",fontFamily:"Consolas" }}>{p.id}</span>}
                  </div>
                  <div style={{ fontSize:"11px",color:"#475569" }}>
                    {p.conditions.sourceType||"Any"} {p.conditions.sourceNameContains?`(${p.conditions.sourceNameContains})`:""}
                    {" → "}
                    {p.conditions.targetType||"Any"} {p.conditions.targetNameContains?`(${p.conditions.targetNameContains})`:""}
                  </div>
                </div>
                <div style={{ display:"flex",gap:"6px",flexShrink:0 }}>
                  <button onClick={() => handleToggle(p)}
                    style={{ padding:"4px 10px",background:p.enabled?"rgba(34,197,94,0.1)":"rgba(100,116,139,0.1)",border:`1px solid ${p.enabled?"rgba(34,197,94,0.3)":"#1A1A35"}`,borderRadius:"6px",color:p.enabled?"#22C55E":"#475569",fontSize:"11px",cursor:"pointer" }}>
                    {p.enabled?"ON":"OFF"}
                  </button>
                  <button onClick={() => setEditing({...p})}
                    style={{ padding:"4px 10px",background:"transparent",border:"1px solid #1A1A35",borderRadius:"6px",color:"#94A3B8",fontSize:"11px",cursor:"pointer" }}>
                    Edit
                  </button>
                  <button onClick={() => handleDelete(p.id)}
                    style={{ padding:"4px 10px",background:"transparent",border:"1px solid rgba(239,68,68,0.2)",borderRadius:"6px",color:"#EF4444",fontSize:"11px",cursor:"pointer" }}>
                    Delete
                  </button>
                </div>
              </div>
            ))
          )}

          {/* Example rules hint */}
          {policies.length === 0 && !editing && (
            <div style={{ marginTop:"16px",padding:"14px",background:"#0D0920",borderRadius:"10px",border:"1px solid #1A1A35" }}>
              <div style={{ fontSize:"10px",color:"#475569",fontWeight:"700",marginBottom:"8px",textTransform:"uppercase",letterSpacing:"1px" }}>Example rules you can create</div>
              {[
                "Mobile → Database (CRITICAL) — internal policy",
                "Admin → anything with 'prod' in name (HIGH)",
                "Service → External with 'payment' (HIGH) — internal audit",
              ].map((ex,i) => (
                <div key={i} style={{ fontSize:"11px",color:"#334155",marginBottom:"4px" }}>· {ex}</div>
              ))}
            </div>
          )}
        </div>

        {saved && (
          <div style={{ padding:"10px",background:"rgba(34,197,94,0.1)",borderTop:"1px solid rgba(34,197,94,0.2)",textAlign:"center",fontSize:"12px",color:"#22C55E" }}>
            ✅ Rule saved — active on canvas
          </div>
        )}
      </div>
    </div>
  );
}
