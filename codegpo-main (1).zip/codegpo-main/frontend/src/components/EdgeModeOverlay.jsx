export default function EdgeModeOverlay({ sourceNode, onCancel }) {
  if (!sourceNode) return null;

  return (
    <>
      {/* Top banner */}
      <div style={{
        position: "absolute",
        top: "16px",
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: 100,
        pointerEvents: "auto"
      }}>
        <div style={{
          display: "flex", alignItems: "center", gap: "12px",
          padding: "10px 18px",
          background: "#1a1200",
          border: "1px solid #f59e0b44",
          borderRadius: "100px",
          boxShadow: "0 4px 24px rgba(245,158,11,0.15)"
        }}>
          {/* Pulse dot */}
          <div style={{ position: "relative", width: "10px", height: "10px" }}>
            <div style={{
              position: "absolute", inset: 0,
              borderRadius: "50%", background: "#f59e0b"
            }} />
            <div style={{
              position: "absolute", inset: 0,
              borderRadius: "50%", background: "#f59e0b",
              animation: "edgePulse 1.2s ease-out infinite"
            }} />
          </div>

          <style>{`
            @keyframes edgePulse {
              0%   { transform: scale(1); opacity: 0.8; }
              100% { transform: scale(2.8); opacity: 0; }
            }
          `}</style>

          <span style={{
            fontSize: "13px", fontWeight: "600", color: "#f59e0b"
          }}>
            Connecting from
          </span>

          <span style={{
            fontSize: "13px", fontWeight: "700",
            color: "#fff",
            background: "#f59e0b22",
            border: "1px solid #f59e0b44",
            padding: "2px 10px",
            borderRadius: "6px"
          }}>
            {sourceNode.name}
          </span>

          <span style={{ fontSize: "13px", color: "#888" }}>
            → click any node to connect
          </span>

          <button
            onClick={onCancel}
            style={{
              background: "transparent",
              border: "1px solid #333",
              color: "#666", padding: "4px 12px",
              borderRadius: "6px", cursor: "pointer",
              fontSize: "12px", marginLeft: "4px",
              transition: "all 0.15s"
            }}
            onMouseEnter={e => { e.currentTarget.style.color = "#cc6666"; e.currentTarget.style.borderColor = "#cc666644"; }}
            onMouseLeave={e => { e.currentTarget.style.color = "#666"; e.currentTarget.style.borderColor = "#333"; }}
          >
            Cancel (Esc)
          </button>
        </div>
      </div>

      {/* Dimmed overlay hint */}
      <div style={{
        position: "absolute", inset: 0,
        background: "rgba(245,158,11,0.02)",
        pointerEvents: "none",
        zIndex: 5,
        border: "2px solid #f59e0b11"
      }} />
    </>
  );
}