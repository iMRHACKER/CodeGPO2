/**
 * CodeGPO — Custom Policy Engine
 * Users write their own governance rules in JSON
 * Stored in localStorage — no backend needed
 */

const STORAGE_KEY = "codegpo_custom_policies";

export const POLICY_TEMPLATE = {
  id: "CUSTOM-001",
  name: "My Custom Rule",
  description: "Describe what this rule checks",
  severity: "HIGH",
  enabled: true,
  // Match conditions
  conditions: {
    sourceType: null,      // e.g. "Frontend", "Mobile", null = any
    targetType: null,      // e.g. "Database", null = any
    sourceNameContains: null, // e.g. "admin"
    targetNameContains: null, // e.g. "prod"
  },
  message: "Custom rule violation detected",
  fix: "Describe how to fix this violation",
  reference: "Internal policy / link",
};

export function getCustomPolicies() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); } catch { return []; }
}

export function saveCustomPolicy(policy) {
  const policies = getCustomPolicies();
  const idx = policies.findIndex(p => p.id === policy.id);
  if (idx >= 0) policies[idx] = policy;
  else policies.push(policy);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(policies));
  return policies;
}

export function deleteCustomPolicy(policyId) {
  const policies = getCustomPolicies().filter(p => p.id !== policyId);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(policies));
  return policies;
}

export function evaluateCustomPolicies(nodes, edges) {
  const policies = getCustomPolicies().filter(p => p.enabled !== false);
  const violations = [];
  const nodeMap = Object.fromEntries(nodes.map(n => [n.id, n]));

  edges.forEach(edge => {
    const src = nodeMap[edge.source];
    const tgt = nodeMap[edge.target];
    if (!src || !tgt) return;

    policies.forEach(policy => {
      const c = policy.conditions || {};
      let matches = true;

      if (c.sourceType && src.type?.toLowerCase() !== c.sourceType.toLowerCase()) matches = false;
      if (c.targetType && tgt.type?.toLowerCase() !== c.targetType.toLowerCase()) matches = false;
      if (c.sourceNameContains && !src.name?.toLowerCase().includes(c.sourceNameContains.toLowerCase())) matches = false;
      if (c.targetNameContains && !tgt.name?.toLowerCase().includes(c.targetNameContains.toLowerCase())) matches = false;

      if (matches) {
        violations.push({
          ruleId: policy.id,
          severity: policy.severity || "MEDIUM",
          message: policy.message || policy.name,
          description: policy.description || "",
          fix: policy.fix || "",
          reference: policy.reference || "",
          source: edge.source,
          target: edge.target,
          sourceName: src.name,
          targetName: tgt.name,
          isCustom: true,
        });
      }
    });
  });

  return violations;
}
