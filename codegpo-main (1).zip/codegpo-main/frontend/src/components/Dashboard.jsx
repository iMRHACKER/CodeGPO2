import { useState, useEffect } from "react";

const SEV_COLOR = { CRITICAL: "#EF4444", HIGH: "#F97316", MEDIUM: "#F59E0B", LOW: "#22C55E" };

const ACC_STATUS_CFG = {
  unresolved: { label: "Open", color: "#EF4444", bg: "#EF444422" },
  approved:   { label: "Approved", color: "#22C55E", bg: "#22C55E22" },
  overridden: { label: "Overridden", color: "#F59E0B", bg: "#F59E0B22" },
};

export default function Dashboard({ user, nodes, edges, violations, score, onLoadTemplate, onClose, onDownloadReport }) {
  const [greeting, setGreeting] = useState("Good morning");
  const [time, setTime] = useState(new Date());
  const [pulse, setPulse] = useState(false);
  const [severityFilter, setSeverityFilter] = useState("ALL");

  useEffect(() => {
    const h = new Date().getHours();
    if (h >= 12 && h < 17) setGreeting("Good afternoon");
    else if (h >= 17) setGreeting("Good evening");
  }, []);

  useEffect(() => {
    const t = setInterval(() => {
      setTime(new Date());
      setPulse(p => !p);
    }, 1000);
    return () => clearInterval(t);
  }, []);

  const name     = user?.name?.split(" ")[0] || user?.email?.split("@")[0] || "there";
  const plan     = user?.plan || "free";
  const planLabel = { free:"Free", pro:"Pro", developer:"Pro", team:"Pro", enterprise:"Enterprise", custom:"Custom" }[plan] || "Free";
  const planColor = { free:"#64748B", pro:"#7C3AED", developer:"#7C3AED", team:"#7C3AED", enterprise:"#F97316", custom:"#06B6D4" }[plan] || "#64748B";

  const critical = violations.filter(v => v.severity === "CRITICAL").length;
  const high     = violations.filter(v => v.severity === "HIGH").length;
  const medium   = violations.filter(v => v.severity === "MEDIUM").length;
  const low      = violations.filter(v => v.severity === "LOW").length;
  const scoreVal = score?.score ?? 0;
  const grade    = score?.grade ?? "–";
  const scoreColor = scoreVal >= 80 ? "#22C55E" : scoreVal >= 60 ? "#F59E0B" : "#EF4444";

  const timeStr = time.toLocaleTimeString("en-IN", { hour:"2-digit", minute:"2-digit", second:"2-digit" });
  const dateStr = time.toLocaleDateString("en-IN", { weekday:"long", day:"numeric", month:"long" });

  const filterCounts = {
    ALL: violations.length,
    CRITICAL: critical,
    HIGH: high,
    MEDIUM: medium,
    LOW: low,
  };

  const filteredViolations = severityFilter === "ALL"
    ? violations
    : violations.filter(v => v.severity === severityFilter);

  return (
    <div style={{
      position:"fixed", inset:0, background:"var(--bg-base, #08080f)",
      zIndex:1500, display:"flex", flexDirection:"column",
      fontFamily:"'DM Mono', 'Fira Code', monospace"
    }}>

      {/* Top bar */}
      <div style={{ padding:"14px 28px", borderBottom:"1px solid #1A1A35", display:"flex", justifyContent:"space-between", alignItems:"center", background:"#0d0d1f" }}>
        <div style={{ display:"flex", alignItems:"center", gap:"16px" }}>
          <span style={{ fontSize:"16px", fontWeight:"700", color:"#A78BFA" }}>⚡ CodeGPO</span>
          <span style={{ fontSize:"11px", color:"#334155" }}>|</span>
          <span style={{ fontSize:"11px", color:"#475569" }}>Live Dashboard</span>
          <span style={{ display:"flex", alignItems:"center", gap:"5px", fontSize:"10px", color:"#22C55E" }}>
            <span style={{ width:"6px", height:"6px", borderRadius:"50%", background: pulse ? "#22C55E" : "#16A34A", display:"inline-block", transition:"background 0.5s" }} />
            LIVE
          </span>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:"16px" }}>
          <span style={{ fontSize:"12px", color:"#475569", fontFamily:"monospace" }}>{dateStr} · {timeStr}</span>
          <span style={{ fontSize:"10px", padding:"3px 10px", background:"#0D0820", border:`1px solid ${planColor}`, borderRadius:"20px", color:planColor }}>{planLabel}</span>
          <button onClick={onClose} style={{ padding:"6px 16px", background:"transparent", border:"1px solid #1A1A35", borderRadius:"8px", color:"#475569", fontSize:"12px", cursor:"pointer" }}>
            ← Canvas
          </button>
        </div>
      </div>

      {/* Main grid */}
      <div style={{ flex:1, overflowY:"auto", padding:"24px 28px", display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gridTemplateRows:"auto auto auto", gap:"16px" }}>

        {/* Greeting card */}
        <div style={{ gridColumn:"1 / 3", background:"#0D0D1F", border:"1px solid #1A1A35", borderRadius:"14px", padding:"22px 26px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <div>
            <div style={{ fontSize:"13px", color:"#475569", marginBottom:"4px" }}>{greeting}</div>
            <div style={{ fontSize:"24px", fontWeight:"800", color:"#fff" }}>{name} 👋</div>
            <div style={{ fontSize:"12px", color:"#334155", marginTop:"6px" }}>
              {nodes.length === 0
                ? "No architecture loaded. Start by adding components or loading a template."
                : `Monitoring ${nodes.length} components, ${edges.length} connections in real-time.`}
            </div>
          </div>
          <div style={{ textAlign:"right" }}>
            <div style={{ fontSize:"52px", fontWeight:"900", color:scoreColor, fontFamily:"monospace", lineHeight:1 }}>{scoreVal}</div>
            <div style={{ fontSize:"11px", color:"#475569" }}>/ 100 health score</div>
            <div style={{ fontSize:"18px", fontWeight:"700", color:scoreColor }}>Grade {grade}</div>
          </div>
        </div>

        {/* Status card */}
        <div style={{ background:"#0D0D1F", border:`1px solid ${violations.length === 0 ? "#22C55E33" : "#EF444433"}`, borderRadius:"14px", padding:"22px 26px" }}>
          <div style={{ fontSize:"11px", color:"#475569", textTransform:"uppercase", letterSpacing:"1px", marginBottom:"14px" }}>System Status</div>
          <div style={{ fontSize:"28px", fontWeight:"800", color: violations.length === 0 ? "#22C55E" : critical > 0 ? "#EF4444" : "#F97316", marginBottom:"6px" }}>
            {violations.length === 0 ? "✅ SECURE" : critical > 0 ? "🚫 CRITICAL" : "⚠️ WARNING"}
          </div>
          <div style={{ fontSize:"12px", color:"#475569" }}>
            {violations.length === 0 ? "No violations detected" : `${violations.length} violation${violations.length > 1 ? "s" : ""} detected`}
          </div>
        </div>

        {/* 4 metric cards */}
        {[
          { label:"COMPONENTS", value:nodes.length, color:"#A78BFA", sub:`${edges.length} connections` },
          { label:"CRITICAL",   value:critical,      color:"#EF4444", sub:"violations" },
          { label:"HIGH",       value:high,           color:"#F97316", sub:"violations" },
          { label:"MEDIUM / LOW", value:`${medium}/${low}`, color:"#F59E0B", sub:"violations" },
        ].map((m,i) => (
          <div key={i} style={{ background:"#0D0D1F", border:"1px solid #1A1A35", borderRadius:"14px", padding:"18px 22px", position:"relative", overflow:"hidden" }}>
            <div style={{ position:"absolute", top:0, left:0, right:0, height:"2px", background:m.color }} />
            <div style={{ fontSize:"10px", color:"#475569", letterSpacing:"1.5px", marginBottom:"10px" }}>{m.label}</div>
            <div style={{ fontSize:"36px", fontWeight:"900", color:m.color, fontFamily:"monospace", lineHeight:1 }}>{m.value}</div>
            <div style={{ fontSize:"11px", color:"#334155", marginTop:"6px" }}>{m.sub}</div>
          </div>
        ))}

        {/* Compliance Findings — filterable table */}
        <div style={{ gridColumn:"1 / 3", background:"#0D0D1F", border:"1px solid #1A1A35", borderRadius:"14px", padding:"20px 24px" }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:"14px" }}>
            <div style={{ fontSize:"11px", color:"#475569", textTransform:"uppercase", letterSpacing:"1px" }}>
              🔴 Compliance Findings
            </div>
          </div>

          {/* Filter pills */}
          <div style={{ display:"flex", gap:"6px", marginBottom:"14px", flexWrap:"wrap" }}>
            {["ALL", "CRITICAL", "HIGH", "MEDIUM", "LOW"].map(sev => {
              const isActive = severityFilter === sev;
              const color = sev === "ALL" ? "#A78BFA" : SEV_COLOR[sev];
              return (
                <button
                  key={sev}
                  onClick={() => setSeverityFilter(sev)}
                  style={{
                    padding: "5px 12px", borderRadius: "20px", fontSize: "10.5px", fontWeight: "700",
                    cursor: "pointer", letterSpacing: "0.4px",
                    background: isActive ? `${color}22` : "transparent",
                    border: `1px solid ${isActive ? color : "#1A1A35"}`,
                    color: isActive ? color : "#475569",
                  }}
                >
                  {sev === "ALL" ? "All" : sev.charAt(0) + sev.slice(1).toLowerCase()} {filterCounts[sev]}
                </button>
              );
            })}
          </div>

          {filteredViolations.length === 0 ? (
            <div style={{ textAlign:"center", padding:"20px", color:"#22C55E", fontSize:"14px" }}>
              {violations.length === 0 ? "✅ All clear — no violations detected" : "No violations match this filter"}
            </div>
          ) : (
            <>
              {/* Table header */}
              <div style={{ display:"flex", alignItems:"center", gap:"12px", padding:"6px 0", borderBottom:"1px solid #1A1A35", fontSize:"9.5px", color:"#334155", textTransform:"uppercase", letterSpacing:"0.5px" }}>
                <span style={{ minWidth:"68px" }}>Severity</span>
                <span style={{ flex:1 }}>Rule / Finding</span>
                <span style={{ minWidth:"150px" }}>Location</span>
                <span style={{ minWidth:"90px", textAlign:"right" }}>Status</span>
              </div>

              {filteredViolations.slice(0, 8).map((v, i) => {
                const color = SEV_COLOR[v.severity] || "#64748B";
                const accStatus = v.accountability?.status || "unresolved";
                const accCfg = ACC_STATUS_CFG[accStatus] || ACC_STATUS_CFG.unresolved;
                return (
                  <div key={i} style={{ display:"flex", alignItems:"center", gap:"12px", padding:"9px 0", borderBottom: i < filteredViolations.length - 1 && i < 7 ? "1px solid #0F0F1F" : "none" }}>
                    <span style={{ fontSize:"9px", fontWeight:"700", padding:"2px 8px", background:`${color}22`, color, borderRadius:"4px", minWidth:"68px", textAlign:"center", letterSpacing:"0.5px" }}>{v.severity}</span>
                    <span style={{ fontSize:"11px", color:"#CBD5E1", flex:1 }}>{v.message || v.ruleId}</span>
                    <span style={{ fontSize:"10px", color:"#334155", fontFamily:"monospace", minWidth:"150px" }}>{(v.sourceName || v.source || "").slice(0,12)} → {(v.targetName || v.target || "").slice(0,12)}</span>
                    <span style={{
                      fontSize:"9.5px", fontWeight:"700", padding:"2px 9px", borderRadius:"4px",
                      background: accCfg.bg, color: accCfg.color, minWidth:"90px", textAlign:"center",
                    }}>
                      {accCfg.label}
                    </span>
                  </div>
                );
              })}
              {filteredViolations.length > 8 && (
                <div style={{ textAlign:"center", marginTop:"10px", fontSize:"11px", color:"#334155" }}>
                  +{filteredViolations.length - 8} more → open canvas to review and approve/override
                </div>
              )}
            </>
          )}
        </div>

        {/* Quick Actions */}
        <div style={{ background:"#0D0D1F", border:"1px solid #1A1A35", borderRadius:"14px", padding:"20px 24px" }}>
          <div style={{ fontSize:"11px", color:"#475569", textTransform:"uppercase", letterSpacing:"1px", marginBottom:"14px" }}>Quick Actions</div>
          <div style={{ display:"flex", flexDirection:"column", gap:"10px" }}>
            <button onClick={onClose} style={{ padding:"11px 14px", background:"#7C3AED", border:"none", borderRadius:"10px", color:"#fff", fontSize:"12px", fontWeight:"600", cursor:"pointer", textAlign:"left" }}>
              🏗️ Open Architecture Canvas
            </button>
            <button onClick={() => { onLoadTemplate(); onClose(); }} style={{ padding:"11px 14px", background:"#0A0A1A", border:"1px solid #1A1A35", borderRadius:"10px", color:"#A78BFA", fontSize:"12px", cursor:"pointer", textAlign:"left" }}>
              📦 Load Template
            </button>
            <button
              onClick={() => { if (onDownloadReport) onDownloadReport(); }}
              style={{ padding:"11px 14px", background:"#0A0A1A", border:"1px solid #1A1A35", borderRadius:"10px", color:"#94A3B8", fontSize:"12px", cursor:"pointer", textAlign:"left" }}
            >
              📄 Download PDF Report
            </button>
            <a href="mailto:harsh@codegpo.com" style={{ padding:"11px 14px", background:"#0A0A1A", border:"1px solid #1A1A35", borderRadius:"10px", color:"#94A3B8", fontSize:"12px", textDecoration:"none", display:"block" }}>
              💬 Contact Support
            </a>
          </div>
        </div>

      </div>
    </div>
  );
}
