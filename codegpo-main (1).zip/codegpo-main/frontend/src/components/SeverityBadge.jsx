import { SEVERITY } from "../core/governanceEngine";

export default function SeverityBadge({ severity, size = "sm" }) {
  const s = SEVERITY[severity] || SEVERITY.MEDIUM;
  const isLg = size === "lg";

  return (
    <span style={{
      display: "inline-flex",
      alignItems: "center",
      gap: "4px",
      background: s.bg,
      border: `1px solid ${s.border}`,
      color: s.color,
      fontSize: isLg ? "11px" : "10px",
      fontWeight: "700",
      padding: isLg ? "3px 10px" : "2px 7px",
      borderRadius: "4px",
      letterSpacing: "0.5px",
      whiteSpace: "nowrap"
    }}>
      <span style={{
        width: isLg ? "6px" : "5px",
        height: isLg ? "6px" : "5px",
        borderRadius: "50%",
        background: s.color,
        display: "inline-block",
        flexShrink: 0
      }} />
      {s.label}
    </span>
  );
}