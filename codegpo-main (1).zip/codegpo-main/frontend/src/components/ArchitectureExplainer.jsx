import { useState } from "react";
import { useGraphStore } from "../state/graphStore";
import { useProjectStore } from "../state/projectStore";
import { useAuditStore } from "../state/auditStore";

const BACKEND = import.meta.env.VITE_API_URL || "http://localhost:8000";

async function callGraphRAG(prompt) {
  const res = await fetch(`${BACKEND}/graphrag`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prompt })
  });
  if (!res.ok) throw new Error("No response from server");
  const data = await res.json();
  return data.response || data.explanation || data.result || "";
}

function buildPrompt(nodes, edges, violations) {
  const nodeList = nodes.map(n => `- ${n.name} (${n.type})`).join("\n");
  const edgeList = edges.map(e => {
    const src = nodes.find(n => n.id === e.source);
    const tgt = nodes.find(n => n.id === e.target);
    return `- ${src?.name} → ${tgt?.name}`;
  }).join("\n");
  const violationList = violations.length > 0
    ? violations.map(v => {
        const src = nodes.find(n => n.id === v.source);
        const tgt = nodes.find(n => n.id === v.target);
        return `- [${v.ruleId}] ${src?.name} → ${tgt?.name}: ${v.message}`;
      }).join("\n")
    : "None — architecture is fully compliant.";

  return `You are an expert software architect. Analyze this system architecture and explain it clearly.

COMPONENTS:
${nodeList}

CONNECTIONS:
${edgeList}

GOVERNANCE VIOLATIONS:
${violationList}

Respond in this EXACT format with these exact headers — no markdown, no bold, no asterisks:

SUMMARY:
3-4 sentences describing what this system does overall and its architectural style.

COMPONENTS:
For each component, one sentence explaining its role.

CONNECTIONS:
Explain the data flow through the system in 3-5 sentences.

VIOLATIONS:
For each violation, explain why it is risky in production. If none, say the architecture is compliant.

RECOMMENDATIONS:
Give 2-3 specific actionable improvements.

Be direct and technical but understandable. Do not use markdown formatting.`;
}

function parseResponse(raw) {
  const sections = {};
  const keys = ["SUMMARY", "COMPONENTS", "CONNECTIONS", "VIOLATIONS", "RECOMMENDATIONS"];

  const cleaned = raw
    .replace(/\*\*(.*?)\*\*/g, '$1')
    .replace(/\*(.*?)\*/g, '$1')
    .replace(/#{1,6}\s/g, '')
    .replace(/`{1,3}/g, '')
    .replace(/\*\*/g, '')
    .replace(/\*/g, '');

  console.log("GEMINI RAW RESPONSE:", cleaned);

  keys.forEach((key, i) => {
    const regex = new RegExp(`${key}\\s*:`, 'i');
    const match = cleaned.match(regex);
    if (!match) {
      console.log(`Section NOT FOUND: ${key}`);
      return;
    }
    const start = match.index + match[0].length;
    const nextPositions = keys.slice(i + 1)
      .map(k => {
        const r = new RegExp(`${k}\\s*:`, 'i');
        const m = cleaned.match(r);
        return m ? m.index : -1;
      })
      .filter(p => p > start);
    const end = nextPositions.length > 0 ? Math.min(...nextPositions) : cleaned.length;
    sections[key] = cleaned.slice(start, end).trim();
    console.log(`Section FOUND: ${key} =`, sections[key].substring(0, 80));
  });

  return sections;
}

function Section({ title, content, defaultOpen = false, accent }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div style={{ borderBottom: "1px solid #202020" }}>
      <button
        onClick={() => setOpen(!open)}
        style={{
          background: "transparent", border: "none",
          color: open ? "#e5e5e5" : "#888",
          cursor: "pointer", fontSize: "12px",
          fontWeight: "600", padding: "12px 0",
          width: "100%", textAlign: "left",
          display: "flex", justifyContent: "space-between",
          alignItems: "center", letterSpacing: "0.3px",
          transition: "color 0.15s"
        }}
      >
        <span style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          {accent && (
            <span style={{
              width: "6px", height: "6px", borderRadius: "50%",
              background: accent, display: "inline-block"
            }} />
          )}
          {title}
        </span>
        <span style={{ fontSize: "16px", color: "#333", fontWeight: "300" }}>
          {open ? "−" : "+"}
        </span>
      </button>
      {open && (
        <div style={{
          fontSize: "12.5px", color: "#bbb",
          lineHeight: "1.8", paddingBottom: "14px",
          whiteSpace: "pre-wrap"
        }}>
          {content}
        </div>
      )}
    </div>
  );
}

function getTypeColor(type) {
  if (!type) return "#555";
  const t = type.toLowerCase();
  if (["user","client","browser","frontend"].some(k => t.includes(k))) return "#f59e0b";
  if (["database","db","sql","mongo","redis"].some(k => t.includes(k))) return "#0ea5e9";
  if (["service","microservice"].some(k => t.includes(k))) return "#7c3aed";
  if (["queue","kafka","rabbit"].some(k => t.includes(k))) return "#ec4899";
  if (["gateway","proxy","nginx"].some(k => t.includes(k))) return "#f97316";
  if (["worker","job","cron"].some(k => t.includes(k))) return "#8b5cf6";
  if (["external","vendor"].some(k => t.includes(k))) return "#64748b";
  if (["cache"].some(k => t.includes(k))) return "#06b6d4";
  return "#555";
}

export default function ArchitectureExplainer({ onClose, allViolations }) {
  const { nodes, edges } = useGraphStore();
  const { getActiveProject } = useProjectStore();
  const { saveExplanation } = useAuditStore();

  const activeProject = getActiveProject();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [sections, setSections] = useState(null);
  const [rawResponse, setRawResponse] = useState("");

  const handleExplain = async () => {
    if (nodes.length === 0) { setError("Add some components first."); return; }
    setLoading(true); setError(""); setSections(null);
    try {
      const raw = await callGraphRAG(buildPrompt(nodes, edges, allViolations));
      setRawResponse(raw);
      console.log("FULL RAW:", raw);
      const parsed = parseResponse(raw);
      console.log("PARSED:", parsed);
      setSections(parsed);
      saveExplanation({
        projectName: activeProject?.name || "Untitled",
        projectId: activeProject?.id,
        nodes, edges,
        violations: allViolations,
        sections: parsed
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      position: "fixed", top: 0, right: 0, bottom: 0,
      width: "360px", background: "#0d0d1f",
      borderLeft: "1px solid #22224a", zIndex: 500,
      display: "flex", flexDirection: "column", overflow: "hidden"
    }}>
      <div style={{
        padding: "16px", borderBottom: "1px solid #202020",
        display: "flex", justifyContent: "space-between",
        alignItems: "flex-start", flexShrink: 0
      }}>
        <div>
          <div style={{ fontSize: "13px", fontWeight: "600", color: "#e5e5e5", marginBottom: "4px" }}>
            Architecture Explainer
          </div>
          <div style={{ fontSize: "11px", color: "#666" }}>
            {nodes.length} components · {edges.length} connections · {allViolations.length} violations
          </div>
        </div>
        <button onClick={onClose} style={{
          background: "transparent", border: "none",
          color: "#666", cursor: "pointer", fontSize: "20px", padding: "0", lineHeight: 1
        }}>×</button>
      </div>

      <div style={{
        flex: 1, overflowY: "auto", padding: "16px",
        scrollbarWidth: "thin", scrollbarColor: "#2a2a55 transparent"
      }}>
        {!sections && !loading && (
          <div>
            <p style={{ fontSize: "12.5px", color: "#999", lineHeight: "1.8", marginBottom: "20px" }}>
              Get a full natural language explanation of your architecture — what each component does, how data flows, what violations mean, and how to improve it.
            </p>
            <div style={{ background: "#12122a", border: "1px solid #22224a", borderRadius: "8px", padding: "12px", marginBottom: "16px" }}>
              <div style={{ fontSize: "10px", color: "#555", letterSpacing: "1px", marginBottom: "10px", textTransform: "uppercase", fontWeight: "600" }}>Current Architecture</div>
              {nodes.length === 0 && <div style={{ fontSize: "12px", color: "#444" }}>No components yet.</div>}
              {nodes.slice(0, 8).map(n => (
                <div key={n.id} style={{ display: "flex", alignItems: "center", gap: "8px", padding: "5px 0", borderBottom: "1px solid #181818" }}>
                  <div style={{ width: "7px", height: "7px", borderRadius: "50%", background: getTypeColor(n.type), flexShrink: 0 }} />
                  <span style={{ fontSize: "12px", color: "#ccc" }}>{n.name}</span>
                  <span style={{ fontSize: "10px", color: "#555", marginLeft: "auto" }}>{n.type}</span>
                </div>
              ))}
              {nodes.length > 8 && <div style={{ fontSize: "11px", color: "#555", marginTop: "8px" }}>+{nodes.length - 8} more</div>}
            </div>
            {allViolations.length > 0 && (
              <div style={{ padding: "10px 12px", background: "#1a1212", border: "1px solid #2e1f1f", borderRadius: "8px", marginBottom: "16px", fontSize: "12px", color: "#cc6666", lineHeight: "1.6" }}>
                ⚠ {allViolations.length} violation{allViolations.length > 1 ? "s" : ""} will be included in the analysis.
              </div>
            )}
            <button onClick={handleExplain} style={{
              width: "100%", padding: "10px",
              background: "linear-gradient(135deg, rgba(124,58,237,0.2), rgba(0,229,160,0.1))",
              border: "1px solid rgba(124,58,237,0.4)",
              color: "#e5e5e5", borderRadius: "8px",
              cursor: "pointer", fontSize: "13px", fontWeight: "600"
            }}>
              ✦ Explain with GraphRAG →
            </button>
            <div style={{ fontSize: "11px", color: "#444", marginTop: "10px", textAlign: "center" }}>Powered by Gemini AI</div>
          </div>
        )}

        {loading && (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "60px 20px", gap: "16px" }}>
            <div style={{ width: "28px", height: "28px", border: "2px solid #22224a", borderTop: "2px solid #888", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
            <div style={{ fontSize: "12.5px", color: "#888", textAlign: "center", lineHeight: "1.7" }}>
              Analyzing architecture with Gemini...<br />
              <span style={{ fontSize: "11px", color: "#555" }}>May take 10–20 seconds</span>
            </div>
            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
          </div>
        )}

        {error && !loading && (
          <div>
            <div style={{ padding: "12px", background: "#1a1212", border: "1px solid #2e1f1f", borderRadius: "8px", fontSize: "12.5px", color: "#cc6666", marginBottom: "12px", lineHeight: "1.6" }}>
              {error}
            </div>
            <button onClick={handleExplain} style={{ width: "100%", padding: "10px", background: "#1a1a35", border: "1px solid #2a2a55", color: "#ccc", borderRadius: "8px", cursor: "pointer", fontSize: "12px" }}>
              Try Again
            </button>
          </div>
        )}

        {sections && (
          <div>
            {sections.SUMMARY && (
              <div style={{ padding: "14px", background: "#12122a", border: "1px solid #22224a", borderRadius: "8px", marginBottom: "16px" }}>
                <div style={{ fontSize: "10px", color: "#555", letterSpacing: "1px", textTransform: "uppercase", marginBottom: "10px", fontWeight: "600" }}>Summary</div>
                <p style={{ fontSize: "12.5px", color: "#ccc", lineHeight: "1.8", margin: 0 }}>{sections.SUMMARY}</p>
              </div>
            )}

            {/* Raw response for debugging */}
            {rawResponse && !sections.COMPONENTS && (
              <div style={{ padding: "12px", background: "#0d0d1f", border: "1px solid #1a1a35", borderRadius: "8px", marginBottom: "16px", fontSize: "11px", color: "#666", whiteSpace: "pre-wrap", maxHeight: "300px", overflowY: "auto" }}>
                <div style={{ color: "#444", marginBottom: "8px", fontSize: "10px" }}>RAW RESPONSE (DEBUG):</div>
                {rawResponse}
              </div>
            )}

            <div style={{ padding: "7px 10px", background: "#0f1a12", border: "1px solid #1a2e1e", borderRadius: "6px", fontSize: "11px", color: "#5a9e6f", marginBottom: "14px" }}>
              ✓ Saved to History → Explanations
            </div>

            {sections.COMPONENTS && <Section title="Components" content={sections.COMPONENTS} accent="#7c3aed" defaultOpen={true} />}
            {sections.CONNECTIONS && <Section title="Data Flow" content={sections.CONNECTIONS} accent="#0ea5e9" defaultOpen={true} />}
            {sections.VIOLATIONS && <Section title={`Violations${allViolations.length > 0 ? ` (${allViolations.length})` : ""}`} content={sections.VIOLATIONS} accent="#cc6666" defaultOpen={allViolations.length > 0} />}
            {sections.RECOMMENDATIONS && <Section title="Recommendations" content={sections.RECOMMENDATIONS} accent="#5a9e6f" defaultOpen={true} />}

            <button onClick={handleExplain} style={{ width: "100%", padding: "9px", background: "transparent", border: "1px solid #22224a", color: "#777", borderRadius: "8px", cursor: "pointer", fontSize: "12px", marginTop: "20px" }}>
              ↺ Re-analyze
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
