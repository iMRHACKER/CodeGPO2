import { useState, useEffect } from "react";
import { useProjectStore } from "../state/projectStore";
import { useGraphStore } from "../state/graphStore";

const GRADE_COLOR = {
  A: "#22c55e", B: "#84cc16", C: "#f59e0b",
  D: "#f97316", F: "#ef4444"
};

function gradeFromScore(score) {
  if (score >= 90) return "A";
  if (score >= 80) return "B";
  if (score >= 70) return "C";
  if (score >= 55) return "D";
  return "F";
}

function scoreFromProject(p) {
  if (!p.nodeCount) return null;
  // Rough estimate from stored metadata
  const base = 100 - Math.min(80, (p.violationCount || 0) * 12);
  return Math.max(10, base);
}

// Mini architecture preview — tiny nodes grid
function MiniPreview({ nodeCount, edgeCount }) {
  const count = Math.min(nodeCount || 0, 12);
  if (count === 0) return (
    <div style={{
      width: "100%", height: "100%",
      display: "flex", alignItems: "center",
      justifyContent: "center",
      color: "#2a2a55", fontSize: "11px",
      fontStyle: "italic"
    }}>
      new
    </div>
  );

  const dots = Array.from({ length: count }, (_, i) => ({
    x: 15 + (i % 4) * 22 + (Math.sin(i * 1.7) * 6),
    y: 15 + Math.floor(i / 4) * 22 + (Math.cos(i * 1.3) * 4),
    color: ["#7c3aed", "#0ea5e9", "#22c55e", "#ec4899", "#f59e0b", "#06b6d4"][i % 6]
  }));

  return (
    <svg width="100%" height="100%" style={{ overflow: "visible" }}>
      {/* Edges — simple lines between nearby dots */}
      {dots.slice(0, Math.min(edgeCount || 0, 8)).map((d, i) => {
        const next = dots[(i + 1) % dots.length];
        return (
          <line key={i}
            x1={d.x} y1={d.y} x2={next.x} y2={next.y}
            stroke="#1a1a35" strokeWidth="1"
          />
        );
      })}
      {/* Nodes */}
      {dots.map((d, i) => (
        <circle key={i}
          cx={d.x} cy={d.y} r="5"
          fill={d.color + "33"}
          stroke={d.color}
          strokeWidth="1.2"
        />
      ))}
    </svg>
  );
}

function ProjectCard({ project, onOpen, onDelete, onRename, index }) {
  const [hovered, setHovered] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [renaming, setRenaming] = useState(false);
  const [newName, setNewName] = useState(project.name);

  const score = scoreFromProject(project);
  const grade = score != null ? gradeFromScore(score) : null;
  const gradeColor = grade ? GRADE_COLOR[grade] : "#333";

  const handleRename = () => {
    if (newName.trim() && newName !== project.name) {
      onRename(project.id, newName.trim());
    }
    setRenaming(false);
    setMenuOpen(false);
  };

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => { setHovered(false); setMenuOpen(false); }}
      style={{
        background: hovered ? "#12122a" : "#0d0d1f",
        border: `1px solid ${hovered ? "#2a2a55" : "#161632"}`,
        borderRadius: "14px",
        overflow: "visible",
        cursor: "pointer",
        transition: "all 0.2s",
        transform: hovered ? "translateY(-2px)" : "none",
        boxShadow: hovered ? "0 8px 32px rgba(0,0,0,0.4)" : "none",
        animation: `cardIn 0.3s ease both`,
        animationDelay: `${index * 0.05}s`,
        position: "relative"
      }}
    >
      <style>{`
        @keyframes cardIn {
          from { opacity: 0; transform: translateY(12px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      {/* Top accent line */}
      <div style={{
        height: "2px",
        background: `linear-gradient(90deg, ${gradeColor}66, transparent)`,
        opacity: hovered ? 1 : 0.4,
        transition: "opacity 0.2s"
      }} />

      {/* Mini preview */}
      <div
        onClick={() => onOpen(project.id)}
        style={{
          height: "90px",
          padding: "12px 16px",
          background: "#08080f",
          position: "relative",
          overflow: "hidden"
        }}
      >
        <MiniPreview nodeCount={project.nodeCount} edgeCount={project.edgeCount} />

        {/* Grade badge */}
        {grade && (
          <div style={{
            position: "absolute", top: "10px", right: "10px",
            width: "28px", height: "28px",
            borderRadius: "8px",
            background: gradeColor + "22",
            border: `1px solid ${gradeColor}44`,
            display: "flex", alignItems: "center",
            justifyContent: "center",
            fontSize: "13px", fontWeight: "800",
            color: gradeColor
          }}>
            {grade}
          </div>
        )}
      </div>

      {/* Info */}
      <div
        onClick={() => onOpen(project.id)}
        style={{ padding: "14px 16px 12px" }}
      >
        {renaming ? (
          <input
            autoFocus
            value={newName}
            onChange={e => setNewName(e.target.value)}
            onKeyDown={e => {
              if (e.key === "Enter") handleRename();
              if (e.key === "Escape") setRenaming(false);
            }}
            onBlur={handleRename}
            onClick={e => e.stopPropagation()}
            style={{
              background: "#161632", border: "1px solid #333",
              color: "#e5e5e5", borderRadius: "6px",
              padding: "4px 8px", fontSize: "14px",
              fontWeight: "600", width: "100%",
              outline: "none", marginBottom: "6px"
            }}
          />
        ) : (
          <div style={{
            fontSize: "14px", fontWeight: "600",
            color: "#e5e5e5", marginBottom: "4px",
            whiteSpace: "nowrap", overflow: "hidden",
            textOverflow: "ellipsis"
          }}>
            {project.name}
          </div>
        )}

        {project.description && (
          <div style={{
            fontSize: "11px", color: "#555",
            marginBottom: "10px",
            whiteSpace: "nowrap", overflow: "hidden",
            textOverflow: "ellipsis"
          }}>
            {project.description}
          </div>
        )}

        {/* Stats row */}
        <div style={{
          display: "flex", gap: "12px",
          alignItems: "center"
        }}>
          <Stat value={project.nodeCount || 0} label="components" />
          <div style={{ width: "1px", height: "12px", background: "#1a1a35" }} />
          <Stat value={project.edgeCount || 0} label="connections" />
          <div style={{ marginLeft: "auto", fontSize: "10px", color: "#444", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: "110px" }}>
            {(() => {
              const raw = project.updatedAt || project.createdAt;
              if (!raw) return "";
              try {
                const d = new Date(raw);
                return d.toLocaleDateString("en-IN", { day:"2-digit", month:"short", year:"2-digit" });
              } catch { return raw?.toString().slice(0,10) || ""; }
            })()}
          </div>
        </div>
      </div>

      {/* Context menu button */}
      <button
        onClick={e => { e.stopPropagation(); setMenuOpen(!menuOpen); }}
        style={{
          position: "absolute", top: "98px", right: "12px",
          background: "transparent", border: "none",
          color: "#444",
          cursor: "pointer", fontSize: "16px",
          padding: "2px 6px", borderRadius: "4px",
          transition: "all 0.15s",
          lineHeight: 1
        }}
        onMouseEnter={e => e.currentTarget.style.color = "#aaa"}
        onMouseLeave={e => e.currentTarget.style.color = "#444"}
      >
        ···
      </button>

      {/* Dropdown menu */}
      {menuOpen && (
        <div
          onClick={e => e.stopPropagation()}
          style={{
            position: "absolute", top: "118px", right: "12px",
            background: "#161632", border: "1px solid #22224a",
            borderRadius: "8px", overflow: "visible",
            zIndex: 9999, minWidth: "130px",
            boxShadow: "0 8px 24px rgba(0,0,0,0.5)"
          }}
        >
          <MenuItem label="Open" icon="→" onClick={() => onOpen(project.id)} />
          <MenuItem label="Rename" icon="✎" onClick={() => { setRenaming(true); setMenuOpen(false); }} />
          <div style={{ height: "1px", background: "#22224a" }} />
          <MenuItem label="Delete" icon="✕" danger onClick={() => { onDelete(project.id); setMenuOpen(false); }} />
        </div>
      )}
    </div>
  );
}

function MenuItem({ label, icon, onClick, danger }) {
  const [hov, setHov] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        display: "flex", alignItems: "center", gap: "8px",
        width: "100%", padding: "9px 14px",
        background: hov ? (danger ? "#1a0a0a" : "#22224a") : "transparent",
        border: "none", cursor: "pointer",
        color: danger ? (hov ? "#ef4444" : "#854444") : (hov ? "#e5e5e5" : "#888"),
        fontSize: "12px", textAlign: "left",
        transition: "all 0.1s"
      }}
    >
      <span style={{ fontSize: "11px", opacity: 0.7 }}>{icon}</span>
      {label}
    </button>
  );
}

function Stat({ value, label }) {
  return (
    <div style={{ display: "flex", alignItems: "baseline", gap: "3px" }}>
      <span style={{ fontSize: "13px", fontWeight: "700", color: "#888" }}>
        {value}
      </span>
      <span style={{ fontSize: "10px", color: "#444" }}>
        {label}
      </span>
    </div>
  );
}

function NewProjectModal({ onCreate, onClose }) {
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");

  useEffect(() => {
    const handler = e => e.key === "Escape" && onClose();
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const handleCreate = () => {
    if (!name.trim()) return;
    onCreate(name.trim(), desc.trim());
    onClose();
  };

  return (
    <div
      onClick={e => e.target === e.currentTarget && onClose()}
      style={{
        position: "fixed", inset: 0,
        background: "rgba(0,0,0,0.8)",
        display: "flex", alignItems: "center",
        justifyContent: "center", zIndex: 1000
      }}
    >
      <div style={{
        background: "#0d0d1f",
        border: "1px solid #22224a",
        borderRadius: "14px",
        width: "420px",
        padding: "24px",
        boxShadow: "0 24px 60px rgba(0,0,0,0.6)"
      }}>
        <h2 style={{
          color: "#e5e5e5", margin: "0 0 6px",
          fontSize: "15px", fontWeight: "600"
        }}>
          New Project
        </h2>
        <p style={{ color: "#666", fontSize: "12px", margin: "0 0 20px" }}>
          Create a new architecture workspace
        </p>

        <label style={{
          fontSize: "11px", color: "#777",
          textTransform: "uppercase", letterSpacing: "0.8px",
          fontWeight: "600", display: "block", marginBottom: "6px"
        }}>
          Project Name
        </label>
        <input
          autoFocus
          value={name}
          onChange={e => setName(e.target.value)}
          onKeyDown={e => e.key === "Enter" && handleCreate()}
          placeholder="e.g. Payment Service, Auth Platform..."
          style={{
            width: "100%", padding: "10px 12px",
            background: "#0d0d1f", border: "1px solid #22224a",
            color: "#e5e5e5", borderRadius: "8px",
            fontSize: "13px", outline: "none",
            boxSizing: "border-box", marginBottom: "14px",
            transition: "border-color 0.15s"
          }}
          onFocus={e => e.target.style.borderColor = "#444"}
          onBlur={e => e.target.style.borderColor = "#22224a"}
        />

        <label style={{
          fontSize: "11px", color: "#777",
          textTransform: "uppercase", letterSpacing: "0.8px",
          fontWeight: "600", display: "block", marginBottom: "6px"
        }}>
          Description (optional)
        </label>
        <input
          value={desc}
          onChange={e => setDesc(e.target.value)}
          placeholder="What does this architecture represent?"
          style={{
            width: "100%", padding: "10px 12px",
            background: "#0d0d1f", border: "1px solid #22224a",
            color: "#e5e5e5", borderRadius: "8px",
            fontSize: "13px", outline: "none",
            boxSizing: "border-box", marginBottom: "20px",
            transition: "border-color 0.15s"
          }}
          onFocus={e => e.target.style.borderColor = "#444"}
          onBlur={e => e.target.style.borderColor = "#22224a"}
        />

        <div style={{ display: "flex", gap: "10px", justifyContent: "flex-end" }}>
          <button
            onClick={onClose}
            style={{
              background: "transparent", border: "1px solid #22224a",
              color: "#777", padding: "9px 20px",
              borderRadius: "8px", cursor: "pointer", fontSize: "13px"
            }}
          >
            Cancel
          </button>
          <button
            onClick={handleCreate}
            disabled={!name.trim()}
            style={{
              background: name.trim() ? "#7c3aed" : "#1a1a35",
              border: "none", color: name.trim() ? "#fff" : "#444",
              padding: "9px 24px", borderRadius: "8px",
              cursor: name.trim() ? "pointer" : "default",
              fontSize: "13px", fontWeight: "600",
              transition: "all 0.15s"
            }}
          >
            Create Project
          </button>
        </div>
      </div>
    </div>
  );
}

export default function ProjectDashboard({ onOpen }) {
  const {
    projects, createProject, deleteProject,
    renameProject, setActiveProject
  } = useProjectStore();
  const { clearGraph, setGraph } = useGraphStore();

  const [showNew, setShowNew] = useState(false);
  const [search, setSearch] = useState("");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setTimeout(() => setMounted(true), 50);
  }, []);

  const handleOpen = (projectId) => {
    setActiveProject(projectId);
    // Load this project's saved graph into the canvas
    const project = useProjectStore.getState().projects.find(p => p.id === projectId);
    const projectNodes = project?.nodes || [];
    const projectEdges = project?.edges || [];
    setGraph(projectNodes, projectEdges);
    onOpen();
  };

  const handleCreate = (name, description) => {
    const id = createProject(name, description);
    clearGraph();
    setActiveProject(id);
    onOpen();
  };

  const handleDelete = (projectId) => {
    if (window.confirm("Delete this project? This cannot be undone.")) {
      deleteProject(projectId);
    }
  };

  const filtered = projects.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  const totalComponents = projects.reduce((s, p) => s + (p.nodeCount || 0), 0);
  const totalProjects = projects.length;

  return (
    <div style={{
      width: "100vw", height: "100vh",
      background: "#08080f",
      overflow: "auto",
      fontFamily: "'DM Sans', 'Helvetica Neue', sans-serif"
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800&display=swap');
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #1a1a35; border-radius: 3px; }
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(16px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      {showNew && (
        <NewProjectModal
          onCreate={handleCreate}
          onClose={() => setShowNew(false)}
        />
      )}

      <div style={{
        maxWidth: "960px",
        margin: "0 auto",
        padding: "60px 40px 80px"
      }}>

        {/* Header */}
        <div style={{
          display: "flex", justifyContent: "space-between",
          alignItems: "flex-start", marginBottom: "48px",
          opacity: mounted ? 1 : 0,
          transform: mounted ? "none" : "translateY(12px)",
          transition: "all 0.4s ease"
        }}>
          <div>
            {/* Logo */}
            <div style={{
              display: "flex", alignItems: "center", gap: "10px",
              marginBottom: "24px"
            }}>
              <div style={{
                width: "32px", height: "32px",
                background: "#7c3aed22",
                border: "1px solid #7c3aed44",
                borderRadius: "8px",
                display: "flex", alignItems: "center",
                justifyContent: "center",
                fontSize: "16px"
              }}>
                ⚡
              </div>
              <span style={{
                fontSize: "14px", fontWeight: "700",
                color: "#e5e5e5", letterSpacing: "0.5px"
              }}>
                CodeGPO
              </span>
              <span style={{
                fontSize: "10px", color: "#7c3aed",
                background: "#7c3aed22",
                border: "1px solid #7c3aed33",
                padding: "2px 8px", borderRadius: "10px",
                fontWeight: "600", letterSpacing: "0.5px"
              }}>
                ALPHA
              </span>
            </div>

            <h1 style={{
              fontSize: "32px", fontWeight: "800",
              color: "#e5e5e5", margin: "0 0 8px",
              letterSpacing: "-0.5px", lineHeight: 1.1
            }}>
              Your Projects
            </h1>
            <p style={{
              fontSize: "14px", color: "#555", margin: 0
            }}>
              {totalProjects} project{totalProjects !== 1 ? "s" : ""}
              {totalComponents > 0 && ` · ${totalComponents} total components`}
            </p>
          </div>

          <button
            onClick={() => setShowNew(true)}
            style={{
              background: "#7c3aed",
              border: "none", color: "#fff",
              padding: "11px 22px", borderRadius: "10px",
              cursor: "pointer", fontSize: "13px",
              fontWeight: "600", display: "flex",
              alignItems: "center", gap: "8px",
              transition: "all 0.15s",
              boxShadow: "0 4px 16px rgba(124,58,237,0.3)"
            }}
            onMouseEnter={e => {
              e.currentTarget.style.background = "#6d28d9";
              e.currentTarget.style.transform = "translateY(-1px)";
              e.currentTarget.style.boxShadow = "0 6px 20px rgba(124,58,237,0.4)";
            }}
            onMouseLeave={e => {
              e.currentTarget.style.background = "#7c3aed";
              e.currentTarget.style.transform = "none";
              e.currentTarget.style.boxShadow = "0 4px 16px rgba(124,58,237,0.3)";
            }}
          >
            <span style={{ fontSize: "16px", lineHeight: 1 }}>+</span>
            New Project
          </button>
        </div>

        {/* Search */}
        {projects.length > 3 && (
          <div style={{
            marginBottom: "24px",
            opacity: mounted ? 1 : 0,
            transition: "opacity 0.4s ease 0.1s"
          }}>
            <div style={{ position: "relative" }}>
              <span style={{
                position: "absolute", left: "14px", top: "50%",
                transform: "translateY(-50%)",
                color: "#444", fontSize: "14px"
              }}>⌕</span>
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search projects..."
                style={{
                  width: "100%", padding: "11px 14px 11px 38px",
                  background: "#0d0d1f", border: "1px solid #161632",
                  color: "#e5e5e5", borderRadius: "10px",
                  fontSize: "13px", outline: "none",
                  transition: "border-color 0.15s"
                }}
                onFocus={e => e.target.style.borderColor = "#2a2a55"}
                onBlur={e => e.target.style.borderColor = "#161632"}
              />
            </div>
          </div>
        )}

        {/* Empty state */}
        {projects.length === 0 && (
          <div style={{
            textAlign: "center", padding: "80px 40px",
            opacity: mounted ? 1 : 0,
            transition: "opacity 0.5s ease 0.2s"
          }}>
            <div style={{
              width: "72px", height: "72px",
              borderRadius: "18px",
              background: "#0d0d1f",
              border: "1px solid #161632",
              display: "flex", alignItems: "center",
              justifyContent: "center",
              fontSize: "32px", margin: "0 auto 20px"
            }}>
              ◈
            </div>
            <div style={{
              fontSize: "20px", fontWeight: "700",
              color: "#e5e5e5", marginBottom: "10px"
            }}>
              No projects yet
            </div>
            <div style={{
              fontSize: "14px", color: "#555",
              marginBottom: "28px", lineHeight: "1.6"
            }}>
              Create your first architecture project to start mapping
              your system and detecting governance violations.
            </div>
            <button
              onClick={() => setShowNew(true)}
              style={{
                background: "#7c3aed", border: "none",
                color: "#fff", padding: "12px 28px",
                borderRadius: "10px", cursor: "pointer",
                fontSize: "14px", fontWeight: "600"
              }}
            >
              + Create First Project
            </button>
          </div>
        )}

        {/* Project grid */}
        {filtered.length > 0 && (
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
            gap: "14px"
          }}>
            {filtered.map((project, i) => (
              <ProjectCard
                key={project.id}
                project={project}
                index={i}
                onOpen={handleOpen}
                onDelete={handleDelete}
                onRename={renameProject}
              />
            ))}

            {/* New project card */}
            <NewCard onClick={() => setShowNew(true)} index={filtered.length} />
          </div>
        )}

        {/* No search results */}
        {projects.length > 0 && filtered.length === 0 && (
          <div style={{
            textAlign: "center", padding: "60px",
            color: "#555", fontSize: "14px"
          }}>
            No projects matching "{search}"
          </div>
        )}
      </div>
    </div>
  );
}

function NewCard({ onClick, index }) {
  const [hov, setHov] = useState(false);

  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        background: "transparent",
        border: `1.5px dashed ${hov ? "#333" : "#1a1a35"}`,
        borderRadius: "14px",
        padding: "0",
        cursor: "pointer",
        minHeight: "180px",
        display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center",
        gap: "10px", transition: "all 0.2s",
        animation: `cardIn 0.3s ease both`,
        animationDelay: `${index * 0.05}s`
      }}
    >
      <div style={{
        width: "36px", height: "36px",
        borderRadius: "10px",
        background: hov ? "#161632" : "transparent",
        border: `1px solid ${hov ? "#333" : "#1a1a35"}`,
        display: "flex", alignItems: "center",
        justifyContent: "center",
        fontSize: "20px", color: hov ? "#777" : "#333",
        transition: "all 0.2s"
      }}>
        +
      </div>
      <span style={{
        fontSize: "12px", fontWeight: "500",
        color: hov ? "#666" : "#333",
        transition: "color 0.2s"
      }}>
        New Project
      </span>
    </button>
  );
}
