import { useState, useEffect } from "react";
import { useGraphStore } from "../state/graphStore";

const BACKEND = import.meta.env.VITE_API_URL || "http://localhost:8000";

// ── Syntax highlight (simple) ─────────────────────────────
function CodeBlock({ code, language }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div style={{ position: "relative" }}>
      <button onClick={handleCopy} style={{
        position: "absolute", top: "10px", right: "10px",
        background: copied ? "#1a2e1e" : "#1a1a35",
        border: `1px solid ${copied ? "#2a4a2e" : "#333"}`,
        color: copied ? "#5a9e6f" : "#777",
        padding: "4px 10px", borderRadius: "6px",
        fontSize: "11px", cursor: "pointer", fontFamily: "monospace", zIndex: 1
      }}>
        {copied ? "✓ Copied" : "Copy"}
      </button>
      <pre style={{
        background: "#0d0d1f", border: "1px solid #1a1a35", borderRadius: "8px",
        padding: "14px", overflowX: "auto", fontSize: "11.5px", lineHeight: "1.65",
        color: "#c9d1d9", margin: 0, fontFamily: "'IBM Plex Mono', monospace",
        whiteSpace: "pre", maxHeight: "320px", overflowY: "auto",
        scrollbarWidth: "thin", scrollbarColor: "#2a2a55 transparent"
      }}><code>{code}</code></pre>
    </div>
  );
}

const ARTIFACT_LABELS = {
  sql:       { label: "SQL",       icon: "🗄", color: "#0ea5e9" },
  orm:       { label: "ORM",       icon: "🧱", color: "#7c3aed" },
  migration: { label: "Migration", icon: "🔃", color: "#f59e0b" },
  prisma:    { label: "Prisma",    icon: "◈",  color: "#22c55e" },
  openapi:   { label: "OpenAPI",   icon: "📄", color: "#0da8ff" },
  mongo:     { label: "MongoDB",   icon: "🍃", color: "#22c55e" },
};

function NodeSchemaCard({ schema }) {
  const [activeTab, setActiveTab] = useState(Object.keys(schema.artifacts || {})[0] || null);
  const [expanded, setExpanded] = useState(false);
  const artifactKeys = Object.keys(schema.artifacts || {});
  if (!artifactKeys.length) return null;
  const activeCode = schema.artifacts[activeTab] || "";
  return (
    <div style={{ background: "#12122a", border: "1px solid #1a1a35", borderRadius: "12px", overflow: "hidden", marginBottom: "12px" }}>
      <button onClick={() => setExpanded(!expanded)} style={{
        width: "100%", background: "transparent", border: "none",
        padding: "14px 16px", cursor: "pointer",
        display: "flex", alignItems: "center", gap: "12px", textAlign: "left"
      }}>
        <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: schema.nodeType?.toLowerCase().includes("api") ? "#22c55e" : "#0ea5e9", flexShrink: 0 }} />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: "13px", fontWeight: "600", color: "#e5e5e5" }}>{schema.nodeName}</div>
          {schema.intent && <div style={{ fontSize: "11px", color: "#555", marginTop: "2px" }}>{schema.intent}</div>}
        </div>
        <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
          {artifactKeys.map(k => (
            <span key={k} style={{
              fontSize: "10px", fontWeight: "600", padding: "2px 7px", borderRadius: "4px",
              background: (ARTIFACT_LABELS[k]?.color || "#555") + "22",
              color: ARTIFACT_LABELS[k]?.color || "#888",
              border: `1px solid ${(ARTIFACT_LABELS[k]?.color || "#555")}44`
            }}>{ARTIFACT_LABELS[k]?.label || k}</span>
          ))}
          <span style={{ color: "#555", fontSize: "14px", transform: expanded ? "rotate(180deg)" : "none", transition: "transform 0.2s", display: "inline-block" }}>▾</span>
        </div>
      </button>
      {expanded && (
        <div style={{ borderTop: "1px solid #161632" }}>
          <div style={{ display: "flex", gap: "4px", padding: "10px 14px 0", borderBottom: "1px solid #161632" }}>
            {artifactKeys.map(k => {
              const cfg = ARTIFACT_LABELS[k] || { label: k, icon: "◆", color: "#888" };
              const isActive = activeTab === k;
              return (
                <button key={k} onClick={() => setActiveTab(k)} style={{
                  background: isActive ? cfg.color + "18" : "transparent",
                  border: `1px solid ${isActive ? cfg.color + "55" : "transparent"}`,
                  color: isActive ? cfg.color : "#555",
                  padding: "6px 12px", borderRadius: "6px 6px 0 0",
                  cursor: "pointer", fontSize: "11.5px", fontWeight: "600",
                  display: "flex", alignItems: "center", gap: "5px"
                }}>
                  <span>{cfg.icon}</span><span>{cfg.label}</span>
                </button>
              );
            })}
          </div>
          <div style={{ padding: "12px 14px 14px" }}>
            {schema.owner && (
              <div style={{ fontSize: "10px", color: "#444", marginBottom: "8px", display: "flex", gap: "12px" }}>
                <span>Owner: <span style={{ color: "#666" }}>{schema.owner}</span></span>
                {schema.nodeType && <span>Type: <span style={{ color: "#666" }}>{schema.nodeType}</span></span>}
              </div>
            )}
            <CodeBlock code={activeCode} language={activeTab} />
          </div>
        </div>
      )}
    </div>
  );
}

export default function SchemaPanel({ onClose }) {
  const { nodes, edges } = useGraphStore();
  const [schemas, setSchemas]     = useState([]);
  const [loading, setLoading]     = useState(false);
  const [error, setError]         = useState("");
  const [generated, setGenerated] = useState(false);
  const [filter, setFilter]       = useState("all");

  const eligibleTypes = ["database", "db", "api", "rest", "sql", "mongo", "nosql", "graphql"];
  const eligibleNodes = nodes.filter(n => eligibleTypes.some(t => (n.type || "").toLowerCase().includes(t)));

  const handleGenerate = async () => {
    if (nodes.length === 0) { setError("No components in graph. Add Database or API nodes first."); return; }
    setLoading(true); setError("");
    try {
      const res = await fetch(`${BACKEND}/schema/generate`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nodes, edges })
      });
      if (!res.ok) { const d = await res.json().catch(() => ({})); throw new Error(d.detail || "Generation failed"); }
      const data = await res.json();
      setSchemas(data.schemas || []); setGenerated(true);
      if (data.schemas.length === 0) setError("No schema-eligible nodes found.");
    } catch (e) { setError(e.message || "Failed to connect to backend"); }
    finally { setLoading(false); }
  };

  const filtered = schemas.filter(s => {
    if (filter === "all") return true;
    if (filter === "database") return (s.nodeType || "").toLowerCase().includes("db") || (s.nodeType || "").toLowerCase().includes("database");
    if (filter === "api") return (s.nodeType || "").toLowerCase().includes("api");
    return true;
  });

  const handleDownload = () => {
    const blob = new Blob([JSON.stringify(schemas, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a");
    a.href = url; a.download = `codegpo-schemas-${Date.now()}.json`; a.click(); URL.revokeObjectURL(url);
  };

  const handleDownloadAll = () => {
    schemas.forEach(s => {
      Object.entries(s.artifacts || {}).forEach(([type, code]) => {
        const ext = { sql: "sql", orm: "py", migration: "py", prisma: "prisma", openapi: "yaml", mongo: "js" };
        const blob = new Blob([code], { type: "text/plain" }); const url = URL.createObjectURL(blob);
        const a = document.createElement("a"); a.href = url;
        a.download = `${s.nodeName?.toLowerCase().replace(/ /g, "_")}_${type}.${ext[type] || "txt"}`; a.click(); URL.revokeObjectURL(url);
      });
    });
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.88)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 3000, padding: "20px" }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background: "#0d0d1f", border: "1px solid #22224a", borderRadius: "16px", width: "780px", maxHeight: "90vh", display: "flex", flexDirection: "column", overflow: "hidden", boxShadow: "0 30px 80px rgba(0,0,0,0.7)" }}>

        <div style={{ padding: "20px 24px 16px", borderBottom: "1px solid #1a1a35", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <span style={{ fontSize: "18px" }}>⟁</span>
              <h2 style={{ color: "#e5e5e5", margin: 0, fontSize: "16px", fontWeight: "700" }}>Schema & Contract Generation</h2>
              <span style={{ fontSize: "9.5px", fontWeight: "700", letterSpacing: "1px", background: "rgba(0,212,180,0.12)", border: "1px solid rgba(0,212,180,0.3)", color: "#00d4b4", padding: "2px 8px", borderRadius: "4px" }}>NEXUS</span>
            </div>
            <p style={{ color: "#555", fontSize: "12px", margin: "5px 0 0" }}>Deterministically generated from the graph — not invented by AI</p>
          </div>
          <button onClick={onClose} style={{ background: "transparent", border: "none", color: "#555", cursor: "pointer", fontSize: "20px" }}>×</button>
        </div>

        <div style={{ padding: "12px 24px", borderBottom: "1px solid #161632", display: "flex", gap: "24px", alignItems: "center" }}>
          <div style={{ display: "flex", gap: "20px", flex: 1 }}>
            <div><span style={{ fontSize: "18px", fontWeight: "700", color: "#e5e5e5" }}>{nodes.length}</span><span style={{ fontSize: "11px", color: "#555", marginLeft: "5px" }}>total nodes</span></div>
            <div><span style={{ fontSize: "18px", fontWeight: "700", color: "#0ea5e9" }}>{eligibleNodes.length}</span><span style={{ fontSize: "11px", color: "#555", marginLeft: "5px" }}>schema-eligible</span></div>
            {generated && <div><span style={{ fontSize: "18px", fontWeight: "700", color: "#00d4b4" }}>{schemas.reduce((sum, s) => sum + Object.keys(s.artifacts || {}).length, 0)}</span><span style={{ fontSize: "11px", color: "#555", marginLeft: "5px" }}>artifacts</span></div>}
          </div>
          <div style={{ display: "flex", gap: "8px" }}>
            {generated && schemas.length > 0 && <>
              <button onClick={handleDownloadAll} style={{ background: "transparent", border: "1px solid #333", color: "#888", padding: "7px 14px", borderRadius: "8px", cursor: "pointer", fontSize: "12px" }}>↓ Download Files</button>
              <button onClick={handleDownload} style={{ background: "transparent", border: "1px solid #333", color: "#888", padding: "7px 14px", borderRadius: "8px", cursor: "pointer", fontSize: "12px" }}>↓ Export JSON</button>
            </>}
            <button onClick={handleGenerate} disabled={loading} style={{ background: loading ? "#1a1a35" : "linear-gradient(135deg, #0ea5e9, #00d4b4)", border: "none", color: loading ? "#555" : "#fff", padding: "8px 20px", borderRadius: "8px", cursor: loading ? "not-allowed" : "pointer", fontSize: "13px", fontWeight: "700" }}>
              {loading ? "⏳ Generating..." : generated ? "↻ Regenerate" : "⟁ Generate Schemas"}
            </button>
          </div>
        </div>

        {generated && schemas.length > 0 && (
          <div style={{ padding: "10px 24px 0", display: "flex", gap: "4px", borderBottom: "1px solid #161632" }}>
            {["all", "database", "api"].map(f => (
              <button key={f} onClick={() => setFilter(f)} style={{ background: filter === f ? "#1a1a35" : "transparent", border: `1px solid ${filter === f ? "#333" : "transparent"}`, color: filter === f ? "#ccc" : "#555", padding: "6px 14px", borderRadius: "6px 6px 0 0", cursor: "pointer", fontSize: "11.5px", fontWeight: "600", textTransform: "capitalize" }}>
                {f === "all" ? `All (${schemas.length})` : f}
              </button>
            ))}
          </div>
        )}

        <div style={{ flex: 1, overflowY: "auto", padding: "16px 24px", scrollbarWidth: "thin", scrollbarColor: "#2a2a55 transparent" }}>
          {error && <div style={{ padding: "12px 16px", marginBottom: "16px", background: "#1a1010", border: "1px solid #2e1a1a", borderLeft: "3px solid #cc6666", borderRadius: "8px", fontSize: "12.5px", color: "#cc8888" }}>⚠ {error}</div>}

          {!generated && !loading && (
            <div style={{ textAlign: "center", padding: "48px 24px", color: "#444" }}>
              <div style={{ fontSize: "48px", marginBottom: "16px", opacity: 0.5 }}>⟁</div>
              <div style={{ fontSize: "15px", fontWeight: "600", color: "#666", marginBottom: "8px" }}>Ready to generate schemas</div>
              <div style={{ fontSize: "12px", color: "#444", marginBottom: "24px", lineHeight: "1.6" }}>
                {eligibleNodes.length > 0 ? `Found ${eligibleNodes.length} schema-eligible node${eligibleNodes.length > 1 ? "s" : ""}: ${eligibleNodes.map(n => n.name).join(", ")}` : "Add Database or API components to your architecture first"}
              </div>
              {eligibleNodes.length > 0 && <button onClick={handleGenerate} style={{ background: "linear-gradient(135deg, #0ea5e9, #00d4b4)", border: "none", color: "#fff", padding: "12px 28px", borderRadius: "10px", cursor: "pointer", fontSize: "14px", fontWeight: "700" }}>⟁ Generate Schemas Now</button>}
            </div>
          )}

          {loading && (
            <div style={{ textAlign: "center", padding: "48px", color: "#555" }}>
              <div style={{ fontSize: "32px", marginBottom: "16px" }}>⏳</div>
              <div style={{ fontSize: "14px" }}>Generating schemas from graph...</div>
              <div style={{ fontSize: "11px", color: "#444", marginTop: "6px" }}>Deterministic generation — no AI involved</div>
            </div>
          )}

          {!loading && generated && filtered.length > 0 && (
            <div>
              <div style={{ fontSize: "11px", color: "#555", marginBottom: "14px" }}>{filtered.length} schema{filtered.length > 1 ? "s" : ""} generated — click to expand</div>
              {filtered.map((schema, i) => <NodeSchemaCard key={schema.nodeId || i} schema={schema} />)}
            </div>
          )}

          {!loading && generated && filtered.length === 0 && schemas.length > 0 && (
            <div style={{ textAlign: "center", padding: "32px", color: "#444", fontSize: "13px" }}>No {filter} schemas in this graph.</div>
          )}
        </div>

        <div style={{ padding: "12px 24px", borderTop: "1px solid #161632", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ fontSize: "11px", color: "#333", fontFamily: "monospace" }}>CodeGPO Nexus — Schema & Contract Generation</div>
          <div style={{ fontSize: "11px", color: "#333" }}>All schemas derived from graph definition only</div>
        </div>
      </div>
    </div>
  );
}
