import { useState } from "react";

const STORAGE_KEY = "codegpo_disclaimer_accepted";

export function checkDisclaimer() {
  try {
    return localStorage.getItem(STORAGE_KEY) === "accepted";
  } catch { return false; }
}

export default function AlphaDisclaimer({ onAccept }) {
  const [checked, setChecked] = useState(false);

  const handleAccept = () => {
    if (!checked) return;
    localStorage.setItem(STORAGE_KEY, "accepted");
    onAccept();
  };

  return (
    <div style={{
      width: "100vw",
      minHeight: "100vh",
      background: "radial-gradient(circle at 30% 20%, #050b14, #000)",
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "center",
      position: "relative",
      overflowY: "auto",
      overflowX: "hidden",
      padding: "40px 20px"
    }}>
      {/* Background grid */}
      <div style={{
        position: "fixed", inset: 0,
        backgroundImage: `
          linear-gradient(rgba(0,240,255,0.03) 1px, transparent 1px),
          linear-gradient(90deg, rgba(0,240,255,0.03) 1px, transparent 1px)
        `,
        backgroundSize: "40px 40px",
        pointerEvents: "none",
        zIndex: 0
      }} />

      <div style={{
        background: "rgba(11,15,26,0.95)",
        border: "1px solid rgba(245,158,11,0.3)",
        borderRadius: "20px",
        padding: "40px 36px",
        width: "100%",
        maxWidth: "480px",
        position: "relative",
        zIndex: 1,
        boxShadow: "0 0 60px rgba(245,158,11,0.05)",
        margin: "auto"
      }}>
        {/* Warning icon */}
        <div style={{ textAlign: "center", marginBottom: "24px" }}>
          <div style={{
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            width: "64px", height: "64px",
            background: "rgba(245,158,11,0.1)",
            border: "1px solid rgba(245,158,11,0.3)",
            borderRadius: "16px",
            fontSize: "28px"
          }}>⚠️</div>
        </div>

        <div style={{ textAlign: "center", marginBottom: "28px" }}>
          <div style={{
            display: "inline-block",
            background: "rgba(245,158,11,0.1)",
            border: "1px solid rgba(245,158,11,0.3)",
            color: "#f59e0b",
            fontSize: "10px",
            padding: "4px 14px",
            borderRadius: "20px",
            letterSpacing: "2px",
            marginBottom: "16px"
          }}>
            PRIVATE ALPHA
          </div>
          <h2 style={{
            color: "#e2e8f0",
            fontSize: "20px",
            fontWeight: "700",
            margin: "0 0 12px 0"
          }}>
            Alpha Disclaimer
          </h2>
          <p style={{ color: "#64748b", fontSize: "13px", lineHeight: "1.7", margin: 0 }}>
            Welcome to CodeGPO Private Alpha. Please read and acknowledge the following before continuing.
          </p>
        </div>

        {/* Disclaimer items */}
        <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "28px" }}>
          {[
            { icon: "🧪", title: "For feedback & validation only", desc: "This is an early alpha release. Features may be incomplete, unstable, or change without notice." },
            { icon: "🚫", title: "Not for production use", desc: "Do not use CodeGPO Alpha to govern real production systems. Use for testing and evaluation only." },
            { icon: "🔒", title: "Keep it confidential", desc: "This is a private alpha. Please do not share access, screenshots, or details publicly." },
            { icon: "💬", title: "Your feedback matters", desc: "Report bugs and share feedback directly with the CodeGPO team. You're shaping the product." },
          ].map((item, i) => (
            <div key={i} style={{
              display: "flex",
              gap: "14px",
              padding: "14px",
              background: "rgba(2,6,23,0.6)",
              border: "1px solid #1e293b",
              borderRadius: "10px",
              alignItems: "flex-start"
            }}>
              <div style={{ fontSize: "18px", minWidth: "24px" }}>{item.icon}</div>
              <div>
                <div style={{ fontSize: "12px", fontWeight: "600", color: "#e2e8f0", marginBottom: "3px" }}>
                  {item.title}
                </div>
                <div style={{ fontSize: "11px", color: "#64748b", lineHeight: "1.5" }}>
                  {item.desc}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Checkbox */}
        <div
          onClick={() => setChecked(!checked)}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "12px",
            padding: "14px",
            background: checked ? "rgba(0,240,255,0.05)" : "rgba(2,6,23,0.6)",
            border: `1px solid ${checked ? "rgba(0,240,255,0.3)" : "#1e293b"}`,
            borderRadius: "10px",
            cursor: "pointer",
            marginBottom: "16px",
            transition: "all 0.2s"
          }}
        >
          <div style={{
            width: "20px", height: "20px",
            border: `2px solid ${checked ? "#00f0ff" : "#334155"}`,
            borderRadius: "5px",
            background: checked ? "#00f0ff" : "transparent",
            display: "flex", alignItems: "center", justifyContent: "center",
            transition: "all 0.2s",
            flexShrink: 0
          }}>
            {checked && <span style={{ color: "#000", fontSize: "13px", fontWeight: "900" }}>✓</span>}
          </div>
          <span style={{ fontSize: "12px", color: checked ? "#e2e8f0" : "#64748b", lineHeight: "1.5" }}>
            I understand this is a private alpha for feedback only and not for production use.
          </span>
        </div>

        <button
          onClick={handleAccept}
          disabled={!checked}
          style={{
            width: "100%",
            padding: "14px",
            background: checked ? "linear-gradient(135deg, #00f0ff, #7c3aed)" : "#1e293b",
            border: "none",
            borderRadius: "10px",
            color: checked ? "#000" : "#334155",
            fontSize: "14px",
            fontWeight: "700",
            cursor: checked ? "pointer" : "not-allowed",
            transition: "all 0.2s",
            letterSpacing: "0.5px"
          }}
        >
          Continue to CodeGPO →
        </button>
      </div>
    </div>
  );
}
