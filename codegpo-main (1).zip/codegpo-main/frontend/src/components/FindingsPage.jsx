import { useState, useEffect } from "react";
import NavRail from "./NavRail";
import { approveViolation, evaluateGovernance } from "../api/graphApi";

const SEV_COLOR = { CRITICAL: "#EF4444", HIGH: "#F97316", MEDIUM: "#F59E0B", LOW: "#22C55E" };

const ACC_STATUS_CFG = {
  unresolved: { label: "Open", color: "#EF4444", bg: "#EF444422" },
  approved:   { label: "In Review", color: "#22C55E", bg: "#22C55E22" },
  overridden: { label: "Overridden", color: "#F59E0B", bg: "#F59E0B22" },
};

export default function FindingsPage({ nodes, edges, violations, onNavigate, onDownloadReport, onOpenSettings, onConnectGitHub }) {
  const [severityFilter, setSeverityFilter] = useState("ALL");
  const [selected, setSelected] = useState(null);
  const [localViolations, setLocalViolations] = useState(violations);
  const [openApproval, setOpenApproval] = useState(false);
  const [approvalDecision, setApprovalDecision] = useState("approved");
  const [reasonDraft, setReasonDraft] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");

  const isGitHubConnected = (() => {
    try {
      const cfg = JSON.parse(localStorage.getItem("codegpo_github_config") || "null");
      return !!(cfg?.token && cfg?.owner && cfg?.repo);
    } catch { return false; }
  })();

  useEffect(() => { setLocalViolations(violations); }, [violations]);

  useEffect(() => {
    if (!selected && filtered.length > 0) {
      setSelected(filtered[0]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [severityFilter, localViolations]);

  const violationKey = (v) => `${v.ruleId}|${v.source || ""}|${v.target || ""}`;

  const refreshViolations = async () => {
    try {
      const fresh = await evaluateGovernance(nodes, edges);
      if (Array.isArray(fresh)) {
        setLocalViolations(fresh);
        if (selected) {
          const key = violationKey(selected);
          const match = fresh.find(v => violationKey(v) === key);
          if (match) setSelected(match);
        }
      }
    } catch {
      // keep showing existing data if refresh fails
    }
  };

  const submitDecision = async () => {
    if (!selected) return;
    if (!reasonDraft.trim() || reasonDraft.trim().length < 3) {
      setSubmitError("Reason must be at least 3 characters — this becomes a permanent audit record.");
      return;
    }
    setSubmitting(true);
    setSubmitError("");
    try {
      await approveViolation({
        rule_id: selected.ruleId,
        source: selected.source,
        target: selected.target,
        decision: approvalDecision,
        reason: reasonDraft.trim(),
      });
      setOpenApproval(false);
      setReasonDraft("");
      await refreshViolations();
    } catch (e) {
      setSubmitError(e.message || "Failed to record decision");
    } finally {
      setSubmitting(false);
    }
  };

  const critical = localViolations.filter(v => v.severity === "CRITICAL").length;
  const high     = localViolations.filter(v => v.severity === "HIGH").length;
  const medium   = localViolations.filter(v => v.severity === "MEDIUM").length;
  const low      = localViolations.filter(v => v.severity === "LOW").length;

  const filterCounts = { ALL: localViolations.length, CRITICAL: critical, HIGH: high, MEDIUM: medium, LOW: low };
  const filtered = severityFilter === "ALL" ? localViolations : localViolations.filter(v => v.severity === severityFilter);

  const selectedAcc = selected ? (selected.accountability?.status || "unresolved") : null;
  const selectedAccCfg = selectedAcc ? (ACC_STATUS_CFG[selectedAcc] || ACC_STATUS_CFG.unresolved) : null;

  return (
    <div style={{ position: "fixed", inset: 0, background: "#08080f", zIndex: 1500, display: "flex" }}>
      <NavRail active="findings" onNavigate={onNavigate} onOpenSettings={onOpenSettings} />

      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {/* Top bar */}
        <div style={{
          padding: "16px 28px", borderBottom: "1px solid #1a1a35", display: "flex",
          justifyContent: "space-between", alignItems: "center", background: "#0d0d1f",
        }}>
          <div>
            <div style={{ fontSize: "17px", fontWeight: "800", color: "#fff" }}>Compliance Findings</div>
            <div style={{ fontSize: "11px", color: "#5f5f85", marginTop: "2px" }}>
              {nodes.length} components · {edges.length} connections · {violations.length} findings
            </div>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
            {isGitHubConnected ? (
              <div style={{
                display: "flex", alignItems: "center", gap: "6px", padding: "5px 12px",
                background: "#12122a", border: "1px solid #1a1a35", borderRadius: "8px",
                fontSize: "11px", color: "#9494b8", fontWeight: "600",
              }}>
                <span style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#22C55E", display: "inline-block" }} />
                GitHub Connected
              </div>
            ) : (
              <button
                onClick={onConnectGitHub}
                style={{
                  display: "flex", alignItems: "center", gap: "6px", padding: "5px 12px",
                  background: "#12122a", border: "1px solid #22224a", borderRadius: "8px",
                  fontSize: "11px", color: "#a78bfa", fontWeight: "600", cursor: "pointer",
                }}
              >
                <span style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#5f5f85", display: "inline-block" }} />
                Connect GitHub
              </button>
            )}
            <button
              onClick={onDownloadReport}
              style={{
                padding: "9px 18px", background: "#7c3aed", border: "none", borderRadius: "9px",
                color: "#fff", fontSize: "12.5px", fontWeight: "700", cursor: "pointer",
              }}
            >
              📄 Download Audit Report
            </button>
          </div>
        </div>

        {/* Body: table on top, Finding Details + Audit Report below it, side by side */}
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 24px" }}>
          {/* Filter pills */}
          <div style={{ display: "flex", gap: "8px", marginBottom: "16px", flexWrap: "wrap" }}>
            {["ALL", "CRITICAL", "HIGH", "MEDIUM", "LOW"].map(sev => {
              const isActive = severityFilter === sev;
              const color = sev === "ALL" ? "#A78BFA" : SEV_COLOR[sev];
              return (
                <button
                  key={sev}
                  onClick={() => setSeverityFilter(sev)}
                  style={{
                    padding: "7px 16px", borderRadius: "20px", fontSize: "11.5px", fontWeight: "700",
                    cursor: "pointer",
                    background: isActive ? `${color}22` : "#0d0d1f",
                    border: `1px solid ${isActive ? color : "#1a1a35"}`,
                    color: isActive ? color : "#5f5f85",
                  }}
                >
                  {sev === "ALL" ? "All" : sev.charAt(0) + sev.slice(1).toLowerCase()} {filterCounts[sev]}
                </button>
              );
            })}
          </div>

          {/* Table */}
          <div style={{ background: "#0d0d1f", border: "1px solid #1a1a35", borderRadius: "12px", overflow: "hidden" }}>
            <div style={{
              display: "flex", padding: "12px 18px", borderBottom: "1px solid #1a1a35",
              fontSize: "10px", color: "#5f5f85", textTransform: "uppercase", letterSpacing: "0.6px", fontWeight: "700",
            }}>
              <span style={{ flex: 2 }}>Rule</span>
              <span style={{ flex: 1 }}>Framework</span>
              <span style={{ flex: 1 }}>Severity</span>
              <span style={{ flex: 1, textAlign: "right" }}>Status</span>
            </div>

            {filtered.length === 0 ? (
              <div style={{ padding: "40px", textAlign: "center", color: "#22C55E", fontSize: "13px" }}>
                ✅ No findings match this filter
              </div>
            ) : (
              filtered.map((v, i) => {
                const accStatus = v.accountability?.status || "unresolved";
                const accCfg = ACC_STATUS_CFG[accStatus] || ACC_STATUS_CFG.unresolved;
                const isSelected = selected === v;
                return (
                  <div
                    key={i}
                    onClick={() => { setSelected(v); setOpenApproval(false); setReasonDraft(""); setSubmitError(""); }}
                    style={{
                      display: "flex", alignItems: "center", padding: "14px 18px", cursor: "pointer",
                      borderBottom: i < filtered.length - 1 ? "1px solid #12122a" : "none",
                      background: isSelected ? "#12122a" : "transparent",
                    }}
                  >
                    <span style={{ flex: 2, fontSize: "12.5px", color: "#e8e8f5", fontWeight: "600" }}>
                      {v.ruleId} <span style={{ color: "#5f5f85", fontWeight: "400" }}>— {v.message}</span>
                    </span>
                    <span style={{ flex: 1, fontSize: "12px", color: "#9494b8" }}>{v.framework || "—"}</span>
                    <span style={{ flex: 1 }}>
                      <span style={{
                        fontSize: "10px", fontWeight: "700", padding: "3px 9px", borderRadius: "5px",
                        background: `${SEV_COLOR[v.severity] || "#64748B"}22`, color: SEV_COLOR[v.severity] || "#64748B",
                      }}>
                        {v.severity}
                      </span>
                    </span>
                    <span style={{ flex: 1, textAlign: "right" }}>
                      <span style={{
                        fontSize: "10px", fontWeight: "700", padding: "3px 9px", borderRadius: "5px",
                        background: accCfg.bg, color: accCfg.color,
                      }}>
                        {accCfg.label}
                      </span>
                    </span>
                  </div>
                );
              })
            )}
          </div>

          {/* Finding Details + Audit Report — both always visible, side by side, below the table */}
          <div style={{ display: "flex", gap: "16px", marginTop: "20px", alignItems: "flex-start" }}>
            {/* Finding Details */}
            <div style={{ flex: 1, minWidth: 0, border: "1px solid #1a1a35", background: "#0d0d1f", borderRadius: "12px", padding: "20px" }}>
              {!selected ? (
                <div style={{ textAlign: "center", color: "#5f5f85", fontSize: "12.5px", padding: "20px 0" }}>
                  Select a finding above to see details
                </div>
              ) : (
                <>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "14px" }}>
                <div style={{ fontSize: "13px", fontWeight: "700", color: "#e8e8f5" }}>Finding Details</div>
                <button onClick={() => { setSelected(null); setOpenApproval(false); }} style={{ background: "transparent", border: "none", color: "#5f5f85", cursor: "pointer", fontSize: "16px" }}>×</button>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "10px" }}>
                <span style={{
                  fontSize: "10px", fontWeight: "700", padding: "3px 9px", borderRadius: "5px",
                  background: `${SEV_COLOR[selected.severity] || "#64748B"}22`, color: SEV_COLOR[selected.severity] || "#64748B",
                }}>
                  {selected.severity}
                </span>
                <span style={{ fontSize: "12px", color: "#9494b8" }}>{selected.ruleId}</span>
              </div>

              <div style={{ fontSize: "13px", color: "#e8e8f5", fontWeight: "600", marginBottom: "8px" }}>
                {selected.message}
              </div>
              {selected.description && (
                <div style={{ fontSize: "12px", color: "#9494b8", lineHeight: "1.6", marginBottom: "14px" }}>
                  {selected.description}
                </div>
              )}

              {(selected.source || selected.target) && (
                <div style={{
                  padding: "10px 12px", background: "#08080f", border: "1px solid #1a1a35",
                  borderRadius: "8px", marginBottom: "14px", fontFamily: "monospace", fontSize: "11px", lineHeight: "1.8",
                }}>
                  <div><span style={{ color: "#5f5f85" }}>"source"</span>: <span style={{ color: "#F59E0B" }}>"{selected.sourceName || selected.source}"</span></div>
                  <div><span style={{ color: "#5f5f85" }}>"target"</span>: <span style={{ color: "#F59E0B" }}>"{selected.targetName || selected.target}"</span></div>
                  <div><span style={{ color: "#5f5f85" }}>"rule"</span>: <span style={{ color: "#06b6d4" }}>"{selected.ruleId}"</span></div>
                </div>
              )}

              {selected.fix && (
                <div style={{ padding: "10px 12px", background: "#111a13", border: "1px solid #1e2e22", borderRadius: "8px", marginBottom: "14px" }}>
                  <div style={{ fontSize: "9.5px", color: "#4a7c59", textTransform: "uppercase", fontWeight: "700", marginBottom: "4px" }}>Recommended Fix</div>
                  <div style={{ fontSize: "12px", color: "#aaa", lineHeight: "1.5" }}>{selected.fix}</div>
                </div>
              )}

              <div style={{ borderTop: "1px solid #1a1a35", paddingTop: "12px", marginTop: "6px" }}>
                <span style={{
                  fontSize: "10px", fontWeight: "700", padding: "4px 10px", borderRadius: "5px",
                  background: selectedAccCfg.bg, color: selectedAccCfg.color,
                }}>
                  {selectedAccCfg.label}
                </span>
                {selected.accountability?.approvedBy && (
                  <div style={{ fontSize: "11px", color: "#9494b8", marginTop: "8px", lineHeight: "1.6" }}>
                    By <strong style={{ color: "#cbd5e1" }}>{selected.accountability.approvedBy}</strong>
                    {selected.accountability.timestamp ? ` on ${new Date(selected.accountability.timestamp).toLocaleDateString()}` : ""}
                    {selected.accountability.reason ? <div style={{ marginTop: "4px", fontStyle: "italic" }}>"{selected.accountability.reason}"</div> : null}
                  </div>
                )}

                {!openApproval && (
                  <div style={{ display: "flex", gap: "8px", marginTop: "12px", flexWrap: "wrap" }}>
                    {selectedAcc === "unresolved" ? (
                      <>
                        <button
                          onClick={() => { setOpenApproval(true); setApprovalDecision("approved"); setSubmitError(""); }}
                          style={{ fontSize: "11.5px", padding: "6px 14px", borderRadius: "6px", border: "1px solid #2e4a35", background: "#111a13", color: "#5a9e6f", cursor: "pointer", fontWeight: "600" }}
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => { setOpenApproval(true); setApprovalDecision("overridden"); setSubmitError(""); }}
                          style={{ fontSize: "11.5px", padding: "6px 14px", borderRadius: "6px", border: "1px solid #4a3d1f", background: "#2a2210", color: "#d4a44c", cursor: "pointer", fontWeight: "600" }}
                        >
                          Override
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => { setOpenApproval(true); setApprovalDecision(selectedAcc === "approved" ? "overridden" : "approved"); setSubmitError(""); }}
                        style={{ fontSize: "11px", padding: "5px 12px", borderRadius: "6px", border: "1px solid #22224a", background: "transparent", color: "#9494b8", cursor: "pointer" }}
                      >
                        Revise decision
                      </button>
                    )}
                    <button
                      onClick={() => { setOpenApproval(true); setApprovalDecision("commented"); setSubmitError(""); }}
                      style={{ fontSize: "11px", padding: "5px 12px", borderRadius: "6px", border: "1px solid #22224a", background: "transparent", color: "#9494b8", cursor: "pointer" }}
                    >
                      💬 Add Comment
                    </button>
                  </div>
                )}

                {openApproval && (
                  <div style={{ marginTop: "12px" }}>
                    <div style={{ fontSize: "10px", color: "#5f5f85", letterSpacing: "0.6px", textTransform: "uppercase", marginBottom: "6px", fontWeight: "700" }}>
                      {approvalDecision === "commented"
                        ? "Comment (visible in audit history, does not change status)"
                        : `Reason for ${approvalDecision === "approved" ? "approval" : "override"} (required — permanent record)`}
                    </div>
                    <textarea
                      value={reasonDraft}
                      onChange={(e) => setReasonDraft(e.target.value)}
                      placeholder={approvalDecision === "commented" ? "e.g. Flagging for follow-up with the platform team next sprint" : "e.g. Reviewed with security team, tracked in JIRA-4521"}
                      rows={3}
                      style={{
                        width: "100%", boxSizing: "border-box", fontSize: "12px", padding: "8px",
                        borderRadius: "6px", border: "1px solid #22224a", background: "#08080f",
                        color: "#e8e8f5", resize: "vertical", fontFamily: "inherit",
                      }}
                    />
                    {submitError && <div style={{ fontSize: "11px", color: "#EF4444", marginTop: "5px" }}>{submitError}</div>}
                    <div style={{ display: "flex", gap: "8px", marginTop: "8px" }}>
                      <button
                        disabled={submitting}
                        onClick={submitDecision}
                        style={{
                          fontSize: "12px", padding: "7px 16px", borderRadius: "6px", border: "none",
                          background: approvalDecision === "approved" ? "#22C55E" : approvalDecision === "overridden" ? "#F59E0B" : "#7c3aed",
                          color: approvalDecision === "commented" ? "#fff" : "#08080f", fontWeight: "700", cursor: submitting ? "default" : "pointer",
                          opacity: submitting ? 0.6 : 1,
                        }}
                      >
                        {submitting ? "Recording…" : approvalDecision === "commented" ? "Post Comment" : `Confirm ${approvalDecision === "approved" ? "Approval" : "Override"}`}
                      </button>
                      <button
                        disabled={submitting}
                        onClick={() => { setOpenApproval(false); setReasonDraft(""); setSubmitError(""); }}
                        style={{ fontSize: "12px", padding: "7px 16px", borderRadius: "6px", border: "1px solid #22224a", background: "transparent", color: "#9494b8", cursor: "pointer" }}
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
                </div>
                </>
              )}
            </div>

            {/* Audit Report — always visible, independent of selection */}
            <div style={{ width: "300px", flexShrink: 0, border: "1px solid #1a1a35", background: "#0d0d1f", borderRadius: "12px", padding: "20px" }}>
              <div style={{ fontSize: "13px", fontWeight: "700", color: "#e8e8f5", marginBottom: "14px" }}>Audit Report</div>
              <div style={{
                display: "flex", alignItems: "center", gap: "10px", padding: "12px",
                background: "#12122a", border: "1px solid #1a1a35", borderRadius: "10px", marginBottom: "16px",
              }}>
                <span style={{ fontSize: "20px" }}>📄</span>
                <div>
                  <div style={{ fontSize: "12px", fontWeight: "700", color: "#e8e8f5" }}>Compliance_Report.pdf</div>
                  <div style={{ fontSize: "10px", color: "#5f5f85", marginTop: "2px" }}>Audit-ready · Full history</div>
                </div>
              </div>
              <button
                onClick={onDownloadReport}
                style={{
                  width: "100%", padding: "10px", background: "#7c3aed", border: "none", borderRadius: "9px",
                  color: "#fff", fontSize: "12.5px", fontWeight: "700", cursor: "pointer", marginBottom: "18px",
                }}
              >
                Download PDF
              </button>
              {[
                "Executive summary",
                "Detailed findings",
                "Approval history",
                "Framework mapping",
                "Evidence and recommendations",
              ].map((item, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: "8px", padding: "7px 0", fontSize: "12px", color: "#9494b8" }}>
                  <span style={{ color: "#22C55E", fontSize: "13px" }}>✓</span>
                  {item}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
