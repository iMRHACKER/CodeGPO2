import { useEffect, useRef } from "react";
import { useGraphStore } from "../state/graphStore";
import { useProjectStore } from "../state/projectStore";

const BRIDGE_URL = "http://localhost:27420";
const POLL_INTERVAL = 3000;

export function useVSCodeBridge() {
  const intervalRef = useRef(null);
  const lastTimestampRef = useRef(null);
  const lastWorkspaceRef = useRef(null);

  useEffect(() => {
    let active = true;

    async function poll() {
      try {
        // Check if bridge is alive
        const pingRes = await fetch(`${BRIDGE_URL}/ping`, {
          signal: AbortSignal.timeout(1000)
        });
        if (!pingRes.ok) return;
        const ping = await pingRes.json();
        if (!ping.lastScan) return;

        // Skip if already loaded this exact scan
        if (ping.lastScan === lastTimestampRef.current) return;

        // Fetch scan data
        const scanRes = await fetch(`${BRIDGE_URL}/scan`, {
          signal: AbortSignal.timeout(2000)
        });
        if (!scanRes.ok) return;
        const scan = await scanRes.json();
        if (!scan || !active) return;
        if (!scan.nodes?.length) return;

        lastTimestampRef.current = scan.timestamp;

        const projectName = `VS Code: ${scan.workspace}`;

        // Get fresh state each poll
        const projectStore = useProjectStore.getState();
        const graphStore = useGraphStore.getState();

        // Find or create project
        let projectId = null;
        const existing = projectStore.projects.find(p => p.name === projectName);

        if (existing) {
          projectId = existing.id;
        } else {
          // createProject returns the new id
          projectId = projectStore.createProject(
            projectName,
            `Auto-imported from VS Code — ${scan.workspace}`
          );
        }

        if (!projectId) return;

        // Save scan data directly into that project's storage
        projectStore.saveGraphForProject(projectId, scan.nodes, scan.edges);

        // If this workspace is already active, also update the live graph
        const currentProject = projectStore.getActiveProject?.();
        if (currentProject?.name === projectName || lastWorkspaceRef.current === scan.workspace) {
          graphStore.setGraph(scan.nodes, scan.edges);
        }

        lastWorkspaceRef.current = scan.workspace;

        console.log(`CodeGPO VS Code Bridge: loaded ${scan.nodes.length} components, ${scan.violations?.length || 0} violations`);

      } catch {
        // Bridge not running — silent fail
      }
    }

    poll();
    intervalRef.current = setInterval(poll, POLL_INTERVAL);

    return () => {
      active = false;
      clearInterval(intervalRef.current);
    };
  }, []);
}