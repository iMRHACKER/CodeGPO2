import { useState, useEffect } from "react";
import { apiFetch } from "./api/graphApi";
import GraphCanvas, { exportCanvasPNG, focusNode } from "./canvas/GraphCanvas";
import Inspector from "./inspector/Inspector";
import UploadPanel from "./toolbar/UploadPanel";
import ProjectDashboard from "./components/ProjectDashboard";
import RulesPanel from "./components/RulesPanel";
import AuditLog from "./components/AuditLog";
import UserGuide from "./components/UserGuide";
import ArchitectureExplainer from "./components/ArchitectureExplainer";
import NodeDetailPanel from "./components/NodeDetailPanel";
import ArchitectureScore from "./components/ArchitectureScore";
import TemplateGallery from "./components/TemplateGallery";
import NodeSearch from "./components/NodeSearch";
import ArchitectureDiff from "./components/ArchitectureDiff";
import ShareModal from "./components/ShareModal";
import AlertSettings from "./components/AlertSettings";
import CollabPanel, { CollabAvatars, CollabCursors } from "./components/CollabPanel";
import AddComponentModal from "./components/AddComponentModal";
import CanvasEmptyState from "./components/CanvasEmptyState";
import FindingsPage from "./components/FindingsPage";
import NavRail from "./components/NavRail";
import EdgeModeOverlay from "./components/EdgeModeOverlay";
import AutoPRPanel from "./components/AutoPRPanel";
import ImpactPanel from "./components/ImpactPanel";
import GitHubSettings from "./components/GitHubSettings";
import SchemaPanel from "./components/SchemaPanel";
import LoginPage from "./pages/LoginPage";
import UpgradeModal from "./components/UpgradeModal";
import { downloadCICDTemplate, exportArchitectureJSON } from "./components/CICDExport";
import { evaluateCustomPolicies, getCustomPolicies } from "./components/CustomPolicyEngine";
import CustomPolicyModal from "./components/CustomPolicyModal";
import { filterAcknowledgedViolations, getAcknowledgedCount } from "./components/FalsePositiveManager";
import { loadDemoSeed } from "./data/demoSeed";

const API_BASE = import.meta.env.VITE_API_URL || "https://codegpo-production-9548.up.railway.app";

import { useGraphStore } from "./state/graphStore";
import { useProjectStore } from "./state/projectStore";
import { useRulesStore } from "./state/rulesStore";
import { useAuditStore, ACTION_TYPES } from "./state/auditStore";
import { useAlertStore } from "./state/alertStore";
import { useCollabStore } from "./state/collabStore";
import UserSettings from "./components/UserSettings";
import { calculateScore } from "./core/architectureScore";
import "./styles/theme.css";

// ── Auth helpers ──────────────────────────────────────────────────────────────
function getToken() {
  try { return localStorage.getItem("codegpo_token"); } catch { return null; }
}
function getUser() {
  try {
    const raw = localStorage.getItem("codegpo_user");
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}
function isLoggedIn() {
  return !!getToken();
}

export default function App() {
  const [view, setView] = useState("dashboard");
  const [showRules, setShowRules] = useState(false);
  const [showAudit, setShowAudit] = useState(false);
  const [showGuide, setShowGuide] = useState(false);
  const [showExplainer, setShowExplainer] = useState(false);
  const [showScore, setShowScore] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showDiff, setShowDiff] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [showAlerts, setShowAlerts] = useState(false);
  const [showCollab, setShowCollab] = useState(false);
  const [showAddComponent, setShowAddComponent] = useState(false);
  const [showAutoPR, setShowAutoPR] = useState(false);
  const [showImpact, setShowImpact] = useState(false);
  const [showGitHub, setShowGitHub] = useState(false);
  const [showSchema, setShowSchema] = useState(false);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [showCustomPolicy, setShowCustomPolicy] = useState(false);
  const [showUserSettings, setShowUserSettings] = useState(false);
  const [upgradeReason, setUpgradeReason] = useState("nodes");

  const {
    addNode, saveToNeo4j, loadFromNeo4j, setGraph,
    edgeMode, cancelEdge, deleteSelected,
    selectedNode, selectedEdge,
    nodes, edges, violations
  } = useGraphStore();

  const { activeProjectId, saveActiveGraph, getActiveProject } = useProjectStore();
  const { rules, evaluateCustomRules } = useRulesStore();
  const { record, log } = useAuditStore();
  const { checkAndAlert, config: alertConfig } = useAlertStore();
  const { connected, sendNodeAdd, sendCursor, sendFullSync } = useCollabStore();

  // Ping activity every 5 minutes to track DAU/WAU/MAU
  useEffect(() => {
    const API = import.meta.env.VITE_API_URL || "https://codegpo-production-9548.up.railway.app";
    const ping = () => {
      const token = localStorage.getItem("codegpo_token");
      if (!token) return;
      fetch(`${API}/api/auth/me/ping`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` }
      }).catch(() => {});
    };
    ping(); // ping on load
    const interval = setInterval(ping, 5 * 60 * 1000); // every 5 min
    return () => clearInterval(interval);
  }, []);

  // Expose graph state globally for collab sync requests
  useEffect(() => {
    window.__codegpo_getGraph = () => ({ nodes, edges });
  }, [nodes, edges]);

  // When collab connects, push current graph to room immediately
  useEffect(() => {
    if (connected && nodes.length > 0) {
      setTimeout(() => {
        sendFullSync(nodes, edges);
      }, 800);
    }
  }, [connected]);

  // Also push whenever nodes change while connected (for new joiners)
  useEffect(() => {
    if (connected && nodes.length > 0) {
      sendFullSync(nodes, edges);
    }
  }, [nodes.length]);

  const customViolations = evaluateCustomRules(nodes, edges);
  const allViolations = [...violations, ...customViolations];
  const activeProject = getActiveProject();
  const scoreResult = nodes.length > 0
    ? calculateScore(nodes, edges, allViolations)
    : null;

  // ── Refresh plan from DB on load (correct hook placement) ────────────────
  useEffect(() => {
    const token = localStorage.getItem("codegpo_token");
    const API = import.meta.env.VITE_API_URL || "https://codegpo-production-9548.up.railway.app";
    if (!token) return;
    fetch(`${API}/api/auth/me`, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.ok ? r.json() : null)
      .then(user => {
        if (!user?.email) return;
        const stored = JSON.parse(localStorage.getItem("codegpo_user") || "{}");
        if (stored.plan !== user.plan) {
          localStorage.setItem("codegpo_user", JSON.stringify({ ...stored, ...user }));
          window.location.reload();
        }
      })
      .catch(() => {});
  }, []);

  // ── If not logged in — show LoginPage ─────────────────────────────────────
  if (!isLoggedIn()) {
    return <LoginPage />;
  }

  const currentUser = getUser();
  // ── Plan limits ──────────────────────────────────────────────
  const userPlan = currentUser?.plan || "free";
  const isAdmin = currentUser?.email === "harshsahu0120@gmail.com" ||
                  currentUser?.email === "harsh@codegpo.com" ||
                  ["enterprise", "custom"].includes(userPlan);

  // 3-day free trial from registration date
  const registeredAt = currentUser?.created_at ? new Date(currentUser.created_at) : new Date();
  const trialDaysLeft = Math.max(0, 3 - Math.floor((Date.now() - registeredAt.getTime()) / (1000 * 60 * 60 * 24)));
  const isInTrial = trialDaysLeft > 0;

  const isPaid = isAdmin || isInTrial || ["developer", "team", "pro", "enterprise", "custom"].includes(userPlan);
  const FREE_NODE_LIMIT = 10;
  const FREE_EDGE_LIMIT = 5;

  const checkLimit = (type) => {
    if (isPaid) return true;
    if (type === "node" && nodes.length >= FREE_NODE_LIMIT) {
      setUpgradeReason("nodes"); setShowUpgrade(true); return false;
    }
    if (type === "edge" && edges.length >= FREE_EDGE_LIMIT) {
      setUpgradeReason("edges"); setShowUpgrade(true); return false;
    }
    return true;
  };

  const handleLogout = () => {
    if (window.confirm("Are you sure you want to logout?")) {
      try {
        localStorage.removeItem("codegpo_token");
        localStorage.removeItem("codegpo_user");
        localStorage.removeItem("codegpo_alpha_access");
        localStorage.removeItem("codegpo_disclaimer_accepted");
      } catch {}
      window.location.reload();
    }
  };

  // ── Effects ─────────────────────────────────────────────────────────────────
  useEffect(() => {
    if (view !== "editor") return;
    if (!alertConfig.slackEnabled && !alertConfig.emailEnabled) return;
    if (allViolations.length === 0) return;
    checkAndAlert(allViolations, activeProject?.name);
  }, [allViolations.length, view]);

  useEffect(() => {
    if (view !== "editor") return;
    const handler = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "f") {
        e.preventDefault();
        setShowSearch(true);
      }
      if (e.key === "Escape" && edgeMode) cancelEdge();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [view, edgeMode]);

  useEffect(() => {
    if (!connected || view !== "editor") return;
    const handler = (e) => sendCursor(e.clientX, e.clientY);
    window.addEventListener("mousemove", handler);
    return () => window.removeEventListener("mousemove", handler);
  }, [connected, view]);

  // ── Handlers ─────────────────────────────────────────────────────────────────
  const handleOpenProject = () => setView("findings");

  const handleBackToDashboard = () => {
    if (activeProjectId) saveActiveGraph(nodes, edges);
    setView("dashboard");
  };

  const handleSave = async () => {
    if (activeProjectId) saveActiveGraph(nodes, edges);
    record(ACTION_TYPES.GRAPH_SAVED, `${nodes.length} nodes, ${edges.length} edges`, activeProject?.name);
    await saveToNeo4j();

    // If GitHub is connected, keep codegpo.json in the repo in sync automatically —
    // no manual export/upload needed for the CI/CD governance gate to see the latest architecture.
    try {
      const ghConfig = JSON.parse(localStorage.getItem("codegpo_github_config") || "null");
      if (ghConfig?.token && ghConfig?.owner && ghConfig?.repo) {
        const res = await apiFetch(`/architecture/sync`, {
          method: "POST",
          body: JSON.stringify({
            nodes, edges,
            githubToken: ghConfig.token,
            githubOwner: ghConfig.owner,
            githubRepo: ghConfig.repo,
          }),
        });
        const data = res && res.ok ? await res.json() : null;
        if (data?.status === "ok") {
          console.log("codegpo.json synced to GitHub");
        }
        // Silently skip on failure — this is a convenience sync, not critical path.
      }
    } catch {
      // GitHub not configured or sync failed — save itself already succeeded, so don't disrupt the user.
    }
  };

  const handleAddComponent = (type, name) => {
    if (!checkLimit("node")) return;
    const node = addNode(type, name);
    record(ACTION_TYPES.NODE_ADDED, `${name} (${type})`, activeProject?.name);
    if (connected && node) sendNodeAdd(node);
  };

  const handleDelete = () => {
    if (selectedNode) record(ACTION_TYPES.NODE_DELETED, selectedNode.name, activeProject?.name);
    if (selectedEdge) record(ACTION_TYPES.EDGE_DELETED, `${selectedEdge.source} → ${selectedEdge.target}`, activeProject?.name);
    deleteSelected();
  };

  const [showReportPreview, setShowReportPreview] = useState(false);

  const handleDownloadReport = async () => {
    if (nodes.length === 0) { alert("Add components first."); return; }
    // Free users see preview, not download
    if (!isPaid && !isAdmin) { setShowReportPreview(true); return; }
    const projectName = activeProject?.name || "My Architecture";
    try {
      // The PDF is generated entirely server-side from the org's real,
      // authenticated Neo4j graph + live governance + accountability data.
      // We only tell it which project name to print — nothing else is
      // client-supplied, so the report can't be spoofed by editing local state.
      const res = await apiFetch("/api/report/download", {
        method: "POST",
        body: JSON.stringify({ project_name: projectName }),
      });
      if (!res || !res.ok) throw new Error(`Server error: ${res?.status}`);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `CodeGPO_Report_${projectName.replace(/\s+/g, "_")}_${new Date().toISOString().split("T")[0]}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      record(ACTION_TYPES.GRAPH_SAVED, "Compliance report downloaded", activeProject?.name);
    } catch (err) {
      console.error("Report download failed:", err);
      alert("Report generation failed. Please try again.");
    }
  };

  const handleLoadDemo = () => {
    loadDemoSeed(setGraph);
    record(ACTION_TYPES.GRAPH_SAVED, "Demo seed loaded", activeProject?.name);
  };

  const handleExportPNG = () => {
    if (nodes.length === 0) { alert("Add components first."); return; }
    exportCanvasPNG(activeProject?.name || "architecture");
    record(ACTION_TYPES.GRAPH_SAVED, "Architecture exported as PNG", activeProject?.name);
  };

  const enabledCustomRules = rules.filter(r => r.enabled).length;
  const showNodeDetail = selectedNode && !showExplainer;
  const alertsActive = alertConfig.slackEnabled || alertConfig.emailEnabled;
  const edgeSourceNode = edgeMode && useGraphStore.getState().edgeSourceId
    ? nodes.find(n => n.id === useGraphStore.getState().edgeSourceId)
    : null;

  // ── Dashboard view ──────────────────────────────────────────────────────────
  if (view === "dashboard") {
    return <ProjectDashboard onOpen={handleOpenProject} />;
  }

  // ── Findings view (full-page compliance findings table) ─────────────────────
  if (view === "findings") {
    return (
      <>
        <FindingsPage
          nodes={nodes}
          edges={edges}
          violations={allViolations}
          onNavigate={(id) => setView(id === "editor" ? "editor" : id === "dashboard" ? "dashboard" : "findings")}
          onDownloadReport={handleDownloadReport}
          onOpenSettings={() => setShowUserSettings(true)}
          onConnectGitHub={() => setShowGitHub(true)}
        />
        {showUserSettings && (
          <UserSettings
            user={currentUser}
            onClose={() => setShowUserSettings(false)}
            onLogout={() => { localStorage.clear(); window.location.reload(); }}
          />
        )}
        {showGitHub && <GitHubSettings onClose={() => setShowGitHub(false)} />}
      </>
    );
  }

  // ── Editor view ─────────────────────────────────────────────────────────────

  // ── Report Preview Modal ─────────────────────────────────────
  const ReportPreviewModal = () => {
    const score = scoreResult?.score ?? 0;
    const critical = allViolations.filter(v => v.severity?.toUpperCase() === "CRITICAL").length;
    const high = allViolations.filter(v => v.severity?.toUpperCase() === "HIGH").length;
    const grade = score >= 90 ? "A" : score >= 75 ? "B" : score >= 60 ? "C" : score >= 40 ? "D" : "F";
    const gradeColor = grade==="A"?"#22C55E":grade==="B"?"#10B981":grade==="C"?"#F59E0B":"#EF4444";

    return (
      <div onClick={e => e.target===e.currentTarget && setShowReportPreview(false)}
        style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.85)", zIndex:3000, display:"flex", alignItems:"center", justifyContent:"center", padding:20 }}>
        <div style={{ background:"#0D0D1F", border:"1px solid #1E1E35", borderRadius:16, width:600, maxHeight:"88vh", overflow:"hidden", display:"flex", flexDirection:"column" }}>

          {/* Header */}
          <div style={{ padding:"18px 22px 14px", borderBottom:"1px solid #1A1A35", display:"flex", justifyContent:"space-between", alignItems:"center", flexShrink:0 }}>
            <div>
              <div style={{ fontSize:15, fontWeight:700, color:"#fff" }}>⚡ Compliance Report Preview</div>
              <div style={{ fontSize:11, color:"#475569", marginTop:2 }}>{activeProject?.name || "My Architecture"} · {new Date().toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"})}</div>
            </div>
            <button onClick={() => setShowReportPreview(false)} style={{ background:"none", border:"none", color:"#475569", fontSize:20, cursor:"pointer" }}>✕</button>
          </div>

          {/* Scrollable content */}
          <div style={{ overflowY:"auto", flex:1, padding:"18px 22px" }}>

            {/* Stats row */}
            <div style={{ display:"flex", gap:10, marginBottom:18 }}>
              {[
                { label:"Health Score", val:`${score}/100`, color:"#7C3AED" },
                { label:"Grade",        val:grade,          color:gradeColor },
                { label:"Critical",     val:critical,       color:"#EF4444" },
                { label:"High",         val:high,           color:"#F97316" },
              ].map((st,i) => (
                <div key={i} style={{ flex:1, background:"#12122A", border:"1px solid #1E1E3A", borderRadius:10, padding:"10px 6px", textAlign:"center" }}>
                  <div style={{ fontSize:22, fontWeight:800, color:st.color }}>{st.val}</div>
                  <div style={{ fontSize:10, color:"#475569", marginTop:2 }}>{st.label}</div>
                </div>
              ))}
            </div>

            {/* First 3 violations */}
            <div style={{ fontSize:11, fontWeight:600, color:"#475569", textTransform:"uppercase", letterSpacing:1, marginBottom:10 }}>
              Violations ({allViolations.length} total)
            </div>
            {allViolations.slice(0,3).map((v,i) => (
              <div key={i} style={{ background:"#12122A", border:"1px solid #1E1E3A", borderRadius:8, padding:"10px 14px", marginBottom:8, display:"flex", gap:10, alignItems:"flex-start" }}>
                <span style={{ fontSize:9, fontWeight:700, padding:"2px 8px", borderRadius:4, flexShrink:0, marginTop:1,
                  background:v.severity==="CRITICAL"?"rgba(239,68,68,0.12)":"rgba(249,115,22,0.12)",
                  color:v.severity==="CRITICAL"?"#EF4444":"#F97316" }}>
                  {v.severity||"HIGH"}
                </span>
                <div>
                  <div style={{ fontSize:12, fontWeight:600, color:"#CBD5E1" }}>{(v.message||"Violation detected").slice(0,75)}</div>
                  <div style={{ fontSize:11, color:"#475569", marginTop:2 }}>{(v.fix||"Review architecture").slice(0,65)}...</div>
                </div>
              </div>
            ))}

            {/* Locked rest */}
            {allViolations.length > 3 && (
              <div style={{ position:"relative", marginBottom:16 }}>
                <div style={{ filter:"blur(4px)", pointerEvents:"none", opacity:0.4 }}>
                  {[1,2,3].map(i => (
                    <div key={i} style={{ background:"#12122A", border:"1px solid #1E1E3A", borderRadius:8, padding:"10px 14px", marginBottom:8 }}>
                      <div style={{ height:12, background:"#1E1E3A", borderRadius:4, width:"70%", marginBottom:6 }} />
                      <div style={{ height:10, background:"#1E1E3A", borderRadius:4, width:"45%" }} />
                    </div>
                  ))}
                </div>
                <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center", background:"rgba(7,7,18,0.75)", borderRadius:8 }}>
                  <div style={{ textAlign:"center" }}>
                    <div style={{ fontSize:22, marginBottom:4 }}>🔒</div>
                    <div style={{ fontSize:13, fontWeight:600, color:"#fff" }}>+{allViolations.length-3} more violations</div>
                    <div style={{ fontSize:11, color:"#A78BFA", marginTop:2 }}>Upgrade to see full report</div>
                  </div>
                </div>
              </div>
            )}

            {/* Blurred checklist */}
            <div style={{ position:"relative" }}>
              <div style={{ filter:"blur(5px)", pointerEvents:"none", opacity:0.35 }}>
                <div style={{ fontSize:11, fontWeight:600, color:"#475569", textTransform:"uppercase", letterSpacing:1, marginBottom:10 }}>Compliance Checklist</div>
                {["Authentication enforced on all services","Database access via API layer only","Data encryption in transit","PII data properly scoped (DPDP)","Payment data bounded (PCI-DSS)"].map((item,i)=>(
                  <div key={i} style={{ display:"flex", gap:8, alignItems:"center", padding:"7px 0", borderBottom:"1px solid #1A1A35" }}>
                    <span style={{ color:i%3===0?"#EF4444":i%3===1?"#F59E0B":"#22C55E", fontSize:13 }}>{i%3===0?"✗":i%3===1?"⚠":"✓"}</span>
                    <span style={{ fontSize:11.5, color:"#CBD5E1" }}>{item}</span>
                  </div>
                ))}
              </div>
              <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center", background:"rgba(7,7,18,0.8)", borderRadius:8 }}>
                <div style={{ textAlign:"center" }}>
                  <div style={{ fontSize:20, marginBottom:4 }}>🔒</div>
                  <div style={{ fontSize:12, fontWeight:600, color:"#fff" }}>Full compliance checklist in Pro</div>
                </div>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div style={{ padding:"14px 22px", borderTop:"1px solid #1A1A35", background:"#0A0A1A", display:"flex", gap:12, alignItems:"center", flexShrink:0 }}>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:13, fontWeight:600, color:"#fff" }}>Download the full PDF report</div>
              <div style={{ fontSize:11, color:"#475569" }}>All violations · checklist · regulatory refs · ₹999/month</div>
            </div>
            <button onClick={() => { setShowReportPreview(false); setUpgradeReason("pdf"); setShowUpgrade(true); }}
              style={{ background:"#7C3AED", border:"none", borderRadius:10, padding:"10px 20px", color:"#fff", fontSize:13, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap" }}>
              Upgrade to Pro →
            </button>
          </div>
        </div>
      </div>
    );
  };


  return (
    <div className="app-layout">
      <NavRail
        active="editor"
        onNavigate={(id) => setView(id === "findings" ? "findings" : id === "dashboard" ? "dashboard" : "editor")}
        onOpenSettings={() => setShowUserSettings(true)}
      />

      {/* ── Modals ── */}
      {showUserSettings && <UserSettings user={currentUser} onClose={() => setShowUserSettings(false)} onLogout={() => { localStorage.clear(); window.location.reload(); }} />}
      {showCustomPolicy && <CustomPolicyModal onClose={() => setShowCustomPolicy(false)} onPoliciesChange={() => {}} />
      }
      {showReportPreview && <ReportPreviewModal />}
      {showUpgrade && <UpgradeModal reason={upgradeReason} onClose={() => setShowUpgrade(false)} />}
      {showAddComponent && <AddComponentModal onAdd={handleAddComponent} onClose={() => setShowAddComponent(false)} />}
      {showAutoPR && <AutoPRPanel onClose={() => setShowAutoPR(false)} onOpenGitHubSettings={() => { setShowAutoPR(false); setShowGitHub(true); }} />}
      {showImpact && <ImpactPanel onClose={() => setShowImpact(false)} />}
      {showGitHub && <GitHubSettings onClose={() => setShowGitHub(false)} />}
      {showSchema && <SchemaPanel onClose={() => setShowSchema(false)} />}
      {showRules && <RulesPanel onClose={() => setShowRules(false)} />}
      {showAudit && <AuditLog onClose={() => setShowAudit(false)} />}
      {showGuide && <UserGuide onClose={() => setShowGuide(false)} />}
      {showScore && <ArchitectureScore onClose={() => setShowScore(false)} />}
      {showTemplates && <TemplateGallery onClose={() => setShowTemplates(false)} />}
      {showDiff && <ArchitectureDiff onClose={() => setShowDiff(false)} />}
      {showShare && <ShareModal onClose={() => setShowShare(false)} allViolations={allViolations} />}
      {showAlerts && <AlertSettings onClose={() => setShowAlerts(false)} />}
      {showCollab && <CollabPanel onClose={() => setShowCollab(false)} />}
      {showSearch && <NodeSearch onClose={() => setShowSearch(false)} onFocus={(id) => focusNode(id)} />}
      {connected && <CollabCursors />}

      {/* ── Toolbar ── */}
      <div className="toolbar">
        <div className="toolbar-logo">⚡ CodeGPO</div>
        <hr />
        <button onClick={handleBackToDashboard}>← All Projects</button>
        <button onClick={() => setShowGuide(true)}>? User Guide</button>

        {activeProject && (
          <div style={{
            margin: "6px 10px 2px", padding: "10px 12px",
            background: "linear-gradient(135deg, rgba(124,58,237,0.12), rgba(14,165,233,0.08))",
            border: "1px solid rgba(124,58,237,0.25)", borderRadius: "8px",
            borderLeft: "3px solid #7c3aed",
          }}>
            <div style={{ fontSize: "9px", color: "#7c3aed", fontWeight: "700", letterSpacing: "1px", textTransform: "uppercase", marginBottom: "4px" }}>
              Current Project
            </div>
            <div style={{ fontSize: "12px", color: "#e5e5e5", fontWeight: "600", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
              {activeProject.name}
            </div>
          </div>
        )}

        {/* ── Architecture ── */}
        <hr />
        <div className="toolbar-section">Architecture</div>
        <button onClick={() => setShowAddComponent(true)}>+ Add Component</button>
        <button onClick={() => setShowTemplates(true)}>⊞ Templates</button>
        <button onClick={() => setShowSearch(true)}>
          ⌕ Search
          <span style={{ marginLeft: "auto", fontSize: "10px", color: "#555", background: "#1a1a1a", border: "1px solid #252525", padding: "1px 5px", borderRadius: "3px", fontFamily: "monospace" }}>
            Ctrl+F
          </span>
        </button>
        <button onClick={() => setShowDiff(true)}>⊕ Diff / Snapshots</button>
        <button onClick={handleLoadDemo} style={{ background: "linear-gradient(135deg, rgba(124,58,237,0.15), rgba(6,182,212,0.1))", border: "1px solid rgba(124,58,237,0.3)", color: "#a78bfa" }}>
          ▶ Load Demo Architecture
        </button>

        {/* ── Import ── */}
        <hr />
        <div className="toolbar-section">Import</div>
        <UploadPanel />

        {/* ── Advanced (collapsed by default — reduces first-time overwhelm) ── */}
        <hr />
        <button
          onClick={() => setShowAdvanced(v => !v)}
          style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            width: "100%", background: "transparent", border: "1px solid #252525",
            color: "#999", fontSize: "12px", fontWeight: "600", padding: "8px 10px",
            borderRadius: "6px", cursor: "pointer",
          }}
        >
          <span>{showAdvanced ? "▾" : "▸"} Advanced (Schema, PR, CI/CD)</span>
        </button>

        {showAdvanced && (
          <>
        {/* ── Schema Generation ── */}
        <hr />
        <div className="toolbar-section">Schema Generation</div>
        <button onClick={() => {
          if (!isPaid) { setUpgradeReason("schema"); setShowUpgrade(true); return; }
          setShowSchema(true);
        }}>◈ Generate Schemas {!isPaid && "🔒"}</button>

        {/* ── Auto Pull Request ── */}
        <hr />
        <div className="toolbar-section">Auto Pull Request</div>
        <button onClick={() => {
          if (!isPaid) { setUpgradeReason("github"); setShowUpgrade(true); return; }
          const criticalCount = allViolations.filter(v => v.severity === "CRITICAL").length;
          const highCount = allViolations.filter(v => v.severity === "HIGH").length;
          if (criticalCount > 0) {
            alert(`🚫 PR Blocked — ${criticalCount} CRITICAL violation${criticalCount > 1 ? "s" : ""} must be fixed before pushing to GitHub.\n\nCodeGPO enforces: Architecture as Law.`);
            return;
          }
          if (highCount > 0) {
            const proceed = window.confirm(`⚠️ ${highCount} HIGH severity violation${highCount > 1 ? "s" : ""} detected.\n\nAre you sure you want to create a PR with unresolved issues?`);
            if (!proceed) return;
          }
          setShowAutoPR(true);
        }}>
          {(() => {
            const crit = allViolations.filter(v => v.severity === "CRITICAL").length;
            const high = allViolations.filter(v => v.severity === "HIGH").length;
            if (!isPaid) return "⤴ Create PR 🔒";
            if (crit > 0) return `🚫 PR Blocked (${crit} Critical)`;
            if (high > 0) return `⚠️ Create PR (${high} High)`;
            return "⤴ Create Pull Request ✅";
          })()}
        </button>
        {isPaid && <button onClick={() => setShowGitHub(true)} style={{ fontSize: "11px", color: "#888" }}>⚙ GitHub Settings</button>}

        {/* ── Export & CI/CD ── */}
        <hr />
        <div className="toolbar-section">Export & CI/CD</div>
        <button onClick={() => exportArchitectureJSON(nodes, edges, "my-project")} title="Export architecture as JSON for CI/CD">
          ⬇ Export codegpo.json
        </button>
        <button onClick={() => {
          if (!isPaid) { setUpgradeReason("cicd"); setShowUpgrade(true); return; }
          downloadCICDTemplate("github");
        }} title="Download GitHub Actions workflow">
          ⚙ GitHub Actions {!isPaid && "🔒"}
        </button>
        <button onClick={() => {
          if (!isPaid) { setUpgradeReason("cicd"); setShowUpgrade(true); return; }
          downloadCICDTemplate("gitlab");
        }} title="Download GitLab CI config">
          ⚙ GitLab CI {!isPaid && "🔒"}
        </button>
          </>
        )}

        {/* ── Governance ── */}
        <hr />
        <div className="toolbar-section">Governance</div>
        <button onClick={() => setView("findings")} style={{ background: "linear-gradient(135deg, rgba(124,58,237,0.15), rgba(6,182,212,0.1))", border: "1px solid rgba(124,58,237,0.3)", color: "#a78bfa" }}>
          ◉ View All Findings {allViolations.length > 0 ? `(${allViolations.length})` : ""}
        </button>
        <button onClick={() => setShowRules(true)}>
          Rules {enabledCustomRules > 0 ? `(+${enabledCustomRules})` : ""}
        </button>
        <button onClick={() => setShowCustomPolicy(true)} style={{ fontSize:"11px",color:"#888" }}>
          + Custom Rules {getCustomPolicies?.()?.filter(p=>p.enabled!==false)?.length > 0 ? `(${getCustomPolicies().filter(p=>p.enabled!==false).length} active)` : ""}
        </button>
        {allViolations.length > 0 && (
          <div style={{ padding: "7px 10px", background: "#1a1010", border: "1px solid #2a1515", borderRadius: "6px", fontSize: "11px", color: "#cc6666", marginTop: "2px" }}>
            {allViolations.length} violation{allViolations.length > 1 ? "s" : ""} detected
          </div>
        )}
        {allViolations.length === 0 && nodes.length > 0 && (
          <div style={{ padding: "7px 10px", background: "#0f1a12", border: "1px solid #1a2e1e", borderRadius: "6px", fontSize: "11px", color: "#5a9e6f", marginTop: "2px" }}>
            ✓ All compliant
          </div>
        )}

        {/* ── Architecture Stats ── */}
        <div style={{ padding:"6px 10px", display:"flex", gap:"12px", borderBottom:"1px solid #1a1a1a" }}>
          <div style={{ textAlign:"center", flex:1 }}>
            <div style={{ fontSize:"16px", fontWeight:"800", color:"#7c3aed" }}>{nodes.length}</div>
            <div style={{ fontSize:"9px", color:"#555", textTransform:"uppercase", letterSpacing:"0.8px" }}>Components</div>
          </div>
          <div style={{ width:"1px", background:"#1a1a1a" }} />
          <div style={{ textAlign:"center", flex:1 }}>
            <div style={{ fontSize:"16px", fontWeight:"800", color:"#06b6d4" }}>{edges.length}</div>
            <div style={{ fontSize:"9px", color:"#555", textTransform:"uppercase", letterSpacing:"0.8px" }}>Connections</div>
          </div>
          <div style={{ width:"1px", background:"#1a1a1a" }} />
          <div style={{ textAlign:"center", flex:1 }}>
            <div style={{ fontSize:"16px", fontWeight:"800", color: violations.length > 0 ? "#ef4444" : "#22c55e" }}>{violations.length}</div>
            <div style={{ fontSize:"9px", color:"#555", textTransform:"uppercase", letterSpacing:"0.8px" }}>Violations</div>
          </div>
        </div>

        {/* ── Health Score ── */}
        <hr />
        <div className="toolbar-section">Health Score</div>
        {scoreResult ? (
          <button onClick={() => setShowScore(true)} style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            padding: "10px 12px", background: "#12122a", border: "1px solid #1a1a35",
            borderRadius: "8px", width: "100%", cursor: "pointer"
          }}
            onMouseEnter={e => e.currentTarget.style.borderColor = "#2a2a2a"}
            onMouseLeave={e => e.currentTarget.style.borderColor = "#1e1e1e"}
          >
            <div style={{ textAlign: "left" }}>
              <div style={{ fontSize: "22px", fontWeight: "800", color: scoreResult.gradeColor, lineHeight: 1 }}>
                {scoreResult.score}<span style={{ fontSize: "12px", color: "#666", fontWeight: "400" }}>/100</span>
              </div>
              <div style={{ fontSize: "11px", color: "#777", marginTop: "3px" }}>Grade {scoreResult.grade} · {scoreResult.status}</div>
            </div>
            <div style={{ fontSize: "24px", fontWeight: "800", color: scoreResult.gradeColor, opacity: 0.3 }}>{scoreResult.grade}</div>
          </button>
        ) : (
          <div style={{ fontSize: "11px", color: "#666", padding: "4px 10px" }}>Add components to see score</div>
        )}

        {/* ── Trial / Free Plan ── */}
        {!isAdmin && (
          <>
            <hr />
            <div style={{ padding: "8px 10px" }}>
              {isInTrial ? (
                <>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                    <span style={{ fontSize: "10px", color: "#22c55e", textTransform: "uppercase", letterSpacing: "0.8px", fontWeight: "700" }}>Free Trial</span>
                    <span style={{ fontSize: "10px", color: "#22c55e", fontWeight: "600" }}>{trialDaysLeft} day{trialDaysLeft !== 1 ? "s" : ""} left</span>
                  </div>
                  <div style={{ background: "#1a1a1a", borderRadius: "4px", height: "4px", overflow: "hidden" }}>
                    <div style={{ background: "#22c55e", height: "100%", width: `${(trialDaysLeft/3)*100}%`, transition: "width 0.3s" }} />
                  </div>
                  <div style={{ fontSize: "10px", color: "#555", marginTop: "6px" }}>Full access during trial</div>
                  <button onClick={() => { setUpgradeReason("nodes"); setShowUpgrade(true); }}
                    style={{ width: "100%", marginTop: "6px", padding: "6px", background: "linear-gradient(135deg,rgba(124,58,237,0.15),rgba(14,165,233,0.08))", border: "1px solid rgba(124,58,237,0.3)", borderRadius: "6px", color: "#a78bfa", fontSize: "11px", fontWeight: "600", cursor: "pointer" }}>
                    ⚡ Upgrade to Pro
                  </button>
                </>
              ) : (
                <>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                    <span style={{ fontSize: "10px", color: "#555", textTransform: "uppercase", letterSpacing: "0.8px" }}>Free Plan</span>
                    <span style={{ fontSize: "10px", color: "#555" }}>{nodes.length}/{FREE_NODE_LIMIT} nodes</span>
                  </div>
                  <div style={{ background: "#1a1a1a", borderRadius: "4px", height: "4px", overflow: "hidden" }}>
                    <div style={{ background: nodes.length >= FREE_NODE_LIMIT ? "#ef4444" : "#7c3aed", height: "100%", width: `${Math.min(100, (nodes.length/FREE_NODE_LIMIT)*100)}%`, transition: "width 0.3s" }} />
                  </div>
                  <div style={{ fontSize: "10px", color: "#ef4444", marginTop: "4px" }}>Trial expired</div>
                  <button onClick={() => { setUpgradeReason("nodes"); setShowUpgrade(true); }}
                    style={{ width: "100%", marginTop: "6px", padding: "6px", background: "linear-gradient(135deg,rgba(239,68,68,0.15),rgba(124,58,237,0.1))", border: "1px solid rgba(239,68,68,0.3)", borderRadius: "6px", color: "#fca5a5", fontSize: "11px", fontWeight: "600", cursor: "pointer" }}>
                    ⚡ Upgrade to Pro
                  </button>
                </>
              )}
            </div>
          </>
        )}

        {/* ── AI Analysis ── */}
        <hr />
        <div className="toolbar-section">AI Analysis</div>
        <button
          onClick={() => {
            if (!isPaid) { setUpgradeReason("ai"); setShowUpgrade(true); return; }
            setShowExplainer(!showExplainer);
          }}
          onMouseEnter={e => {
            e.currentTarget.style.background = "linear-gradient(135deg, rgba(124,58,237,0.25), rgba(14,165,233,0.15))";
            e.currentTarget.style.borderColor = "#7c3aed";
            e.currentTarget.style.color = "#a78bfa";
            e.currentTarget.style.boxShadow = "0 0 12px rgba(124,58,237,0.35)";
          }}
          onMouseLeave={e => {
            e.currentTarget.style.background = showExplainer ? "linear-gradient(135deg, rgba(124,58,237,0.2), rgba(14,165,233,0.1))" : "transparent";
            e.currentTarget.style.borderColor = showExplainer ? "#7c3aed" : "#2a2a2a";
            e.currentTarget.style.color = showExplainer ? "#a78bfa" : "#bbb";
            e.currentTarget.style.boxShadow = showExplainer ? "0 0 10px rgba(124,58,237,0.25)" : "none";
          }}
          style={{
            background: showExplainer ? "linear-gradient(135deg, rgba(124,58,237,0.2), rgba(14,165,233,0.1))" : "transparent",
            color: showExplainer ? "#a78bfa" : "#bbb",
            border: `1px solid ${showExplainer ? "#7c3aed" : "#2a2a2a"}`,
            borderRadius: "6px",
            boxShadow: showExplainer ? "0 0 10px rgba(124,58,237,0.25)" : "none",
            transition: "all 0.2s ease"
          }}
        >
          {showExplainer ? "× Close Explainer" : "✦ Explain Architecture"}
        </button>

        {/* ── Collaborate ── */}
        <hr />
        <div className="toolbar-section">Collaborate</div>
        <button onClick={() => {
          const isEnterprise = ["enterprise", "custom"].includes(userPlan) || isAdmin;
          if (!isEnterprise) { setUpgradeReason("collab"); setShowUpgrade(true); return; }
          setShowCollab(true);
        }} style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span>⟳ Live Collab {!["enterprise","custom"].includes(userPlan) && !isAdmin && "🔒"}</span>
          {connected && <span style={{ fontSize: "9px", color: "#5a9e6f", background: "#0f1a12", border: "1px solid #1a2e1e", padding: "1px 6px", borderRadius: "10px", fontWeight: "700" }}>LIVE</span>}
        </button>
        {connected && <div style={{ padding: "4px 0" }}><CollabAvatars /></div>}

        {/* ── Export ── */}
        <hr />
        <div className="toolbar-section">Export</div>
        <button onClick={() => setShowShare(true)}>⤴ Share Link</button>
        <button onClick={handleDownloadReport}>↓ Compliance PDF</button>
        <button onClick={handleExportPNG}>↓ Export PNG</button>

        {/* ── Alerts ── */}
        <hr />
        <div className="toolbar-section">Alerts</div>
        <button onClick={() => setShowAlerts(true)} style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span>🔔 Alert Settings</span>
          {alertsActive && <span style={{ fontSize: "9px", color: "#5a9e6f", background: "#0f1a12", border: "1px solid #1a2e1e", padding: "1px 6px", borderRadius: "10px", fontWeight: "700" }}>ON</span>}
        </button>

        {/* ── Storage ── */}
        <hr />
        <div className="toolbar-section">Storage</div>
        <button onClick={handleSave}>↑ Save to Neo4j</button>
        <button onClick={loadFromNeo4j}>↓ Load from Neo4j</button>

        {/* ── History ── */}
        <hr />
        <div className="toolbar-section">History</div>
        <button onClick={() => setShowAudit(true)}>
          Audit Log {log.length > 0 ? `(${log.length})` : ""}
        </button>

        {(selectedNode || selectedEdge) && (
          <>
            <hr />
            <button onClick={() => setShowImpact(true)} style={{ color: "#f59e0b" }}>⚡ Change Impact</button>
            <button onClick={handleDelete} style={{ color: "#854444" }}>Delete Selected</button>
          </>
        )}

        <div style={{ flex: 1 }} />

        {/* ── Account ── */}
        <hr />
        <div className="toolbar-section">Account</div>
        {currentUser && (
          <div>
            <div style={{
              margin: "2px 10px 6px", padding: "8px 10px",
              background: "#0D0D1F", border: "1px solid #1A1A35",
              borderRadius: "6px",
            }}>
              <div style={{ fontSize: "11px", color: "#7C3AED", fontWeight: "700", marginBottom: "2px", textTransform: "capitalize" }}>
                {currentUser.plan || "free"} plan
              </div>
              <div style={{ fontSize: "11px", color: "#475569", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                {currentUser.email}
              </div>
            </div>
            <button onClick={() => setShowUserSettings(true)} style={{ width: "100%", marginTop: "2px", padding: "7px", background: "#0D0D1F", border: "1px solid #1A1A35", borderRadius: "8px", color: "#A78BFA", fontSize: "11px", cursor: "pointer", textAlign: "center" }}>
              ⚙ Account Settings
            </button>
          </div>
        )}
        <button onClick={handleLogout} style={{ color: "#854444", fontSize: "12px" }}>⎋ Logout</button>

        <div className="toolbar-hint">
          Click node → click another to connect.<br />
          Click arrow to inspect.<br />
          Ctrl+F to search.
        </div>
      </div>

      {/* ── Canvas ── */}
      <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>
        {nodes.length === 0 && (
          <CanvasEmptyState
            onAddComponent={() => setShowAddComponent(true)}
            onLoadTemplate={() => setShowTemplates(true)}
          />
        )}
        {edgeMode && <EdgeModeOverlay sourceNode={edgeSourceNode} onCancel={cancelEdge} />}
        <GraphCanvas customViolations={customViolations} />
      </div>

      {/* ── Right Panels ── */}
      {showExplainer && <ArchitectureExplainer onClose={() => setShowExplainer(false)} allViolations={allViolations} />}
      {showNodeDetail && <NodeDetailPanel onClose={() => useGraphStore.getState().selectNode(null)} />}
      {!showExplainer && !showNodeDetail && <Inspector allViolations={allViolations} />}
    </div>
  );
}
