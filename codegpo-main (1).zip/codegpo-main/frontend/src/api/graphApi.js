const API_BASE = import.meta.env.VITE_API_URL || "https://codegpo-production-9548.up.railway.app";

// ── Auth helper ───────────────────────────────────────────
function getToken() {
  try { return localStorage.getItem("codegpo_token"); } catch { return null; }
}

// ── Fetch wrapper — handles 401 (token expired → redirect to login) ──────────
async function apiFetch(url, options = {}) {
  const token = getToken();
  const headers = {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(options.headers || {}),
  };

  const res = await fetch(`${API_BASE}${url}`, { ...options, headers });

  // Token expired or invalid → clear storage and reload to login
  if (res.status === 401) {
    try {
      localStorage.removeItem("codegpo_token");
      localStorage.removeItem("codegpo_user");
    } catch {}
    window.location.reload();
    return null;
  }

  return res;
}

// ── Graph API ─────────────────────────────────────────────
export async function saveGraph(nodes, edges) {
  const res = await apiFetch("/graph/save", {
    method: "POST",
    body: JSON.stringify({ nodes, edges }),
  });
  if (!res) return null;
  return res.ok ? res.json() : null;
}

export async function loadGraph() {
  const res = await apiFetch("/graph/load");
  if (!res || !res.ok) return { nodes: [], edges: [], violations: [] };
  return res.json();
}

export async function evaluateGovernance(nodes, edges) {
  const res = await apiFetch("/governance/evaluate", {
    method: "POST",
    body: JSON.stringify({ nodes, edges }),
  });
  if (!res || !res.ok) return [];
  return res.json();
}

// ── Accountability API ──────────────────────────────────────
// Record a named, timestamped, immutable approve/override decision on a violation.
export async function approveViolation({ rule_id, source, target, decision, reason }) {
  const res = await apiFetch("/accountability/approve", {
    method: "POST",
    body: JSON.stringify({ rule_id, source, target, decision, reason }),
  });
  if (!res) return null;
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || "Failed to record decision");
  }
  return res.json();
}

// Full audit trail for the current org, optionally filtered to one violation.
export async function getAccountabilityLog(violationId = null) {
  const qs = violationId ? `?violation_id=${encodeURIComponent(violationId)}` : "";
  const res = await apiFetch(`/accountability/log${qs}`);
  if (!res || !res.ok) return { count: 0, records: [] };
  return res.json();
}

export { apiFetch };
