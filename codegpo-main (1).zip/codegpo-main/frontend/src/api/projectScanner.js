import JSZip from "jszip";
import { apiFetch } from "./graphApi";

const BACKEND = import.meta.env.VITE_API_URL || "https://codegpo-production-9548.up.railway.app";

// ── Layout: nodes ko canvas center mein rakhta hai ─────────────────────────
const LAYOUT = {
  startX: 420,
  startY: 120,
  xSpacing: 220,
  ySpacing: 160,
  maxPerRow: 4,
};

function layoutNodes(nodes) {
  if (!nodes || nodes.length === 0) return nodes;
  const rowCount = Math.ceil(nodes.length / LAYOUT.maxPerRow);
  return nodes.map((node, index) => {
    const row = Math.floor(index / LAYOUT.maxPerRow);
    const col = index % LAYOUT.maxPerRow;
    const itemsInRow = row === rowCount - 1 ? nodes.length - row * LAYOUT.maxPerRow : LAYOUT.maxPerRow;
    const rowWidth = (itemsInRow - 1) * LAYOUT.xSpacing;
    const rowStartX = LAYOUT.startX - rowWidth / 2;
    return { ...node, position: { x: rowStartX + col * LAYOUT.xSpacing, y: LAYOUT.startY + row * LAYOUT.ySpacing } };
  });
}

// ── Detection keywords ──────────────────────────────────────────────────────
const DB_LIBS = ["mongoose","mongodb","pg","postgres","mysql","mysql2","sqlite","sqlite3","redis","ioredis","neo4j","dynamodb","cassandra","prisma","sequelize","typeorm","knex","pymongo","psycopg","sqlalchemy","peewee","tortoise","supabase","django.db","mongoengine","motor","aioredis","asyncpg"];
const QUEUE_LIBS = ["kafka","kafkajs","rabbitmq","amqplib","bull","bullmq","sqs","celery","rq","nats","pubsub","eventbus","django_celery","pika","confluent","kombu"];
const API_LIBS = ["express","fastapi","django","flask","koa","hapi","nestjs","fastify","rest_framework","djangorestframework","spring","laravel","rails","gin","echo","fiber","axum","actix"];
const EXTERNAL_LIBS = ["stripe","twilio","sendgrid","mailgun","paypal","firebase","aws-sdk","boto3","axios","requests","social-auth","djoser","oauth","braintree","plaid","algolia","cloudinary","pusher","intercom","hubspot","salesforce","zendesk","okta","auth0"];
const CACHE_LIBS = ["redis","ioredis","memcached","node-cache","django_redis","cache_framework","aioredis","pylibmc"];
const WORKER_LIBS = ["bull","bullmq","celery","rq","agenda","node-cron","apscheduler","django_celery_beat","sidekiq","delayed_job","faktory"];
const GATEWAY_LIBS = ["nginx","traefik","kong","envoy","haproxy","caddy","istio","linkerd"];

const match = (text, keywords) => keywords.some(k => text.toLowerCase().includes(k.toLowerCase()));

function detectTypeFromContent(name, content) {
  if (match(content, GATEWAY_LIBS)) return "Gateway";
  if (match(name + content, WORKER_LIBS)) return "Worker";
  if (match(content, QUEUE_LIBS)) return "Queue";
  if (match(content, CACHE_LIBS)) return "Cache";
  if (match(content, DB_LIBS)) return "Database";
  if (match(content, EXTERNAL_LIBS)) return "External";
  if (match(content, API_LIBS)) return "Service";
  return "Service";
}

function detectTypeFromName(name) {
  const n = name.toLowerCase();
  if (["user","ui","frontend","client","browser","web","app","mobile","react","vue","angular","next","nuxt"].some(k => n.includes(k))) return "User";
  if (["db","database","mongo","postgres","mysql","redis","neo4j","sqlite","storage","dynamo","cassandra","elastic","opensearch"].some(k => n.includes(k))) return "Database";
  if (["queue","kafka","rabbit","bull","sqs","broker","celery","nats","pubsub","event","message","stream"].some(k => n.includes(k))) return "Queue";
  if (["gateway","proxy","nginx","balancer","loadbalancer","ingress","router"].some(k => n.includes(k))) return "Gateway";
  if (["worker","job","cron","scheduler","beat","task","processor","consumer"].some(k => n.includes(k))) return "Worker";
  if (["cache","memcache","redis","cdn"].some(k => n.includes(k))) return "Cache";
  if (["stripe","twilio","sendgrid","payment","email","sms","auth0","okta","firebase","aws","gcp","azure","vendor","external","third"].some(k => n.includes(k))) return "External";
  if (["api","rest","graphql","endpoint","grpc"].some(k => n.includes(k))) return "API";
  return null;
}

function makeId(name) {
  return `svc-${name.replace(/[^a-zA-Z0-9]/g, "-").toLowerCase().substring(0, 40)}`;
}

function detectEdges(nodes, nodeContentMap) {
  const edges = [];
  const seen = new Set();

  const addEdge = (src, tgt) => {
    if (src === tgt) return;
    const key = `${src}→${tgt}`;
    if (seen.has(key)) return;
    seen.add(key);
    edges.push({ source: src, target: tgt });
  };

  // Pass 1: Content-based — source content mentions target name
  nodes.forEach(source => {
    nodes.forEach(target => {
      if (source.id === target.id) return;
      const cnt = (nodeContentMap[source.id] || "").toLowerCase();
      const tName = target.name.toLowerCase().replace(/[-_\s]/g, "");
      const cNorm = cnt.replace(/[-_\s]/g, "");
      if (tName.length > 2 && cNorm.includes(tName)) addEdge(source.id, target.id);
    });
  });

  // Pass 2: Type-based — standard architecture patterns
  // These fire when content-based misses (e.g. GitHub URL with sparse content)
  const byType = {};
  nodes.forEach(n => {
    const t = (n.type || "Service").toLowerCase();
    if (!byType[t]) byType[t] = [];
    byType[t].push(n);
  });

  const get = (t) => byType[t] || [];
  const users    = get("user");
  const gateways = get("gateway");
  const services = get("service");
  const apis     = get("api");
  const auths    = get("auth");
  const dbs      = get("database");
  const caches   = get("cache");
  const queues   = get("queue");
  const workers  = get("worker");
  const externals= get("external");
  const monitors = get("monitoring");
  const iot      = get("iot");

  // User → Gateway (or first service if no gateway)
  users.forEach(u => {
    if (gateways.length > 0) gateways.forEach(g => addEdge(u.id, g.id));
    else if (apis.length > 0) apis.forEach(a => addEdge(u.id, a.id));
    else if (services.length > 0) addEdge(u.id, services[0].id);
  });

  // Gateway → Auth
  gateways.forEach(g => {
    auths.forEach(a => addEdge(g.id, a.id));
    // Gateway → all services
    services.forEach(s => addEdge(g.id, s.id));
    apis.forEach(a => addEdge(g.id, a.id));
  });

  // If no gateway: User → Auth
  if (gateways.length === 0) {
    users.forEach(u => auths.forEach(a => addEdge(u.id, a.id)));
  }

  // Auth → first service or DB
  auths.forEach(a => {
    if (dbs.length > 0) addEdge(a.id, dbs[0].id);
    else if (services.length > 0) addEdge(a.id, services[0].id);
  });

  // Service → DB, Cache, Queue, External
  services.forEach(s => {
    dbs.forEach(d => addEdge(s.id, d.id));
    caches.forEach(c => addEdge(s.id, c.id));
    queues.forEach(q => addEdge(s.id, q.id));
    externals.forEach(e => addEdge(s.id, e.id));
  });

  // API → DB, Cache, Queue, External
  apis.forEach(a => {
    dbs.forEach(d => addEdge(a.id, d.id));
    caches.forEach(c => addEdge(a.id, c.id));
    queues.forEach(q => addEdge(a.id, q.id));
    externals.forEach(e => addEdge(a.id, e.id));
  });

  // Queue → Worker
  queues.forEach(q => workers.forEach(w => addEdge(q.id, w.id)));
  // Worker → DB
  workers.forEach(w => dbs.forEach(d => addEdge(w.id, d.id)));

  // IoT → Gateway or Service
  iot.forEach(i => {
    if (gateways.length > 0) gateways.forEach(g => addEdge(i.id, g.id));
    else if (services.length > 0) addEdge(i.id, services[0].id);
  });

  // Monitoring → all critical nodes
  monitors.forEach(m => {
    [...services, ...apis, ...dbs, ...gateways].forEach(n => addEdge(m.id, n.id));
  });

  // If still very few edges and multiple services: connect them in a chain
  const allServices = [...services, ...apis];
  if (edges.length < Math.max(1, nodes.length - 2) && allServices.length > 1) {
    for (let i = 0; i < allServices.length - 1; i++) {
      addEdge(allServices[i].id, allServices[i+1].id);
    }
  }

  return edges;
}

function capitalizeLib(lib) {
  const names = {
    "mongoose":"MongoDB","mongodb":"MongoDB","pg":"PostgreSQL","postgres":"PostgreSQL",
    "mysql":"MySQL","mysql2":"MySQL","sqlite":"SQLite","sqlite3":"SQLite","redis":"Redis",
    "ioredis":"Redis","neo4j":"Neo4j","dynamodb":"DynamoDB","prisma":"Prisma DB",
    "sequelize":"SQL DB","kafka":"Kafka","kafkajs":"Kafka","rabbitmq":"RabbitMQ",
    "amqplib":"RabbitMQ","bull":"Bull Queue","bullmq":"Bull Queue","sqs":"AWS SQS",
    "celery":"Celery","stripe":"Stripe","twilio":"Twilio","sendgrid":"SendGrid",
    "firebase":"Firebase","aws-sdk":"AWS","boto3":"AWS","memcached":"Memcached",
    "pymongo":"MongoDB","psycopg":"PostgreSQL","sqlalchemy":"SQL DB",
  };
  return names[lib.toLowerCase()] || lib;
}

// ── Generic Scanner ─────────────────────────────────────────────────────────
function scanGenericProject(fileMap) {
  const nodes = [];
  const nodeContentMap = {};
  const seen = new Set();

  const addNode = (id, name, type, content = "") => {
    if (seen.has(id)) return;
    seen.add(id);
    nodes.push({ id, name, type });
    nodeContentMap[id] = (nodeContentMap[id] || "") + " " + content;
  };

  const updateContent = (id, content) => {
    if (nodeContentMap[id] !== undefined) nodeContentMap[id] += " " + content;
  };

  const SERVICE_DIRS = ["services","apps","packages","microservices","modules","api","workers","backend","frontend","src"];

  const folderFiles = {};
  Object.keys(fileMap).forEach(path => {
    const parts = path.split("/");
    const cleanParts = parts.length > 1 && !parts[0].includes(".") ? parts.slice(1) : parts;
    if (cleanParts.length >= 2) {
      const folder = cleanParts[0];
      if (!folderFiles[folder]) folderFiles[folder] = [];
      folderFiles[folder].push({ path: cleanParts.join("/"), content: fileMap[path] });
    }
  });

  // Step 2: Detect top-level service folders
  Object.entries(folderFiles).forEach(([folder, files]) => {
    if (["node_modules",".git","__pycache__","dist","build",".next","coverage","test","tests","__tests__","docs","doc",".github",".vscode"].includes(folder)) return;
    const allContent = files.map(f => f.content).join(" ");
    const hasPackageJson = files.some(f => f.path.endsWith("package.json"));
    const hasRequirements = files.some(f => f.path.endsWith("requirements.txt"));
    const hasDockerfile = files.some(f => f.path.split("/").pop() === "Dockerfile");
    const hasMainPy = files.some(f => f.path.endsWith("main.py") || f.path.endsWith("app.py") || f.path.endsWith("server.py"));
    const hasIndexJs = files.some(f => f.path.endsWith("index.js") || f.path.endsWith("index.ts") || f.path.endsWith("server.js") || f.path.endsWith("server.ts"));
    if (hasPackageJson || hasRequirements || hasDockerfile || hasMainPy || hasIndexJs) {
      const type = detectTypeFromName(folder) || detectTypeFromContent(folder, allContent);
      const id = makeId(folder);
      addNode(id, folder, type, allContent);
    }
  });

  // Step 3: Scan all important files
  Object.entries(fileMap).forEach(([rawPath, content]) => {
    const parts = rawPath.split("/");
    const cleanParts = parts.length > 1 && !parts[0].includes(".") ? parts.slice(1) : parts;
    const path = cleanParts.join("/");
    const filename = cleanParts[cleanParts.length - 1];
    const parentFolder = cleanParts.length >= 2 ? cleanParts[cleanParts.length - 2] : "";

    // package.json
    if (filename === "package.json") {
      try {
        const pkg = JSON.parse(content);
        const name = pkg.name || parentFolder || "app";
        const deps = { ...pkg.dependencies, ...pkg.devDependencies };
        const depStr = Object.keys(deps).join(" ");
        const type = detectTypeFromName(name) || detectTypeFromContent(name, depStr);
        const id = makeId(name);
        if (!seen.has(id)) addNode(id, name, type, depStr + " " + content);
        else updateContent(id, depStr + " " + content);
        if (match(depStr, DB_LIBS)) { const lib = DB_LIBS.find(l => depStr.toLowerCase().includes(l)); if (lib) addNode(makeId(lib), capitalizeLib(lib), "Database"); }
        if (match(depStr, QUEUE_LIBS)) { const lib = QUEUE_LIBS.find(l => depStr.toLowerCase().includes(l)); if (lib) addNode(makeId(lib), capitalizeLib(lib), "Queue"); }
        if (match(depStr, EXTERNAL_LIBS)) { const lib = EXTERNAL_LIBS.find(l => depStr.toLowerCase().includes(l)); if (lib) addNode(makeId(lib), capitalizeLib(lib), "External"); }
        if (match(depStr, CACHE_LIBS)) { const lib = CACHE_LIBS.find(l => depStr.toLowerCase().includes(l)); if (lib) addNode(makeId(lib), capitalizeLib(lib), "Cache"); }
      } catch (e) {}
    }

    // requirements.txt
    if (filename === "requirements.txt" || filename === "requirements-dev.txt" || filename === "requirements-prod.txt") {
      const svcName = parentFolder || "PythonApp";
      const type = detectTypeFromName(svcName) || detectTypeFromContent(svcName, content);
      const id = makeId(svcName);
      if (!seen.has(id)) addNode(id, svcName, type, content);
      else updateContent(id, content);
      if (match(content, DB_LIBS)) { const lib = DB_LIBS.find(l => content.toLowerCase().includes(l)); if (lib) addNode(makeId(lib), capitalizeLib(lib), "Database"); }
      if (match(content, QUEUE_LIBS)) { const lib = QUEUE_LIBS.find(l => content.toLowerCase().includes(l)); if (lib) addNode(makeId(lib), capitalizeLib(lib), "Queue"); }
      if (match(content, EXTERNAL_LIBS)) { const lib = EXTERNAL_LIBS.find(l => content.toLowerCase().includes(l)); if (lib) addNode(makeId(lib), capitalizeLib(lib), "External"); }
    }

    // docker-compose
    if (filename === "docker-compose.yml" || filename === "docker-compose.yaml" || filename === "compose.yml" || filename === "compose.yaml") {
      const serviceBlocks = content.split(/\n(?=  [a-zA-Z0-9_-]+:)/);
      serviceBlocks.forEach(block => {
        const nameMatch = block.match(/^  ([a-zA-Z0-9_-]+):/);
        if (!nameMatch) return;
        const name = nameMatch[1];
        if (["version","services","networks","volumes","configs","secrets"].includes(name)) return;
        const imageMatch = block.match(/image:\s*([^\n]+)/);
        const imageStr = imageMatch ? imageMatch[1].toLowerCase() : "";
        const combined = name + " " + imageStr + " " + block;
        const type = detectTypeFromName(name) || detectTypeFromContent(name, imageStr) || "Service";
        addNode(makeId(name), name, type, combined);
      });
    }

    // Dockerfile
    if (filename === "Dockerfile" || filename.startsWith("Dockerfile.")) {
      const svcName = parentFolder || "DockerService";
      if (!seen.has(makeId(svcName))) addNode(makeId(svcName), svcName, detectTypeFromContent(svcName, content), content);
    }

    // .env files
    if (filename === ".env" || filename === ".env.example" || filename === ".env.sample") {
      const svcId = makeId(parentFolder || "app");
      updateContent(svcId, content);
      const dbMatches = content.match(/(DATABASE_URL|DB_HOST|DB_NAME|MONGO_URI|MONGO_URL|REDIS_URL|REDIS_HOST|NEO4J_URI|POSTGRES_URL|MYSQL_URL)=([^\n]+)/gi) || [];
      dbMatches.forEach(m => {
        const key = m.split("=")[0].toUpperCase();
        let dbName = "Database";
        if (key.includes("MONGO")) dbName = "MongoDB";
        else if (key.includes("REDIS")) dbName = "Redis";
        else if (key.includes("NEO4J")) dbName = "Neo4j";
        else if (key.includes("POSTGRES")) dbName = "PostgreSQL";
        else if (key.includes("MYSQL")) dbName = "MySQL";
        addNode(makeId(dbName), dbName, "Database");
      });
      const extMatches = content.match(/(STRIPE|TWILIO|SENDGRID|MAILGUN|FIREBASE|AWS|CLOUDINARY|PUSHER|AUTH0|OKTA)_/gi) || [];
      [...new Set(extMatches.map(m => m.replace(/_$/, "").toUpperCase()))].forEach(ext => {
        addNode(makeId(ext), ext, "External");
      });
    }

    // go.mod
    if (filename === "go.mod") addNode(makeId(parentFolder || "GoService"), parentFolder || "GoService", detectTypeFromName(parentFolder || "GoService") || "Service", content);

    // pom.xml
    if (filename === "pom.xml") {
      const svcName = parentFolder || "JavaService";
      addNode(makeId(svcName), svcName, detectTypeFromName(svcName) || "Service", content);
      if (content.includes("spring-boot")) updateContent(makeId(svcName), "spring springboot");
    }

    // build.gradle
    if (filename === "build.gradle" || filename === "build.gradle.kts") addNode(makeId(parentFolder || "JavaService"), parentFolder || "JavaService", detectTypeFromName(parentFolder || "JavaService") || "Service", content);

    // Cargo.toml
    if (filename === "Cargo.toml") addNode(makeId(parentFolder || "RustService"), parentFolder || "RustService", detectTypeFromName(parentFolder || "RustService") || "Service", content);

    // kubernetes
    if (path.includes("k8s/") || path.includes("kubernetes/") || path.includes("helm/") || filename.endsWith(".yaml") || filename.endsWith(".yml")) {
      if (content.includes("kind: Deployment") || content.includes("kind: Service")) {
        const nameMatch = content.match(/name:\s+([a-zA-Z0-9_-]+)/);
        if (nameMatch) {
          const name = nameMatch[1];
          if (!["default","kube-system"].includes(name)) addNode(makeId(name), name, detectTypeFromName(name) || "Service", content);
        }
      }
    }

    // nginx
    if (filename === "nginx.conf" || path.includes("nginx/")) addNode("svc-nginx", "Nginx", "Gateway", content);

    // Service folder detection
    const svcFolderIndex = cleanParts.findIndex(p => SERVICE_DIRS.includes(p.toLowerCase()));
    if (svcFolderIndex !== -1 && cleanParts.length > svcFolderIndex + 1) {
      const svcName = cleanParts[svcFolderIndex + 1];
      if (!["index.js","index.ts","main.py"].includes(svcName)) {
        const id = makeId(svcName);
        if (!seen.has(id)) addNode(id, svcName, detectTypeFromName(svcName) || detectTypeFromContent(svcName, content), content);
        else updateContent(id, content);
      }
    }
  });

  // Step 4: fallback — top-level folders
  if (nodes.length === 0) {
    Object.keys(folderFiles).forEach(folder => {
      if (["node_modules",".git","__pycache__","dist","build"].includes(folder)) return;
      const allContent = folderFiles[folder].map(f => f.content).join(" ");
      addNode(makeId(folder), folder, detectTypeFromName(folder) || detectTypeFromContent(folder, allContent) || "Service", allContent);
    });
  }

  return { nodes, nodeContentMap };
}

// ── Django Scanner ──────────────────────────────────────────────────────────
function scanDjangoProject(fileMap) {
  const nodes = [];
  const nodeContentMap = {};
  const seen = new Set();

  const addNode = (id, name, type, content = "") => {
    if (seen.has(id)) return;
    seen.add(id);
    nodes.push({ id, name, type });
    nodeContentMap[id] = (nodeContentMap[id] || "") + " " + content;
  };

  const settingsPath = Object.keys(fileMap).find(p => p.endsWith("settings.py") || p.includes("/settings/"));
  if (settingsPath) {
    const settings = fileMap[settingsPath];
    const appsMatch = settings.match(/INSTALLED_APPS\s*=\s*\[([\s\S]*?)\]/);
    if (appsMatch) {
      const apps = appsMatch[1].match(/'([a-zA-Z0-9_]+)'/g) || [];
      apps.forEach(app => {
        const name = app.replace(/'/g, "");
        if (name.startsWith("django.") || ["rest_framework","baton","modeltranslation","imagekit","djoser","admin_numeric_filter","django_filters","corsheaders","whitenoise"].includes(name)) return;
        const id = makeId(name);
        const appContent = Object.entries(fileMap).filter(([p]) => p.includes(`/${name}/`) || p.startsWith(`${name}/`)).map(([, c]) => c).join(" ");
        addNode(id, name, detectTypeFromName(name) || "Service", appContent);
      });
    }
    if (settings.includes("postgresql") || settings.includes("postgres")) addNode("svc-postgresql", "PostgreSQL", "Database");
    else if (settings.includes("mysql")) addNode("svc-mysql", "MySQL", "Database");
    else if (settings.includes("sqlite")) addNode("svc-sqlite", "SQLite", "Database");
    else if (settings.includes("django.db")) addNode("svc-database", "Database", "Database");
    if (settings.includes("redis") || settings.includes("REDIS")) addNode("svc-redis", "Redis", "Cache");
    if (settings.includes("CELERY") || settings.includes("celery")) addNode("svc-celery", "CeleryWorker", "Worker");
    if (settings.includes("social_django") || settings.includes("social-auth")) addNode("svc-socialauth", "SocialAuth", "External");
    if (settings.includes("rest_framework")) addNode("svc-restapi", "REST API", "API");
    if (settings.includes("djoser") || settings.includes("JWT")) addNode("svc-auth", "AuthService", "Service");
    if (settings.includes("CHANNEL_LAYERS") || settings.includes("channels")) addNode("svc-channels", "WebSocketServer", "Service");
    if (settings.includes("elasticsearch") || settings.includes("ELASTICSEARCH")) addNode("svc-elasticsearch", "Elasticsearch", "Database");
  }

  const urlsPaths = Object.keys(fileMap).filter(p => p.endsWith("urls.py"));
  urlsPaths.forEach(urlPath => {
    const content = fileMap[urlPath];
    const includes = content.match(/include\(['"]([^'"]+)['"]\)/g) || [];
    includes.forEach(inc => {
      const mod = inc.match(/include\(['"]([^'"]+)['"]\)/)?.[1];
      if (mod) {
        const parts = mod.split(".");
        const appName = parts[0];
        if (!appName.startsWith("django") && appName !== "baton" && appName.length > 1) {
          const id = makeId(appName);
          if (!seen.has(id)) addNode(id, appName, detectTypeFromName(appName) || "Service", content);
        }
      }
    });
  });

  const reqPath = Object.keys(fileMap).find(p => p.endsWith("requirements.txt"));
  if (reqPath) {
    const req = fileMap[reqPath];
    if (match(req, QUEUE_LIBS)) { const lib = QUEUE_LIBS.find(l => req.toLowerCase().includes(l)); if (lib) addNode(makeId(lib), capitalizeLib(lib), "Queue"); }
    if (match(req, EXTERNAL_LIBS)) { const lib = EXTERNAL_LIBS.find(l => req.toLowerCase().includes(l)); if (lib) addNode(makeId(lib), capitalizeLib(lib), "External"); }
    if (match(req, CACHE_LIBS)) { const lib = CACHE_LIBS.find(l => req.toLowerCase().includes(l)); if (lib) addNode(makeId(lib), capitalizeLib(lib), "Cache"); }
  }

  const hasClientApp = Object.keys(fileMap).some(p => p.includes("/client/") || p.includes("/frontend/"));
  if (hasClientApp) addNode("svc-client", "WebClient", "User", "client frontend");

  return { nodes, nodeContentMap };
}

// ── ZIP Scanner ─────────────────────────────────────────────────────────────
export async function scanZip(file) {
  const zip = await JSZip.loadAsync(file);
  const fileMap = {};
  const SKIP_DIRS = ["node_modules/",".git/","__pycache__/","dist/","build/",".next/","coverage/","venv/","env/",".env/","vendor/"];
  const SKIP_EXTS = [".pyc",".lock",".png",".jpg",".jpeg",".ico",".mo",".map",".woff",".woff2",".ttf",".eot",".svg",".gif",".pdf",".zip",".tar",".gz"];

  const allFiles = Object.values(zip.files).filter(f => !f.dir);
  for (const zipFile of allFiles) {
    const path = zipFile.name;
    if (SKIP_DIRS.some(d => path.includes(d))) continue;
    if (SKIP_EXTS.some(e => path.endsWith(e))) continue;
    const content = await zipFile.async("string").catch(() => "");
    if (content.length > 500000) continue;
    fileMap[path] = content;
  }

  const isDjango = Object.keys(fileMap).some(p => p.endsWith("settings.py")) && Object.values(fileMap).some(c => c.includes("INSTALLED_APPS"));

  let nodes, nodeContentMap;
  if (isDjango) {
    ({ nodes, nodeContentMap } = scanDjangoProject(fileMap));
  } else {
    ({ nodes, nodeContentMap } = scanGenericProject(fileMap));
  }

  const edges = detectEdges(nodes, nodeContentMap);
  // ─ LAYOUT FIX: nodes center mein aayenge ─
  return { nodes: layoutNodes(nodes), edges };
}

// ── Parse package.json ──────────────────────────────────────────────────────
export function parsePackageJson(content, filename = "app") {
  try {
    const pkg = JSON.parse(content);
    const allDeps = { ...pkg.dependencies, ...pkg.devDependencies };
    const depString = Object.keys(allDeps).join(" ");
    const name = pkg.name || filename;
    const nodes = [];
    const seen = new Set();
    nodes.push({ id: makeId(name), name, type: detectTypeFromContent(name, depString) });
    seen.add(name);
    if (match(depString, DB_LIBS)) { const lib = DB_LIBS.find(l => depString.toLowerCase().includes(l)); if (lib && !seen.has(lib)) { seen.add(lib); nodes.push({ id: makeId(lib), name: capitalizeLib(lib), type: "Database" }); } }
    if (match(depString, QUEUE_LIBS)) { const lib = QUEUE_LIBS.find(l => depString.toLowerCase().includes(l)); if (lib && !seen.has(lib)) { seen.add(lib); nodes.push({ id: makeId(lib), name: capitalizeLib(lib), type: "Queue" }); } }
    if (match(depString, EXTERNAL_LIBS)) { const lib = EXTERNAL_LIBS.find(l => depString.toLowerCase().includes(l)); if (lib && !seen.has(lib)) { seen.add(lib); nodes.push({ id: makeId(lib), name: capitalizeLib(lib), type: "External" }); } }
    if (match(depString, CACHE_LIBS)) { const lib = CACHE_LIBS.find(l => depString.toLowerCase().includes(l)); if (lib && !seen.has(lib)) { seen.add(lib); nodes.push({ id: makeId(lib), name: capitalizeLib(lib), type: "Cache" }); } }
    return { nodes, edges: [] };
  } catch (e) { return { nodes: [], edges: [] }; }
}

// ── Parse requirements.txt ──────────────────────────────────────────────────
export function parseRequirements(content, filename = "app") {
  const lines = content.split("\n").map(l => l.trim().split("==")[0].split(">=")[0].split("~=")[0]).filter(l => l && !l.startsWith("#"));
  const depString = lines.join(" ");
  const name = filename.replace(/requirements[-_]?/i, "").replace(".txt", "").trim() || "PythonApp";
  const nodes = [];
  const seen = new Set();
  nodes.push({ id: makeId(name), name, type: detectTypeFromContent(name, depString) });
  seen.add(name);
  if (match(depString, DB_LIBS)) { const lib = DB_LIBS.find(l => depString.toLowerCase().includes(l)); if (lib && !seen.has(lib)) { seen.add(lib); nodes.push({ id: makeId(lib), name: capitalizeLib(lib), type: "Database" }); } }
  if (match(depString, QUEUE_LIBS)) { const lib = QUEUE_LIBS.find(l => depString.toLowerCase().includes(l)); if (lib && !seen.has(lib)) { seen.add(lib); nodes.push({ id: makeId(lib), name: capitalizeLib(lib), type: "Queue" }); } }
  if (match(depString, EXTERNAL_LIBS)) { const lib = EXTERNAL_LIBS.find(l => depString.toLowerCase().includes(l)); if (lib && !seen.has(lib)) { seen.add(lib); nodes.push({ id: makeId(lib), name: capitalizeLib(lib), type: "External" }); } }
  return { nodes, edges: [] };
}

// ── GitHub Scanner ──────────────────────────────────────────────────────────
export async function scanGitHub(url) {
  try {
    const matchUrl = url.match(/github\.com\/([^/]+)\/([^/#?]+)/);
    if (!matchUrl) throw new Error("Invalid GitHub URL — use: https://github.com/user/repo");
    const owner = matchUrl[1];
    const repo  = matchUrl[2].replace(/\.git$/, "");

    // Strategy 1: Backend proxies the GitHub ZIP (avoids CORS) → same as manual ZIP upload
    try {
      const res = await apiFetch(`/scan/github-zip`, {
        method: "POST",
        body: JSON.stringify({ owner, repo, branch: "main" })
      });
      if (res && res.ok) {
        const blob = await res.blob();
        const file = new File([blob], `${repo}.zip`, { type: "application/zip" });
        const result = await scanZip(file);
        if (result.nodes && result.nodes.length > 0) return result;
      }
    } catch {}

    // Strategy 2: GitHub Contents API (if backend fails)
    try {
      const result = await scanGitHubAPI(owner, repo);
      if (result.nodes.length > 0) return { nodes: layoutNodes(result.nodes), edges: result.edges };
    } catch {}

    // Strategy 3: Infer from repo name/metadata
    return inferFromRepoMeta(owner, repo);
  } catch (err) {
    throw new Error(err.message);
  }
}

async function scanGitHubAPI(owner, repo) {
  const fileMap = {};

  // Config files — same as before
  const CONFIG_FILES = new Set(["package.json","requirements.txt","docker-compose.yml","docker-compose.yaml","compose.yml","compose.yaml","Dockerfile","dockerfile",".env.example",".env.sample",".env","go.mod","go.sum","pom.xml","build.gradle","Cargo.toml","pyproject.toml","setup.py","setup.cfg","Gemfile","serverless.yml","serverless.yaml","k8s.yaml","k8s.yml","deployment.yaml","service.yaml","chart.yaml","Chart.yaml","main.tf","variables.tf"]);

  // Source entry-point files — these give us imports/dependencies like ZIP does
  const SOURCE_FILES = new Set(["main.py","app.py","server.py","wsgi.py","asgi.py","manage.py","index.js","server.js","app.js","index.ts","server.ts","app.ts","main.go","main.rs","Application.java","Program.cs","index.php","app.rb","main.dart","lib/main.dart"]);

  const SKIP_DIRS = new Set(["node_modules",".git","dist","build","coverage",".cache","__pycache__","venv",".venv","vendor","bin","obj",".next","out","target","pkg"]);

  const fetchFile = async (url) => fetch(url).then(r => r.text()).catch(() => null);

  const rootRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents`, { headers: { "Accept": "application/vnd.github.v3+json" } });
  if (!rootRes.ok) throw new Error("Cannot access repository — may be private");
  const rootItems = await rootRes.json();
  if (!Array.isArray(rootItems)) throw new Error("Invalid repository response");

  // Root-level files
  for (const item of rootItems) {
    if (item.type === "file" && (CONFIG_FILES.has(item.name) || SOURCE_FILES.has(item.name))) {
      const fc = await fetchFile(item.download_url);
      if (fc) fileMap[item.name] = fc;
    }
  }

  // Scan subdirs — config + source files, 2 levels deep
  const dirs = rootItems.filter(item => item.type === "dir" && !SKIP_DIRS.has(item.name));
  for (const dir of dirs.slice(0, 50)) {
    try {
      const dirRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${dir.name}`, { headers: { "Accept": "application/vnd.github.v3+json" } });
      if (!dirRes.ok) continue;
      const dirItems = await dirRes.json();
      if (!Array.isArray(dirItems)) continue;
      for (const item of dirItems) {
        if (item.type === "file" && (CONFIG_FILES.has(item.name) || SOURCE_FILES.has(item.name))) {
          const fc = await fetchFile(item.download_url);
          if (fc) fileMap[`${dir.name}/${item.name}`] = fc;
        }
        // 2nd level deep for monorepos
        if (item.type === "dir" && !SKIP_DIRS.has(item.name)) {
          try {
            const subRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${dir.name}/${item.name}`, { headers: { "Accept": "application/vnd.github.v3+json" } });
            if (!subRes.ok) continue;
            const subItems = await subRes.json();
            if (!Array.isArray(subItems)) continue;
            for (const sub of subItems) {
              if (sub.type === "file" && (CONFIG_FILES.has(sub.name) || SOURCE_FILES.has(sub.name))) {
                const fc = await fetchFile(sub.download_url);
                if (fc) fileMap[`${dir.name}/${item.name}/${sub.name}`] = fc;
              }
            }
          } catch {}
        }
      }
    } catch {}
  }

  // Also use directory names for node detection even if no config files found
  const dirNames = rootItems.filter(i => i.type === "dir" && !SKIP_DIRS.has(i.name)).map(i => i.name);

  if (Object.keys(fileMap).length === 0 && dirNames.length < 2) throw new Error("No recognizable project files found");

  const isDjango = Object.keys(fileMap).some(p => p.endsWith("settings.py")) && Object.values(fileMap).some(c => c.includes("INSTALLED_APPS"));
  let nodes, nodeContentMap;
  if (isDjango) {
    ({ nodes, nodeContentMap } = scanDjangoProject(fileMap));
  } else {
    ({ nodes, nodeContentMap } = scanGenericProject(fileMap));
  }

  // Merge directory-inferred nodes (for monorepos / microservice repos)
  if (dirNames.length > 0) {
    const dirNodes = inferFromDirStructure(owner, repo, dirNames);
    dirNodes.forEach(dn => {
      if (!nodes.find(n => n.id === dn.id)) nodes.push(dn);
    });
  }

  const edges = detectEdges(nodes, nodeContentMap);
  return { nodes, edges };
}

function inferFromDirStructure(owner, repo, dirNames) {
  // Build nodes from directory structure
  const nodes = [];
  const seen = new Set();
  const add = (id, name, type, intent) => {
    if (seen.has(id)) return;
    seen.add(id);
    nodes.push({ id, name, type, intent: intent || `Detected from directory: ${name}`, owner });
  };

  const serviceKeywords = ["service","svc","api","backend","server","worker","job","task","handler","processor","consumer","producer"];
  const frontendKeywords = ["frontend","ui","web","client","app","dashboard","portal","admin"];
  const dbKeywords = ["db","database","data","store","storage","repo","repository"];
  const cacheKeywords = ["cache","redis","memcache"];
  const queueKeywords = ["queue","worker","job","task","event","stream","kafka","rabbit","bus"];
  const gatewayKeywords = ["gateway","proxy","nginx","ingress","router","lb","loadbalancer"];
  const authKeywords = ["auth","login","iam","identity","user","account","permission","access"];

  dirNames.forEach(dir => {
    const d = dir.toLowerCase();
    if (frontendKeywords.some(k => d.includes(k))) add(makeId(dir), dir, "User", `Frontend component: ${dir}`);
    else if (gatewayKeywords.some(k => d.includes(k))) add(makeId(dir), dir, "Gateway", `API Gateway: ${dir}`);
    else if (authKeywords.some(k => d.includes(k))) add(makeId(dir), dir, "Auth", `Auth service: ${dir}`);
    else if (dbKeywords.some(k => d.includes(k))) add(makeId(dir), dir, "Database", `Database: ${dir}`);
    else if (cacheKeywords.some(k => d.includes(k))) add(makeId(dir), dir, "Cache", `Cache: ${dir}`);
    else if (queueKeywords.some(k => d.includes(k))) add(makeId(dir), dir, "Queue", `Queue/Worker: ${dir}`);
    else if (serviceKeywords.some(k => d.includes(k))) add(makeId(dir), dir, "Service", `Microservice: ${dir}`);
  });

  return nodes;
}

function inferFromRepoMeta(owner, repo) {
  const nodes = [];
  const seen = new Set();
  const repoLower = repo.toLowerCase();

  const add = (id, name, type) => {
    if (seen.has(id)) return;
    seen.add(id);
    nodes.push({ id, name, type, intent: `Inferred from GitHub repo: ${owner}/${repo}`, owner });
  };

  const mainType = detectTypeFromName(repoLower) || "Service";
  add(makeId(repo), repo, mainType);

  if (["api","backend","server","service"].some(k => repoLower.includes(k))) { add("inferred-gateway","API Gateway","Gateway"); add("inferred-db","Database","Database"); }
  if (["web","frontend","ui","app","client"].some(k => repoLower.includes(k))) { add("inferred-frontend","Frontend","User"); add("inferred-api","API","API"); }
  if (["shop","store","ecommerce","payment","checkout"].some(k => repoLower.includes(k))) { add("inferred-payment","PaymentGateway","External"); add("inferred-db","ProductDB","Database"); add("inferred-queue","OrderQueue","Queue"); }
  if (["auth","login","user","account","iam"].some(k => repoLower.includes(k))) { add("inferred-auth","AuthService","Service"); add("inferred-db","UserDB","Database"); }
  if (["fullstack","monorepo","platform"].some(k => repoLower.includes(k))) { add("inferred-frontend","Frontend","User"); add("inferred-gateway","API Gateway","Gateway"); add("inferred-service","Backend Service","Service"); add("inferred-db","Database","Database"); add("inferred-cache","Cache","Cache"); }
  if (nodes.length === 0) add(makeId(repo), repo, "Service");

  const edges = [];
  for (let i = 0; i < nodes.length - 1; i++) edges.push({ source: nodes[i].id, target: nodes[i + 1].id });

  // ─ LAYOUT FIX ─
  return { nodes: layoutNodes(nodes), edges, inferred: true };
}

// ══════════════════════════════════════════════════════════
// OPENAPI / SWAGGER INGEST
// ══════════════════════════════════════════════════════════
export function parseOpenAPI(text, filename = "openapi") {
  let spec;
  try {
    spec = JSON.parse(text);
  } catch {
    // Try YAML — basic key:value parser
    try {
      spec = parseYAMLBasic(text);
    } catch {
      throw new Error("Could not parse OpenAPI file. Use JSON or YAML format.");
    }
  }

  const nodes = [];
  const edges = [];
  const seen = new Set();

  const title = spec?.info?.title || filename.replace(/\.(json|yaml|yml)$/i, "");
  const version = spec?.info?.version || "1.0";

  // Main API node
  const apiId = makeId(title + "-api");
  nodes.push({
    id: apiId,
    type: "API",
    name: title,
    intent: `OpenAPI ${version} — ${Object.keys(spec?.paths || {}).length} endpoints`,
    owner: spec?.info?.contact?.name || "",
    team: "",
    criticality: "high",
    compliance_scope: "",
    fields: "[]",
  });

  // Extract servers as Gateway nodes
  (spec?.servers || []).forEach((srv, i) => {
    const gid = makeId(`gateway-${i}`);
    const url = srv.url || "";
    nodes.push({
      id: gid, type: "Gateway",
      name: url.includes("localhost") ? "Local Gateway" : `API Gateway ${i + 1}`,
      intent: `Server: ${url}`,
      owner: "", team: "", criticality: "high", compliance_scope: "", fields: "[]",
    });
    edges.push({ source: gid, target: apiId });
  });

  // Extract tags as Service nodes
  const tagNodes = {};
  (spec?.tags || []).forEach(tag => {
    const tid = makeId(`svc-${tag.name}`);
    tagNodes[tag.name] = tid;
    if (!seen.has(tid)) {
      seen.add(tid);
      nodes.push({
        id: tid, type: "Service",
        name: tag.name,
        intent: tag.description || `${tag.name} service`,
        owner: "", team: "", criticality: "medium", compliance_scope: "", fields: "[]",
      });
      edges.push({ source: apiId, target: tid });
    }
  });

  // Extract paths — group by tag → service
  const pathGroups = {};
  Object.entries(spec?.paths || {}).forEach(([path, methods]) => {
    Object.entries(methods).forEach(([method, op]) => {
      if (typeof op !== "object") return;
      const tag = (op.tags || [])[0] || "General";
      if (!pathGroups[tag]) pathGroups[tag] = [];
      pathGroups[tag].push({ path, method: method.toUpperCase(), summary: op.summary || path });
    });
  });

  // Create service nodes from path groups
  Object.entries(pathGroups).forEach(([tag, paths]) => {
    const tid = tagNodes[tag] || makeId(`svc-${tag}`);
    if (!seen.has(tid)) {
      seen.add(tid);
      const samplePaths = paths.slice(0, 3).map(p => `${p.method} ${p.path}`).join(", ");
      nodes.push({
        id: tid, type: "Service",
        name: tag,
        intent: `${paths.length} endpoints: ${samplePaths}`,
        owner: "", team: "", criticality: "medium", compliance_scope: "", fields: "[]",
      });
      edges.push({ source: apiId, target: tid });
    }
  });

  // Extract security schemes → Auth node
  const secSchemes = spec?.components?.securitySchemes || spec?.securityDefinitions || {};
  if (Object.keys(secSchemes).length > 0) {
    const authId = makeId("auth-service");
    const schemes = Object.keys(secSchemes).join(", ");
    nodes.push({
      id: authId, type: "Auth",
      name: "Auth Service",
      intent: `Security: ${schemes}`,
      owner: "", team: "", criticality: "critical", compliance_scope: "", fields: "[]",
    });
    edges.push({ source: apiId, target: authId });
  }

  // Extract external refs / callbacks → External nodes
  const externalsSeen = new Set();
  Object.values(spec?.paths || {}).forEach(methods => {
    Object.values(methods).forEach(op => {
      if (typeof op !== "object") return;
      Object.entries(op?.callbacks || {}).forEach(([cbName]) => {
        if (!externalsSeen.has(cbName)) {
          externalsSeen.add(cbName);
          const eid = makeId(`ext-${cbName}`);
          nodes.push({
            id: eid, type: "External",
            name: cbName,
            intent: `Callback/webhook: ${cbName}`,
            owner: "", team: "", criticality: "low", compliance_scope: "", fields: "[]",
          });
          edges.push({ source: apiId, target: eid });
        }
      });
    });
  });

  return { nodes: layoutNodes(nodes), edges };
}

// ══════════════════════════════════════════════════════════
// TERRAFORM HCL INGEST (basic)
// ══════════════════════════════════════════════════════════
export function parseTerraform(text, filename = "main.tf") {
  const nodes = [];
  const edges = [];
  const seen = new Set();

  // Extract resource blocks
  const resourceRegex = /resource\s+"([^"]+)"\s+"([^"]+)"/g;
  let match;

  while ((match = resourceRegex.exec(text)) !== null) {
    const [, resourceType, resourceName] = match;
    const id = makeId(`tf-${resourceName}`);
    if (seen.has(id)) continue;
    seen.add(id);

    // Map Terraform resource types to CodeGPO node types
    let nodeType = "Service";
    let compliance = "";
    const rt = resourceType.toLowerCase();

    if (rt.includes("db") || rt.includes("rds") || rt.includes("database") || rt.includes("dynamo") || rt.includes("mongo") || rt.includes("postgres") || rt.includes("mysql") || rt.includes("redis") || rt.includes("elasticache") || rt.includes("bigtable") || rt.includes("spanner")) {
      nodeType = "Database"; compliance = "gdpr,dpdp";
    } else if (rt.includes("lambda") || rt.includes("function") || rt.includes("cloudfunction")) {
      nodeType = "Worker";
    } else if (rt.includes("api_gateway") || rt.includes("alb") || rt.includes("elb") || rt.includes("load_balancer") || rt.includes("nginx") || rt.includes("ingress")) {
      nodeType = "Gateway";
    } else if (rt.includes("sqs") || rt.includes("sns") || rt.includes("kafka") || rt.includes("pubsub") || rt.includes("eventbridge") || rt.includes("queue") || rt.includes("topic")) {
      nodeType = "Queue";
    } else if (rt.includes("s3") || rt.includes("storage") || rt.includes("blob") || rt.includes("bucket") || rt.includes("gcs")) {
      nodeType = "Storage";
    } else if (rt.includes("cloudfront") || rt.includes("cdn") || rt.includes("fastly")) {
      nodeType = "CDN";
    } else if (rt.includes("cognito") || rt.includes("iam") || rt.includes("identity") || rt.includes("keycloak") || rt.includes("auth")) {
      nodeType = "Auth";
    } else if (rt.includes("secret") || rt.includes("kms") || rt.includes("vault") || rt.includes("ssm_parameter")) {
      nodeType = "Secrets";
    } else if (rt.includes("eks") || rt.includes("ecs") || rt.includes("kubernetes") || rt.includes("container") || rt.includes("instance") || rt.includes("compute")) {
      nodeType = "Service";
    } else if (rt.includes("monitoring") || rt.includes("cloudwatch") || rt.includes("datadog") || rt.includes("grafana") || rt.includes("prometheus")) {
      nodeType = "Monitoring";
    }

    nodes.push({
      id, type: nodeType,
      name: resourceName.replace(/_/g, " "),
      intent: `Terraform: ${resourceType}`,
      owner: "", team: "", criticality: nodeType === "Database" ? "critical" : "medium",
      compliance_scope: compliance, fields: "[]",
    });
  }

  // Basic edge detection from depends_on
  const dependsRegex = /resource\s+"([^"]+)"\s+"([^"]+)"[^}]*depends_on\s*=\s*\[([^\]]+)\]/gs;
  while ((match = dependsRegex.exec(text)) !== null) {
    const [, , srcName, deps] = match;
    const srcId = makeId(`tf-${srcName}`);
    deps.split(",").forEach(dep => {
      const depName = dep.trim().replace(/^[a-z_]+\./, "").replace(/\..+$/, "").trim();
      if (depName) {
        const depId = makeId(`tf-${depName}`);
        if (seen.has(depId)) edges.push({ source: srcId, target: depId });
      }
    });
  }

  if (nodes.length === 0) throw new Error("No Terraform resources found in this file.");
  return { nodes: layoutNodes(nodes), edges };
}

// ══════════════════════════════════════════════════════════
// K8s YAML INGEST
// ══════════════════════════════════════════════════════════
export function parseK8s(text) {
  const nodes = [];
  const edges = [];
  const seen = new Set();
  const serviceMap = {}; // name → id for edge building

  // Split multi-doc YAML
  const docs = text.split(/^---/m).filter(d => d.trim());

  docs.forEach(doc => {
    const kindMatch = doc.match(/kind:\s*(\w+)/);
    const nameMatch = doc.match(/name:\s*([^\n\s]+)/);
    if (!kindMatch || !nameMatch) return;

    const kind = kindMatch[1];
    const name = nameMatch[1];
    const id = makeId(`k8s-${name}`);
    if (seen.has(id)) return;
    seen.add(id);

    let nodeType = "Service";
    let intent = `Kubernetes ${kind}: ${name}`;
    let criticality = "medium";
    let compliance = "";

    switch (kind) {
      case "Deployment":
      case "StatefulSet":
      case "DaemonSet":
        nodeType = "Service"; break;
      case "Service":
        nodeType = "Gateway";
        intent = `K8s Service — exposes pods as network endpoint`;
        break;
      case "Ingress":
        nodeType = "Gateway";
        intent = `K8s Ingress — external traffic routing`;
        break;
      case "CronJob":
      case "Job":
        nodeType = "Worker"; break;
      case "ConfigMap":
        return; // Skip ConfigMaps
      case "Secret":
        nodeType = "Secrets";
        criticality = "critical";
        compliance = "gdpr,dpdp";
        break;
      case "PersistentVolumeClaim":
      case "PersistentVolume":
        nodeType = "Storage"; break;
    }

    serviceMap[name] = id;
    nodes.push({ id, type: nodeType, name, intent, owner: "", team: "", criticality, compliance_scope: compliance, fields: "[]" });
  });

  // Edge: Ingress → Services via rules
  const ingressDocs = docs.filter(d => /kind:\s*Ingress/.test(d));
  ingressDocs.forEach(doc => {
    const nameMatch = doc.match(/name:\s*([^\n\s]+)/);
    if (!nameMatch) return;
    const ingressId = makeId(`k8s-${nameMatch[1]}`);
    const serviceRefs = [...doc.matchAll(/serviceName:\s*([^\n\s]+)|name:\s*([^\n\s]+)\n\s*port:/g)];
    serviceRefs.forEach(m => {
      const svcName = m[1] || m[2];
      const svcId = serviceMap[svcName];
      if (svcId) edges.push({ source: ingressId, target: svcId });
    });
  });

  if (nodes.length === 0) throw new Error("No Kubernetes resources found.");
  return { nodes: layoutNodes(nodes), edges };
}

// ══════════════════════════════════════════════════════════
// BASIC YAML PARSER (no external lib needed)
// ══════════════════════════════════════════════════════════
function parseYAMLBasic(text) {
  // For OpenAPI YAML — convert to parseable structure
  // This handles basic key:value and nested structures
  const lines = text.split("\n");
  const result = {};
  const stack = [{ obj: result, indent: -1 }];

  lines.forEach(line => {
    if (!line.trim() || line.trim().startsWith("#")) return;
    const indent = line.search(/\S/);
    const colonIdx = line.indexOf(":");
    if (colonIdx === -1) return;
    const key = line.slice(0, colonIdx).trim();
    const value = line.slice(colonIdx + 1).trim();

    while (stack.length > 1 && indent <= stack[stack.length - 1].indent) stack.pop();
    const parent = stack[stack.length - 1].obj;

    if (!value || value === "") {
      parent[key] = {};
      stack.push({ obj: parent[key], indent });
    } else {
      parent[key] = value.replace(/^["']|["']$/g, "");
    }
  });
  return result;
}
