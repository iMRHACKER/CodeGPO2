const BACKEND = import.meta.env.VITE_API_URL || "http://localhost:8000";

export async function askOllama(prompt) {
  try {
    const res = await fetch(`${BACKEND}/graphrag`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt })
    });
    const data = await res.json();
    return data.response || data.result || "No response from server";
  } catch (err) {
    return "❌ Backend not reachable. Make sure the server is running.";
  }
}
