import { askOllama } from "./ollamaClient";

export async function explainViolation({
  sourceNode,
  targetNode,
  rule
}) {
  const prompt = `
You are a senior software architect.

Architecture context:
- Source component: ${sourceNode.name} (${sourceNode.type})
- Target component: ${targetNode.name} (${targetNode.type})

Governance rule violated:
${rule.ruleId}: ${rule.message}
${rule.description ? `Detail: ${rule.description}` : ""}
${rule.framework ? `Compliance framework: ${rule.framework}` : ""}
${rule.reference ? `Reference: ${rule.reference}` : ""}

Explain in simple, technical terms:
1. Why this connection is risky
2. What architectural principle is violated
3. A safer alternative design
4. Compliance impact if applicable

Do NOT invent new rules.
Do NOT mention AI.
Be concise and clear.
`;

  return await askOllama(prompt);
}
