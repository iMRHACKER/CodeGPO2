// Encodes architecture into a compressed URL-safe string
// Uses base64 — no server needed, works forever

export function encodeArchitecture({ project, nodes, edges, violations, score }) {
  const payload = {
    v: 1, // version
    p: {
      name: project?.name || "Untitled Project",
      desc: project?.description || ""
    },
    n: nodes.map(n => ({ i: n.id, t: n.type, nm: n.name })),
    e: edges.map(e => ({ s: e.source, t: e.target })),
    vl: violations.map(v => ({
      r: v.ruleId,
      sv: v.severity,
      s: v.source,
      t: v.target,
      m: v.message,
      c: v.custom || false
    })),
    sc: score ? { s: score.score, g: score.grade } : null,
    ts: Date.now()
  };

  try {
    const json = JSON.stringify(payload);
    const encoded = btoa(encodeURIComponent(json));
    return encoded;
  } catch (e) {
    console.error("Encode error:", e);
    return null;
  }
}

export function decodeArchitecture(encoded) {
  try {
    const json = decodeURIComponent(atob(encoded));
    const payload = JSON.parse(json);

    return {
      project: payload.p,
      nodes: payload.n.map(n => ({ id: n.i, type: n.t, name: n.nm })),
      edges: payload.e.map(e => ({ source: e.s, target: e.t })),
      violations: payload.vl?.map(v => ({
        ruleId: v.r,
        severity: v.sv,
        source: v.s,
        target: v.t,
        message: v.m,
        custom: v.c
      })) || [],
      score: payload.sc,
      timestamp: payload.ts,
      version: payload.v
    };
  } catch (e) {
    console.error("Decode error:", e);
    return null;
  }
}

export function buildShareUrl(encoded) {
  const base = window.location.origin + window.location.pathname;
  return `${base}?share=${encoded}`;
}

export function getSharedData() {
  const params = new URLSearchParams(window.location.search);
  const share = params.get("share");
  if (!share) return null;
  return decodeArchitecture(share);
}