// ── CodeGPO Governance Engine ──────────────────────────────────────────────
// 30 Architecture Rules — deterministic, no AI needed
// Enterprise-grade: covers microservices, IoT, payments, data flows

function isType(node, types) {
  if (!node?.type) return false;
  const t = node.type.toLowerCase();
  return types.some(type => t.includes(type.toLowerCase()));
}

const FRONTEND  = ["user","client","browser","frontend","ui","mobile","app","web"];
const DB        = ["database","db","sql","mongo","postgres","mysql","neo4j","redis","pg","sqlite","dynamo","cassandra","elastic","elasticsearch","opensearch","clickhouse","bigquery","snowflake","supabase"];
const EXTERNAL  = ["external","vendor","third-party","stripe","twilio","sendgrid","aws","gcp","azure","firebase","segment","mixpanel","amplitude","intercom","hubspot","salesforce","datadog","sentry","pagerduty"];
const SERVICE   = ["service","api","backend","microservice","server","rest","graphql","grpc","rpc"];
const QUEUE     = ["queue","kafka","rabbit","rabbitmq","sqs","bull","celery","pubsub","nats","kinesis","eventbus","bus","topic","stream","event"];
const GATEWAY   = ["gateway","proxy","nginx","kong","traefik","load balancer","ingress","reverse proxy","cdn","cloudflare","apigee","envoy"];
const WORKER    = ["worker","job","cron","scheduler","celery","task","consumer","processor","lambda","function","serverless","batch"];
const CACHE     = ["cache","redis","memcached","varnish","hazelcast"];
const AUTH      = ["auth","authentication","authorization","oauth","jwt","sso","identity","keycloak","auth0","okta","cognito","iam","rbac","ldap","saml"];
const SECRETS   = ["secret","vault","config","env","credential","hsm","kms","ssm","parameter store"];
const IOT       = ["iot","device","sensor","edge","embedded","firmware","vehicle","car","bike","ev","scooter","telematics","gps","tracker","obd"];
const ADMIN     = ["admin","dashboard","backoffice","back-office","cms","ops","management","control panel","internal portal"];
const ANALYTICS = ["analytics","tracking","metrics","reporting","bi","warehouse","looker","tableau","grafana","kibana","superset"];
const PAYMENT   = ["payment","billing","stripe","checkout","invoice","transaction","pci","card","wallet","razorpay","paytm","phonepe","upi","banking"];
const SEARCH    = ["elastic","opensearch","solr","algolia","typesense","search"];
const MONITOR   = ["monitoring","logging","log","trace","apm","prometheus","grafana","datadog","newrelic","sentry","splunk","elk","loki"];

const RULES = [
  // ══ TIER 1: CRITICAL — Immediate security risks ══════════════════════════

  {
    ruleId:"GOV-001", severity:"CRITICAL",
    message:"Client cannot directly access Database — route through an API or Service",
    description:"Direct client-to-database exposes your entire data layer, bypasses auth/business logic, and violates every compliance framework.",
    fix:"Add an API or Service layer. Use parameterized queries. Never expose DB credentials to the client.",
    check:(src,tgt)=>isType(src,FRONTEND)&&isType(tgt,DB)
  },
  {
    ruleId:"GOV-002", severity:"CRITICAL",
    message:"External service cannot directly access internal Database",
    description:"External DB access exposes internal schema, allows data exfiltration, and bypasses all access controls.",
    fix:"Create a dedicated, authenticated API endpoint for external data access. Never expose DB to the internet.",
    check:(src,tgt)=>isType(src,EXTERNAL)&&isType(tgt,DB)
  },
  {
    ruleId:"GOV-003", severity:"CRITICAL",
    message:"IoT/Device cannot directly access Database — must go through API Gateway",
    description:"IoT devices are untrusted endpoints. Direct DB access allows device compromise to expose all data.",
    fix:"Route all device communication through an API Gateway with device authentication (mTLS or API keys).",
    check:(src,tgt)=>isType(src,IOT)&&isType(tgt,DB)
  },
  {
    ruleId:"GOV-004", severity:"CRITICAL",
    message:"Frontend/Client is accessing Secrets or Vault directly — critical security violation",
    description:"Secrets in client-side code are fully exposed. Any user can read API keys, passwords, and tokens.",
    fix:"Secrets must only be accessed server-side. Use environment variables injected at build time or a secrets proxy API.",
    check:(src,tgt)=>isType(src,FRONTEND)&&isType(tgt,SECRETS)
  },
  {
    ruleId:"GOV-005", severity:"CRITICAL",
    message:"Admin panel is directly exposed to external/internet without a Gateway",
    description:"Exposed admin panels are primary targets for credential stuffing, brute force, and admin takeover attacks.",
    fix:"Put admin panels behind VPN, IP allowlisting, or an authenticated gateway. Never expose directly to internet.",
    check:(src,tgt)=>isType(src,EXTERNAL)&&isType(tgt,ADMIN)
  },
  {
    ruleId:"GOV-006", severity:"CRITICAL",
    message:"IoT/Device is sending data directly to a Queue without authentication gateway",
    description:"Unauthenticated device-to-queue access allows message injection, replay attacks, and data poisoning.",
    fix:"Add an IoT Gateway (AWS IoT Core, Azure IoT Hub) that authenticates devices before enqueuing messages.",
    check:(src,tgt)=>isType(src,IOT)&&isType(tgt,QUEUE)
  },

  // ══ TIER 2: HIGH — Architecture violations ═══════════════════════════════

  {
    ruleId:"GOV-007", severity:"HIGH",
    message:"Database should not initiate calls to Services — Databases are passive components",
    description:"DBs calling services creates tight coupling, unpredictable flows, and makes debugging nearly impossible.",
    fix:"Use Change Data Capture (Debezium, Maxwell), DB triggers feeding a queue, or a polling Worker.",
    check:(src,tgt)=>isType(src,DB)&&isType(tgt,[...SERVICE,...EXTERNAL,...FRONTEND,...GATEWAY,...QUEUE])
  },
  {
    ruleId:"GOV-008", severity:"HIGH",
    message:"Shared Database anti-pattern — multiple Services sharing one Database",
    description:"Shared DBs couple services at the data layer, preventing independent deployments and scaling.",
    fix:"Give each service its own database. Share data via APIs or async events (Event-Driven Architecture).",
    check:(src,tgt,nodes,edges)=>{
      if(!isType(src,[...SERVICE,...WORKER]))return false;
      if(!isType(tgt,DB))return false;
      return nodes.some(n=>isType(n,[...SERVICE,...WORKER])&&n.id!==src.id&&edges.some(e=>e.source===n.id&&e.target===tgt.id));
    }
  },
  {
    ruleId:"GOV-009", severity:"HIGH",
    message:"Queue should not directly write to Database — use a Worker or Consumer Service",
    description:"Queues are transport layers. Business logic and DB writes must be handled by a consumer.",
    fix:"Add a Worker/Consumer service between the Queue and Database.",
    check:(src,tgt)=>isType(src,QUEUE)&&isType(tgt,DB)
  },
  {
    ruleId:"GOV-010", severity:"HIGH",
    message:"External service should not access internal Cache directly",
    description:"Cache often contains sessions, tokens, and partial data. External access exposes internal state.",
    fix:"Expose cache data only through an authenticated Service API.",
    check:(src,tgt)=>isType(src,EXTERNAL)&&isType(tgt,CACHE)
  },
  {
    ruleId:"GOV-011", severity:"HIGH",
    message:"External service is calling an internal Service without going through an API Gateway",
    description:"Bypassing the gateway removes rate limiting, authentication, logging, and circuit breaking.",
    fix:"All external traffic must enter through an API Gateway. No direct external-to-service calls.",
    check:(src,tgt)=>isType(src,EXTERNAL)&&isType(tgt,[...SERVICE,...WORKER])
  },
  {
    ruleId:"GOV-012", severity:"HIGH",
    message:"IoT/Device is calling an internal Service directly without a Gateway",
    description:"Unmanaged device connections bypass fleet authentication, firmware validation, and rate limiting.",
    fix:"Use an IoT Gateway or MQTT broker as the single entry point for all device communication.",
    check:(src,tgt)=>isType(src,IOT)&&isType(tgt,SERVICE)
  },
  {
    ruleId:"GOV-013", severity:"HIGH",
    message:"Database should not push directly to a Message Queue",
    description:"DB-to-queue coupling makes the database responsible for event propagation — a reliability risk.",
    fix:"Use CDC (Debezium, AWS DMS) or a polling Worker to publish events from DB changes.",
    check:(src,tgt)=>isType(src,DB)&&isType(tgt,QUEUE)
  },
  {
    ruleId:"GOV-014", severity:"HIGH",
    message:"Search Engine (Elasticsearch/OpenSearch) is directly accessible from Client",
    description:"Search engines often index sensitive data. Direct client access exposes unfiltered search results.",
    fix:"Route search requests through a Service that filters results and enforces access control.",
    check:(src,tgt)=>isType(src,FRONTEND)&&isType(tgt,SEARCH)
  },
  {
    ruleId:"GOV-015", severity:"HIGH",
    message:"Analytics/Tracking service is receiving raw data directly from Client without sanitization",
    description:"Unsanitized analytics events may contain PII, session tokens, or sensitive user data.",
    fix:"Route analytics through a server-side proxy that strips PII before forwarding to analytics vendor.",
    check:(src,tgt)=>isType(src,FRONTEND)&&isType(tgt,ANALYTICS)&&isType(tgt,EXTERNAL)
  },
  {
    ruleId:"GOV-016", severity:"HIGH",
    message:"Payment component is directly accessible from Client without a Service layer",
    description:"Client-side payment handling violates PCI-DSS and enables card data interception.",
    fix:"All payment operations must go through a server-side Service. Use tokenization (Stripe.js, Razorpay).",
    check:(src,tgt)=>isType(src,FRONTEND)&&isType(tgt,PAYMENT)
  },
  {
    ruleId:"GOV-017", severity:"HIGH",
    message:"Worker is calling another Worker directly — use a Queue for async handoff",
    description:"Direct worker-to-worker calls create synchronous coupling in async pipelines and cascading failures.",
    fix:"Publish a message to a Queue. Let the downstream Worker consume it independently.",
    check:(src,tgt)=>isType(src,WORKER)&&isType(tgt,WORKER)
  },
  {
    ruleId:"GOV-018", severity:"HIGH",
    message:"External service is writing directly to an internal Queue",
    description:"Unauthenticated external queue writes allow message injection and event spoofing.",
    fix:"Route external requests through an API Gateway that validates and enqueues messages.",
    check:(src,tgt)=>isType(src,EXTERNAL)&&isType(tgt,QUEUE)
  },

  // ══ TIER 3: MEDIUM — Design warnings ═════════════════════════════════════

  {
    ruleId:"GOV-019", severity:"MEDIUM",
    message:"API Gateway should not directly access a Database — route through a Service layer",
    description:"Gateways handle routing, auth, and rate limiting — not data persistence logic.",
    fix:"Add a dedicated Service between the Gateway and Database.",
    check:(src,tgt)=>isType(src,GATEWAY)&&isType(tgt,DB)
  },
  {
    ruleId:"GOV-020", severity:"MEDIUM",
    message:"Client should not publish to a Queue directly — use an API as intermediary",
    description:"Direct client-to-queue bypasses validation, authentication, and rate limiting.",
    fix:"Add an API endpoint that validates the request before enqueuing.",
    check:(src,tgt)=>isType(src,FRONTEND)&&isType(tgt,QUEUE)
  },
  {
    ruleId:"GOV-021", severity:"MEDIUM",
    message:"Cache should not write to Database directly — use a Service layer",
    description:"Cache write-back to DB should flow through business logic for validation.",
    fix:"Use a Service or Worker to handle cache invalidation and DB writes.",
    check:(src,tgt)=>isType(src,CACHE)&&isType(tgt,DB)
  },
  {
    ruleId:"GOV-022", severity:"MEDIUM",
    message:"API Gateway chaining detected — avoid routing from one Gateway to another",
    description:"Gateway chaining adds latency, complexity, and creates single points of failure.",
    fix:"Consolidate to a single Gateway or use a service mesh for internal routing.",
    check:(src,tgt)=>isType(src,GATEWAY)&&isType(tgt,GATEWAY)
  },
  {
    ruleId:"GOV-023", severity:"MEDIUM",
    message:"Client should not call Workers directly — use a Queue or API as intermediary",
    description:"Clients calling workers directly creates synchronous coupling for async operations.",
    fix:"Route through an API that enqueues the job, or use a Queue directly.",
    check:(src,tgt)=>isType(src,FRONTEND)&&isType(tgt,WORKER)
  },
  {
    ruleId:"GOV-024", severity:"MEDIUM",
    message:"Client is directly accessing Cache — route through a Service",
    description:"Direct cache access can return stale, unvalidated, or sensitive cached data to clients.",
    fix:"Add a Service layer that reads from cache and validates data before returning.",
    check:(src,tgt)=>isType(src,FRONTEND)&&isType(tgt,CACHE)
  },
  {
    ruleId:"GOV-025", severity:"MEDIUM",
    message:"Monitoring/Logging service is receiving raw Database output directly",
    description:"Raw DB output in logs can expose PII, credentials, and sensitive business data.",
    fix:"Use structured logging with PII masking before sending data to monitoring systems.",
    check:(src,tgt)=>isType(src,DB)&&isType(tgt,MONITOR)
  },
  {
    ruleId:"GOV-026", severity:"MEDIUM",
    message:"Auth service is sending data to an External service — verify scope",
    description:"Auth services forwarding data externally may leak identity tokens or session data.",
    fix:"Ensure OAuth/SSO integrations are explicitly scoped and only share non-sensitive tokens.",
    check:(src,tgt)=>isType(src,AUTH)&&isType(tgt,EXTERNAL)
  },
  {
    ruleId:"GOV-027", severity:"MEDIUM",
    message:"IoT/Device is directly accessing an Auth service without a Gateway",
    description:"Devices authenticating directly to auth services bypass fleet-level access policies.",
    fix:"Use device certificates (mTLS) via an IoT Gateway. Don't expose auth services to devices.",
    check:(src,tgt)=>isType(src,IOT)&&isType(tgt,AUTH)
  },
  {
    ruleId:"GOV-028", severity:"MEDIUM",
    message:"Admin panel is directly connected to Database without a Service layer",
    description:"Admin-to-DB without a service layer means no audit trail, no validation, and unrestricted access.",
    fix:"Route admin DB operations through a Service that logs every action with user context.",
    check:(src,tgt)=>isType(src,ADMIN)&&isType(tgt,DB)
  },

  // ══ TIER 4: LOW — Advisory recommendations ════════════════════════════════

  {
    ruleId:"GOV-029", severity:"LOW",
    message:"Service is calling an External service directly without a Gateway — consider adding circuit breaking",
    description:"Direct service-to-external calls with no circuit breaker can cascade failures across the system.",
    fix:"Add an API Gateway or service mesh (Istio, Linkerd) with circuit breaking and retry policies.",
    check:(src,tgt)=>isType(src,SERVICE)&&isType(tgt,EXTERNAL)
  },
  {
    ruleId:"GOV-030", severity:"LOW",
    message:"IoT/Device is sending telemetry to an External service directly",
    description:"Device data bypassing your platform means no control over data residency or vendor lock-in.",
    fix:"Route all device telemetry through your internal platform before forwarding to external analytics.",
    check:(src,tgt)=>isType(src,IOT)&&isType(tgt,EXTERNAL)
  },
];

const SEVERITY_ORDER = { CRITICAL:0, HIGH:1, MEDIUM:2, LOW:3 };

export function evaluateGraph(nodes, edges) {
  const violations = [];
  const nodeMap = {};
  for (const n of nodes) nodeMap[n.id] = n;

  for (const edge of edges) {
    const src = nodeMap[edge.source];
    const tgt = nodeMap[edge.target];
    if (!src || !tgt) continue;

    for (const rule of RULES) {
      try {
        if (rule.check(src, tgt, nodes, edges)) {
          violations.push({
            ruleId:      rule.ruleId,
            severity:    rule.severity,
            message:     rule.message,
            description: rule.description || "",
            fix:         rule.fix || "",
            source:      edge.source,
            target:      edge.target,
          });
          break;
        }
      } catch {}
    }
  }

  violations.sort((a,b)=>(SEVERITY_ORDER[a.severity]??9)-(SEVERITY_ORDER[b.severity]??9));
  return violations;
}

export function checkEdge(sourceNode, targetNode, nodes, edges) {
  for (const rule of RULES) {
    try {
      if (rule.check(sourceNode, targetNode, nodes, edges)) {
        return { ruleId:rule.ruleId, severity:rule.severity, message:rule.message, description:rule.description||"", fix:rule.fix||"", source:sourceNode.id, target:targetNode.id };
      }
    } catch {}
  }
  return null;
}

export function getAllRules() {
  return RULES.map(r=>({ ruleId:r.ruleId, severity:r.severity, message:r.message, description:r.description||"", fix:r.fix||"" }));
}

export const getRules = getAllRules;

export const SEVERITY = {
  CRITICAL: { priority:4, color:"#ef4444", bg:"#1a0808", border:"#2a1010", label:"Critical" },
  HIGH:     { priority:3, color:"#f97316", bg:"#1a1008", border:"#2a1a10", label:"High"     },
  MEDIUM:   { priority:2, color:"#f59e0b", bg:"#1a1508", border:"#2a2010", label:"Medium"   },
  LOW:      { priority:1, color:"#84cc16", bg:"#0f1a08", border:"#182810", label:"Low"      },
};
