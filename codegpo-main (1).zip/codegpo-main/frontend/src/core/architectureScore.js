// ── Architecture Score Calculator ─────────────────────────
const SEVERITY_DEDUCTION = {
  CRITICAL: 20,
  HIGH:     12,
  MEDIUM:    6,
  LOW:       2
};

const GRADE_THRESHOLDS = [
  { min: 95, grade: "A+", color: "#22c55e", status: "Excellent" },
  { min: 90, grade: "A",  color: "#22c55e", status: "Excellent" },
  { min: 80, grade: "B",  color: "#84cc16", status: "Good"      },
  { min: 70, grade: "C",  color: "#f59e0b", status: "Fair"      },
  { min: 55, grade: "D",  color: "#f97316", status: "Poor"      },
  { min: 0,  grade: "F",  color: "#ef4444", status: "Critical"  },
];

export function calculateScore(nodes, edges, violations = []) {
  if (!nodes?.length) return null;

  let score = 100;
  const deductions = [];
  const bonuses = [];

  // ── Deductions per violation ──────────────────────────
  for (const v of violations) {
    const pts = SEVERITY_DEDUCTION[v.severity] ?? 2;
    score -= pts;
    deductions.push({
      label: v.message || `${v.ruleId} violation`,
      severity: v.severity,
      points: pts,
      ruleId: v.ruleId
    });
  }

  // Cap after deductions BEFORE adding bonuses
  score = Math.max(0, score);

  // ── Bonuses for good practices ────────────────────────
  const types = nodes.map(n => (n.type || "").toLowerCase());

  const hasGateway = types.some(t =>
    ["gateway", "api gateway", "proxy", "nginx", "kong"].some(k => t.includes(k))
  );
  const hasService = types.some(t =>
    ["service", "microservice", "backend"].some(k => t.includes(k))
  );
  const hasQueue = types.some(t =>
    ["queue", "kafka", "rabbit", "sqs", "pubsub", "bus"].some(k => t.includes(k))
  );
  const hasCache = types.some(t =>
    ["cache", "redis", "memcached"].some(k => t.includes(k))
  );
  const hasWorker = types.some(t =>
    ["worker", "job", "cron", "consumer"].some(k => t.includes(k))
  );

  const directClientDB = edges.filter(e => {
    const src = nodes.find(n => n.id === e.source);
    const tgt = nodes.find(n => n.id === e.target);
    const srcType = (src?.type || "").toLowerCase();
    const tgtType = (tgt?.type || "").toLowerCase();
    return (
      ["user", "client", "browser", "frontend", "mobile"].some(k => srcType.includes(k)) &&
      ["database", "db", "sql", "mongo", "postgres"].some(k => tgtType.includes(k))
    );
  }).length === 0;

  const externalIsolated = !edges.some(e => {
    const src = nodes.find(n => n.id === e.source);
    const tgt = nodes.find(n => n.id === e.target);
    const srcType = (src?.type || "").toLowerCase();
    const tgtType = (tgt?.type || "").toLowerCase();
    return (
      ["database", "db"].some(k => srcType.includes(k)) &&
      ["external", "vendor", "third"].some(k => tgtType.includes(k))
    );
  });

  if (hasGateway)    bonuses.push({ id: "HAS_GATEWAY",        label: "API Gateway present",           points: 3 });
  if (hasService)    bonuses.push({ id: "HAS_SERVICE_LAYER",  label: "Service layer present",         points: 2 });
  if (hasQueue)      bonuses.push({ id: "HAS_QUEUE",          label: "Async messaging present",       points: 3 });
  if (hasCache)      bonuses.push({ id: "HAS_CACHE",          label: "Caching layer present",         points: 2 });
  if (hasWorker)     bonuses.push({ id: "HAS_WORKER",         label: "Background workers present",    points: 2 });
  if (directClientDB)bonuses.push({ id: "NO_DIRECT_CLIENT_DB",label: "No direct client-DB access",   points: 3 });
  if (externalIsolated)bonuses.push({ id: "EXTERNAL_ISOLATED",label: "External services isolated",   points: 2 });
  if (violations.length === 0 && nodes.length >= 3)
    bonuses.push({ id: "FULLY_COMPLIANT", label: "Fully compliant architecture", points: 5 });

  // Apply bonuses — max 50% of bonus points apply when violations exist
  const totalBonused = bonuses.reduce((sum, b) => sum + b.points, 0);
  const effectiveBonused = violations.length > 0
    ? Math.floor(totalBonused * 0.5)
    : totalBonused;
  score = Math.min(100, score + effectiveBonused);
  // If violations exist, hard cap at 95
  if (violations.length > 0) score = Math.min(score, 95);

  const totalDeducted = deductions.reduce((sum, d) => sum + d.points, 0);
  const criticalCount = violations.filter(v => v.severity === "CRITICAL").length;

  // ── Grade ─────────────────────────────────────────────
  const gradeInfo = GRADE_THRESHOLDS.find(g => score >= g.min)
    || GRADE_THRESHOLDS[GRADE_THRESHOLDS.length - 1];

  // ── Breakdown ─────────────────────────────────────────
  const breakdown = {
    critical: violations.filter(v => v.severity === "CRITICAL").length,
    high:     violations.filter(v => v.severity === "HIGH").length,
    medium:   violations.filter(v => v.severity === "MEDIUM").length,
    low:      violations.filter(v => v.severity === "LOW").length,
  };

  const complianceRate = edges.length > 0
    ? Math.round(((edges.length - violations.length) / edges.length) * 100)
    : 100;

  // ── Insights ──────────────────────────────────────────
  const insights = [];
  if (breakdown.critical > 0)
    insights.push({ type: "danger", text: `${breakdown.critical} critical violation${breakdown.critical > 1 ? "s" : ""} — fix immediately` });
  if (breakdown.high > 0)
    insights.push({ type: "warn",   text: `${breakdown.high} high severity violation${breakdown.high > 1 ? "s" : ""} need attention` });
  if (complianceRate === 100 && violations.length === 0)
    insights.push({ type: "success", text: "All connections comply with governance rules" });
  if (nodes.length >= 5 && violations.length === 0)
    insights.push({ type: "success", text: "Well-structured architecture — no violations detected" });

  return {
    score,
    grade:        gradeInfo.grade,
    gradeColor:   gradeInfo.color,
    status:       gradeInfo.status,
    breakdown,
    complianceRate,
    insights,
    deductions,
    bonuses,
    totalDeducted,
    totalBonused,
    violationCount: violations.length,
    criticalCount,
    totalNodes:   nodes.length,
    totalEdges:   edges.length
  };
}
