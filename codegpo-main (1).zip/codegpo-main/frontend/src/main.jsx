import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom/client";
import "./styles/canvas.css";

// ── Global contrast enforcement ──────────────────────────
// Watches the entire DOM and auto-fixes any inline style
// using near-invisible dark colors on dark backgrounds
function enforceContrast() {
  const fixStyle = (el) => {
    const style = el.getAttribute("style");
    if (!style) return;
    let s = style;
    // Bump dark text colors up to readable values
    s = s.replace(/#333(?![0-9a-fA-F])/g, "#666");
    s = s.replace(/#444(?![0-9a-fA-F])/g, "#777");
    s = s.replace(/#555(?![0-9a-fA-F])/g, "#888");
    // Bump tiny font sizes up to minimum readable
    s = s.replace(/font-size:\s*9px/g,  "font-size: 11px");
    s = s.replace(/font-size:\s*10px/g, "font-size: 11px");
    if (s !== style) el.setAttribute("style", s);
  };

  // Fix everything already rendered
  document.querySelectorAll("[style]").forEach(fixStyle);

  // Watch for anything added or changed in future
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((m) => {
      // New nodes added to DOM
      m.addedNodes.forEach((node) => {
        if (node.nodeType !== 1) return;
        if (node.hasAttribute?.("style")) fixStyle(node);
        node.querySelectorAll?.("[style]").forEach(fixStyle);
      });
      // Existing node style attribute changed
      if (m.type === "attributes" && m.attributeName === "style") {
        fixStyle(m.target);
      }
    });
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["style"]
  });
}

function getSharedData() {
  try {
    const params = new URLSearchParams(window.location.search);
    const share = params.get("share");
    if (!share) return null;
    const json = decodeURIComponent(atob(share));
    const payload = JSON.parse(json);
    return {
      project: payload.p || { name: "Untitled" },
      nodes: payload.n
        ? payload.n.map(n => ({ id: n.i, type: n.t, name: n.nm }))
        : [],
      edges: payload.e
        ? payload.e.map(e => ({ source: e.s, target: e.t }))
        : [],
      violations: payload.vl
        ? payload.vl.map(v => ({
            ruleId: v.r,
            severity: v.sv,
            source: v.s,
            target: v.t,
            message: v.m,
            custom: v.c
          }))
        : [],
      score: payload.sc || null,
      timestamp: payload.ts || null
    };
  } catch {
    return null;
  }
}

function Root() {
  // ── Reset password flow ────────────────────────────────
  const urlParams = new URLSearchParams(window.location.search);
  const resetToken = urlParams.get("token");
  if (resetToken && window.location.pathname.includes("reset-password")) {
    const ResetPage = React.lazy(() => import("./pages/ResetPasswordPage"));
    return (
      <React.Suspense fallback={<LoadingScreen />}>
        <ResetPage token={resetToken} />
      </React.Suspense>
    );
  }

  const sharedData = getSharedData();

  // ── Shared read-only view — no auth needed ─────────────
  if (sharedData) {
    const SharedView = React.lazy(() => import("./components/SharedView"));
    return (
      <React.Suspense fallback={<LoadingScreen />}>
        <SharedView data={sharedData} />
      </React.Suspense>
    );
  }

  // ── Normal app flow ────────────────────────────────────
  const [step, setStep] = useState("checking");

  useEffect(() => {
    try {
      // Handle email verification
      const urlParams = new URLSearchParams(window.location.search);
      const verifyToken = urlParams.get("verify");
      if (verifyToken) {
        const API = import.meta.env.VITE_API_URL || "https://codegpo-production-9548.up.railway.app";
        fetch(`${API}/api/auth/verify-email?token=${verifyToken}`)
          .then(r => r.json())
          .then(d => {
            if (d.ok) {
              alert("✅ Email verified! You can now log in.");
              window.history.replaceState({}, "", "/");
            } else {
              alert("❌ Verification link invalid or expired.");
            }
          }).catch(() => {});
      }
      // Alpha gate and disclaimer removed — product is now public
      setStep("app");
    } catch {
      setStep("app");
    }
  }, []);

  if (step === "checking") return <LoadingScreen />;

  // Alpha gate and disclaimer removed

  const App = React.lazy(() => import("./App"));
  return (
    <React.Suspense fallback={<LoadingScreen />}>
      <App />
    </React.Suspense>
  );
}

function LoadingScreen() {
  return (
    <div style={{
      minHeight: "100vh",
      background: "#0d0d0d",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: "16px",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif"
    }}>
      <div style={{
        width: "28px",
        height: "28px",
        border: "2px solid #252525",
        borderTop: "2px solid #888",
        borderRadius: "50%",
        animation: "spin 0.8s linear infinite"
      }} />
      <div style={{ fontSize: "12px", color: "#666" }}>
        Loading CodeGPO...
      </div>
      <style>{"@keyframes spin { to { transform: rotate(360deg); } }"}</style>
    </div>
  );
}

// ── Mount app ────────────────────────────────────────────
const container = document.getElementById("root");
const root = ReactDOM.createRoot(container);

root.render(
  <React.StrictMode>
    <Root />
  </React.StrictMode>
);

// Start contrast enforcement after first render
setTimeout(enforceContrast, 100);
