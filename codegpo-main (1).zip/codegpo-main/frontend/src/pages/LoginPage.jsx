import { useState } from "react";

const API = import.meta.env.VITE_API_URL || "https://codegpo-production-9548.up.railway.app";

function getPasswordStrength(pwd) {
  if (!pwd) return null;
  let score = 0;
  if (pwd.length >= 8) score++;
  if (/[A-Z]/.test(pwd)) score++;
  if (/[0-9]/.test(pwd)) score++;
  if (/[^A-Za-z0-9]/.test(pwd)) score++;
  if (score <= 1) return { label: "Weak", color: "#EF4444" };
  if (score === 2) return { label: "Fair", color: "#F97316" };
  if (score === 3) return { label: "Good", color: "#F59E0B" };
  return { label: "Strong", color: "#22C55E" };
}

export default function LoginPage() {
  const [mode, setMode]       = useState("login"); // login | register | forgot
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState("");
  const [success, setSuccess] = useState("");
  const [showResend, setShowResend] = useState(false);
  const [form, setForm]       = useState({ name:"", email:"", password:"", org_name:"" });

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const submit = async () => {
    setError(""); setSuccess("");

    // Validation
    if (mode === "register") {
      if (!form.name.trim()) { setError("Full name is required"); return; }
      if (!form.org_name.trim()) { setError("Organization name is required"); return; }
    }
    if (!form.email.trim()) { setError("Email is required"); return; }
    if (!form.password) { setError("Password is required"); return; }

    setLoading(true);
    try {
      const endpoint = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const payload  = mode === "login"
        ? { email: form.email, password: form.password }
        : { email: form.email, password: form.password, name: form.name, org_name: form.org_name };

      const r = await fetch(API + endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const d = await r.json();

      if (!r.ok) {
        if (r.status === 403 && d.detail?.includes("verify")) {
          setError("📧 Please verify your email first. Check your inbox.");
          setShowResend(true);
        } else {
          setError(d.detail || "Something went wrong");
        }
        return;
      }

      if (mode === "register") {
        setSuccess("✅ Account created! Check your email to verify your account.");
        setMode("login");
        setForm(f => ({ ...f, password: "" }));
        return;
      }

      localStorage.setItem("codegpo_token", d.access_token);
      localStorage.setItem("codegpo_user", JSON.stringify(d.user));
      window.location.reload();
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const forgotPassword = async () => {
    if (!form.email) { setError("Enter your email first"); return; }
    setLoading(true);
    try {
      await fetch(`${API}/api/auth/forgot-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email })
      });
      setSuccess("✅ Reset link sent! Check your email.");
      setMode("login");
    } catch {
      setError("Failed to send reset email");
    } finally {
      setLoading(false);
    }
  };

  const resendVerification = async () => {
    setLoading(true);
    try {
      await fetch(`${API}/api/auth/resend-verification`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email })
      });
      setSuccess("📧 Verification email resent! Check your inbox.");
      setShowResend(false);
    } catch {
      setError("Failed to resend");
    } finally {
      setLoading(false);
    }
  };

  // Styles
  const S = {
    page:  { minHeight:"100vh", background:"#070711", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"system-ui,sans-serif" },
    left:  { flex:1, padding:"60px", display:"flex", flexDirection:"column", justifyContent:"center", maxWidth:"520px" },
    right: { width:"440px", padding:"40px", background:"#0D0D1F", borderLeft:"1px solid #1A1A35", minHeight:"100vh", display:"flex", flexDirection:"column", justifyContent:"center" },
    inp:   { width:"100%", padding:"12px 14px", background:"#08080F", border:"1px solid #1E1E3A", borderRadius:"10px", color:"#CBD5E1", fontSize:"14px", outline:"none", boxSizing:"border-box", marginBottom:"12px" },
    btn:   { width:"100%", padding:"13px", background:"#7C3AED", border:"none", borderRadius:"10px", color:"#fff", fontSize:"15px", fontWeight:"700", cursor:loading?"not-allowed":"pointer", opacity:loading?0.7:1, marginTop:"4px" },
    lbl:   { fontSize:"11px", color:"#475569", textTransform:"uppercase", letterSpacing:"1px", marginBottom:"6px", display:"block" },
    err:   { background:"rgba(239,68,68,0.08)", border:"1px solid rgba(239,68,68,0.2)", borderRadius:"8px", padding:"10px 14px", fontSize:"13px", color:"#FCA5A5", marginBottom:"12px" },
    suc:   { background:"rgba(34,197,94,0.08)", border:"1px solid rgba(34,197,94,0.2)", borderRadius:"8px", padding:"10px 14px", fontSize:"13px", color:"#86EFAC", marginBottom:"12px" },
  };

  return (
    <div style={S.page}>
      {/* Left — branding */}
      <div style={S.left}>
        <div style={{ fontSize:"24px", fontWeight:"800", color:"#A78BFA", marginBottom:"40px" }}>⚡ CodeGPO</div>
        <div style={{ fontSize:"42px", fontWeight:"900", color:"#fff", lineHeight:1.2, marginBottom:"16px" }}>
          Architecture as Law.<br />
          <span style={{ color:"#7C3AED" }}>Governance as Code.</span>
        </div>
        <div style={{ fontSize:"16px", color:"#475569", marginBottom:"40px", lineHeight:1.6 }}>
          The first tool that catches architecture violations before your code is written.
        </div>
        {[
          "128+ governance rules — real-time",
          "24 compliance frameworks (DPDP, RBI, GDPR, OWASP, ISO 42001...)",
          "AI-powered violation explanation",
          "PDF compliance reports in one click",
        ].map(f => (
          <div key={f} style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"12px" }}>
            <span style={{ color:"#7C3AED", fontSize:"16px" }}>✓</span>
            <span style={{ fontSize:"14px", color:"#64748B" }}>{f}</span>
          </div>
        ))}

        {/* Framework badges */}
        <div style={{ display:"flex", gap:"8px", flexWrap:"wrap", marginTop:"28px" }}>
          {["GDPR", "HIPAA", "PCI-DSS", "SOC 2"].map(fw => (
            <div key={fw} style={{
              background:"#12122a", border:"1px solid #1a1a35", borderRadius:"8px",
              padding:"10px 14px", fontSize:"11px", fontWeight:"700", color:"#A78BFA",
              textAlign:"center", minWidth:"64px",
            }}>
              {fw}
            </div>
          ))}
          <div style={{
            background:"transparent", border:"1px solid #1a1a35", borderRadius:"8px",
            padding:"10px 14px", fontSize:"11px", fontWeight:"600", color:"#475569",
            textAlign:"center", minWidth:"64px",
          }}>
            + more
          </div>
        </div>

        {/* 4-step flow */}
        <div style={{ display:"flex", gap:"18px", marginTop:"36px", flexWrap:"wrap" }}>
          {[
            { n:"1", label:"Connect", sub:"Link your GitHub repo" },
            { n:"2", label:"Scan", sub:"Check 128+ rules" },
            { n:"3", label:"Review", sub:"Approve or override" },
            { n:"4", label:"Report", sub:"Audit-ready PDF" },
          ].map((s, i) => (
            <div key={s.n} style={{ display:"flex", alignItems:"center", gap:"18px" }}>
              <div>
                <div style={{ fontSize:"13px", fontWeight:"700", color:"#e5e5e5" }}>
                  {s.n}. {s.label}
                </div>
                <div style={{ fontSize:"10.5px", color:"#475569", marginTop:"2px" }}>{s.sub}</div>
              </div>
              {i < 3 && <span style={{ color:"#334155", fontSize:"14px" }}>→</span>}
            </div>
          ))}
        </div>

        <div style={{ marginTop:"32px", fontSize:"12px", color:"#1E293B" }}>
          codegpo.com · Built in India 🇮🇳
        </div>
      </div>

      {/* Right — form */}
      <div style={S.right}>
        {/* Tabs */}
        <div style={{ display:"flex", marginBottom:"28px", background:"#08080F", borderRadius:"10px", padding:"4px" }}>
          {["login","register"].map(m => (
            <button key={m} onClick={() => { setMode(m); setError(""); setSuccess(""); setShowResend(false); }}
              style={{ flex:1, padding:"10px", background:mode===m?"#7C3AED":"transparent", border:"none", borderRadius:"8px", color:mode===m?"#fff":"#475569", fontSize:"13px", fontWeight:"600", cursor:"pointer", textTransform:"capitalize" }}>
              {m === "login" ? "Sign In" : "Create Account"}
            </button>
          ))}
        </div>

        {/* Title */}
        <div style={{ fontSize:"22px", fontWeight:"800", color:"#fff", marginBottom:"6px" }}>
          {mode === "login" ? "Welcome back" : "Join CodeGPO"}
        </div>
        <div style={{ fontSize:"13px", color:"#475569", marginBottom:"24px" }}>
          {mode === "login" ? "Sign in to your account" : "Start governing your architecture"}
        </div>

        {/* Error / Success */}
        {error   && <div style={S.err}>⚠ {error}</div>}
        {success && <div style={S.suc}>{success}</div>}

        {/* Resend */}
        {showResend && (
          <button onClick={resendVerification} style={{ ...S.btn, background:"#1A0A2E", color:"#A78BFA", border:"1px solid #7C3AED", marginBottom:"12px" }}>
            Resend Verification Email
          </button>
        )}

        {/* Fields */}
        {mode === "register" && (
          <>
            <label style={S.lbl}>Full Name *</label>
            <input style={S.inp} value={form.name} onChange={e => update("name", e.target.value)} placeholder="Your full name" />
          </>
        )}

        <label style={S.lbl}>Email Address *</label>
        <input style={S.inp} type="email" value={form.email} onChange={e => update("email", e.target.value)} placeholder="you@company.com" />

        <label style={S.lbl}>Password *</label>
        <input style={S.inp} type="password" value={form.password} onChange={e => update("password", e.target.value)} placeholder="••••••••" />

        {mode === "register" && form.password && (
          <div style={{ fontSize:"11px", color:getPasswordStrength(form.password)?.color, marginTop:"-8px", marginBottom:"12px" }}>
            Strength: {getPasswordStrength(form.password)?.label}
            {getPasswordStrength(form.password)?.label === "Weak" && " — min 8 chars, 1 uppercase, 1 number"}
          </div>
        )}

        {mode === "register" && (
          <>
            <label style={S.lbl}>Organization / Company *</label>
            <input style={S.inp} value={form.org_name} onChange={e => update("org_name", e.target.value)} placeholder="Your company or team name" />
          </>
        )}

        {mode === "login" && (
          <div style={{ textAlign:"right", marginTop:"-6px", marginBottom:"16px" }}>
            <span onClick={() => setMode("forgot")} style={{ fontSize:"12px", color:"#7C3AED", cursor:"pointer" }}>Forgot password?</span>
          </div>
        )}

        {mode === "forgot" ? (
          <>
            <label style={S.lbl}>Email Address</label>
            <input style={S.inp} type="email" value={form.email} onChange={e => update("email", e.target.value)} placeholder="you@company.com" />
            <button style={S.btn} onClick={forgotPassword} disabled={loading}>
              {loading ? "Sending..." : "Send Reset Link"}
            </button>
            <div style={{ textAlign:"center", marginTop:"14px" }}>
              <span onClick={() => setMode("login")} style={{ fontSize:"12px", color:"#475569", cursor:"pointer" }}>← Back to Sign In</span>
            </div>
          </>
        ) : (
          <button style={S.btn} onClick={submit} disabled={loading}>
            {loading ? "Please wait..." : mode === "login" ? "Sign In →" : "Create Account →"}
          </button>
        )}

        {mode === "register" && (
          <div style={{ fontSize:"11px", color:"#334155", marginTop:"12px", lineHeight:1.5 }}>
            By creating an account you agree to our{" "}
            <a href="/terms.html" style={{ color:"#7C3AED" }}>Terms</a> and{" "}
            <a href="/privacy.html" style={{ color:"#7C3AED" }}>Privacy Policy</a>.
          </div>
        )}

        <div style={{ textAlign:"center", marginTop:"20px", fontSize:"11px", color:"#1E293B" }}>
          Free 3-day trial · No credit card required
        </div>
      </div>
    </div>
  );
}
