import { useState, useEffect } from "react";

const API_BASE = import.meta.env.VITE_API_URL || "https://codegpo-production-9548.up.railway.app";

export default function ResetPasswordPage({ token }) {
  const [password, setPassword]   = useState("");
  const [confirm, setConfirm]     = useState("");
  const [loading, setLoading]     = useState(false);
  const [error, setError]         = useState("");
  const [success, setSuccess]     = useState(false);
  const [validating, setValidating] = useState(true);
  const [tokenValid, setTokenValid] = useState(false);

  useEffect(() => {
    // Validate token on mount
    fetch(`${API_BASE}/api/auth/reset-password/validate?token=${token}`)
      .then(r => r.json())
      .then(data => {
        setTokenValid(data.valid);
        if (!data.valid) setError(data.reason || "Invalid or expired reset link.");
      })
      .catch(() => setError("Could not validate reset link."))
      .finally(() => setValidating(false));
  }, [token]);

  const handleSubmit = async () => {
    if (!password) { setError("Enter a new password"); return; }
    if (password.length < 6) { setError("Password must be at least 6 characters"); return; }
    if (password !== confirm) { setError("Passwords do not match"); return; }

    setLoading(true); setError("");
    try {
      const res = await fetch(`${API_BASE}/api/auth/reset-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, new_password: password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "Reset failed");
      setSuccess(true);
      setTimeout(() => {
        window.location.href = "/";
      }, 2500);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const styles = {
    root: { minHeight:"100vh", background:"#08080F", display:"flex", alignItems:"center", justifyContent:"center", padding:"20px", fontFamily:"'Inter',sans-serif" },
    card: { background:"#0D0D1F", border:"1px solid #1A1A35", borderRadius:"16px", padding:"40px", width:"400px" },
    logo: { fontSize:"22px", fontWeight:"800", color:"#fff", marginBottom:"28px" },
    title: { fontSize:"22px", fontWeight:"800", color:"#fff", marginBottom:"6px" },
    sub: { fontSize:"13px", color:"#475569", marginBottom:"24px" },
    label: { fontSize:"11px", color:"#64748B", textTransform:"uppercase", letterSpacing:"1px", fontWeight:"600", marginBottom:"6px", display:"block" },
    input: { width:"100%", padding:"10px 14px", background:"#08080F", border:"1px solid #1E1E3A", borderRadius:"8px", color:"#CBD5E1", fontSize:"14px", outline:"none", boxSizing:"border-box", marginBottom:"14px" },
    btn: { width:"100%", padding:"12px", background:"linear-gradient(135deg,#6D28D9,#7C3AED)", border:"none", borderRadius:"8px", color:"#fff", fontSize:"14px", fontWeight:"700", cursor:"pointer" },
    error: { background:"rgba(239,68,68,0.08)", border:"1px solid rgba(239,68,68,0.25)", borderRadius:"8px", padding:"10px 14px", fontSize:"13px", color:"#FCA5A5", marginBottom:"12px" },
    success: { background:"rgba(16,185,129,0.08)", border:"1px solid rgba(16,185,129,0.25)", borderRadius:"8px", padding:"16px", fontSize:"13px", color:"#6EE7B7", textAlign:"center" },
  };

  if (validating) return (
    <div style={styles.root}>
      <div style={{ color:"#475569", fontSize:"14px" }}>Validating reset link...</div>
    </div>
  );

  return (
    <div style={styles.root}>
      <div style={styles.card}>
        <div style={styles.logo}>⚡ Code<span style={{color:"#7C3AED"}}>GPO</span></div>

        {success ? (
          <div style={styles.success}>
            ✓ Password reset successful!<br/>
            <span style={{fontSize:"12px",color:"#4ade80",marginTop:"8px",display:"block"}}>Redirecting to login...</span>
          </div>
        ) : !tokenValid ? (
          <>
            <div style={styles.title}>Link Expired</div>
            <div style={styles.sub}>This reset link is invalid or has expired.</div>
            <div style={styles.error}>{error}</div>
            <a href="/" style={{...styles.btn, display:"block", textAlign:"center", textDecoration:"none"}}>← Back to Login</a>
          </>
        ) : (
          <>
            <div style={styles.title}>Reset Password</div>
            <div style={styles.sub}>Enter your new password below</div>

            <label style={styles.label}>New Password</label>
            <input type="password" value={password} onChange={e=>setPassword(e.target.value)}
              placeholder="Min 6 characters" style={styles.input}
              onKeyDown={e=>e.key==="Enter"&&handleSubmit()}/>

            <label style={styles.label}>Confirm Password</label>
            <input type="password" value={confirm} onChange={e=>setConfirm(e.target.value)}
              placeholder="Repeat password" style={styles.input}
              onKeyDown={e=>e.key==="Enter"&&handleSubmit()}/>

            {error && <div style={styles.error}>⚠ {error}</div>}

            <button onClick={handleSubmit} disabled={loading}
              style={{...styles.btn, opacity:loading?0.7:1, cursor:loading?"not-allowed":"pointer"}}>
              {loading ? "Resetting..." : "Reset Password →"}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
