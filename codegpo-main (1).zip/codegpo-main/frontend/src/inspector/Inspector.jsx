import { useEffect, useState, useRef } from "react";
import { useGraphStore } from "../state/graphStore";
import { explainViolation } from "../graphrag/graphragEngine";

const SEVERITY_CONFIG = {
  CRITICAL: { color: "#ef4444", bg: "#1a0808", border: "#2a1010", label: "Critical" },
  HIGH:     { color: "#f97316", bg: "#1a1008", border: "#2a1a10", label: "High"     },
  MEDIUM:   { color: "#f59e0b", bg: "#1a1508", border: "#2a2010", label: "Medium"   },
  LOW:      { color: "#84cc16", bg: "#0f1a08", border: "#182810", label: "Low"      },
};

const TYPE_ICONS = {
  service:  { icon: "⚙",  color: "#7c3aed" },
  api:      { icon: "◈",  color: "#22c55e" },
  database: { icon: "🗄", color: "#0ea5e9" },
  db:       { icon: "🗄", color: "#0ea5e9" },
  queue:    { icon: "⇌",  color: "#ec4899" },
  cache:    { icon: "⚡", color: "#06b6d4" },
  gateway:  { icon: "◉",  color: "#f97316" },
  worker:   { icon: "↻",  color: "#8b5cf6" },
  external: { icon: "⊕",  color: "#64748b" },
  user:     { icon: "◎",  color: "#f59e0b" },
  client:   { icon: "◎",  color: "#f59e0b" },
  frontend: { icon: "▣",  color: "#f59e0b" },
};

function getTypeConfig(type) {
  if (!type) return { icon: "◆", color: "#888" };
  const t = type.toLowerCase();
  for (const [key, cfg] of Object.entries(TYPE_ICONS)) {
    if (t.includes(key)) return cfg;
  }
  return { icon: "◆", color: "#888" };
}

function NodeChip({ node }) {
  if (!node) return null;
  const cfg = getTypeConfig(node.type);
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: "7px",
      padding: "7px 10px",
      background: "#12122a",
      border: "1px solid #1a1a35",
      borderRadius: "8px",
      minWidth: 0
    }}>
      <div style={{
        width: "24px", height: "24px",
        borderRadius: "6px",
        background: cfg.color + "22",
        border: `1px solid ${cfg.color}44`,
        display: "flex", alignItems: "center",
        justifyContent: "center",
        fontSize: "12px", flexShrink: 0
      }}>
        {cfg.icon}
      </div>
      <div style={{ minWidth: 0 }}>
        <div style={{
          fontSize: "12px", fontWeight: "600",
          color: "#e5e5e5",
          whiteSpace: "nowrap", overflow: "hidden",
          textOverflow: "ellipsis"
        }}>
          {node.name}
        </div>
        <div style={{ fontSize: "10px", color: cfg.color, fontWeight: "600" }}>
          {node.type?.toUpperCase()}
        </div>
      </div>
    </div>
  );
}

function SeverityBadge({ severity }) {
  const cfg = SEVERITY_CONFIG[severity] || SEVERITY_CONFIG.LOW;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: "4px",
      padding: "2px 8px",
      background: cfg.bg,
      border: `1px solid ${cfg.border}`,
      borderRadius: "6px",
      fontSize: "10px", fontWeight: "700",
      color: cfg.color,
      letterSpacing: "0.5px"
    }}>
      <span style={{
        width: "5px", height: "5px",
        borderRadius: "50%",
        background: cfg.color,
        display: "inline-block"
      }} />
      {cfg.label.toUpperCase()}
    </span>
  );
}

function ViolationCard({ violation, nodes, onExplain, isExpanded, onToggle }) {
  const src = nodes.find(n => n.id === violation.source);
  const tgt = nodes.find(n => n.id === violation.target);
  const cfg = SEVERITY_CONFIG[violation.severity] || SEVERITY_CONFIG.LOW;

  return (
    <div style={{
      background: cfg.bg,
      border: `1px solid ${cfg.border}`,
      borderRadius: "10px",
      overflow: "hidden",
      transition: "border-color 0.15s"
    }}>
      {/* Header row */}
      <button
        onClick={onToggle}
        style={{
          width: "100%", padding: "10px 12px",
          background: "transparent", border: "none",
          cursor: "pointer", textAlign: "left",
          display: "flex", alignItems: "center",
          gap: "8px"
        }}
      >
        <SeverityBadge severity={violation.severity} />
        <span style={{
          fontSize: "11px", color: "#666",
          fontFamily: "monospace", fontWeight: "600"
        }}>
          {violation.ruleId}
        </span>
        <span style={{
          marginLeft: "auto", color: "#555",
          fontSize: "12px", flexShrink: 0
        }}>
          {isExpanded ? "▲" : "▼"}
        </span>
      </button>

      {/* Connection */}
      <div style={{ padding: "0 12px 10px" }}>
        <div style={{
          fontSize: "11px", color: "#888",
          display: "flex", alignItems: "center", gap: "6px"
        }}>
          <span style={{ color: cfg.color, fontWeight: "600" }}>
            {src?.name || violation.source}
          </span>
          <span style={{ color: "#444" }}>→</span>
          <span style={{ color: cfg.color, fontWeight: "600" }}>
            {tgt?.name || violation.target}
          </span>
        </div>
      </div>

      {/* Expanded detail */}
      {isExpanded && (
        <div style={{
          padding: "10px 12px 12px",
          borderTop: `1px solid ${cfg.border}`
        }}>
          <p style={{
            fontSize: "12px", color: "#aaa",
            margin: "0 0 12px", lineHeight: "1.6"
          }}>
            {violation.message}
          </p>
          <button
            onClick={() => onExplain(violation, src, tgt)}
            style={{
              background: "transparent",
              border: `1px solid ${cfg.color}44`,
              color: cfg.color,
              padding: "6px 12px", borderRadius: "6px",
              cursor: "pointer", fontSize: "11px",
              fontWeight: "600", transition: "all 0.15s",
              width: "100%"
            }}
            onMouseEnter={e => e.currentTarget.style.background = cfg.color + "22"}
            onMouseLeave={e => e.currentTarget.style.background = "transparent"}
          >
            ✦ Explain with GraphRAG
          </button>
        </div>
      )}
    </div>
  );
}

export default function Inspector({ allViolations = [] }) {
  const { selectedEdge, selectedNode, nodes } = useGraphStore();
  const [expandedId, setExpandedId] = useState(null);
  const [aiExplanation, setAiExplanation] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("violations"); // violations | selected
  const prevEdgeRef = useRef(null);

  // Auto-switch tab when something is selected
  useEffect(() => {
    if (selectedEdge || selectedNode) setActiveTab("selected");
    else setActiveTab("violations");
  }, [selectedEdge, selectedNode]);

  // Clear AI explanation on edge change
  useEffect(() => {
    if (selectedEdge !== prevEdgeRef.current) {
      setAiExplanation(null);
      prevEdgeRef.current = selectedEdge;
    }
  }, [selectedEdge]);

  const handleExplain = async (violation, srcNode, tgtNode) => {
    setAiLoading(true);
    setAiExplanation(null);
    try {
      const text = await explainViolation({
        sourceNode: srcNode,
        targetNode: tgtNode,
        rule: violation
      });
      setAiExplanation(text);
    } catch {
      setAiExplanation("Could not connect to AI. Make sure the backend is running.");
    }
    setAiLoading(false);
  };

  const sourceNode = selectedEdge ? nodes.find(n => n.id === selectedEdge.source) : null;
  const targetNode = selectedEdge ? nodes.find(n => n.id === selectedEdge.target) : null;

  const edgeViolation = selectedEdge
    ? allViolations.find(v => v.source === selectedEdge.source && v.target === selectedEdge.target)
    : null;

  const criticalCount = allViolations.filter(v => v.severity === "CRITICAL").length;
  const highCount     = allViolations.filter(v => v.severity === "HIGH").length;

  return (
    <div style={{
      width: "290px",
      background: "#0d0d1f",
      borderLeft: "1px solid #1a1a1a",
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      flexShrink: 0
    }}>

      {/* Header */}
      <div style={{
        padding: "16px 16px 0",
        borderBottom: "1px solid #1a1a1a"
      }}>
        <div style={{
          fontSize: "11px", fontWeight: "700",
          color: "#555", textTransform: "uppercase",
          letterSpacing: "0.8px", marginBottom: "12px"
        }}>
          Inspector
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: "2px" }}>
          {[
            {
              id: "violations",
              label: `Violations`,
              count: allViolations.length
            },
            {
              id: "selected",
              label: "Selected"
            }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                flex: 1, padding: "7px 8px",
                background: "transparent", border: "none",
                borderBottom: activeTab === tab.id
                  ? "2px solid #e5e5e5"
                  : "2px solid transparent",
                color: activeTab === tab.id ? "#e5e5e5" : "#555",
                cursor: "pointer", fontSize: "12px",
                fontWeight: activeTab === tab.id ? "600" : "400",
                transition: "all 0.15s",
                display: "flex", alignItems: "center",
                justifyContent: "center", gap: "6px"
              }}
            >
              {tab.label}
              {tab.count > 0 && (
                <span style={{
                  background: criticalCount > 0 ? "#ef444422" : "#1a1a35",
                  border: `1px solid ${criticalCount > 0 ? "#ef444433" : "#252525"}`,
                  color: criticalCount > 0 ? "#ef4444" : "#666",
                  fontSize: "10px", fontWeight: "700",
                  padding: "1px 6px", borderRadius: "10px"
                }}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div style={{
        flex: 1, overflowY: "auto",
        padding: "14px"
      }}>

        {/* ── VIOLATIONS TAB ──────────────────────────── */}
        {activeTab === "violations" && (
          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>

            {/* Summary row */}
            {allViolations.length > 0 && (
              <div style={{
                display: "flex", gap: "6px",
                marginBottom: "4px"
              }}>
                {criticalCount > 0 && (
                  <div style={{
                    flex: 1, padding: "8px",
                    background: "#1a0808",
                    border: "1px solid #2a1010",
                    borderRadius: "8px", textAlign: "center"
                  }}>
                    <div style={{
                      fontSize: "18px", fontWeight: "800",
                      color: "#ef4444", lineHeight: 1
                    }}>
                      {criticalCount}
                    </div>
                    <div style={{ fontSize: "10px", color: "#854444", marginTop: "2px" }}>
                      CRITICAL
                    </div>
                  </div>
                )}
                {highCount > 0 && (
                  <div style={{
                    flex: 1, padding: "8px",
                    background: "#1a1008",
                    border: "1px solid #2a1a10",
                    borderRadius: "8px", textAlign: "center"
                  }}>
                    <div style={{
                      fontSize: "18px", fontWeight: "800",
                      color: "#f97316", lineHeight: 1
                    }}>
                      {highCount}
                    </div>
                    <div style={{ fontSize: "10px", color: "#854422", marginTop: "2px" }}>
                      HIGH
                    </div>
                  </div>
                )}
                {allViolations.length - criticalCount - highCount > 0 && (
                  <div style={{
                    flex: 1, padding: "8px",
                    background: "#12122a",
                    border: "1px solid #1a1a35",
                    borderRadius: "8px", textAlign: "center"
                  }}>
                    <div style={{
                      fontSize: "18px", fontWeight: "800",
                      color: "#888", lineHeight: 1
                    }}>
                      {allViolations.length - criticalCount - highCount}
                    </div>
                    <div style={{ fontSize: "10px", color: "#555", marginTop: "2px" }}>
                      OTHER
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Violation list */}
            {allViolations.length === 0 ? (
              <div style={{
                padding: "32px 16px", textAlign: "center"
              }}>
                <div style={{ fontSize: "24px", marginBottom: "10px" }}>✓</div>
                <div style={{
                  fontSize: "13px", fontWeight: "600",
                  color: "#5a9e6f", marginBottom: "6px"
                }}>
                  All compliant
                </div>
                <div style={{ fontSize: "11px", color: "#555", lineHeight: "1.6" }}>
                  No governance violations detected in this architecture.
                </div>
              </div>
            ) : (
              allViolations.map((v, i) => {
                const vid = `${v.source}-${v.target}-${v.ruleId}`;
                return (
                  <ViolationCard
                    key={vid}
                    violation={v}
                    nodes={nodes}
                    isExpanded={expandedId === vid}
                    onToggle={() => setExpandedId(expandedId === vid ? null : vid)}
                    onExplain={handleExplain}
                  />
                );
              })
            )}

            {/* AI explanation */}
            {(aiLoading || aiExplanation) && (
              <div style={{
                padding: "12px",
                background: "#0a1929",
                border: "1px solid #0e2a3a",
                borderRadius: "10px",
                marginTop: "4px"
              }}>
                <div style={{
                  fontSize: "11px", color: "#0ea5e9",
                  fontWeight: "600", marginBottom: "8px",
                  display: "flex", alignItems: "center", gap: "6px"
                }}>
                  <span>✦</span> GraphRAG Analysis
                </div>
                {aiLoading ? (
                  <div style={{
                    display: "flex", gap: "4px",
                    alignItems: "center"
                  }}>
                    {[0,1,2].map(i => (
                      <div key={i} style={{
                        width: "6px", height: "6px",
                        borderRadius: "50%",
                        background: "#0ea5e9",
                        animation: `dot 1s ease-in-out ${i * 0.2}s infinite`,
                        opacity: 0.5
                      }} />
                    ))}
                    <style>{`
                      @keyframes dot {
                        0%, 100% { opacity: 0.3; transform: scale(0.8); }
                        50%      { opacity: 1;   transform: scale(1.2); }
                      }
                    `}</style>
                  </div>
                ) : (
                  <p style={{
                    fontSize: "12px", color: "#94a3b8",
                    margin: 0, lineHeight: "1.7"
                  }}>
                    {aiExplanation}
                  </p>
                )}
              </div>
            )}
          </div>
        )}

        {/* ── SELECTED TAB ────────────────────────────── */}
        {activeTab === "selected" && (
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>

            {/* Nothing selected */}
            {!selectedEdge && !selectedNode && (
              <div style={{
                padding: "32px 16px", textAlign: "center"
              }}>
                <div style={{ fontSize: "24px", marginBottom: "10px", color: "#333" }}>◈</div>
                <div style={{ fontSize: "13px", color: "#555", lineHeight: "1.6" }}>
                  Click any node or connection on the canvas to inspect it
                </div>
              </div>
            )}

            {/* Node selected */}
            {selectedNode && !selectedEdge && (
              <>
                <div style={{
                  fontSize: "11px", color: "#555",
                  fontWeight: "600", textTransform: "uppercase",
                  letterSpacing: "0.8px"
                }}>
                  Component
                </div>
                <NodeChip node={selectedNode} />

                {/* Node violations */}
                {(() => {
                  const nodeViolations = allViolations.filter(
                    v => v.source === selectedNode.id || v.target === selectedNode.id
                  );
                  return nodeViolations.length > 0 ? (
                    <>
                      <div style={{
                        fontSize: "11px", color: "#555",
                        fontWeight: "600", textTransform: "uppercase",
                        letterSpacing: "0.8px", marginTop: "6px"
                      }}>
                        Violations on this node ({nodeViolations.length})
                      </div>
                      {nodeViolations.map((v, i) => {
                        const vid = `${v.source}-${v.target}-${v.ruleId}`;
                        return (
                          <ViolationCard
                            key={vid}
                            violation={v}
                            nodes={nodes}
                            isExpanded={expandedId === vid}
                            onToggle={() => setExpandedId(expandedId === vid ? null : vid)}
                            onExplain={handleExplain}
                          />
                        );
                      })}
                    </>
                  ) : (
                    <div style={{
                      padding: "12px",
                      background: "#0f1a12",
                      border: "1px solid #1a2e1e",
                      borderRadius: "8px",
                      fontSize: "12px", color: "#5a9e6f"
                    }}>
                      ✓ No violations on this component
                    </div>
                  );
                })()}
              </>
            )}

            {/* Edge selected */}
            {selectedEdge && (
              <>
                <div style={{
                  fontSize: "11px", color: "#555",
                  fontWeight: "600", textTransform: "uppercase",
                  letterSpacing: "0.8px"
                }}>
                  Connection
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
                  <NodeChip node={sourceNode} />
                  <div style={{
                    display: "flex", alignItems: "center",
                    gap: "8px", padding: "0 10px"
                  }}>
                    <div style={{
                      flex: 1, height: "1px",
                      background: edgeViolation ? "#cc444422" : "#1a1a35"
                    }} />
                    <span style={{
                      fontSize: "14px",
                      color: edgeViolation ? "#cc4444" : "#333"
                    }}>
                      {edgeViolation ? "⚠" : "→"}
                    </span>
                    <div style={{
                      flex: 1, height: "1px",
                      background: edgeViolation ? "#cc444422" : "#1a1a35"
                    }} />
                  </div>
                  <NodeChip node={targetNode} />
                </div>

                {/* Edge violation or compliant */}
                {edgeViolation ? (
                  <ViolationCard
                    violation={edgeViolation}
                    nodes={nodes}
                    isExpanded={true}
                    onToggle={() => {}}
                    onExplain={handleExplain}
                  />
                ) : (
                  <div style={{
                    padding: "12px 14px",
                    background: "#0f1a12",
                    border: "1px solid #1a2e1e",
                    borderRadius: "8px"
                  }}>
                    <div style={{
                      fontSize: "12px", fontWeight: "600",
                      color: "#5a9e6f", marginBottom: "4px"
                    }}>
                      ✓ Compliant Connection
                    </div>
                    <div style={{ fontSize: "11px", color: "#4a7a5a", lineHeight: "1.5" }}>
                      This connection follows all governance rules.
                    </div>
                  </div>
                )}

                {/* AI explanation */}
                {(aiLoading || aiExplanation) && (
                  <div style={{
                    padding: "12px",
                    background: "#0a1929",
                    border: "1px solid #0e2a3a",
                    borderRadius: "10px"
                  }}>
                    <div style={{
                      fontSize: "11px", color: "#0ea5e9",
                      fontWeight: "600", marginBottom: "8px"
                    }}>
                      ✦ GraphRAG Analysis
                    </div>
                    {aiLoading ? (
                      <div style={{ fontSize: "12px", color: "#555" }}>
                        Analyzing...
                      </div>
                    ) : (
                      <p style={{
                        fontSize: "12px", color: "#94a3b8",
                        margin: 0, lineHeight: "1.7"
                      }}>
                        {aiExplanation}
                      </p>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
