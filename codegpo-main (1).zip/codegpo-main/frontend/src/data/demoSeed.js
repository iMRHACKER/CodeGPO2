/**
 * CodeGPO Demo Seeds
 * ──────────────────
 * Company-specific architectures for enterprise demos.
 * Each seed has realistic violations pre-loaded to demonstrate
 * CodeGPO's governance engine in action.
 *
 * Companies:
 *   1. Fintech (default demo)
 *   2. Zypp Electric (EV Fleet / IoT / Mobility)
 *   3. Zopper (InsurTech / Insurance Distribution)
 *   4. Spyne.ai (AI / Automotive Image Processing)
 */

// ════════════════════════════════════════════════════════════════
// SEED 1 — FINTECH (default)
// ════════════════════════════════════════════════════════════════
export const DEMO_SEED = {
  nodes: [
    { id:"demo-web-client",   type:"User",     name:"Web Client",          intent:"React SPA used by customers to manage accounts and initiate payments",             owner:"Frontend Team",  team:"Consumer Products", criticality:"high",     compliance_scope:"",           fields:"[]" },
    { id:"demo-mobile-app",   type:"User",     name:"Mobile App",          intent:"iOS/Android app for mobile banking and payment initiation",                        owner:"Mobile Team",    team:"Consumer Products", criticality:"high",     compliance_scope:"",           fields:"[]" },
    { id:"demo-api-gateway",  type:"Gateway",  name:"API Gateway",         intent:"Central entry point. Handles auth, rate limiting, TLS termination and routing",    owner:"Platform Team",  team:"Infrastructure",    criticality:"critical", compliance_scope:"soc2",       fields:"[]" },
    { id:"demo-auth-service", type:"Service",  name:"Auth Service",        intent:"JWT token issuance, session management and MFA verification",                      owner:"Security Team",  team:"Identity",          criticality:"critical", compliance_scope:"soc2,gdpr",  fields:"[]" },
    { id:"demo-user-service", type:"Service",  name:"User Service",        intent:"Manages user profiles, KYC data, preferences. Primary custodian of PII",          owner:"Identity Team",  team:"Identity",          criticality:"critical", compliance_scope:"gdpr,soc2",  fields:"[]" },
    { id:"demo-payment-svc",  type:"Service",  name:"Payment Service",     intent:"Orchestrates payment flows, validates limits, applies fraud rules",                owner:"Payments Team",  team:"Payments",          criticality:"critical", compliance_scope:"soc2,pci",   fields:"[]" },
    { id:"demo-ledger-svc",   type:"Service",  name:"Ledger Service",      intent:"Maintains immutable double-entry accounting ledger",                               owner:"Payments Team",  team:"Payments",          criticality:"critical", compliance_scope:"soc2",       fields:"[]" },
    { id:"demo-notif-svc",    type:"Service",  name:"Notification Service",intent:"Sends emails, SMS and push notifications from queue events",                      owner:"Platform Team",  team:"Infrastructure",    criticality:"medium",   compliance_scope:"gdpr",       fields:"[]" },
    { id:"demo-public-api",   type:"API",      name:"Public REST API",     intent:"Versioned REST API exposing account data and payment initiation",                  owner:"Platform Team",  team:"Infrastructure",    criticality:"high",     compliance_scope:"soc2,gdpr",  fields:"[]" },
    { id:"demo-user-db",      type:"Database", name:"User DB",             intent:"PostgreSQL storing PII: names, emails, addresses, KYC, credentials",              owner:"Identity Team",  team:"Identity",          criticality:"critical", compliance_scope:"gdpr,soc2",  fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"email",type:"email",required:true},{name:"full_name",type:"string",required:true},{name:"phone",type:"string",required:false},{name:"kyc_status",type:"string",required:true},{name:"gdpr_consent",type:"boolean",required:true},{name:"created_at",type:"datetime",required:true}]) },
    { id:"demo-payment-db",   type:"Database", name:"Payment DB",          intent:"PostgreSQL storing transactions, tokenized card refs, status and audit trail",    owner:"Payments Team",  team:"Payments",          criticality:"critical", compliance_scope:"soc2,pci",   fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"user_id",type:"uuid",required:true},{name:"amount",type:"decimal",required:true},{name:"currency",type:"string",required:true},{name:"status",type:"string",required:true},{name:"reference",type:"string",required:true},{name:"created_at",type:"datetime",required:true}]) },
    { id:"demo-ledger-db",    type:"Database", name:"Ledger DB",           intent:"Append-only PostgreSQL double-entry ledger. Immutable audit trail",               owner:"Payments Team",  team:"Payments",          criticality:"critical", compliance_scope:"soc2",       fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"transaction_id",type:"uuid",required:true},{name:"account_id",type:"uuid",required:true},{name:"entry_type",type:"string",required:true},{name:"amount",type:"decimal",required:true},{name:"balance",type:"decimal",required:true},{name:"created_at",type:"datetime",required:true}]) },
    { id:"demo-notif-queue",  type:"Queue",    name:"Notification Queue",  intent:"RabbitMQ decoupling payment events from notification delivery",                   owner:"Platform Team",  team:"Infrastructure",    criticality:"medium",   compliance_scope:"",           fields:"[]" },
    { id:"demo-session-cache",type:"Cache",    name:"Session Cache",       intent:"Redis storing JWT tokens, rate limit counters and user preferences",               owner:"Security Team",  team:"Identity",          criticality:"high",     compliance_scope:"soc2",       fields:"[]" },
    { id:"demo-stripe",       type:"External", name:"Stripe",              intent:"Third-party payment processor. Receives tokenized card data only",                 owner:"Payments Team",  team:"Payments",          criticality:"high",     compliance_scope:"soc2,pci",   fields:"[]" },
    { id:"demo-sendgrid",     type:"External", name:"SendGrid",            intent:"Transactional email provider. Never receives data directly from clients",          owner:"Platform Team",  team:"Infrastructure",    criticality:"low",      compliance_scope:"gdpr",       fields:"[]" },
  ],
  edges: [
    { source:"demo-web-client",    target:"demo-api-gateway" },
    { source:"demo-mobile-app",    target:"demo-api-gateway" },
    { source:"demo-api-gateway",   target:"demo-auth-service" },
    { source:"demo-api-gateway",   target:"demo-public-api" },
    { source:"demo-public-api",    target:"demo-user-service" },
    { source:"demo-public-api",    target:"demo-payment-svc" },
    { source:"demo-auth-service",  target:"demo-session-cache" },
    { source:"demo-auth-service",  target:"demo-user-db" },
    { source:"demo-user-service",  target:"demo-user-db" },
    { source:"demo-payment-svc",   target:"demo-payment-db" },
    { source:"demo-payment-svc",   target:"demo-ledger-svc" },
    { source:"demo-payment-svc",   target:"demo-notif-queue" },
    { source:"demo-payment-svc",   target:"demo-stripe" },
    { source:"demo-ledger-svc",    target:"demo-ledger-db" },
    { source:"demo-notif-queue",   target:"demo-notif-svc" },
    { source:"demo-notif-svc",     target:"demo-sendgrid" },
  ]
};

// ════════════════════════════════════════════════════════════════
// SEED 2 — ZYPP ELECTRIC
// EV Fleet Management | IoT Telematics | Last-Mile Delivery
// ════════════════════════════════════════════════════════════════
export const ZYPP_SEED = {
  nodes: [
    // Frontends
    { id:"zypp-rider-app",    type:"Mobile",   name:"Rider App",              intent:"iOS/Android app for EV riders — booking, navigation, trip tracking, payments",       owner:"Rider Experience",  team:"Consumer",      criticality:"high",     compliance_scope:"dpdp,gdpr",      fields:"[]" },
    { id:"zypp-partner-app",  type:"Mobile",   name:"Partner/Driver App",     intent:"App for delivery partners — accepts jobs, tracks earnings, manages vehicle status",   owner:"Partner Team",      team:"Operations",    criticality:"high",     compliance_scope:"dpdp",           fields:"[]" },
    { id:"zypp-fleet-portal", type:"Frontend", name:"Fleet Management Portal",intent:"Web portal for fleet managers to monitor vehicles, assign routes, view analytics",    owner:"Fleet Ops Team",    team:"Operations",    criticality:"high",     compliance_scope:"",               fields:"[]" },
    { id:"zypp-admin",        type:"Admin",    name:"Admin Dashboard",        intent:"Internal ops tool for managing fleet, pricing, zones and compliance reports",         owner:"Ops Team",          team:"Operations",    criticality:"critical", compliance_scope:"rbi,dpdp",       fields:"[]" },

    // IoT Devices
    { id:"zypp-ev-vehicle",   type:"IoT",      name:"EV Vehicle (Scooter)",   intent:"Electric vehicle with embedded MCU — sends GPS, battery, speed, trip data via MQTT", owner:"Hardware Team",     team:"IoT",           criticality:"critical", compliance_scope:"dpdp",           fields:"[]" },
    { id:"zypp-gps-tracker",  type:"IoT",      name:"GPS Tracker",            intent:"Dedicated GPS module sending location pings every 5 seconds for fleet tracking",     owner:"Hardware Team",     team:"IoT",           criticality:"high",     compliance_scope:"dpdp",           fields:"[]" },

    // Gateway & Security
    { id:"zypp-api-gateway",  type:"Gateway",  name:"API Gateway (Kong)",     intent:"Kong Gateway handling auth, rate limiting, JWT validation for all client traffic",   owner:"Platform Team",     team:"Infrastructure",criticality:"critical", compliance_scope:"rbi,soc2",       fields:"[]" },
    { id:"zypp-iot-gateway",  type:"Gateway",  name:"IoT Gateway (AWS IoT)",  intent:"AWS IoT Core managing device auth, MQTT broker, message routing from EV fleet",     owner:"IoT Team",          team:"IoT",           criticality:"critical", compliance_scope:"rbi",            fields:"[]" },
    { id:"zypp-auth-svc",     type:"Auth",     name:"Auth Service",           intent:"JWT-based auth, OTP verification for riders/partners, device certificate management",owner:"Security Team",     team:"Security",      criticality:"critical", compliance_scope:"rbi,soc2,dpdp",  fields:"[]" },

    // Services
    { id:"zypp-fleet-svc",    type:"Service",  name:"Fleet Management API",   intent:"Core service for vehicle assignment, availability, maintenance scheduling",          owner:"Fleet Team",        team:"Operations",    criticality:"critical", compliance_scope:"rbi",            fields:"[]" },
    { id:"zypp-telematics-svc",type:"Service", name:"Telematics Service",     intent:"Processes real-time vehicle telemetry — battery, speed, location, diagnostics",     owner:"IoT Team",          team:"IoT",           criticality:"high",     compliance_scope:"dpdp",           fields:"[]" },
    { id:"zypp-trip-svc",     type:"Service",  name:"Trip Service",           intent:"Manages trip lifecycle — start, tracking, end, fare calculation, receipts",          owner:"Rider Team",        team:"Consumer",      criticality:"high",     compliance_scope:"dpdp,gdpr",      fields:"[]" },
    { id:"zypp-payment-svc",  type:"Service",  name:"Payment Service",        intent:"Handles wallet top-ups, trip payments, partner settlements via Razorpay",            owner:"Payments Team",     team:"Finance",       criticality:"critical", compliance_scope:"pci,rbi,dpdp",   fields:"[]" },
    { id:"zypp-notif-svc",    type:"Service",  name:"Notification Service",   intent:"Sends SMS, push notifications for OTP, trip alerts, payment confirmations",         owner:"Platform Team",     team:"Infrastructure",criticality:"medium",   compliance_scope:"dpdp",           fields:"[]" },
    { id:"zypp-analytics-svc",type:"Service",  name:"Analytics Service",      intent:"Aggregates fleet metrics, rider behaviour, route efficiency for business insights",  owner:"Data Team",         team:"Analytics",     criticality:"medium",   compliance_scope:"dpdp",           fields:"[]" },

    // Databases
    { id:"zypp-user-db",      type:"Database", name:"User-Rider DB",        intent:"PostgreSQL storing rider PII — name, phone, Aadhaar ref, location history, KYC",    owner:"Identity Team",     team:"Data",          criticality:"critical", compliance_scope:"dpdp,gdpr,rbi",  fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"phone",type:"string",required:true},{name:"full_name",type:"string",required:true},{name:"aadhaar_ref",type:"string",required:false},{name:"home_location",type:"string",required:false},{name:"dpdp_consent",type:"boolean",required:true},{name:"created_at",type:"datetime",required:true}]) },
    { id:"zypp-fleet-db",     type:"Database", name:"Fleet DB",               intent:"PostgreSQL storing vehicle inventory, battery history, maintenance logs, assignments",owner:"Fleet Team",        team:"Data",          criticality:"critical", compliance_scope:"rbi",            fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"vehicle_id",type:"string",required:true},{name:"status",type:"string",required:true},{name:"battery_pct",type:"integer",required:true},{name:"last_location",type:"string",required:true},{name:"assigned_partner",type:"uuid",required:false},{name:"updated_at",type:"datetime",required:true}]) },
    { id:"zypp-trip-db",      type:"Database", name:"Trip DB",                intent:"PostgreSQL storing trip records, GPS polylines, fare breakdown, payment refs",       owner:"Rider Team",        team:"Data",          criticality:"high",     compliance_scope:"dpdp",           fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"rider_id",type:"uuid",required:true},{name:"vehicle_id",type:"uuid",required:true},{name:"start_location",type:"string",required:true},{name:"end_location",type:"string",required:true},{name:"fare",type:"decimal",required:true},{name:"status",type:"string",required:true},{name:"created_at",type:"datetime",required:true}]) },
    { id:"zypp-payment-db",   type:"Database", name:"Payment DB",             intent:"PostgreSQL storing wallet transactions, UPI payment refs, partner settlement records",owner:"Finance Team",      team:"Data",          criticality:"critical", compliance_scope:"pci,rbi,dpdp",   fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"user_id",type:"uuid",required:true},{name:"amount",type:"decimal",required:true},{name:"type",type:"string",required:true},{name:"upi_ref",type:"string",required:false},{name:"status",type:"string",required:true},{name:"created_at",type:"datetime",required:true}]) },
    { id:"zypp-telemetry-db", type:"Database", name:"Telemetry DB (TimeSeries)",intent:"TimescaleDB storing GPS pings, battery readings, speed, engine events per vehicle",owner:"IoT Team",          team:"Data",          criticality:"high",     compliance_scope:"dpdp",           fields:JSON.stringify([{name:"vehicle_id",type:"uuid",required:true},{name:"timestamp",type:"datetime",required:true,primary:true},{name:"lat",type:"decimal",required:true},{name:"lng",type:"decimal",required:true},{name:"battery_pct",type:"integer",required:true},{name:"speed_kmh",type:"integer",required:true},{name:"event_type",type:"string",required:false}]) },

    // Queue & Cache
    { id:"zypp-kafka",        type:"Queue",    name:"Kafka Event Bus",        intent:"Kafka streaming telemetry events, trip events, and payment events across services",  owner:"Platform Team",     team:"Infrastructure",criticality:"high",     compliance_scope:"",               fields:"[]" },
    { id:"zypp-redis",        type:"Cache",    name:"Redis Cache",            intent:"Caching session tokens, real-time vehicle locations, rate limit counters",           owner:"Platform Team",     team:"Infrastructure",criticality:"high",     compliance_scope:"",               fields:"[]" },

    // External
    { id:"zypp-razorpay",     type:"External", name:"Razorpay",               intent:"Payment gateway for UPI, cards, wallets. PCI-DSS certified processor",              owner:"Finance Team",      team:"Finance",       criticality:"high",     compliance_scope:"pci",            fields:"[]" },
    { id:"zypp-twilio",       type:"External", name:"Twilio / SMS",           intent:"SMS gateway for OTP delivery and trip notifications to riders and partners",        owner:"Platform Team",     team:"Infrastructure",criticality:"medium",   compliance_scope:"",               fields:"[]" },
    { id:"zypp-googlemaps",   type:"External", name:"Google Maps API",        intent:"Route planning, geocoding, ETA calculation for trip navigation",                    owner:"Rider Team",        team:"Consumer",      criticality:"high",     compliance_scope:"",               fields:"[]" },
    { id:"zypp-monitoring",   type:"Monitoring",name:"Monitoring (Datadog)",  intent:"Real-time monitoring, APM, alerts for all services and IoT data pipeline",         owner:"SRE Team",          team:"Infrastructure",criticality:"high",     compliance_scope:"rbi,soc2",       fields:"[]" },
  ],
  edges: [
    // ✅ Correct flows
    { source:"zypp-rider-app",      target:"zypp-api-gateway" },
    { source:"zypp-partner-app",    target:"zypp-api-gateway" },
    { source:"zypp-fleet-portal",   target:"zypp-api-gateway" },
    { source:"zypp-api-gateway",    target:"zypp-auth-svc" },
    { source:"zypp-api-gateway",    target:"zypp-fleet-svc" },
    { source:"zypp-api-gateway",    target:"zypp-trip-svc" },
    { source:"zypp-api-gateway",    target:"zypp-payment-svc" },
    { source:"zypp-auth-svc",       target:"zypp-redis" },
    { source:"zypp-auth-svc",       target:"zypp-user-db" },
    { source:"zypp-fleet-svc",      target:"zypp-fleet-db" },
    { source:"zypp-trip-svc",       target:"zypp-trip-db" },
    { source:"zypp-trip-svc",       target:"zypp-kafka" },
    { source:"zypp-payment-svc",    target:"zypp-payment-db" },
    { source:"zypp-payment-svc",    target:"zypp-razorpay" },
    { source:"zypp-payment-svc",    target:"zypp-kafka" },
    { source:"zypp-kafka",          target:"zypp-notif-svc" },
    { source:"zypp-kafka",          target:"zypp-analytics-svc" },
    { source:"zypp-kafka",          target:"zypp-telematics-svc" },
    { source:"zypp-notif-svc",      target:"zypp-twilio" },
    { source:"zypp-telematics-svc", target:"zypp-telemetry-db" },
    { source:"zypp-analytics-svc",  target:"zypp-trip-db" },
    { source:"zypp-trip-svc",       target:"zypp-googlemaps" },
    { source:"zypp-fleet-svc",      target:"zypp-monitoring" },
    { source:"zypp-iot-gateway",    target:"zypp-kafka" },

    // ❌ VIOLATIONS — CodeGPO will catch these
    { source:"zypp-ev-vehicle",     target:"zypp-fleet-db" },       // CRITICAL: GOV-003 IoT → DB directly
    { source:"zypp-gps-tracker",    target:"zypp-telemetry-db" },   // CRITICAL: GOV-003 IoT → DB directly
    { source:"zypp-admin",          target:"zypp-user-db" },        // MEDIUM: GOV-027 Admin → DB no service
    { source:"zypp-rider-app",      target:"zypp-redis" },          // MEDIUM: GOV-023 Client → Cache
  ]
};

// ════════════════════════════════════════════════════════════════
// SEED 3 — ZOPPER
// InsurTech | Digital Insurance Distribution | India
// ════════════════════════════════════════════════════════════════
export const ZOPPER_SEED = {
  nodes: [
    // Frontends
    { id:"zop-customer-portal", type:"Frontend", name:"Customer Portal",         intent:"Web portal for customers to compare, buy and manage insurance policies",              owner:"Customer Team",   team:"Consumer",      criticality:"high",     compliance_scope:"dpdp,gdpr",      fields:"[]" },
    { id:"zop-agent-app",       type:"Mobile",   name:"Agent Mobile App",         intent:"App for insurance agents to sell policies, submit claims, manage client portfolio",   owner:"Distribution",    team:"Sales",         criticality:"high",     compliance_scope:"dpdp",           fields:"[]" },
    { id:"zop-admin",           type:"Admin",    name:"Ops Admin Dashboard",      intent:"Internal dashboard for policy ops, claims management, partner management",            owner:"Ops Team",        team:"Operations",    criticality:"critical", compliance_scope:"dpdp,rbi",       fields:"[]" },

    // Gateway & Auth
    { id:"zop-api-gateway",     type:"Gateway",  name:"API Gateway",              intent:"Kong gateway handling auth, rate limiting, SSL termination for all traffic",         owner:"Platform Team",   team:"Infrastructure",criticality:"critical", compliance_scope:"soc2,rbi",       fields:"[]" },
    { id:"zop-auth-svc",        type:"Auth",     name:"Auth Service",             intent:"JWT auth, OTP verification for customers and agents, role-based access control",    owner:"Security Team",   team:"Security",      criticality:"critical", compliance_scope:"soc2,dpdp",      fields:"[]" },

    // Services
    { id:"zop-policy-svc",      type:"Service",  name:"Policy Management Service",intent:"Core service for policy issuance, renewal, endorsements and cancellations",         owner:"Policy Team",     team:"Insurance",     criticality:"critical", compliance_scope:"dpdp,rbi",       fields:"[]" },
    { id:"zop-claims-svc",      type:"Service",  name:"Claims Processing Service",intent:"Manages FNOL, claims assessment, surveyor assignment, settlement processing",        owner:"Claims Team",     team:"Insurance",     criticality:"critical", compliance_scope:"dpdp,rbi",       fields:"[]" },
    { id:"zop-premium-svc",     type:"Service",  name:"Premium Calculator",       intent:"Risk-based premium calculation engine using actuarial models and insurer APIs",      owner:"Actuarial Team",  team:"Insurance",     criticality:"high",     compliance_scope:"",               fields:"[]" },
    { id:"zop-kyc-svc",         type:"Service",  name:"KYC Service",              intent:"eKYC via Aadhaar/DigiLocker, document verification, identity validation",           owner:"Compliance Team", team:"Compliance",    criticality:"critical", compliance_scope:"dpdp,rbi",       fields:"[]" },
    { id:"zop-doc-svc",         type:"Service",  name:"Document Service",         intent:"Manages policy documents, claims photos, ID proofs with secure access control",     owner:"Platform Team",   team:"Infrastructure",criticality:"high",     compliance_scope:"dpdp",           fields:"[]" },
    { id:"zop-notif-svc",       type:"Service",  name:"Notification Service",     intent:"Policy renewal reminders, claims status updates, payment confirmations via SMS/email",owner:"Platform Team",  team:"Infrastructure",criticality:"medium",   compliance_scope:"dpdp",           fields:"[]" },
    { id:"zop-payment-svc",     type:"Service",  name:"Payment Service",          intent:"Premium collection via UPI, cards, net banking. Partner commission settlement",     owner:"Finance Team",    team:"Finance",       criticality:"critical", compliance_scope:"pci,rbi,dpdp",   fields:"[]" },
    { id:"zop-reporting-svc",   type:"Service",  name:"IRDAI Reporting Service",  intent:"Generates and submits mandatory regulatory reports to IRDAI portal",               owner:"Compliance Team", team:"Compliance",    criticality:"critical", compliance_scope:"rbi",            fields:"[]" },

    // Databases
    { id:"zop-customer-db",     type:"Database", name:"Customer DB",              intent:"PostgreSQL storing customer PII — Aadhaar ref, PAN, address, health data for KYC", owner:"Identity Team",   team:"Data",          criticality:"critical", compliance_scope:"dpdp,gdpr,rbi",  fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"phone",type:"string",required:true},{name:"email",type:"email",required:false},{name:"full_name",type:"string",required:true},{name:"dob",type:"date",required:true},{name:"pan_ref",type:"string",required:false},{name:"aadhaar_ref",type:"string",required:false},{name:"dpdp_consent",type:"boolean",required:true},{name:"created_at",type:"datetime",required:true}]) },
    { id:"zop-policy-db",       type:"Database", name:"Policy DB",                intent:"PostgreSQL storing policy master — coverage, premium, term, nominee, endorsements",  owner:"Policy Team",     team:"Data",          criticality:"critical", compliance_scope:"dpdp,rbi",       fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"policy_no",type:"string",required:true},{name:"customer_id",type:"uuid",required:true},{name:"insurer_code",type:"string",required:true},{name:"product_code",type:"string",required:true},{name:"premium",type:"decimal",required:true},{name:"sum_insured",type:"decimal",required:true},{name:"start_date",type:"date",required:true},{name:"end_date",type:"date",required:true},{name:"status",type:"string",required:true}]) },
    { id:"zop-claims-db",       type:"Database", name:"Claims DB",                intent:"PostgreSQL storing claims — FNOL, surveyor notes, medical docs, settlement amounts", owner:"Claims Team",     team:"Data",          criticality:"critical", compliance_scope:"dpdp,rbi",       fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"policy_id",type:"uuid",required:true},{name:"claim_type",type:"string",required:true},{name:"amount_claimed",type:"decimal",required:true},{name:"amount_settled",type:"decimal",required:false},{name:"status",type:"string",required:true},{name:"surveyor_id",type:"uuid",required:false},{name:"created_at",type:"datetime",required:true}]) },
    { id:"zop-payment-db",      type:"Database", name:"Payment DB",               intent:"PostgreSQL storing premium transactions, UPI refs, commission payouts, ledger",      owner:"Finance Team",    team:"Data",          criticality:"critical", compliance_scope:"pci,rbi,dpdp",   fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"policy_id",type:"uuid",required:true},{name:"amount",type:"decimal",required:true},{name:"mode",type:"string",required:true},{name:"gateway_ref",type:"string",required:true},{name:"status",type:"string",required:true},{name:"created_at",type:"datetime",required:true}]) },

    // Queue & Cache
    { id:"zop-rabbit",          type:"Queue",    name:"RabbitMQ",                 intent:"Async messaging for claims events, renewal reminders, notification triggering",     owner:"Platform Team",   team:"Infrastructure",criticality:"high",     compliance_scope:"",               fields:"[]" },
    { id:"zop-redis",           type:"Cache",    name:"Redis Cache",              intent:"Session cache, premium quote cache, OTP store with TTL",                            owner:"Platform Team",   team:"Infrastructure",criticality:"high",     compliance_scope:"",               fields:"[]" },

    // External
    { id:"zop-razorpay",        type:"External", name:"Razorpay",                 intent:"PCI-DSS certified payment gateway for premium collection",                         owner:"Finance Team",    team:"Finance",       criticality:"high",     compliance_scope:"pci",            fields:"[]" },
    { id:"zop-insurer-api",     type:"External", name:"Insurer Partner APIs",     intent:"HDFC Ergo, Bajaj Allianz, Star Health APIs for policy issuance and claims",       owner:"Partnerships",    team:"Insurance",     criticality:"high",     compliance_scope:"rbi",            fields:"[]" },
    { id:"zop-digilocker",      type:"External", name:"DigiLocker / NSDL",        intent:"Govt eKYC APIs for Aadhaar verification, PAN validation, DigiLocker docs",        owner:"Compliance Team", team:"Compliance",    criticality:"high",     compliance_scope:"dpdp,rbi",       fields:"[]" },
    { id:"zop-twilio",          type:"External", name:"Twilio SMS",               intent:"OTP delivery, claims alerts and renewal reminders to customers",                   owner:"Platform Team",   team:"Infrastructure",criticality:"medium",   compliance_scope:"",               fields:"[]" },
    { id:"zop-s3",              type:"External", name:"AWS S3",                   intent:"Secure document storage for policy PDFs, claims evidence, KYC documents",         owner:"Platform Team",   team:"Infrastructure",criticality:"high",     compliance_scope:"dpdp",           fields:"[]" },
    { id:"zop-monitoring",      type:"Monitoring",name:"Monitoring (Datadog)",    intent:"APM, real-time alerts, IRDAI audit trail and SLA monitoring",                      owner:"SRE Team",        team:"Infrastructure",criticality:"high",     compliance_scope:"rbi,soc2",       fields:"[]" },
  ],
  edges: [
    // ✅ Correct flows
    { source:"zop-customer-portal", target:"zop-api-gateway" },
    { source:"zop-agent-app",       target:"zop-api-gateway" },
    { source:"zop-api-gateway",     target:"zop-auth-svc" },
    { source:"zop-api-gateway",     target:"zop-policy-svc" },
    { source:"zop-api-gateway",     target:"zop-claims-svc" },
    { source:"zop-api-gateway",     target:"zop-payment-svc" },
    { source:"zop-api-gateway",     target:"zop-kyc-svc" },
    { source:"zop-auth-svc",        target:"zop-redis" },
    { source:"zop-auth-svc",        target:"zop-customer-db" },
    { source:"zop-policy-svc",      target:"zop-policy-db" },
    { source:"zop-policy-svc",      target:"zop-premium-svc" },
    { source:"zop-policy-svc",      target:"zop-insurer-api" },
    { source:"zop-policy-svc",      target:"zop-rabbit" },
    { source:"zop-claims-svc",      target:"zop-claims-db" },
    { source:"zop-claims-svc",      target:"zop-doc-svc" },
    { source:"zop-claims-svc",      target:"zop-rabbit" },
    { source:"zop-kyc-svc",         target:"zop-digilocker" },
    { source:"zop-kyc-svc",         target:"zop-customer-db" },
    { source:"zop-doc-svc",         target:"zop-s3" },
    { source:"zop-payment-svc",     target:"zop-payment-db" },
    { source:"zop-payment-svc",     target:"zop-razorpay" },
    { source:"zop-payment-svc",     target:"zop-rabbit" },
    { source:"zop-rabbit",          target:"zop-notif-svc" },
    { source:"zop-notif-svc",       target:"zop-twilio" },
    { source:"zop-reporting-svc",   target:"zop-policy-db" },
    { source:"zop-policy-svc",      target:"zop-monitoring" },

    // ❌ VIOLATIONS — CodeGPO will catch these
    { source:"zop-customer-portal", target:"zop-customer-db" },  // CRITICAL: GOV-001 Client → DB
    { source:"zop-insurer-api",     target:"zop-claims-svc" },   // HIGH: GOV-011 External → Service no gateway
    { source:"zop-admin",           target:"zop-claims-db" },    // MEDIUM: GOV-027 Admin → DB no service
  ]
};

// ════════════════════════════════════════════════════════════════
// SEED 4 — SPYNE.AI
// AI-Powered Automotive Image Processing | Computer Vision
// ════════════════════════════════════════════════════════════════
export const SPYNE_SEED = {
  nodes: [
    // Frontends
    { id:"spy-web-app",        type:"Frontend", name:"Web Dashboard",           intent:"React dashboard for dealerships to upload car photos and manage catalogues",          owner:"Product Team",    team:"Consumer",      criticality:"high",     compliance_scope:"gdpr,dpdp",      fields:"[]" },
    { id:"spy-mobile-sdk",     type:"Mobile",   name:"Mobile SDK",              intent:"iOS/Android SDK for dealers to capture standardized car photos in-dealership",       owner:"SDK Team",        team:"Consumer",      criticality:"high",     compliance_scope:"",               fields:"[]" },
    { id:"spy-admin",          type:"Admin",    name:"Admin Panel",             intent:"Internal tool for managing customer accounts, AI model versions, billing",           owner:"Ops Team",        team:"Operations",    criticality:"high",     compliance_scope:"",               fields:"[]" },

    // Gateway & Auth
    { id:"spy-api-gateway",    type:"Gateway",  name:"API Gateway (Kong)",      intent:"Kong gateway for auth, rate limiting, request routing and SSL termination",         owner:"Platform Team",   team:"Infrastructure",criticality:"critical", compliance_scope:"soc2",           fields:"[]" },
    { id:"spy-auth-svc",       type:"Auth",     name:"Auth Service",            intent:"JWT auth, API key management for dealer integrations, OAuth for enterprise SSO",    owner:"Security Team",   team:"Security",      criticality:"critical", compliance_scope:"soc2,gdpr",      fields:"[]" },

    // Services
    { id:"spy-image-api",      type:"Service",  name:"Image Processing API",    intent:"Accepts image uploads, validates quality, orchestrates AI pipeline processing",     owner:"Core Team",       team:"AI",            criticality:"critical", compliance_scope:"",               fields:"[]" },
    { id:"spy-ai-svc",         type:"Service",  name:"AI Inference Service",    intent:"Runs computer vision models — background removal, angle detection, quality scoring",owner:"AI Team",         team:"AI",            criticality:"critical", compliance_scope:"",               fields:"[]" },
    { id:"spy-catalogue-svc",  type:"Service",  name:"Catalogue Service",       intent:"Manages vehicle listings, processed image sets, publishing to dealer platforms",    owner:"Product Team",    team:"Product",       criticality:"high",     compliance_scope:"gdpr",           fields:"[]" },
    { id:"spy-dealer-svc",     type:"Service",  name:"Dealer Management API",   intent:"Manages dealership accounts, subscriptions, usage limits and billing",             owner:"Sales Team",      team:"Growth",        criticality:"high",     compliance_scope:"gdpr,dpdp",      fields:"[]" },
    { id:"spy-billing-svc",    type:"Service",  name:"Billing Service",         intent:"Usage-based billing, invoice generation, Stripe subscription management",          owner:"Finance Team",    team:"Finance",       criticality:"high",     compliance_scope:"pci",            fields:"[]" },
    { id:"spy-notif-svc",      type:"Service",  name:"Notification Service",    intent:"Processing complete webhooks, email notifications, Slack alerts to dealers",       owner:"Platform Team",   team:"Infrastructure",criticality:"medium",   compliance_scope:"",               fields:"[]" },

    // AI Workers
    { id:"spy-bg-worker",      type:"Worker",   name:"Background Removal Worker",intent:"GPU-powered worker removing backgrounds and generating studio-quality white bg",  owner:"AI Team",         team:"AI",            criticality:"high",     compliance_scope:"",               fields:"[]" },
    { id:"spy-enhance-worker", type:"Worker",   name:"Image Enhancement Worker",intent:"Worker applying colour correction, sharpening, standardized angles per vehicle type",owner:"AI Team",       team:"AI",            criticality:"high",     compliance_scope:"",               fields:"[]" },
    { id:"spy-360-worker",     type:"Worker",   name:"360° Spin Generator",     intent:"Stitches multi-angle images into interactive 360° vehicle spin for web/apps",      owner:"AI Team",         team:"AI",            criticality:"medium",   compliance_scope:"",               fields:"[]" },

    // Databases
    { id:"spy-dealer-db",      type:"Database", name:"Dealer DB",               intent:"PostgreSQL storing dealership profiles, subscription plans, API keys and contacts", owner:"Sales Team",      team:"Data",          criticality:"high",     compliance_scope:"gdpr,dpdp",      fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"company_name",type:"string",required:true},{name:"contact_email",type:"email",required:true},{name:"plan",type:"string",required:true},{name:"api_key_hash",type:"string",required:true},{name:"gdpr_consent",type:"boolean",required:true},{name:"created_at",type:"datetime",required:true}]) },
    { id:"spy-image-db",       type:"Database", name:"Image & Job DB",          intent:"PostgreSQL storing image metadata, processing job status, output URLs, quality scores",owner:"Core Team",    team:"Data",          criticality:"high",     compliance_scope:"",               fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"dealer_id",type:"uuid",required:true},{name:"vehicle_id",type:"string",required:true},{name:"input_url",type:"string",required:true},{name:"output_url",type:"string",required:false},{name:"status",type:"string",required:true},{name:"quality_score",type:"decimal",required:false},{name:"created_at",type:"datetime",required:true}]) },
    { id:"spy-model-db",       type:"Database", name:"AI Model Registry",       intent:"PostgreSQL storing model versions, performance metrics, deployment configs",        owner:"ML Ops Team",    team:"AI",            criticality:"high",     compliance_scope:"",               fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"model_name",type:"string",required:true},{name:"version",type:"string",required:true},{name:"accuracy",type:"decimal",required:true},{name:"deployed_at",type:"datetime",required:false},{name:"status",type:"string",required:true}]) },
    { id:"spy-billing-db",     type:"Database", name:"Billing DB",              intent:"PostgreSQL storing invoices, usage records, Stripe subscription IDs, payment history",owner:"Finance Team",  team:"Data",          criticality:"high",     compliance_scope:"pci,gdpr",       fields:JSON.stringify([{name:"id",type:"uuid",required:true,primary:true},{name:"dealer_id",type:"uuid",required:true},{name:"amount",type:"decimal",required:true},{name:"images_processed",type:"integer",required:true},{name:"stripe_invoice_id",type:"string",required:true},{name:"status",type:"string",required:true},{name:"created_at",type:"datetime",required:true}]) },

    // Queue & Cache
    { id:"spy-sqs",            type:"Queue",    name:"AWS SQS",                 intent:"Job queue for distributing image processing tasks to GPU worker fleet",            owner:"Platform Team",   team:"Infrastructure",criticality:"high",     compliance_scope:"",               fields:"[]" },
    { id:"spy-redis",          type:"Cache",    name:"Redis Cache",             intent:"Job status cache, session tokens, rate limit counters per API key",               owner:"Platform Team",   team:"Infrastructure",criticality:"high",     compliance_scope:"",               fields:"[]" },

    // External
    { id:"spy-s3",             type:"External", name:"AWS S3",                  intent:"Object storage for original and processed vehicle images, CDN origin",            owner:"Platform Team",   team:"Infrastructure",criticality:"high",     compliance_scope:"",               fields:"[]" },
    { id:"spy-cloudfront",     type:"External", name:"AWS CloudFront CDN",      intent:"CDN delivering processed images to dealer websites and apps at low latency",      owner:"Platform Team",   team:"Infrastructure",criticality:"high",     compliance_scope:"",               fields:"[]" },
    { id:"spy-stripe",         type:"External", name:"Stripe",                  intent:"Subscription billing and usage-based payment processing for SaaS plans",         owner:"Finance Team",    team:"Finance",       criticality:"high",     compliance_scope:"pci",            fields:"[]" },
    { id:"spy-dealer-portals", type:"External", name:"Dealer Platform APIs",    intent:"CarDekho, Cars24, OLX Autos APIs for automatic catalogue syndication",           owner:"Partnerships",    team:"Growth",        criticality:"medium",   compliance_scope:"",               fields:"[]" },
    { id:"spy-monitoring",     type:"Monitoring",name:"Monitoring (Grafana)",   intent:"GPU utilisation, processing pipeline metrics, SLA tracking, cost monitoring",    owner:"SRE Team",        team:"Infrastructure",criticality:"high",     compliance_scope:"soc2",           fields:"[]" },
  ],
  edges: [
    // ✅ Correct flows
    { source:"spy-web-app",       target:"spy-api-gateway" },
    { source:"spy-mobile-sdk",    target:"spy-api-gateway" },
    { source:"spy-api-gateway",   target:"spy-auth-svc" },
    { source:"spy-api-gateway",   target:"spy-image-api" },
    { source:"spy-api-gateway",   target:"spy-catalogue-svc" },
    { source:"spy-api-gateway",   target:"spy-dealer-svc" },
    { source:"spy-api-gateway",   target:"spy-billing-svc" },
    { source:"spy-auth-svc",      target:"spy-redis" },
    { source:"spy-auth-svc",      target:"spy-dealer-db" },
    { source:"spy-image-api",     target:"spy-image-db" },
    { source:"spy-image-api",     target:"spy-sqs" },
    { source:"spy-image-api",     target:"spy-s3" },
    { source:"spy-sqs",           target:"spy-bg-worker" },
    { source:"spy-sqs",           target:"spy-enhance-worker" },
    { source:"spy-sqs",           target:"spy-360-worker" },
    { source:"spy-bg-worker",     target:"spy-ai-svc" },
    { source:"spy-enhance-worker",target:"spy-ai-svc" },
    { source:"spy-360-worker",    target:"spy-ai-svc" },
    { source:"spy-ai-svc",        target:"spy-model-db" },
    { source:"spy-ai-svc",        target:"spy-s3" },
    { source:"spy-catalogue-svc", target:"spy-image-db" },
    { source:"spy-catalogue-svc", target:"spy-dealer-portals" },
    { source:"spy-dealer-svc",    target:"spy-dealer-db" },
    { source:"spy-billing-svc",   target:"spy-billing-db" },
    { source:"spy-billing-svc",   target:"spy-stripe" },
    { source:"spy-s3",            target:"spy-cloudfront" },
    { source:"spy-image-api",     target:"spy-notif-svc" },
    { source:"spy-ai-svc",        target:"spy-monitoring" },

    // ❌ VIOLATIONS — CodeGPO will catch these
    { source:"spy-web-app",       target:"spy-image-db" },   // CRITICAL: GOV-001 Client → DB
    { source:"spy-mobile-sdk",    target:"spy-ai-svc" },     // HIGH: GOV-011 Client calling internal service without gateway
    { source:"spy-admin",         target:"spy-dealer-db" },  // MEDIUM: GOV-027 Admin → DB no audit service
  ]
};

// ════════════════════════════════════════════════════════════════
// TEMPLATE REGISTRY — used by TemplateGallery
// ════════════════════════════════════════════════════════════════
export const DEMO_TEMPLATES = [
  {
    id: "fintech",
    name: "Fintech Platform",
    description: "Payment processing, ledger, KYC, GDPR/SOC2/PCI-DSS compliant",
    icon: "💳",
    tags: ["Payments", "GDPR", "SOC2", "PCI-DSS"],
    nodeCount: 16,
    seed: DEMO_SEED,
  },
  {
    id: "zypp",
    name: "EV Fleet Platform",
    description: "IoT telematics, GPS fleet management, UPI payments, DPDP/RBI compliant",
    icon: "⚡",
    tags: ["IoT", "Fleet", "DPDP", "RBI", "Payments"],
    nodeCount: 23,
    seed: ZYPP_SEED,
  },
  {
    id: "zopper",
    name: "InsurTech Platform",
    description: "Policy management, claims processing, KYC, IRDAI/RBI/DPDP compliant",
    icon: "🛡️",
    tags: ["Insurance", "DPDP", "RBI", "KYC", "PCI-DSS"],
    nodeCount: 22,
    seed: ZOPPER_SEED,
  },
  {
    id: "spyne",
    name: "AI Vision SaaS",
    description: "Computer vision pipeline, GPU workers, usage-based billing, GDPR compliant",
    icon: "🤖",
    tags: ["AI/ML", "SaaS", "GDPR", "Computer Vision"],
    nodeCount: 24,
    seed: SPYNE_SEED,
  },
];

export function loadDemoSeed(setGraph) {
  setGraph(DEMO_SEED.nodes, DEMO_SEED.edges);
}

export function loadTemplateSeed(setGraph, templateId) {
  const template = DEMO_TEMPLATES.find(t => t.id === templateId);
  if (template?.seed) {
    setGraph(template.seed.nodes, template.seed.edges);
  }
}
