import { useState } from "react";
import { useGraphStore } from "../state/graphStore";

export default function NodeToolbar() {
  const addNode = useGraphStore((s) => s.addNode);
  const [name, setName] = useState("");

  const handleAdd = () => {
    if (!name.trim()) return;
    addNode(name.trim());
    setName("");
  };

  return (
    <div className="toolbar">
      <h3>Architecture</h3>

      <input
        placeholder="Node name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <button onClick={handleAdd}>＋ Add Node</button>
    </div>
  );
}
