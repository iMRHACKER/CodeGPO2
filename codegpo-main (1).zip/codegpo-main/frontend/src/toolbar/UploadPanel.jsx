import { useRef, useState } from "react";
import { useGraphStore } from "../state/graphStore";
import { useAuditStore, ACTION_TYPES } from "../state/auditStore";
import { scanZip, parsePackageJson, parseRequirements, scanGitHub, parseOpenAPI, parseTerraform, parseK8s } from "../api/projectScanner";

export default function UploadPanel() {
  const { setGraph } = useGraphStore();
  const { record } = useAuditStore();
  const fileRef = useRef(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [githubUrl, setGithubUrl] = useState("");
  const [showGithub, setShowGithub] = useState(false);

  const handleFile = async (file) => {
    setLoading(true);
    setError("");
    try {
      let result;
      const name = file.name.toLowerCase();
      const text = await file.text();

      if (name.endsWith(".zip")) {
        result = await scanZip(file);
      } else if (name === "package.json") {
        result = parsePackageJson(text, "project");
      } else if (name.includes("requirements")) {
        result = parseRequirements(text, "project");
      } else if (name.endsWith(".yaml") || name.endsWith(".yml")) {
        // Detect OpenAPI vs K8s
        if (text.includes("openapi:") || text.includes("swagger:") || text.includes("paths:")) {
          result = parseOpenAPI(text, file.name);
        } else if (text.includes("kind:") || text.includes("apiVersion:")) {
          result = parseK8s(text);
        } else {
          throw new Error("YAML file not recognized. Supports OpenAPI/Swagger and Kubernetes YAML.");
        }
      } else if (name.endsWith(".json")) {
        const parsed = JSON.parse(text);
        if (parsed.openapi || parsed.swagger || parsed.paths) {
          result = parseOpenAPI(text, file.name);
        } else {
          throw new Error("JSON file not recognized. Supports OpenAPI/Swagger JSON.");
        }
      } else if (name.endsWith(".tf")) {
        result = parseTerraform(text, file.name);
      } else {
        throw new Error("Supported: .zip, package.json, requirements.txt, openapi.yaml, openapi.json, k8s.yaml, main.tf");
      }

      if (result.nodes.length === 0) throw new Error("No components detected.");
      setGraph(result.nodes, result.edges);
      record(ACTION_TYPES.SCAN_COMPLETED, `${file.name} → ${result.nodes.length} components`);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleGitHub = async () => {
    if (!githubUrl.trim()) return;
    setLoading(true);
    setError("");
    try {
      const result = await scanGitHub(githubUrl.trim());
      if (result.nodes.length === 0) throw new Error("No components detected.");
      setGraph(result.nodes, result.edges);
      const note = result.inferred ? " (inferred from repo name — edit nodes to refine)" : "";
      record(ACTION_TYPES.SCAN_COMPLETED, `GitHub: ${githubUrl} → ${result.nodes.length} components${note}`);
      if (result.inferred) {
        setError(`Loaded ${result.nodes.length} inferred components from repo name. The repo has no detectable config files — edit the nodes to match your actual architecture.`);
      } else {
        setGithubUrl("");
        setShowGithub(false);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
      <input
        ref={fileRef}
        type="file"
        accept=".zip,application/json,.txt"
        style={{ display: "none" }}
        onChange={e => e.target.files[0] && handleFile(e.target.files[0])}
      />
      <button
        onClick={() => fileRef.current.click()}
        disabled={loading}
        className="toolbar-btn"
      >
        {loading ? "Scanning..." : "↑ Upload ZIP / File"}
      </button>
      <button
        onClick={() => setShowGithub(!showGithub)}
        disabled={loading}
      >
        ⌥ GitHub Repo URL
      </button>

      {showGithub && (
        <div style={{ display: "flex", flexDirection: "column", gap: "4px", padding: "4px 0" }}>
          <input
            value={githubUrl}
            onChange={e => setGithubUrl(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleGitHub()}
            placeholder="https://github.com/user/repo"
            style={{
              padding: "7px 10px",
              background: "#0d0d1f",
              border: "1px solid #22224a",
              color: "#ccc",
              fontSize: "11px",
              borderRadius: "6px",
              outline: "none"
            }}
          />
          <button onClick={handleGitHub} disabled={loading || !githubUrl.trim()}>
            {loading ? "Fetching..." : "Scan Repo"}
          </button>
        </div>
      )}

      {error && (
        <div style={{
          fontSize: "11px", color: "#7a3535",
          padding: "6px 10px",
          background: "#1a1010",
          border: "1px solid #2a1515",
          borderRadius: "6px",
          marginTop: "2px"
        }}>
          {error}
        </div>
      )}
    </div>
  );
}
